"""Permis détaillés : liste des autorisations d'urbanisme (base Sitadel, SDES).

Jeu DiDo « Liste des permis de construire et autres autorisations
d'urbanisme » (identifiant 6513f0189d7d312c80ec5b5b), un fichier par type :
- PC et DP créant des logements ;
- permis d'aménager (lotissements notamment) ;
- permis de démolir ;
(le fichier des locaux non résidentiels n'est pas utilisé).

Les fichiers sont reconnus par leur titre, les colonnes par leur nom
(COMM, Num_DAU, Etat_DAU, DATE_REELLE_AUTORISATION, NB_LGT_TOT_CREES...)
avec repli par mots-clés : un renommage par le SDES est signalé par le
bouton « Diagnostic » au lieu de faire échouer l'extraction.

Le filtre par commune est appliqué par le serveur (COMM=in:...), le filtre
par année localement. Le code commune est celui du dépôt : un permis déposé
sous l'ancien code d'une commune fusionnée n'est pas retrouvé.
"""
import re
from datetime import date

from . import cadastre, dido, reseau

ID_JEU = "6513f0189d7d312c80ec5b5b"

TYPES = [("logements", "Logements (PC et DP)"), ("amenager", "Permis d'aménager"),
         ("demolir", "Permis de démolir")]
LIB_TYPE = dict(TYPES)

ETATS = {"2": "Autorisé", "4": "Annulé", "5": "Commencé", "6": "Terminé"}
CAT_DEM = {"10": "Particulier", "11": "Particulier", "12": "SCI de particuliers",
           "20": "Bailleur social", "21": "Organisme HLM", "22": "EPL (ex SEM)", "23": "Bailleur social",
           "30": "Promoteur", "31": "Promoteur", "32": "SCI ou support de programme", "33": "Professionnel de la construction",
           "40": "Administration publique", "41": "État", "42": "Département ou région",
           "43": "Commune ou intercommunalité", "50": "Autre société", "80": "Sans objet", "90": "Non déterminé"}
GROUPE_DEM = {"1": "Particuliers", "2": "Bailleurs sociaux", "3": "Promoteurs et professionnels",
              "4": "Collectivités et État", "5": "Autres sociétés", "8": "Non déterminé", "9": "Non déterminé"}
VALIDITE_ANS = 3      # durée de validité d'une autorisation (hors prorogation)


# ------------------------------------------------------------------ fichiers du jeu
def classer_fichiers(jeu):
    """{'logements'|'amenager'|'demolir': {rid, titre, millesime, colonnes, embargo, filtres}}."""
    resultat = {}
    for df in jeu.get("datafiles", []):
        titre = dido.normaliser(df.get("title", "") + " " + df.get("description", ""))
        if "demol" in titre:
            cle = "demolir"
        elif "amenag" in titre:
            cle = "amenager"
        elif "locaux" in titre and "logement" not in dido.normaliser(df.get("title", "")):
            continue
        elif "logement" in titre:
            cle = "logements"
        else:
            continue
        mill, colonnes, embargo = dido.millesime_utilisable(df)
        if cle in resultat and str(resultat[cle]["millesime"] or "") >= str(mill or ""):
            continue
        col_comm = _colonne(colonnes, "COMM", "CODE_COMMUNE", "COM", motif=r"^comm?$|commune")
        resultat[cle] = {"rid": df["rid"], "titre": df.get("title", ""), "millesime": mill,
                         "colonnes": colonnes, "embargo": embargo,
                         "col_commune": col_comm["name"] if col_comm else "COMM",
                         "filtres": (col_comm or {}).get("filters") or ["in", "eq"]}
    return resultat


def _colonne(colonnes, *noms, motif=None):
    par_nom = {str(c.get("name", "")).upper(): c for c in colonnes}
    for n in noms:
        if n.upper() in par_nom:
            return par_nom[n.upper()]
    if motif:
        for c in colonnes:
            if re.search(motif, str(c.get("name", "")), re.I):
                return c
    return None


# ------------------------------------------------------------------ lecture d'une ligne
class Ligne:
    """Accès tolérant aux colonnes d'une ligne CSV (noms insensibles à la casse)."""

    def __init__(self, entetes):
        self.idx = {h.upper(): i for i, h in enumerate(entetes)}
        self.entetes = entetes

    def trouver(self, *noms, motif=None):
        for n in noms:
            if n.upper() in self.idx:
                return self.idx[n.upper()]
        if motif:
            for h, i in self.idx.items():
                if re.search(motif, h, re.I):
                    return i
        return None


def _v(ligne, i):
    return ligne[i].strip() if i is not None and i < len(ligne) else ""


def _n(texte):
    t = str(texte or "").strip().replace(" ", "").replace(",", ".")
    try:
        return float(t) if t else None
    except ValueError:
        return None


def _date(texte):
    t = str(texte or "").strip()[:10]
    return t if re.match(r"^\d{4}-\d{2}-\d{2}$", t) else ""


def normaliser(type_permis, entetes, lignes):
    """Lignes brutes -> liste de permis (dicts homogènes) + dict des colonnes reconnues."""
    L = Ligne(entetes)
    c = {
        "commune": L.trouver("COMM", motif=r"^COMM"),
        "type_dau": L.trouver("TYPE_DAU", motif=r"^TYPE_?DAU"),
        "num": L.trouver("NUM_DAU", "NUM_PA", "NUM_PD", motif=r"^NUM_(DAU|PA|PD|PC)"),
        "etat": L.trouver("ETAT_DAU", motif=r"^ETAT"),
        "date_aut": L.trouver("DATE_REELLE_AUTORISATION", motif=r"DATE.*AUTORIS"),
        "date_doc": L.trouver("DATE_REELLE_DOC", motif=r"DATE.*DOC$"),
        "date_daact": L.trouver("DATE_REELLE_DAACT", motif=r"DATE.*DAACT"),
        "cat_dem": L.trouver("CAT_DEM"),
        "denom": L.trouver("DENOM_DEM"),
        "num_voie": L.trouver("ADR_NUM_TER"),
        "type_voie": L.trouver("ADR_TYPEVOIE_TER"),
        "voie": L.trouver("ADR_LIBVOIE_TER"),
        "lieudit": L.trouver("ADR_LIEUDIT_TER"),
        "superficie": L.trouver("SUPERFICIE_TERRAIN", motif=r"SUPERFICIE"),
        "lgt": L.trouver("NB_LGT_TOT_CREES"),
        "lgt_ind": L.trouver("NB_LGT_IND_CREES"),
        "lgt_col": L.trouver("NB_LGT_COL_CREES"),
        "lgt_dem": L.trouver("NB_LGT_DEMOLIS", motif=r"LGT.*DEMOL"),
        "surf_hab": L.trouver("SURF_HAB_CREEE"),
        "lots": L.trouver("NB_LOTS", motif=r"^NB_?LOTS?$|LOTS"),
        "nature": L.trouver("NATURE_PROJET", motif=r"^NATURE_PROJET"),
        "residence": L.trouver("RESIDENCE_SERVICE", motif=r"^RESIDENCE"),
    }
    parcelles = [(L.trouver(f"SEC_CADASTRE{k}"), L.trouver(f"NUM_CADASTRE{k}")) for k in (1, 2, 3)]
    permis = []
    for ligne in lignes:
        if len(ligne) < len(entetes) * 0.8:
            continue
        date_aut = _date(_v(ligne, c["date_aut"]))
        etat = _v(ligne, c["etat"])
        cat = _v(ligne, c["cat_dem"])
        adresse = " ".join(x for x in (_v(ligne, c["num_voie"]), _v(ligne, c["type_voie"]),
                                       _v(ligne, c["voie"])) if x)
        if not adresse:
            adresse = _v(ligne, c["lieudit"])
        p = {
            "theme": type_permis,
            "type_dau": _v(ligne, c["type_dau"]) or {"amenager": "PA", "demolir": "PD"}.get(type_permis, ""),
            "num": _v(ligne, c["num"]),
            "commune": _v(ligne, c["commune"]).zfill(5),
            "etat": ETATS.get(etat, etat or "?"),
            "etat_code": etat,
            "date_aut": date_aut,
            "annee": int(date_aut[:4]) if date_aut else None,
            "date_doc": _date(_v(ligne, c["date_doc"])),
            "date_daact": _date(_v(ligne, c["date_daact"])),
            "demandeur": CAT_DEM.get(cat, cat),
            "groupe_dem": GROUPE_DEM.get(cat[:1], "Non déterminé") if cat else "Non déterminé",
            "denomination": _v(ligne, c["denom"]),
            "adresse": adresse,
            "superficie": _n(_v(ligne, c["superficie"])),
            "logements": _n(_v(ligne, c["lgt"])),
            "lgt_ind": _n(_v(ligne, c["lgt_ind"])),
            "lgt_col": _n(_v(ligne, c["lgt_col"])),
            "lgt_demolis": _n(_v(ligne, c["lgt_dem"])),
            "surf_hab": _n(_v(ligne, c["surf_hab"])),
            "lots": _n(_v(ligne, c["lots"])),
            "nature": {"1": "Nouvelle construction", "2": "Travaux sur l'existant"}.get(
                _v(ligne, c["nature"]), _v(ligne, c["nature"])),
            "parcelles": [(_v(ligne, s), _v(ligne, n)) for s, n in parcelles if s is not None and _v(ligne, s)],
            "brut": ligne,
        }
        permis.append(p)
    reconnues = {k: (entetes[i] if i is not None else None) for k, i in c.items()}
    return permis, reconnues


# ------------------------------------------------------------------ indicateurs
def en_attente(p, aujourdhui=None):
    """Logements « à venir » : chantier ouvert non achevé, ou autorisation récente pas encore commencée."""
    if p["theme"] != "logements" or p["etat_code"] in ("4", "6"):
        return False
    if p["etat_code"] == "5" or p["date_doc"]:
        return not p["date_daact"]
    aujourdhui = aujourdhui or date.today()
    if p["date_aut"]:
        a, m, j = (int(x) for x in p["date_aut"].split("-"))
        return (aujourdhui - date(a, m, j)).days <= VALIDITE_ANS * 365
    return False


def _vide():
    return {"lgt_nb_permis": 0, "lgt_aut": 0.0, "lgt_ind": 0.0, "lgt_col": 0.0, "lgt_commences": 0.0,
            "lgt_termines": 0.0, "lgt_a_venir": 0.0, "surf_hab": 0.0, "lgt_annules": 0.0,
            "pa_nb": 0, "pa_superficie": 0.0, "pa_lots": 0.0, "pd_nb": 0, "pd_lgt_demolis": 0.0}


def _ajouter(s, p, aujourdhui):
    if p["theme"] == "logements":
        if p["etat_code"] == "4":
            s["lgt_annules"] += p["logements"] or 0
            return
        s["lgt_nb_permis"] += 1
        s["lgt_aut"] += p["logements"] or 0
        s["lgt_ind"] += p["lgt_ind"] or 0
        s["lgt_col"] += p["lgt_col"] or 0
        s["surf_hab"] += p["surf_hab"] or 0
        if p["etat_code"] in ("5", "6") or p["date_doc"]:
            s["lgt_commences"] += p["logements"] or 0
        if p["etat_code"] == "6" or p["date_daact"]:
            s["lgt_termines"] += p["logements"] or 0
        if en_attente(p, aujourdhui):
            s["lgt_a_venir"] += p["logements"] or 0
    elif p["etat_code"] != "4":
        if p["theme"] == "amenager":
            s["pa_nb"] += 1
            s["pa_superficie"] += (p["superficie"] or 0) / 10000
            s["pa_lots"] += p["lots"] or 0
        elif p["theme"] == "demolir":
            s["pd_nb"] += 1
            s["pd_lgt_demolis"] += p["lgt_demolis"] or 0


def synthese(permis, communes, codes, nom_epci, annees):
    """Tableaux par commune (+ Sélection, EPCI) et séries annuelles."""
    aujourdhui = date.today()
    noms = {c["code"]: c["nom"] for c in communes}
    par_commune = {code: _vide() for code in codes}
    par_annee = {a: {"logements": {"ind": 0.0, "col": 0.0, "autre": 0.0, "commences": 0.0},
                     "amenager": 0, "demolir": 0} for a in annees}
    total = _vide()
    for p in permis:
        if p["commune"] in par_commune:
            _ajouter(par_commune[p["commune"]], p, aujourdhui)
        _ajouter(total, p, aujourdhui)
        a = p["annee"]
        if a in par_annee and p["etat_code"] != "4":
            if p["theme"] == "logements":
                ind, col, tot = p["lgt_ind"] or 0, p["lgt_col"] or 0, p["logements"] or 0
                s = par_annee[a]["logements"]
                s["ind"] += ind
                s["col"] += col
                s["autre"] += max(0, tot - ind - col)
                if p["etat_code"] in ("5", "6") or p["date_doc"]:
                    s["commences"] += tot
            else:
                par_annee[a][p["theme"]] += 1
    lignes = [{"niveau": "Commune", "code": code, "nom": noms.get(code, code), **par_commune[code]}
              for code in sorted(codes, key=lambda c: noms.get(c, c))]
    niveau_total = "EPCI" if len(codes) == len(communes) else "Sélection"
    nom_total = nom_epci if niveau_total == "EPCI" else f"Sélection ({len(codes)} communes)"
    if len(codes) > 1:
        lignes.append({"niveau": niveau_total, "code": "TOTAL", "nom": nom_total, **total})
    return {"lignes": lignes, "par_annee": par_annee, "total": total, "nom_total": nom_total if len(codes) > 1
            else lignes[0]["nom"]}


# ------------------------------------------------------------------ extraction
def extraire(communes, codes, nom_epci, types, annee_min, annee_max, localiser=True,
             stop_event=None, journal=print):
    jeu = dido.metadonnees(ID_JEU, stop_event)
    fichiers = classer_fichiers(jeu)
    journal(f"   jeu SDES : « {jeu.get('title', ID_JEU)} »")
    permis, colonnes, millesimes, bruts = [], {}, {}, {}
    part = 0.4 if localiser else 0.95
    for k, t in enumerate(types):
        with reseau.etape(part * k / len(types), part * (k + 1) / len(types), f"Téléchargement : {LIB_TYPE[t]}"):
            _extraire_type(t, fichiers, codes, annee_min, annee_max, stop_event, journal,
                           permis, colonnes, millesimes, bruts)
    if localiser and permis:
        with reseau.etape(0.4, 0.98, "Localisation sur le cadastre"):
            cadastre.localiser(permis, stop_event, journal)
    annees = list(range(annee_min, annee_max + 1))
    return {"permis": permis, "synthese": synthese(permis, communes, codes, nom_epci, annees),
            "annees": annees, "types": types, "colonnes": colonnes, "millesimes": millesimes,
            "entetes": bruts, "localise": localiser}


def _extraire_type(t, fichiers, codes, annee_min, annee_max, stop_event, journal, permis, colonnes, millesimes, bruts):
    """Télécharge et filtre un type d'autorisation ; complète les listes passées en argument."""
    reseau.verifier_annulation(stop_event)
    f = fichiers.get(t)
    if not f:
        journal(f"   {LIB_TYPE[t]} : fichier introuvable dans le jeu (voir Diagnostic), ignoré")
        return
    for m, d in f["embargo"][:1]:
        journal(f"   {LIB_TYPE[t]} : millésime {m} annoncé pour le {d}, pas encore utilisable")
    journal(f"   {LIB_TYPE[t]} : téléchargement (millésime {f['millesime'] or 'dernier publié'})...")
    entetes, lignes = dido.telecharger(f["rid"], f["millesime"], f["col_commune"], codes,
                                       f["filtres"], stop_event, journal)
    liste, reconnues = normaliser(t, entetes, lignes)
    manquantes = [k for k in ("commune", "date_aut", "etat") if not reconnues.get(k)]
    if manquantes:
        journal(f"      ATTENTION : colonnes non reconnues : {', '.join(manquantes)} (voir Diagnostic)")
    gardes = [p for p in liste if p["annee"] and annee_min <= p["annee"] <= annee_max]
    journal(f"      {len(liste)} autorisation(s) reçue(s), {len(gardes)} autorisée(s) entre "
            f"{annee_min} et {annee_max}")
    permis.extend(gardes)
    colonnes[t], millesimes[t], bruts[t] = reconnues, f["millesime"] or "dernier publié", entetes


def diagnostic(stop_event=None, journal=print):
    """Ce que l'outil comprend du jeu (bouton « Diagnostic de la source »)."""
    jeu = dido.metadonnees(ID_JEU, stop_event, forcer=True)
    journal(f"Jeu : {jeu.get('title')} ({len(jeu.get('datafiles', []))} fichiers)")
    for df in jeu.get("datafiles", []):
        journal(f"  · {df.get('title')}")
    for t, f in classer_fichiers(jeu).items():
        journal(f"→ {LIB_TYPE[t]} : « {f['titre']} » · millésime utilisé : {f['millesime'] or 'dernier publié'}"
                f" · colonne commune : {f['col_commune']}")
        for m, d in f["embargo"]:
            journal(f"    millésime {m} annoncé, publié le {d}")
        noms = [c.get("name") for c in f["colonnes"]]
        _p, reconnues = normaliser(t, noms, [])
        journal("    colonnes reconnues : " + ", ".join(f"{k}={v}" for k, v in reconnues.items() if v))
        absentes = [k for k, v in reconnues.items() if not v]
        if absentes:
            journal("    non trouvées (sans conséquence si le type ne les contient pas) : " + ", ".join(absentes))

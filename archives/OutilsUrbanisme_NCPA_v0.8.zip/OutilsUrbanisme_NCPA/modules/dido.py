"""Accès commun à l'API DiDo du SDES (serveur des données Sitadel).

Reprend les leçons de l'outil Habitat :
- le SDES annonce parfois un millésime quelques jours avant sa publication
  (date de diffusion dans le futur) ; le demander renvoie HTTP 400. On prend
  donc le millésime le plus récent DÉJÀ diffusé ;
- en cas de refus (HTTP 400), nouvel essai sans préciser de millésime (DiDo
  sert alors le dernier publié) ;
- séparateur du CSV détecté, pas supposé.
Documentation de l'API : filtres de la forme COLONNE=in:valeur1,valeur2.
"""
import csv
import io
import json
import os
import time
import unicodedata
from datetime import datetime, timezone

from . import reseau
from .chemins import dossier_application

URL_DIDO = "https://data.statistiques.developpement-durable.gouv.fr/dido/api/v1"
DUREE_CACHE_META = 24 * 3600          # les listes de permis sont mises à jour chaque mois


def normaliser(texte):
    """minuscules, sans accents, espaces simples."""
    texte = unicodedata.normalize("NFD", str(texte or ""))
    texte = "".join(c for c in texte if unicodedata.category(c) != "Mn")
    return " ".join(texte.lower().replace("_", " ").replace("'", " ").split())


def deja_diffuse(millesime):
    """False si la date de diffusion du millésime est dans le futur (embargo)."""
    date = str(millesime.get("date_diffusion") or "")
    if not date:
        return True
    try:
        quand = datetime.fromisoformat(date.replace("Z", "+00:00"))
        if quand.tzinfo is None:
            quand = quand.replace(tzinfo=timezone.utc)
        return quand <= datetime.now(timezone.utc)
    except ValueError:
        return True


def metadonnees(id_jeu, stop_event=None, forcer=False):
    """Description d'un jeu DiDo (fichiers, millésimes, colonnes). Cache 24 h, repli sur le cache."""
    chemin = os.path.join(dossier_application(), f"cache_dido_{id_jeu}.json")
    if not forcer and os.path.exists(chemin) and time.time() - os.path.getmtime(chemin) < DUREE_CACHE_META:
        try:
            with open(chemin, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            pass
    try:
        jeu = reseau.get(f"{URL_DIDO}/datasets/{id_jeu}", stop_event=stop_event)
    except reseau.ErreurSource:
        if os.path.exists(chemin):
            with open(chemin, encoding="utf-8") as f:
                return json.load(f)
        raise
    if not isinstance(jeu, dict) or "datafiles" not in jeu:
        raise reseau.ErreurSource(f"jeu DiDo {id_jeu} : réponse inattendue (identifiant changé ?)")
    try:
        with open(chemin, "w", encoding="utf-8") as f:
            json.dump(jeu, f, ensure_ascii=False)
    except OSError:
        pass
    return jeu


def millesime_utilisable(fichier):
    """-> (millésime à demander ou None, colonnes, [(millésime, date)] sous embargo)."""
    tries = sorted(fichier.get("millesimes") or [], key=lambda m: str(m.get("millesime", "")))
    if not tries:
        return None, [], []
    diffuses = [m for m in tries if deja_diffuse(m)]
    embargo = [(m.get("millesime"), str(m.get("date_diffusion", ""))[:10]) for m in tries if not deja_diffuse(m)]
    colonnes = tries[-1].get("columns") or (diffuses[-1].get("columns") if diffuses else []) or []
    return (diffuses[-1]["millesime"] if diffuses else None), colonnes, embargo


def telecharger(rid, millesime, colonne, codes, filtres_dispo=None, stop_event=None, journal=print):
    """CSV d'un fichier DiDo filtré sur une liste de codes. -> (entêtes, lignes)."""
    url = f"{URL_DIDO}/datafiles/{rid}/csv"
    base = {"withColumnName": "true", "withColumnDescription": "false", "withColumnUnit": "false"}
    filtres_dispo = filtres_dispo or ["in", "eq"]

    def appel(mill, valeur):
        params = dict(base, **{colonne: valeur})
        if mill:
            params["millesime"] = mill
        return reseau.get(url, params=params, stop_event=stop_event, attendu="texte")

    essais = [millesime, None] if millesime else [None]
    textes, derniere = [], None
    for mill in essais:
        try:
            if "in" in filtres_dispo:
                textes = [appel(mill, "in:" + ",".join(codes))]
            else:
                textes = []
                for code in codes:
                    textes.append(appel(mill, "eq:" + code))
                    reseau.pause(0.2, stop_event)
            if mill is None and millesime:
                journal("      (données obtenues sans préciser de millésime : dernier millésime publié)")
            break
        except reseau.ErreurSource as exc:
            derniere = exc
            if exc.code_http != 400:
                raise
            journal(f"      HTTP 400 avec le millésime {mill or '(par défaut)'} : "
                    + ("nouvel essai sans millésime" if mill else "échec"))
    else:
        raise reseau.ErreurSource(
            "le serveur DiDo refuse la demande (HTTP 400). Cause la plus fréquente : un nouveau millésime "
            f"est annoncé mais pas encore publié ; réessayez après sa date de diffusion. Détail : {derniere}", 400)

    entetes, lignes = None, []
    for texte in textes:
        premiere = texte.split("\n", 1)[0]
        separateur = ";" if premiere.count(";") >= premiere.count(",") else ","
        rangs = list(csv.reader(io.StringIO(texte), delimiter=separateur))
        if not rangs:
            continue
        if entetes is None:
            entetes = [h.strip().lstrip("\ufeff").strip('"') for h in rangs[0]]
        lignes.extend(r for r in rangs[1:] if r)
    return entetes or [], lignes

"""Croisement des permis et des friches avec le zonage, les servitudes et les
prescriptions : dans quelle zone se trouve chaque point ?

Les points viennent soit des onglets Permis et Friches (extractions faites
dans la même séance), soit de fichiers GeoJSON exportés par ces onglets
(bouton « Charger un GeoJSON »). Le thème Zonage reste ainsi utilisable seul.
"""
import json

from shapely.geometry import Point, shape

from . import geometrie as G
from . import permis as P
from .servitudes import Index

LIB_THEME = {"logements": "Logements (PC et DP)", "amenager": "Permis d'aménager",
             "demolir": "Permis de démolir", "friche": "Friche"}


def points_permis(resultat):
    sortie = []
    for p in resultat.get("permis", []):
        if p.get("lon") is None:
            continue
        sortie.append({"source": p["theme"], "lon": p["lon"], "lat": p["lat"], "commune_code": p["commune"],
                       "nom": f"{p['type_dau']} {p['num']}".strip(), "date": p.get("date_aut"),
                       "etat": p.get("etat"), "logements": p.get("logements") or 0,
                       "a_venir": "oui" if P.en_attente(p) else ""})
    return sortie


def points_friches(resultat):
    sortie = []
    for s in resultat.get("sites", []):
        if not s.get("centre"):
            continue
        sortie.append({"source": "friche", "lon": s["centre"][0], "lat": s["centre"][1],
                       "commune_code": s["commune"], "nom": s["nom"], "statut": s["statut"],
                       "surface_ha": round(s["surface_m2"] / 10000, 3) if s.get("surface_m2") else None})
    return sortie


def points_geojson(chemin):
    """Lit un GeoJSON exporté par l'onglet Permis ou Friches. -> (points, type reconnu)."""
    with open(chemin, encoding="utf-8") as f:
        fc = json.load(f)
    sortie, genre = [], None
    for feat in fc.get("features", []):
        p = feat.get("properties", {})
        c = G.centre(feat.get("geometry"))
        if not c:
            continue
        if "theme_code" in p:
            genre = "permis"
            sortie.append({"source": p["theme_code"], "lon": c[0], "lat": c[1], "commune_code": p.get("commune"),
                           "nom": f"{p.get('type_dau') or ''} {p.get('num') or ''}".strip(), "date": p.get("date_aut"),
                           "etat": p.get("etat"), "logements": p.get("logements") or 0, "a_venir": p.get("a_venir") or ""})
        elif "statut_code" in p:
            genre = "friches"
            sortie.append({"source": "friche", "lon": c[0], "lat": c[1], "commune_code": p.get("comm_insee"),
                           "nom": p.get("site_nom") or p.get("site_id"), "statut": p["statut_code"],
                           "surface_ha": p.get("surface_ha")})
    if genre is None:
        raise ValueError("ce GeoJSON ne vient ni de l'onglet Permis ni de l'onglet Friches")
    return sortie, genre


def croiser(points, zones, servitudes, prescriptions):
    """Ajoute à chaque point sa zone, ses servitudes et ses prescriptions. -> (points, synthèse)."""
    iz, isup, ipsc = Index(zones), Index(servitudes), Index(prescriptions)
    for pt in points:
        geo = Point(pt["lon"], pt["lat"])
        z = iz.contenant(geo)
        pt["zone"] = z[0].get("libelle") or z[0].get("typezone") if z else ""
        pt["famille"] = z[0].get("famille") if z else "hors zonage"
        pt["famille_lib"] = z[0].get("famille_lib") if z else "Hors zonage (RNU ou non couvert)"
        pt["reglement_url"] = z[0].get("reglement_url") if z else None
        pt["servitudes"] = ", ".join(sorted({s["categorie"] for s in isup.contenant(geo)}))
        pt["prescriptions"] = ", ".join(sorted({s["type_lib"] for s in ipsc.contenant(geo)}))
    synthese = {}
    for pt in points:
        cle = (pt["source"], pt["famille_lib"])
        s = synthese.setdefault(cle, {"nombre": 0, "logements": 0.0, "a_venir": 0.0, "surface_ha": 0.0,
                                      "sans_projet": 0})
        s["nombre"] += 1
        s["logements"] += pt.get("logements") or 0
        if pt.get("a_venir") == "oui":
            s["a_venir"] += pt.get("logements") or 0
        s["surface_ha"] += pt.get("surface_ha") or 0
        if pt.get("statut") == "friche sans projet":
            s["sans_projet"] += 1
    tableau = [{"source": LIB_THEME.get(k[0], k[0]), "source_code": k[0], "famille": k[1], **v}
               for k, v in sorted(synthese.items())]
    contraintes = {}
    for pt in points:
        for cat in [c for c in pt["servitudes"].split(", ") if c]:
            cle = (pt["source"], cat)
            contraintes[cle] = contraintes.get(cle, 0) + 1
    return points, {"par_zone": tableau,
                    "par_servitude": [{"source": LIB_THEME.get(s, s), "categorie": c, "nombre": n}
                                      for (s, c), n in sorted(contraintes.items())]}


def entites(points):
    return [{"type": "Feature", "geometry": {"type": "Point", "coordinates": [p["lon"], p["lat"]]},
             "properties": {"couche": "point croisé", "type": LIB_THEME.get(p["source"], p["source"]),
                            **{k: v for k, v in p.items() if k not in ("lon", "lat")}}} for p in points]

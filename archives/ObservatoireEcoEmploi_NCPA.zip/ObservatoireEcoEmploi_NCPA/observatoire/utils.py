"""Utilitaires communs : chemins, journal des opérations, suivi de la collecte par source, téléchargements."""
import os
import re
import sys
import threading
import time
import unicodedata
from datetime import datetime
from pathlib import Path

if getattr(sys, "frozen", False):  # application compilée : dossiers à côté de l'exécutable
    RACINE = Path(sys.executable).resolve().parent
else:
    RACINE = Path(__file__).resolve().parent.parent
CACHE = RACINE / "cache"
MANUELS = RACINE / "donnees_manuelles"
SORTIES = RACINE / "sorties"
ASSETS = Path(__file__).resolve().parent / "assets"
for _d in (CACHE, MANUELS, SORTIES):
    _d.mkdir(exist_ok=True)

# ---------------------------------------------------------------- suivi de la collecte
class Suivi:
    """État de chaque source pendant la collecte, lu par l'interface toutes les secondes.
    Chaque appel réseau est compté pour la source « courante » (la collecte est séquentielle).
    statut : attente | en cours | ok | cache | alerte | erreur | ignoree"""

    def __init__(self):
        self.verrou = threading.Lock()
        self.etats, self.courante, self.t0 = {}, None, None

    def preparer(self, plan):
        with self.verrou:
            self.etats = {s["id"]: {"id": s["id"], "libelle": s["libelle"], "api": s["api"], "statut": "attente",
                                    "appels": 0, "octets": 0, "debut": None, "fin": None, "message": "",
                                    "fraction": None, "attendus": s.get("appels"), "niveau_max": "info"}
                          for s in plan}
            self.courante, self.t0 = None, time.time()

    def debut(self, sid):
        with self.verrou:
            e = self.etats.get(sid)
            if e:
                e.update(statut="en cours", debut=time.time(), message="démarrage")
            self.courante = sid

    def fin(self, sid, statut=None, message=None):
        with self.verrou:
            e = self.etats.get(sid)
            if e:
                if statut is None:  # déduit : aucun appel réseau = données lues dans le cache
                    statut = {"erreur": "erreur", "alerte": "alerte"}.get(e["niveau_max"],
                                                                         "cache" if e["appels"] == 0 else "ok")
                e.update(statut=statut, fin=time.time(), fraction=1.0)
                if message:
                    e["message"] = message
                elif e["message"] == "démarrage":
                    e["message"] = "données lues dans le cache" if statut == "cache" else "terminé"
            if self.courante == sid:
                self.courante = None

    def ignorer(self, sid, message):
        with self.verrou:
            e = self.etats.get(sid)
            if e:
                e.update(statut="ignoree", message=message, fraction=None)

    def appel(self, octets=0):
        with self.verrou:
            e = self.etats.get(self.courante)
            if e:
                e["appels"] += 1
                e["octets"] += octets

    def ajouter_octets(self, n):
        with self.verrou:
            e = self.etats.get(self.courante)
            if e:
                e["octets"] += n

    def progression(self, fraction, texte=None, sid=None):
        with self.verrou:
            e = self.etats.get(sid or self.courante)
            if e:
                e["fraction"] = max(0.0, min(1.0, fraction))
                if texte:
                    e["message"] = texte

    def message(self, texte, niveau="info"):
        with self.verrou:
            e = self.etats.get(self.courante)
            if e:
                e["message"] = str(texte).strip()[:160]
                ordre = {"info": 0, "ok": 0, "alerte": 1, "erreur": 2}
                if ordre.get(niveau, 0) > ordre.get(e["niveau_max"], 0):
                    e["niveau_max"] = niveau

    def instantane(self):
        """Copie de l'état pour l'affichage, avec une progression estimée quand elle n'est pas connue."""
        with self.verrou:
            out = []
            for e in self.etats.values():
                d = dict(e)
                if d["fraction"] is None and d["statut"] == "en cours":
                    d["fraction"] = min(.95, d["appels"] / d["attendus"]) if d["attendus"] else None
                if d["statut"] in ("ok", "cache", "alerte", "erreur"):
                    d["fraction"] = 1.0
                d["duree"] = ((d["fin"] or time.time()) - d["debut"]) if d["debut"] else None
                out.append(d)
            return out


SUIVI = Suivi()


# ---------------------------------------------------------------- journal
# Chaque étape y consigne son statut : il est affiché à l'écran, repris dans
# le rapport HTML (annexe) et dans l'onglet "Journal" du classeur Excel.
JOURNAL = []
ABONNES = []        # fonctions appelées à chaque ligne du journal (affichage en direct dans l'interface)
PROGRESSION = []    # fonctions appelées pendant un téléchargement : f(nom_fichier, lu, total)


def dossier_application():
    """Dossier de l'outil (fichiers de clés, cache) : repris des outils .exe de la suite."""
    return str(RACINE)


def log(etape, message, niveau="info"):
    """niveau : info | ok | alerte | erreur"""
    ligne = {"heure": datetime.now().strftime("%H:%M:%S"), "etape": etape, "niveau": niveau, "message": message,
             "source": SUIVI.courante or ""}
    JOURNAL.append(ligne)
    SUIVI.message(message, niveau)
    pictos = {"info": "  ", "ok": "OK", "alerte": "!!", "erreur": "XX"}
    print(f"[{pictos.get(niveau, '  ')}] {etape} : {message}", flush=True)
    for f in ABONNES:
        try:
            f(ligne)
        except Exception:
            pass


# ---------------------------------------------------------------- texte
def norm(txt):
    """Minuscules, sans accents, apostrophes unifiées : sert aux recherches
    par motif sur les libellés INSEE (insensibles aux accents)."""
    if txt is None:
        return ""
    t = unicodedata.normalize("NFKD", str(txt))
    t = "".join(c for c in t if not unicodedata.combining(c))
    t = t.replace("’", "'").replace("\u00a0", " ")
    return re.sub(r"\s+", " ", t).strip().lower()


def fmt_nombre(x, dec=0):
    """1234567.8 -> '1 234 568' (espace fine insécable à la française)."""
    if x is None or (isinstance(x, float) and x != x):
        return "n.d."
    s = f"{x:,.{dec}f}".replace(",", "\u202f").replace(".", ",")
    return s


def fmt_pct(x, dec=1):
    if x is None or (isinstance(x, float) and x != x):
        return "n.d."
    return fmt_nombre(x, dec) + "\u00a0%"


# ---------------------------------------------------------------- réseau
def session_http(proxy=None):
    from .reseau import SessionSuivie
    s = SessionSuivie()
    if proxy:
        s.proxies = {"http": proxy, "https": proxy}
    return s


def telecharger(url, destination, session, etape, params=None, timeout=120):
    """Télécharge en flux vers un fichier (affiche la progression).
    Écrit d'abord dans un .part puis renomme : un téléchargement interrompu
    ne laisse jamais un fichier tronqué pris pour valide."""
    destination = Path(destination)
    tmp = destination.with_suffix(destination.suffix + ".part")
    t0 = time.time()
    with session.get(url, params=params, stream=True, timeout=timeout) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length") or 0)
        lu = 0
        with open(tmp, "wb") as f:
            for bloc in r.iter_content(chunk_size=1 << 20):
                f.write(bloc)
                lu += len(bloc)
                SUIVI.ajouter_octets(len(bloc))
                if total:
                    SUIVI.progression(lu / total, f"{destination.name} : {lu / 1e6:.0f} / {total / 1e6:.0f} Mo")
                for cb in PROGRESSION:
                    try:
                        cb(destination.name, lu, total)
                    except Exception:
                        pass
                if sys.stdout.isatty():
                    if total:
                        print(f"\r     {lu/1e6:6.1f} / {total/1e6:.1f} Mo", end="")
                    else:
                        print(f"\r     {lu/1e6:6.1f} Mo", end="")
        if sys.stdout.isatty():
            print()
    os.replace(tmp, destination)
    log(etape, f"téléchargé {destination.name} ({lu/1e6:.1f} Mo en {time.time()-t0:.0f} s)", "ok")
    return destination


def age_jours(chemin):
    chemin = Path(chemin)
    if not chemin.exists():
        return None
    return (time.time() - chemin.stat().st_mtime) / 86400


# ---------------------------------------------------------------- fichiers de sortie
def horodatage():
    """Suffixe des fichiers produits : un nouveau rapport n'écrase plus le précédent."""
    return datetime.now().strftime("%Y-%m-%d_%Hh%M")


def enregistrer_sur(chemin, ecrire, etape):
    """Appelle ecrire(chemin). Si le fichier est verrouillé (ouvert dans Excel ou le
    navigateur), enregistre sous un autre nom au lieu d'interrompre tout le traitement.
    Renvoie le chemin réellement écrit."""
    chemin = Path(chemin)
    try:
        ecrire(chemin)
        return chemin
    except PermissionError:
        autre = chemin.with_name(f"{chemin.stem}_{datetime.now():%H%M%S}{chemin.suffix}")
        log(etape, f"{chemin.name} est ouvert dans un autre logiciel : enregistré sous {autre.name}", "alerte")
        ecrire(autre)
        return autre


def nom_extrait_insee(cfg):
    """Nom de l'extrait régional de la base INSEE. Il dépend de la liste des départements :
    si on la modifie dans config.xlsx, un nouvel extrait est produit."""
    return f"insee_extrait_{cfg['region']}_{'-'.join(cfg['deps_region'])}.parquet"


# ---------------------------------------------------------------- libellés de territoires
# Les noms sont saisis avec leur article dans config.xlsx (« le Calvados », « la Manche »,
# « l'Orne »), ce qui permet d'accorder les phrases du rapport.
_ARTICLES = (("les ", "des ", "dans les "), ("le ", "du ", "dans le "), ("la ", "de la ", "dans la "),
             ("l'", "de l'", "dans l'"), ("l’", "de l’", "dans l’"))


def sans_article(t):
    """« le Calvados » -> « Calvados » (étiquettes de graphiques et de tableaux)."""
    for art, _, _ in _ARTICLES:
        if t.lower().startswith(art):
            reste = t[len(art):]
            return reste[:1].upper() + reste[1:]
    return t


def de(t):
    """« le Calvados » -> « du Calvados » ; « la Normandie » -> « de la Normandie »."""
    for art, prep, _ in _ARTICLES:
        if t.lower().startswith(art):
            return prep + t[len(art):]
    return "de " + t


def dans(t):
    """« le Calvados » -> « dans le Calvados »."""
    for art, _, prep in _ARTICLES:
        if t.lower().startswith(art):
            return prep + t[len(art):]
    return "dans " + t

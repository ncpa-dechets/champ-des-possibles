"""Localisation des permis à partir de leurs références cadastrales.

Sitadel ne donne pas de coordonnées, mais jusqu'à 3 parcelles par permis
(section + numéro, préfixe en général absent). On télécharge une fois par
commune le plan cadastral d'Etalab (cadastre.data.gouv.fr, GeoJSON), on
calcule le centre de chaque parcelle, et on garde un petit fichier en cache
(section+numéro -> longitude, latitude). Les téléchargements suivants ne
sont plus nécessaires pendant 180 jours.

Identifiant cadastral complet : commune (5) + préfixe (3) + section (2) +
numéro (4), ex. 14117000AB0123. Le préfixe vaut 000 sauf dans les communes
nouvelles (ancienne commune) : on cherche donc section + numéro, tous
préfixes confondus.
"""
import gzip
import json
import os
import time

from . import reseau
from .chemins import dossier_application

URL_CADASTRE = "https://cadastre.data.gouv.fr/data/etalab-cadastre/latest/geojson/communes/{dep}/{code}/cadastre-{code}-parcelles.json.gz"
DUREE_CACHE = 180 * 24 * 3600


def dossier_cache():
    chemin = os.path.join(dossier_application(), "cache_cadastre")
    os.makedirs(chemin, exist_ok=True)
    return chemin


def cle(section, numero):
    """('ab', '123') -> 'AB0123' ; section sur 2 caractères, numéro sur 4."""
    s = str(section or "").strip().upper().replace(" ", "")
    n = str(numero or "").strip().replace(" ", "")
    if not s or not n or not n.isdigit():
        return None
    s = s[-2:].rjust(2, "0")
    return s + n.zfill(4)[-4:]


def _centre(geometrie):
    """Centre (barycentre de surface) du plus grand anneau extérieur."""
    if not geometrie:
        return None
    polys = geometrie["coordinates"] if geometrie.get("type") == "MultiPolygon" else [geometrie.get("coordinates")]
    meilleur, aire_max = None, -1
    for poly in polys:
        if not poly:
            continue
        anneau = poly[0]
        a = cx = cy = 0.0
        for (x1, y1), (x2, y2) in zip(anneau, anneau[1:]):
            f = x1 * y2 - x2 * y1
            a += f
            cx += (x1 + x2) * f
            cy += (y1 + y2) * f
        if abs(a) < 1e-14:
            xs, ys = [p[0] for p in anneau], [p[1] for p in anneau]
            c, aire = (sum(xs) / len(xs), sum(ys) / len(ys)), 0
        else:
            c, aire = (cx / (3 * a), cy / (3 * a)), abs(a)
        if aire > aire_max:
            meilleur, aire_max = c, aire
    return [round(meilleur[0], 6), round(meilleur[1], 6)] if meilleur else None


def centres_commune(code, stop_event=None, journal=print):
    """{'AB0123': [lon, lat], ...} pour une commune (cache 180 jours), ou {} si indisponible."""
    cache = os.path.join(dossier_cache(), f"parcelles_{code}.json")
    if os.path.exists(cache) and time.time() - os.path.getmtime(cache) < DUREE_CACHE:
        try:
            with open(cache, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            pass
    temporaire = os.path.join(dossier_cache(), f"parcelles_{code}.json.gz")
    url = URL_CADASTRE.format(dep=code[:2], code=code)
    try:
        if not reseau.telecharger(url, temporaire, stop_event):
            journal(f"      cadastre {code} : fichier absent sur cadastre.data.gouv.fr")
            return {}
        with gzip.open(temporaire, "rt", encoding="utf-8") as f:
            fc = json.load(f)
    except reseau.ErreurSource as exc:
        if os.path.exists(cache):
            with open(cache, encoding="utf-8") as f:
                return json.load(f)
        journal(f"      cadastre {code} : {exc}")
        return {}
    except (OSError, ValueError) as exc:
        journal(f"      cadastre {code} : fichier illisible ({exc.__class__.__name__})")
        return {}
    finally:
        if os.path.exists(temporaire):
            try:
                os.remove(temporaire)
            except OSError:
                pass
    centres = {}
    for feat in fc.get("features", []):
        p = feat.get("properties", {})
        ident = str(p.get("id") or "")
        # identifiant complet : commune (5) + préfixe (3) + section (2) + numéro (4)
        k = ident[8:14] if len(ident) == 14 else cle(p.get("section"), p.get("numero"))
        if k and k not in centres:
            c = _centre(feat.get("geometry"))
            if c:
                centres[k] = c
    try:
        with open(cache, "w", encoding="utf-8") as f:
            json.dump(centres, f)
    except OSError:
        pass
    return centres


def localiser(permis, stop_event=None, journal=print):
    """Ajoute 'lon', 'lat' et 'localisation' à chaque permis (liste de dicts)."""
    communes = sorted({p["commune"] for p in permis if p.get("commune")})
    journal(f"   localisation sur le cadastre : {len(communes)} commune(s) "
            "(premier lancement : téléchargement du plan cadastral, puis cache 180 jours)")
    trouves = 0
    for i, code in enumerate(communes):
        reseau.verifier_annulation(stop_event)
        with reseau.etape(i / len(communes), (i + 1) / len(communes)):
            centres = centres_commune(code, stop_event, journal)
        for p in permis:
            if p.get("commune") != code:
                continue
            points = [centres[k] for k in (cle(s, n) for s, n in p.get("parcelles", [])) if k and k in centres]
            if points:
                p["lon"] = round(sum(x for x, _y in points) / len(points), 6)
                p["lat"] = round(sum(y for _x, y in points) / len(points), 6)
                p["localisation"] = "parcelle" if len(points) == 1 else f"{len(points)} parcelles"
                trouves += 1
            else:
                p["localisation"] = "non localisé"
    journal(f"   {trouves} permis localisés sur {len(permis)}"
            + (f" ({len(permis) - trouves} sans parcelle reconnue)" if trouves < len(permis) else ""))
    return trouves

# -*- coding: utf-8 -*-
"""Textes de méthode, repris dans l'export Excel et le tableau de bord HTML."""

METHODE = [
    ("Sources", "Urssaf (open.urssaf.fr) : établissements employeurs et effectifs salariés du secteur privé par "
                "commune et activité (APE), au 31 décembre depuis 2006 ; effectif moyen et masse salariale par EPCI "
                "depuis 1998. OFGL (data.ofgl.fr) : population des EPCI. Insee Melodi (DS_TOUR_CAP) : capacités "
                "d'hébergement touristique. data.gouv.fr : communes soumises à la loi Littoral. geo.api.gouv.fr : "
                "contours des communes."),
    ("Champ", "Établissements employeurs du secteur privé, régime général. Ni l'emploi public, ni l'agriculture "
              "relevant de la MSA, ni les indépendants sans salarié."),
    ("Date de mesure", "Effectifs au 31 décembre : sur un territoire touristique, l'emploi saisonnier de l'été "
                       "n'apparaît presque pas. Le chiffre reflète l'emploi permanent."),
    ("Ruptures de série", "Depuis juin 2023, les apprentis sont comptés dans les effectifs. Le passage à la DSN "
                          "(2016-2021) a aussi entraîné des révisions : comparer des territoires entre eux plutôt "
                          "que lire une évolution isolée."),
    ("Périmètre des EPCI", "Nomenclature des communes et EPCI au 1er janvier 2023, appliquée à toutes les années."),
    ("Salaire moyen", "Masse salariale brute de l'année divisée par l'effectif salarié moyen de l'année, hors "
                      "intérimaires. C'est un salaire brut annuel par poste, pas un salaire en équivalent temps "
                      "plein : un territoire avec beaucoup de temps partiel affiche un salaire moyen plus bas."),
    ("Indice de spécificité", "Part d'un secteur dans l'emploi de l'EPCI divisée par sa part en France. "
                              "Au-dessus de 1, le secteur est plus présent qu'en moyenne."),
    ("Décomposition de la variation", "Tendance nationale : variation qu'aurait connue l'EPCI si son emploi avait "
                                      "évolué comme en France. Effet de structure : gain ou perte dû au poids local "
                                      "de secteurs qui progressent ou reculent au niveau national. Effet local : le "
                                      "reste, c'est-à-dire la dynamique propre du territoire."),
    ("Capacité d'accueil touristique", "Convention Insee-DGE : une chambre d'hôtel = 2 lits, un emplacement de "
                                       "camping = 3 lits, plus les lits des autres hébergements collectifs (données "
                                       "2026), et 5 lits par résidence secondaire (recensement, dernière année "
                                       "disponible). Les meublés de tourisme sont classés en résidences secondaires par "
                                       "le recensement. Si les résidences secondaires ne sont pas connues pour tous les "
                                       "EPCI, le critère touristique se limite aux lits marchands, pour rester "
                                       "comparable."),
    ("Groupe « littoraux et touristiques »", "EPCI comptant au moins une commune soumise à la loi Littoral, et dont "
                                            "la capacité d'accueil touristique pour 100 habitants est proche de celle "
                                            "de l'EPCI de référence (tolérance choisie dans l'outil)."),
    ("Employeurs (SIRENE)", "Établissements aujourd'hui actifs et employeurs, d'après la période en cours du répertoire "
                            "SIRENE de l'Insee (avant la v0.5, des établissements fermés figuraient dans la liste). L'effectif est une tranche (par exemple 10 à 19 salariés), souvent celle de "
                            "l'année n-2, et manque pour une partie des établissements. Les entrepreneurs individuels "
                            "ayant demandé la non-diffusion n'apparaissent pas nominativement. Usage interne."),
    ("Observatoire des territoires", "Indicateurs de l'ANCT téléchargés à la maille EPCI (dernière année "
                                     "disponible, souvent le recensement de la population). Valeurs en %, sauf "
                                     "l'indice de concentration de l'emploi."),
    ("Enquête BMO", "Enquête Besoins en main-d'œuvre de France Travail : projets de recrutement déclarés par les "
                    "employeurs pour l'année, par métier et bassin d'emploi, dont projets jugés difficiles et projets "
                    "saisonniers. Ce sont des intentions, pas des embauches réalisées."),
    ("France Travail", "API Marché du travail et Informations sur un territoire (francetravail.io) : demandeurs "
                       "d'emploi en fin de trimestre (catégories A, B, C), nouveaux inscrits et offres cumulés sur 12 "
                       "mois, embauches du trimestre, population active. Les offres comptent toutes les annonces "
                       "diffusées sur francetravail.fr, partenaires compris. Difficultés de recrutement : indices de 1 "
                       "à 5 calculés par France Travail et la Dares, disponibles au mieux à la maille du bassin d'emploi."),
    ("Médiane et rang", "Médiane calculée sur les autres EPCI du groupe (EPCI de référence exclu). Rang : 1 = "
                        "valeur la plus élevée, EPCI de référence inclus."),
    ("Saisonnalité", "Séries trimestrielles brutes de France Travail (demandeurs d'emploi en fin de trimestre, "
                     "embauches et offres du trimestre). Pour chaque année complète depuis 2021, chaque trimestre est "
                     "rapporté à la moyenne de l'année ; le profil est la moyenne de ces écarts. L'amplitude est l'écart "
                     "entre le trimestre le plus haut et le plus bas. Les demandeurs sont comptés le dernier jour du "
                     "trimestre (fin juin, fin septembre) : le creux de juillet-août est en partie lissé. Depuis 2022, "
                     "un nouveau formulaire d'actualisation a fait passer des demandeurs de la catégorie A vers B et C."),
    ("Emploi tous employeurs (Flores)", "Insee, Flores : postes salariés présents la dernière semaine de décembre, "
                                        "tous employeurs (publics, privés, agricoles, particuliers employeurs). "
                                        "L'écart avec l'Urssaf (secteur privé, régime général) mesure ce que le reste de "
                                        "l'outil ne voit pas. Les deux sources ne comptent pas tout à fait de la même "
                                        "façon : de petits écarts dans les secteurs privés sont normaux. L'Insee "
                                        "déconseille de comparer deux millésimes de Flores entre eux."),
    ("Déplacements domicile-travail", "Insee, recensement : commune de résidence et commune de travail des actifs "
                                      "occupés de 15 ans ou plus. Le recensement étant réalisé par sondage, les flux "
                                      "de moins de 200 actifs sont des ordres de grandeur ; ils sont regroupés par EPCI "
                                      "pour la lecture. Les emplois au lieu de travail du recensement incluent l'emploi "
                                      "public et les non-salariés."),
    ("Créations d'entreprises", "Insee (répertoire SIRENE, démographie des entreprises) : créations d'entreprises de "
                                "l'année, y compris les micro-entrepreneurs (entrepreneurs individuels). Taux de "
                                "création : créations de l'année rapportées au stock d'entreprises au 31 décembre "
                                "précédent. Les créations et fermetures d'établissements viennent directement de "
                                "l'API SIRENE ; une fermeture peut correspondre à un simple déménagement."),
    ("Procédures collectives (BODACC)", "Jugements d'ouverture de liquidation judiciaire, de redressement judiciaire "
                                        "ou de sauvegarde publiés au BODACC dans le département, une fois par entreprise "
                                        "et par année (définition proche des défaillances de la Banque de France). "
                                        "Rattachées à l'EPCI si l'entreprise figure parmi ses employeurs, actuels ou "
                                        "passés, ou si l'adresse publiée est dans l'une de ses communes. L'année en "
                                        "cours est incomplète."),
]

# Méthode du portrait économique (reprise de l'outil « Portrait économique »)
METHODE_ECO = [
    ("Dossier complet Insee", "Recensements de la population 2012, 2017 et 2023 (emploi au lieu de travail, actifs, "
                              "logements), Filosofi (revenus), Flores, hébergement touristique, dans la géographie "
                              "communale la plus récente. Fichier national (≈ 300 Mo) téléchargé une fois puis filtré."),
    ("Indicateur de concentration d'emploi", "Emplois localisés pour 100 actifs occupés résidents. Sous 100 : "
                                             "territoire à dominante résidentielle."),
    ("Sphère présentielle", "Activités qui répondent aux besoins des personnes présentes (habitants, résidents "
                            "secondaires, touristes). Chaque code APE Urssaf est classé selon la grille officielle de "
                            "l'Insee ; à défaut, par la table approximative de config.xlsx (onglet Spheres_NAF). La "
                            "mesure officielle Insee, qui couvre aussi l'emploi public, fait référence."),
    ("Base économique", "Approche de Laurent Davezies : revenus issus des activités exportatrices (base productive), "
                        "des emplois publics (base publique), des transferts sociaux (base sociale) et des revenus "
                        "captés par la présence de personnes dont les revenus sont formés ailleurs (base résidentielle). "
                        "Estimation fondée sur des hypothèses explicites (config.xlsx, onglet Base_eco du classeur Excel, "
                        "recalculable) : à présenter comme un ordre de grandeur. L'Urssaf ne couvre pas l'agriculture : "
                        "sa part vient du recensement et est comptée dans la base productive. La base publique est "
                        "approchée par les secteurs « administration, enseignement, santé, action sociale »."),
    ("IRCOM", "DGFiP, impôt sur le revenu par commune : salaires et pensions déclarés. Corrige la part des pensions "
              "quand l'Insee ne publie pas la décomposition du revenu pour l'EPCI."),
]

# Introduction de chaque thème (rapport HTML et interface)
INTRO_THEMES = {
    "recensement": "Combien d'emplois le territoire offre-t-il à ses actifs, dans quels grands secteurs ?",
    "spheres": "L'économie présentielle répond aux besoins des personnes présentes (habitants, résidents secondaires, "
               "touristes) ; la sphère productive vend ses biens et services hors du territoire. Un territoire très "
               "présentiel dépend de son attractivité résidentielle et touristique.",
    "base_eco": "D'où vient le revenu du territoire ? Revenus des activités exportatrices, des emplois publics, des "
                "transferts sociaux et des revenus formés ailleurs (retraités, navetteurs, résidents secondaires, "
                "touristes).",
    "evolution": "L'emploi salarié privé progresse-t-il plus ou moins vite qu'ailleurs ?",
    "secteurs": "Quels secteurs portent l'emploi, lesquels gagnent ou perdent des postes, et pourquoi ?",
    "communes": "Où se concentrent les emplois ? La dépendance à quelques communes ou activités rend l'économie "
                "locale plus vulnérable à un choc ponctuel.",
    "salaires": "Quel salaire moyen par poste, comparé aux territoires voisins et semblables ?",
    "flores": "Ce que l'Urssaf ne voit pas : emploi public, agricole, particuliers employeurs.",
    "ft": "Combien de demandeurs d'emploi, d'offres et d'embauches ?",
    "saison": "À quel moment de l'année le territoire recrute-t-il et le chômage baisse-t-il ?",
    "bmo": "Quels métiers les employeurs du bassin prévoient-ils de recruter, et avec quelles difficultés ?",
    "tensions": "Les métiers les plus recherchés sont-ils en tension ?",
    "employeurs": "Qui sont les employeurs du territoire et où sont-ils implantés ?",
    "lbb": "Quelles entreprises sont susceptibles d'embaucher, et pour quels métiers ?",
    "demographie": "Les entreprises se créent-elles, ferment-elles, font-elles défaut ?",
    "mobilites": "Où travaillent les habitants, d'où viennent ceux qui travaillent ici ?",
    "anct": "Comment le territoire se situe-t-il sur les indicateurs de l'Observatoire des territoires ?",
}

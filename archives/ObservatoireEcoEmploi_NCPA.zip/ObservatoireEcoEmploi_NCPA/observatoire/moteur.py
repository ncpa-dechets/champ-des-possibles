# -*- coding: utf-8 -*-
"""Moteur unique : collecte (une fois par source, quel que soit le nombre de thèmes qui s'en servent), puis
analyses. Appelé par l'interface Streamlit (app.py) ; la collecte tourne dans un fil d'exécution séparé et publie
son avancement dans utils.SUIVI.

Organisation :
  collecter(themes, options, mode, forcer) -> brut  (données brutes, une entrée par source)
  analyser(brut, themes, params)          -> resultat (blocs d'analyse, chiffres clés, synthèse, cartes)
"""
import hashlib
import json
import time
import traceback
import warnings
from datetime import datetime

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

from . import catalogue  # noqa: E402
from .config import charger_config  # noqa: E402
from .reseau import Cache, Client  # noqa: E402
from .utils import JOURNAL, SUIVI, log, sans_article  # noqa: E402

MOTS_ALERTE = ("indisponible", "échec", "erreur", "refus", "introuvable", "impossible", "attention")


def _log_source(etape):
    """Journal des modules repris de l'outil Emploi (un seul argument) -> journal commun, avec un niveau déduit."""
    def f(m):
        txt = str(m).strip()
        if not txt or txt.startswith("(cache du"):
            if txt:
                log(etape, txt.strip("() "), "info")
            return
        niveau = "alerte" if any(k in txt.lower() for k in MOTS_ALERTE) else "info"
        log(etape, txt, niveau)
    return f


class Contexte:
    def __init__(self, cfg, options, mode, forcer):
        self.cfg, self.options, self.mode = cfg, options, mode
        self.forcer = set(forcer or ())
        self.hors_ligne = mode == "hors_ligne"
        self.client = Client(log=_log_source("Réseau"), proxy=cfg.get("proxy"))
        self.client.s.hors_ligne = self.hors_ligne
        self.cache = Cache()
        self.siren = cfg["code_epci"]
        self.dep, self.reg = cfg["departement"], cfg["region"]
        self.nom = cfg.get("nom_long") or cfg.get("nom_court")
        self.brut = {"siren": self.siren, "cfg": cfg, "date": datetime.now().strftime("%d/%m/%Y %H:%M"),
                     "nom": self.nom, "nom_court": cfg.get("nom_court"), "dep": self.dep, "reg": self.reg,
                     "dep_nom": sans_article(cfg.get("nom_departement") or self.dep),
                     "reg_nom": sans_article(cfg.get("nom_region") or self.reg), "options": options}

    def src(self, sid):
        from .collecte.sources import Sources
        return Sources(self.client, self.cache, _log_source(catalogue.SOURCES[sid][0]),
                       forcer=sid in self.forcer and not self.hors_ligne)

    def codes(self):
        return self.brut.get("codes") or sorted({l["code_commune"] for l in
                                                 (self.brut.get("urssaf") or {}).get("detail", [])
                                                 if l.get("code_commune")})


# ================================================================================================ collecteurs
def _geo(c):
    from .collecte.geo import charger_geo
    com, epcis = charger_geo(c.cfg, c.client.s, "geo" in c.forcer, c.hors_ligne)
    c.brut["com"], c.brut["epcis"] = com, epcis
    sel = com[com.code_epci == c.siren]
    c.brut["codes"] = sorted(sel.code)
    pts = sel.geometry.representative_point()
    c.brut["centres"] = {k: (round(p.x, 5), round(p.y, 5)) for k, p in zip(sel.code, pts)}
    c.brut["fc_epci"] = json.loads(sel[["code", "nom", "population", "geometry"]].to_json(na="null"))
    try:  # fichier brut : garde les codes postaux (rattachement des procédures collectives à l'EPCI)
        from .utils import CACHE
        fc = json.loads((CACHE / "communes_region.geojson").read_text(encoding="utf-8"))
        feats = [f for f in fc["features"] if (f.get("properties") or {}).get("codeEpci") == c.siren]
        if feats:
            c.brut["fc_epci"] = {"type": "FeatureCollection", "features": feats}
    except Exception:
        pass
    log("Contours des communes", f"{len(sel)} communes dans l'EPCI étudié", "ok")


def _urssaf(c):
    from .collecte import urssaf
    c.brut["urssaf"] = urssaf.charger(c.src("urssaf"), c.cfg, c.siren, _log_source("Urssaf"))


def _urssaf_masse(c):
    c.brut["masse"] = c.src("urssaf_masse").masse_salariale()


def _ofgl(c):
    annees = (c.brut.get("urssaf") or {}).get("annees") or [datetime.now().year - 2]
    c.brut["pop"] = c.src("ofgl").population(annees[-1])
    log("Population des EPCI", f"population connue pour {len(c.brut['pop'])} EPCI", "ok")


def _insee(c):
    from .collecte.insee import charger_insee, exporter_catalogue
    df = charger_insee(c.cfg, c.client.s, "insee" in c.forcer, c.hors_ligne)
    c.brut["insee"] = df
    try:
        exporter_catalogue(df, c.siren, c.cfg["nom_court"])
    except Exception as e:  # le catalogue des indicateurs est un plus, pas une étape bloquante
        log("Dossier complet", f"catalogue des indicateurs non produit ({e})", "info")


def _grille(c):
    from .collecte.spheres import charger_grille
    c.brut["grille"] = charger_grille(c.client.s, c.hors_ligne, "grille" in c.forcer)


def _ircom(c):
    from .collecte.ircom import charger_ircom
    c.brut["ircom"] = charger_ircom(c.cfg, c.client.s, "ircom" in c.forcer, c.hors_ligne)


def _tourisme(c):
    c.brut["tourisme"] = c.src("tourisme").tourisme()
    t = c.brut["tourisme"].get(c.siren)
    if t:
        log("Capacités touristiques", f"EPCI : {t['chambres_hotel']:.0f} chambres d'hôtel, "
                                      f"{t['emplacements_camping']:.0f} emplacements de camping, "
                                      f"{t['lits']:.0f} lits marchands", "ok")


def _littoral(c):
    c.brut["littoral"] = c.src("littoral").littoral()


def _rs_epci(c):
    codes = sorted({l["code_epci"] for l in (c.brut.get("urssaf") or {}).get("epci", []) if l.get("code_epci")})
    c.brut["rs"] = {k: tuple(v) for k, v in c.src("rs_epci").residences_secondaires(codes).items()}
    log("Résidences secondaires", f"connues pour {len(c.brut['rs'])} EPCI", "ok")


def _flores(c):
    c.brut["flores"] = c.src("flores").flores(c.siren, c.dep)


def _side(c):
    c.brut["creations"] = c.src("side").creations(c.siren, c.dep)


def _mobilites(c):
    c.brut["mobilites"] = c.src("mobilites").mobilites(c.siren, c.codes())


def _bmo(c):
    c.brut["bmo"] = c.src("bmo").bmo()


def _ft(c):
    c.brut["ft"] = c.src("ft").france_travail(c.siren, c.nom, c.dep, c.reg)
    e = (c.brut["ft"].get("territoires") or {}).get("EPCI") or {}
    log("France Travail", f"EPCI : {e.get('de_abc')} demandeurs A, B, C ({e.get('periode_de')}), "
                          f"{e.get('offres_12m')} offres sur 12 mois", "ok")


def _bassin(c):
    from .collecte import bmo
    bassins = bmo.bassins(c.brut.get("bmo") or {}, c.dep) if c.brut.get("bmo") else {}
    b = c.options.get("bassin")
    return b if b in bassins else next(iter(bassins), None)


def _ft_tensions(c):
    from .collecte import bmo
    b = _bassin(c)
    if not b:
        raise RuntimeError("enquête BMO indisponible : liste des métiers inconnue")
    an = bmo.analyser(c.brut["bmo"], b, c.dep, c.reg)
    c.brut["ft_tensions"] = c.src("ft_tensions").ft_tensions(b, c.dep, an["metiers"])
    log("Difficultés de recrutement", f"{len(c.brut['ft_tensions'].get('tensions') or [])} métiers renseignés", "ok")


def _sirene(c):
    from .collecte import sirene
    bruts = c.src("sirene").employeurs(c.siren, c.codes())
    actifs, comptes = sirene.etat_actuel(bruts, _log_source("Employeurs"))
    ape = sirene.libelles_ape((c.brut.get("urssaf") or {}).get("detail", []))
    c.brut["employeurs"] = sirene.mettre_en_forme(actifs, ape)
    c.brut["employeurs_tous"] = sirene.mettre_en_forme(bruts, ape)
    sy = sirene.synthese(c.brut["employeurs"])
    fermes = sum(n for (e, _), n in comptes.items() if e == "F")
    log("Employeurs", f"{sy['total']} employeurs actifs ({sy['geolocalises']} localisés) ; {fermes} établissements "
                      f"fermés écartés", "ok")


def _sirene_demo(c):
    annees = list(range(2015, datetime.now().year))
    c.brut["sirene_demo"] = c.src("sirene_demo").sirene_demographie(c.siren, c.codes(), annees)


def _bodacc(c):
    annees = [str(a) for a in range(2016, datetime.now().year + 1)]
    c.brut["bodacc"] = c.src("bodacc").bodacc(c.dep, annees)


def _lbb(c):
    from .collecte import labonneboite as lbb
    from .collecte.francetravail import ClientFT, MDT
    romes = dict(c.options.get("lbb_metiers") or {})
    if c.options.get("lbb_bmo") and c.brut.get("bmo"):  # métiers qui recrutent le plus dans le bassin
        from .collecte import bmo
        b = _bassin(c)
        try:
            an = bmo.analyser(c.brut["bmo"], b, c.dep, c.reg)
            table = c.cache.lire("ft_rome_fap", 180)[0]
            if table is None:  # correspondance FAP -> ROME, mise en cache (utile aussi hors ligne)
                table = ClientFT(c.client, _log_source("La Bonne Boite")).get(
                    MDT, "/v1/referentiel/rechercherActivitesRomeFap") or {}
                if table.get("romeFapList"):
                    c.cache.ecrire("ft_rome_fap", table)
            par_fap = {}
            for x in table.get("romeFapList") or []:
                par_fap.setdefault(str(x.get("codeFap", ""))[:5], []).append(
                    (x.get("codeRome"), x.get("libelleRome") or x.get("libRome")))
            for m in an["metiers"][:12]:
                for rome, lib in par_fap.get(str(m.get("code_metier") or "")[:5], [])[:1]:
                    if rome:
                        romes.setdefault(rome, lib or m["metier"])
            log("La Bonne Boite", f"métiers BMO du bassin ajoutés : {len(romes)} métiers au total", "info")
        except Exception as e:
            log("La Bonne Boite", f"métiers BMO non convertis en codes ROME ({str(e)[:120]})", "alerte")
    if not romes:
        romes = dict(lbb.METIERS_DEFAUT)
    if not c.brut.get("centres"):
        raise RuntimeError("contours des communes indisponibles : zone de recherche inconnue")
    empreinte = hashlib.md5(",".join(sorted(romes)).encode()).hexdigest()[:8]
    cle = f"lbb_{c.siren}_{empreinte}"
    d = None if "lbb" in c.forcer else c.cache.lire(cle, 30)[0]
    if d is None:
        if c.hors_ligne:
            raise RuntimeError("mode hors ligne : recherche La Bonne Boite absente du cache")
        d = lbb.rechercher(c.client.s, romes, c.brut["centres"], _log_source("La Bonne Boite"),
                           progression=lambda f, t: SUIVI.progression(f, t))
        c.cache.ecrire(cle, d)
    else:
        log("La Bonne Boite", f"résultat en cache ({len(d['items'])} entreprises x métiers)", "info")
    lbb.placer_sans_coordonnees(d["items"], c.brut["centres"])
    c.brut["lbb"] = d


def _anct(c):
    c.brut["anct"] = c.src("anct").anct()


COLLECTEURS = {"geo": _geo, "urssaf": _urssaf, "urssaf_masse": _urssaf_masse, "ofgl": _ofgl, "insee": _insee,
               "grille": _grille, "ircom": _ircom, "tourisme": _tourisme, "littoral": _littoral, "rs_epci": _rs_epci,
               "flores": _flores, "side": _side, "mobilites": _mobilites, "bmo": _bmo, "ft": _ft,
               "ft_tensions": _ft_tensions, "sirene": _sirene, "sirene_demo": _sirene_demo, "bodacc": _bodacc,
               "lbb": _lbb, "anct": _anct}
SORTIE = {"geo": "com", "urssaf": "urssaf", "urssaf_masse": "masse", "ofgl": "pop", "insee": "insee",
          "grille": "grille", "ircom": "ircom", "tourisme": "tourisme", "littoral": "littoral", "rs_epci": "rs",
          "flores": "flores", "side": "creations", "mobilites": "mobilites", "bmo": "bmo", "ft": "ft",
          "ft_tensions": "ft_tensions", "sirene": "employeurs", "sirene_demo": "sirene_demo", "bodacc": "bodacc",
          "lbb": "lbb", "anct": "anct"}


def cle_manquante(sid):
    from .collecte import sirene
    from .collecte.francetravail import lire_identifiants
    besoin = catalogue.SOURCES[sid][3]
    if besoin == "sirene" and not sirene.lire_cle():
        return "clé SIRENE absente (fichier cle_sirene.txt, onglet Paramètres)"
    if besoin == "ft" and not lire_identifiants()[0]:
        return "identifiants France Travail absents (onglet Paramètres)"
    return None


def collecter(themes, options=None, mode="normal", forcer=()):
    """Collecte les sources nécessaires aux thèmes. Ne lève pas d'exception pour une source en échec : elle est
    marquée « erreur » dans le suivi et les analyses qui en dépendent sont simplement absentes."""
    options = options or {}
    JOURNAL.clear()
    t0 = time.time()
    cfg = charger_config()
    plan = catalogue.plan(themes, options)
    SUIVI.preparer(plan)
    c = Contexte(cfg, options, mode, forcer)
    log("Collecte", f"{len(plan)} sources pour {len(themes)} thèmes (mode {mode.replace('_', ' ')})", "info")
    for etape in plan:
        sid = etape["id"]
        manque = cle_manquante(sid)
        dep_ko = [d for d in catalogue.SOURCES[sid][6] if c.brut.get(SORTIE[d]) is None and d not in ("geo",)]
        if sid in ("sirene", "sirene_demo", "mobilites") and not c.codes():
            dep_ko = dep_ko or ["geo"]
        if manque or dep_ko:
            msg = manque or ("source préalable indisponible : " + ", ".join(catalogue.SOURCES[d][0] for d in dep_ko))
            SUIVI.ignorer(sid, msg)
            log(etape["libelle"], f"non interrogée : {msg}", "alerte")
            continue
        SUIVI.debut(sid)
        try:
            COLLECTEURS[sid](c)
            SUIVI.fin(sid)
        except Exception as e:
            log(etape["libelle"], f"indisponible : {str(e)[:300]}", "erreur")
            log(etape["libelle"], traceback.format_exc()[-1500:], "info")
            SUIVI.fin(sid, "erreur", str(e)[:200])
    c.brut["duree_collecte"] = time.time() - t0
    c.brut["themes"] = list(themes)
    c.brut["journal_collecte"] = list(JOURNAL)
    log("Collecte", f"terminée en {c.brut['duree_collecte']:.0f} s", "ok")
    return c.brut


# ================================================================================================ analyses
def analyser(brut, themes, params):
    from .analyses.assemblage import assembler
    return assembler(brut, themes, params)

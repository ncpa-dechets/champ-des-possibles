"""Zonage : documents d'urbanisme et zones du Géoportail de l'Urbanisme.

Source : API Carto de l'IGN, module GPU (https://apicarto.ign.fr/api/gpu),
gratuite et sans clé. Couches utilisées à l'étape 1 :
- municipality : la commune relève-t-elle du RNU ?
- document     : document d'urbanisme applicable (PLUi, PLU, POS, CC, PSMV),
                 avec ses dates ;
- zone-urba    : zones des PLU et PLUi (U, AUc, AUs, A, N) ;
- secteur-cc   : secteurs des cartes communales (constructible ou non).

Principe :
1. pour chaque commune, document qui couvre un point situé à l'intérieur
   de la commune -> « partition » du document (DU_<insee> pour un PLU,
   DU_<siren> pour un PLUi) ;
2. zones téléchargées une fois par partition (1 000 objets par appel,
   pagination avec _start), cache local de 30 jours ;
3. chaque zone est découpée selon les limites communales (shapely), puis
   sa surface est mesurée en Lambert-93 (m² exacts).

Chaque document n'est découpé que sur les communes qui lui sont rattachées
(pas de double compte). Limite : une commune nouvelle couverte par
plusieurs documents (un par ancienne commune) n'est rattachée qu'au
document de son point intérieur ; le journal le signale.
"""
import json
import os
import time

from shapely import make_valid
from shapely.geometry import mapping, shape
from shapely.ops import transform
from shapely.strtree import STRtree

from . import geometrie as G
from . import reseau
from .chemins import dossier_application

API = "https://apicarto.ign.fr/api/gpu"
LIMITE = 1000
DUREE_CACHE = 30 * 24 * 3600
TYPES_DU = ("PLUi", "PLU", "POS", "CC", "PSMV")

# Familles de zones (couleurs inspirées du standard CNIG)
FAMILLES = [("U", "Urbaine (U)", "#C8323C"), ("AUc", "À urbaniser ouverte (AUc)", "#F08C3C"),
            ("AUs", "À urbaniser fermée (AUs)", "#F5BE82"), ("A", "Agricole (A)", "#E8D44D"),
            ("N", "Naturelle (N)", "#6FA84F"), ("ZC", "Constructible (carte communale)", "#D46A6A"),
            ("ZnC", "Non constructible (carte communale)", "#A9C98F"), ("autre", "Autre", "#9A9A90")]
LIB_FAMILLE = {k: l for k, l, _c in FAMILLES}


def famille(typezone):
    t = str(typezone or "").strip()
    tl = t.lower()
    if tl.startswith("auc") or tl == "au":
        return "AUc"
    if tl.startswith("aus"):
        return "AUs"
    if tl.startswith("u"):
        return "U"
    if tl.startswith("znc"):
        return "ZnC"
    if tl.startswith("zc"):
        return "ZC"
    if tl.startswith("a"):
        return "A"
    if tl.startswith("n"):
        return "N"
    return "autre"


def famille_secteur(typesect):
    """Cartes communales (standard CNIG) : 01, 02, 03 constructibles ; 99 non constructible."""
    t = str(typesect or "").strip()
    if t in ("01", "1", "02", "2", "03", "3") or t.lower().startswith("zc"):
        return "ZC"
    if t in ("99",) or t.lower().startswith("znc"):
        return "ZnC"
    return "autre"


# ------------------------------------------------------------------ appels
def _cache(nom):
    d = os.path.join(dossier_application(), "cache_zonage")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, nom)


def _lire_cache(nom, duree):
    c = _cache(nom)
    if os.path.exists(c) and time.time() - os.path.getmtime(c) < duree:
        try:
            with open(c, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            pass
    return None


def _ecrire_cache(nom, donnees):
    try:
        with open(_cache(nom), "w", encoding="utf-8") as f:
            json.dump(donnees, f, ensure_ascii=False)
    except OSError:
        pass


def appel(couche, params, stop_event=None):
    rep = reseau.get(f"{API}/{couche}", params=params, stop_event=stop_event)
    if not isinstance(rep, dict):
        raise reseau.ErreurSource(f"API Carto GPU ({couche}) : réponse inattendue")
    return rep.get("features", []) or []


def toutes_les_pages(couche, params, stop_event=None, journal=print):
    """Pagination _start / _limit ; s'arrête si l'API renvoie des objets déjà vus."""
    objets, vus, debut = [], set(), 0
    while True:
        page = appel(couche, dict(params, _limit=LIMITE, _start=debut), stop_event)
        nouveaux = 0
        for f in page:
            cle = f.get("id") or json.dumps(f.get("properties", {}), sort_keys=True)[:300]
            if cle not in vus:
                vus.add(cle)
                objets.append(f)
                nouveaux += 1
        if len(page) < LIMITE or nouveaux == 0:
            break
        debut += LIMITE
        journal(f"      {len(objets)} objets reçus, page suivante...")
        reseau.pause(0.2, stop_event)
    return objets


# ------------------------------------------------------------------ documents
def _premier(props, *cles):
    for c in cles:
        v = props.get(c)
        if v not in (None, ""):
            return v
    return None


def resume_document(props):
    """Champs lisibles d'un document GPU (noms variables selon les versions de l'API)."""
    return {
        "type": _premier(props, "du_type", "typedoc", "type"),
        "partition": props.get("partition"),
        "nom": _premier(props, "grid_title", "nom", "title", "libelle", "name"),
        "approbation": _premier(props, "datappro", "date_appro", "approval_date"),
        "validite": _premier(props, "datvalid", "date_valid"),
        "etat": _premier(props, "etat", "state", "gpu_status", "statut"),
        "maj": _premier(props, "gpu_timestamp", "update_date", "datemaj"),
        "idurba": props.get("idurba"),
        "tous": {k: v for k, v in props.items() if not isinstance(v, (dict, list))},
    }


def documents_communes(communes, contours, stop_event=None, journal=print):
    """{code: {statut, document (résumé) ou None, rnu}}."""
    cache = _lire_cache("documents.json", 7 * 24 * 3600)
    if cache and all(c["code"] in cache for c in communes):
        journal("   documents d'urbanisme : cache du jour (7 jours)")
        return cache
    formes = {str(f["properties"]["code"]): shape(f["geometry"]) for f in contours.get("features", [])}
    resultat = {}
    for i, c in enumerate(communes, start=1):
        reseau.verifier_annulation(stop_event)
        code = c["code"]
        rnu = None
        try:
            m = appel("municipality", {"insee": code}, stop_event)
            if m:
                rnu = bool(m[0].get("properties", {}).get("is_rnu"))
        except reseau.ErreurSource as exc:
            journal(f"      {c['nom']} : statut RNU inconnu ({exc})")
        doc = None
        forme = formes.get(code)
        if forme is not None and not rnu:
            pt = forme.representative_point()
            geom = json.dumps({"type": "Point", "coordinates": [round(pt.x, 6), round(pt.y, 6)]})
            docs = [resume_document(f.get("properties", {})) for f in appel("document", {"geom": geom}, stop_event)]
            docs = [d for d in docs if str(d["type"] or "").upper() in [t.upper() for t in TYPES_DU]]
            ordre = {t.upper(): k for k, t in enumerate(TYPES_DU)}
            docs.sort(key=lambda d: ordre.get(str(d["type"]).upper(), 9))
            doc = docs[0] if docs else None
        statut = "RNU" if rnu else (str(doc["type"]) if doc else "Aucun document en ligne")
        resultat[code] = {"statut": statut, "document": doc, "rnu": rnu}
        reseau.avancement(i / len(communes))
        if i % 10 == 0:
            journal(f"      {i} / {len(communes)} communes interrogées")
        reseau.pause(0.1, stop_event)
    _ecrire_cache("documents.json", resultat)
    return resultat


# ------------------------------------------------------------------ zones
def zones_partition(partition, type_doc, stop_event=None, journal=print):
    nom = f"zones_{partition}.json"
    cache = _lire_cache(nom, DUREE_CACHE)
    if cache is not None:
        journal(f"   {partition} : {len(cache)} zones (cache)")
        return cache
    couche = "secteur-cc" if str(type_doc).upper() == "CC" else "zone-urba"
    journal(f"   {partition} : téléchargement des zones ({couche})...")
    objets = toutes_les_pages(couche, {"partition": partition}, stop_event, journal)
    journal(f"      {len(objets)} zones reçues")
    _ecrire_cache(nom, objets)
    return objets


def _vers_l93(geom):
    """shapely transform appelle la fonction coordonnée par coordonnée si on passe des scalaires."""
    def f(xs, ys, zs=None):
        try:
            pts = [G.wgs84_vers_lambert93(x, y) for x, y in zip(xs, ys)]
            return [p[0] for p in pts], [p[1] for p in pts]
        except TypeError:
            return G.wgs84_vers_lambert93(xs, ys)
    return transform(f, geom)


def decouper(zones_brutes, contours, codes, documents, simplification=0.00002, journal=print):
    """Découpe les zones par commune. -> (morceaux GeoJSON, surfaces par commune et famille)."""
    communes_formes = {}
    for f in contours.get("features", []):
        code = str(f["properties"]["code"])
        if code in codes:
            communes_formes[code] = make_valid(shape(f["geometry"]))
    morceaux, surfaces, alertes = [], {code: {} for code in codes}, []
    surf_commune = {code: _vers_l93(g).area / 10000 for code, g in communes_formes.items()}
    for partition, (type_doc, objets) in zones_brutes.items():
        geoms, props = [], []
        for o in objets:
            try:
                g = make_valid(shape(o["geometry"]))
            except Exception:
                continue
            if not g.is_empty:
                geoms.append(g)
                props.append(o.get("properties", {}))
        if not geoms:
            continue
        arbre = STRtree(geoms)
        for code, cforme in communes_formes.items():
            doc = (documents.get(code) or {}).get("document") or {}
            if doc.get("partition") != partition:
                # zones d'un document qui n'est pas celui de la commune : on ne les compte pas,
                # mais on signale un recouvrement notable (commune nouvelle, document partiel...)
                recouvre = sum(geoms[int(i)].intersection(cforme).area for i in arbre.query(cforme))
                if recouvre and _vers_l93(cforme).area and recouvre / cforme.area > 0.05:
                    alertes.append(code)
                continue
            for idx in arbre.query(cforme):
                g = geoms[int(idx)]
                inter = g.intersection(cforme)
                if inter.is_empty:
                    continue
                inter = inter if inter.geom_type in ("Polygon", "MultiPolygon") else \
                    make_valid(inter.buffer(0)) if inter.geom_type == "GeometryCollection" else None
                if inter is None or inter.is_empty or inter.geom_type not in ("Polygon", "MultiPolygon"):
                    continue
                ha = _vers_l93(inter).area / 10000
                if ha < 0.01:          # éclats de découpage le long des limites communales
                    continue
                p = props[int(idx)]
                typezone = p.get("typezone") or p.get("typesect") or ""
                fam = famille_secteur(p.get("typesect")) if p.get("typesect") and not p.get("typezone") \
                    else famille(typezone)
                s = surfaces[code].setdefault(fam, {"ha": 0.0, "detail": {}})
                s["ha"] += ha
                lib = p.get("libelle") or typezone or "?"
                s["detail"][lib] = s["detail"].get(lib, 0.0) + ha
                simple = inter.simplify(simplification, preserve_topology=True)
                morceaux.append({"type": "Feature", "geometry": _arrondir(mapping(simple)), "properties": {
                    "commune_code": code, "partition": partition, "type_document": type_doc,
                    "libelle": p.get("libelle"), "libelong": p.get("libelong"), "typezone": typezone,
                    "famille": fam, "famille_lib": LIB_FAMILLE[fam], "surface_ha": round(ha, 3),
                    "destination": p.get("destdomi"), "reglement_url": p.get("urlfic"),
                    "date_approbation": p.get("datappro")}})
    return morceaux, surfaces, surf_commune, sorted(set(alertes))


def _arrondir(geom):
    def r(c):
        if isinstance(c, (list, tuple)) and c and isinstance(c[0], (int, float)):
            return [round(c[0], 6), round(c[1], 6)]
        return [r(x) for x in c]
    return {"type": geom["type"], "coordinates": r(geom["coordinates"])}


# ------------------------------------------------------------------ enchaînement
def extraire(communes, codes, nom_epci, contours, stop_event=None, journal=print):
    choisies = [c for c in communes if c["code"] in codes]
    journal(f"   recherche du document d'urbanisme de {len(choisies)} commune(s)...")
    with reseau.etape(0, 0.45, "Recherche des documents d'urbanisme"):
        docs = documents_communes(choisies, contours, stop_event, journal)
    partitions = {}
    for code in codes:
        d = docs.get(code, {}).get("document")
        if d and d.get("partition"):
            partitions[d["partition"]] = d["type"]
    bilan = {}
    for code in codes:
        bilan[docs[code]["statut"]] = bilan.get(docs[code]["statut"], 0) + 1
    journal("   " + " · ".join(f"{k} : {v}" for k, v in sorted(bilan.items())))
    zones_brutes = {}
    for k, (partition, type_doc) in enumerate(partitions.items()):
        reseau.verifier_annulation(stop_event)
        with reseau.etape(0.45 + 0.35 * k / len(partitions), 0.45 + 0.35 * (k + 1) / len(partitions),
                          "Téléchargement des zones"):
            zones_brutes[partition] = (type_doc, zones_partition(partition, type_doc, stop_event, journal))
    journal("   découpage des zones selon les limites communales et calcul des surfaces...")
    reseau.avancement(0.82, "Découpage des zones par commune")
    morceaux, surfaces, surf_commune, alertes = decouper(zones_brutes, contours, codes, docs, journal=journal)
    noms = {c["code"]: c["nom"] for c in communes}
    for m in morceaux:
        m["properties"]["commune"] = noms.get(m["properties"]["commune_code"], "")
    lignes = []
    for code in sorted(codes, key=lambda c: noms.get(c, c)):
        d = docs[code]
        ligne = {"niveau": "Commune", "code": code, "nom": noms.get(code, code), "statut": d["statut"],
                 "document": d["document"], "surface_commune": surf_commune.get(code)}
        for fam, _l, _c in FAMILLES:
            ligne[fam] = surfaces[code].get(fam, {}).get("ha", 0.0)
        ligne["zone"] = sum(ligne[f] for f, _l, _c in FAMILLES)
        lignes.append(ligne)
    if len(codes) > 1:
        tot = {"niveau": "EPCI" if len(codes) == len(communes) else "Sélection", "code": "TOTAL",
               "nom": nom_epci if len(codes) == len(communes) else f"Sélection ({len(codes)} communes)",
               "statut": "", "document": None,
               "surface_commune": sum(l["surface_commune"] or 0 for l in lignes)}
        for fam, _l, _c in FAMILLES + [("zone", "", "")]:
            tot[fam] = sum(l[fam] for l in lignes)
        lignes.append(tot)
    if alertes:
        journal("   ATTENTION : d'autres documents recouvrent en partie " + ", ".join(noms.get(a, a) for a in alertes)
                + " (commune nouvelle couverte par plusieurs documents ?). Seul le document principal est compté.")
    journal(f"   {len(morceaux)} morceaux de zones sur {len(codes)} commune(s)")
    return {"lignes": lignes, "zones": {"type": "FeatureCollection", "features": morceaux},
            "documents": {code: docs[code] for code in codes},
            "details": {code: {f: surfaces[code][f]["detail"] for f in surfaces[code]} for code in codes},
            "date": time.strftime("%d/%m/%Y")}


def diagnostic(code, nom, contours, stop_event=None, journal=print):
    """Teste chaque couche sur une commune et affiche les champs reçus."""
    journal(f"Diagnostic sur {nom} ({code})...")
    try:
        m = appel("municipality", {"insee": code}, stop_event)
        journal(f"  OK      municipality : {json.dumps(m[0].get('properties', {}), ensure_ascii=False)[:300] if m else 'aucune réponse'}")
    except reseau.ErreurSource as exc:
        journal(f"  ÉCHEC   municipality : {exc}")
    forme = next((shape(f["geometry"]) for f in contours.get("features", [])
                  if str(f["properties"]["code"]) == code), None)
    if forme is None:
        journal("  ÉCHEC   contour de la commune indisponible")
        return
    pt = forme.representative_point()
    try:
        docs = appel("document", {"geom": json.dumps({"type": "Point", "coordinates": [pt.x, pt.y]})}, stop_event)
        journal(f"  OK      document : {len(docs)} document(s)")
        for d in docs:
            journal(f"          champs : {json.dumps(d.get('properties', {}), ensure_ascii=False)[:400]}")
        part = next((resume_document(d.get("properties", {}))["partition"] for d in docs
                     if str(resume_document(d.get("properties", {}))["type"]).upper() in [t.upper() for t in TYPES_DU]), None)
        if part:
            z = appel("zone-urba", {"partition": part, "_limit": 2}, stop_event)
            journal(f"  OK      zone-urba ({part}) : exemple de champs : "
                    f"{json.dumps(z[0].get('properties', {}), ensure_ascii=False)[:400] if z else 'aucune zone'}")
    except reseau.ErreurSource as exc:
        journal(f"  ÉCHEC   {exc}")

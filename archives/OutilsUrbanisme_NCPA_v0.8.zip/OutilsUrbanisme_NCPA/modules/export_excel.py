"""Export Excel du thème « Consommation d'espaces » (openpyxl, sans pandas).

Onglets : Synthèse ZAN · Annuel (ha) · Par destination · Lisez-moi.
Les nombres restent des nombres (triables, utilisables dans des formules).
"""
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from . import conso_enaf as C

NAVY = "1B3A5C"
GRIS = "E8EEF5"
ENTETE = Font(bold=True, color="FFFFFF")
FOND_ENTETE = PatternFill("solid", fgColor=NAVY)
FOND_COMPARAISON = PatternFill("solid", fgColor=GRIS)

COLONNES_SYNTHESE = [
    ("nom", "Territoire", 34, None),
    ("niveau", "Niveau", 12, None),
    ("surface", "Surface (ha)", 12, "#,##0"),
    ("ref_ha", "Conso. 2011-2021 (ha)", 14, "#,##0.0"),
    ("ref_rythme", "Rythme 2011-2021 (ha/an)", 14, "#,##0.00"),
    ("ref_hab_part", "Part habitat 2011-2021 (%)", 14, "0"),
    ("rec_ha", "Conso. depuis 2021 (ha)", 14, "#,##0.0"),
    ("rec_rythme", "Rythme depuis 2021 (ha/an)", 14, "#,##0.00"),
    ("evolution", "Évolution du rythme (%)", 13, "+0;-0;0"),
    ("enveloppe", "Enveloppe indicative 2021-2031 (ha)", 16, "#,##0.0"),
    ("part_enveloppe", "Part de l'enveloppe déjà consommée (%)", 16, "0"),
    ("part_surface", "Conso. 2011-2021 / surface (%)", 14, "0.00"),
]


def _entete(ws, ligne, valeurs, largeurs=None):
    for j, v in enumerate(valeurs, start=1):
        c = ws.cell(row=ligne, column=j, value=v)
        c.font, c.fill = ENTETE, FOND_ENTETE
        c.alignment = Alignment(wrap_text=True, vertical="center")
        if largeurs:
            ws.column_dimensions[get_column_letter(j)].width = largeurs[j - 1]
    ws.row_dimensions[ligne].height = 45
    ws.freeze_panes = ws.cell(row=ligne + 1, column=2)


def exporter(chemin, resultat, params):
    territoires, annees = resultat["territoires"], resultat["annees"]
    dests = resultat["destinations"]
    wb = Workbook()

    # ---- Synthèse
    ws = wb.active
    ws.title = "Synthèse ZAN"
    _entete(ws, 1, [c[1] for c in COLONNES_SYNTHESE], [c[2] for c in COLONNES_SYNTHESE])
    for i, t in enumerate(territoires, start=2):
        for j, (cle, _lib, _l, fmt) in enumerate(COLONNES_SYNTHESE, start=1):
            v = t.get(cle) if cle in ("nom", "niveau", "surface") else t["synthese"].get(cle)
            if isinstance(v, float):
                v = round(v, 4)
            cell = ws.cell(row=i, column=j, value=v)
            if fmt:
                cell.number_format = fmt
            if t["niveau"] != "Commune":
                cell.fill = FOND_COMPARAISON
                cell.font = Font(bold=True)
    ws.auto_filter.ref = f"A1:{get_column_letter(len(COLONNES_SYNTHESE))}{len(territoires) + 1}"

    # ---- Annuel
    ws = wb.create_sheet("Annuel (ha)")
    _entete(ws, 1, ["Territoire", "Niveau"] + [f"{a}-{a + 1}" for a in annees],
            [34, 12] + [10] * len(annees))
    for i, t in enumerate(territoires, start=2):
        ws.cell(row=i, column=1, value=t["nom"])
        ws.cell(row=i, column=2, value=t["niveau"])
        for j, a in enumerate(annees, start=3):
            c = ws.cell(row=i, column=j, value=round(t["flux"][a]["total"], 4))
            c.number_format = "#,##0.00"
        if t["niveau"] != "Commune":
            for j in range(1, len(annees) + 3):
                ws.cell(row=i, column=j).fill = FOND_COMPARAISON
    derniere = ws.cell(row=len(territoires) + 3, column=1,
                       value=f"La dernière année ({annees[-1]}-{annees[-1] + 1}) est provisoire : "
                             "elle sera révisée à la hausse lors des prochains millésimes.")
    derniere.font = Font(italic=True, color="5B6878")

    # ---- Par destination (format long, pratique pour un tableau croisé dynamique)
    ws = wb.create_sheet("Par destination")
    _entete(ws, 1, ["Territoire", "Niveau", "Période", "Année de début", "Destination", "Surface (ha)"],
            [34, 12, 12, 10, 16, 12])
    ligne = 2
    for t in territoires:
        for a in annees:
            for d in dests:
                ws.cell(row=ligne, column=1, value=t["nom"])
                ws.cell(row=ligne, column=2, value=t["niveau"])
                ws.cell(row=ligne, column=3, value=f"{a}-{a + 1}")
                ws.cell(row=ligne, column=4, value=a)
                ws.cell(row=ligne, column=5, value=C.LIB_DEST[d])
                ws.cell(row=ligne, column=6, value=round(t["flux"][a][d], 4)).number_format = "#,##0.00"
                ligne += 1
    ws.auto_filter.ref = f"A1:F{ligne - 1}"

    # ---- Lisez-moi
    ws = wb.create_sheet("Lisez-moi")
    ws.column_dimensions["A"].width = 32
    ws.column_dimensions["B"].width = 110
    meta = resultat["meta"]
    lignes = [
        ("Source", "Cerema, consommation d'espaces naturels, agricoles et forestiers (ENAF), "
                   "d'après les Fichiers fonciers · data.gouv.fr · Licence Ouverte 2.0"),
        ("Millésime", f"{meta.get('millesime')} · {meta.get('titre', '')}"),
        ("Fichier", f"{meta.get('url', '')} (récupéré le {meta.get('date', '?')})"),
        ("Communes", params.get("communes", "")),
        ("Extraction", params.get("date", "")),
        ("", ""),
        ("Définition", "Consommation d'ENAF : création ou extension effective d'espaces urbanisés "
                       "(article 194 de la loi Climat et résilience). Mesurée par le changement de "
                       "nature fiscale des parcelles, au commencement des travaux."),
        ("Lecture d'une année", "« 2021-2022 » = flux entre le 1er janvier 2021 et le 1er janvier 2022."),
        ("Période de référence", "2011-2021 : flux du 1/1/2011 au 1/1/2021 (10 ans)."),
        ("Enveloppe indicative", "50 % de la consommation 2011-2021, soit l'objectif national de la "
                                 "première tranche 2021-2031. L'enveloppe réellement opposable est fixée par "
                                 "le SRADDET de Normandie puis le SCoT : ce chiffre est un repère, pas une "
                                 "obligation chiffrée pour la commune."),
        ("Dernière année", "Provisoire : les consommations sont souvent enregistrées avec retard. "
                           "Le Cerema indique qu'il faut environ 3 ans pour que les chiffres se stabilisent."),
        ("Destinations", "Habitat, activité, mixte, routes, voies ferrées, non renseigné."),
    ]
    for i, (a, b) in enumerate(lignes, start=1):
        ws.cell(row=i, column=1, value=a).font = Font(bold=True, color=NAVY)
        c = ws.cell(row=i, column=2, value=b)
        c.alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(chemin)

# -*- coding: utf-8 -*-
"""API La Bonne Boite v2 (France Travail) : entreprises susceptibles d'embaucher, par métier (code ROME).

D'après la documentation relevée en octobre 2026 (non vérifié en réel avec ces identifiants) :
  - GET https://api.francetravail.io/partenaire/labonneboite/v2/recherche ;
  - paramètres : rome (code ROME), citycode (code Insee d'une commune) avec distance (km, 200 au plus),
    page, page_size (100 au plus) ;
  - réponse : hits, puis items[] (SIRET, raison sociale, effectif, NAF, ROME, lieu, hiring_potential de 0 à 100,
    is_high_potential) ; aucune coordonnée de contact ;
  - 2 appels par seconde ; données mises à jour chaque mois ;
  - un scope non accordé fait échouer tout le jeton : La Bonne Boite a donc son propre jeton, demandé à part de
    celui des API Marché du travail et Informations sur un territoire ;
  - licence ouverte, avec obligation de citer France Travail à côté des résultats.

Les noms de champs exacts n'étant pas confirmés, la lecture essaie plusieurs noms et enregistre la première réponse
brute dans cache/sonde_labonneboite.json : en cas de résultat vide ou incomplet, c'est ce fichier qu'il faut m'envoyer.
"""
import json
import math
import time

from ..utils import CACHE
from .francetravail import JETON_URL, lire_identifiants

URL = "https://api.francetravail.io/partenaire/labonneboite/v2/recherche"
SCOPES_ESSAIS = ["api_labonneboitev2 search office", "api_labonneboitev2", "api_labonneboitev2 search"]
DELAI = 0.55          # 2 appels par seconde au plus
PAGE = 100
MAX_PAGES = 10        # par métier : 1 000 entreprises au plus
SONDE = CACHE / "sonde_labonneboite.json"

# Métiers proposés par défaut (codes ROME) : métiers qui recrutent souvent sur un territoire littoral et touristique.
METIERS_DEFAUT = {
    "G1602": "Personnel de cuisine", "G1603": "Personnel polyvalent en restauration",
    "G1803": "Service en restauration", "G1703": "Réception en hôtellerie", "G1501": "Personnel d'étage",
    "D1106": "Vente en alimentation", "D1505": "Personnel de caisse", "D1507": "Mise en rayon libre-service",
    "D1102": "Boulangerie - viennoiserie", "K1302": "Assistance auprès d'adultes",
    "K1304": "Services domestiques", "J1501": "Soins d'hygiène, de confort du patient",
    "J1506": "Soins infirmiers généralistes", "K2204": "Nettoyage de locaux", "F1703": "Maçonnerie",
    "F1602": "Électricité bâtiment", "F1603": "Installation d'équipements sanitaires et thermiques",
    "A1203": "Aménagement et entretien des espaces verts", "I1203": "Maintenance des bâtiments et des locaux",
    "N1103": "Magasinage et préparation de commandes", "M1607": "Secrétariat",
    "G1204": "Éducation en activités sportives",
}


class ClientLBB:
    def __init__(self, session, log):
        self.s, self.log = session, log
        self.cid, self.secret = lire_identifiants()
        if not self.cid:
            raise RuntimeError("fichier identifiants_francetravail.txt absent ou incomplet")
        self.jeton, self.expiration, self.dernier, self.scope = None, 0, 0, None

    def _jeton(self):
        if self.jeton and time.time() < self.expiration - 60:
            return self.jeton
        dernier_msg = ""
        for scope in ([self.scope] if self.scope else SCOPES_ESSAIS):
            r = self.s.post(JETON_URL, params={"realm": "/partenaire"}, timeout=60,
                            data={"grant_type": "client_credentials", "client_id": self.cid,
                                  "client_secret": self.secret, "scope": scope})
            if r.status_code == 200:
                js = r.json()
                self.jeton, self.scope = js["access_token"], scope
                self.expiration = time.time() + int(js.get("expires_in", 1400))
                return self.jeton
            dernier_msg = f"HTTP {r.status_code} : {r.text[:150]}"
        raise RuntimeError("jeton La Bonne Boite refusé : l'application francetravail.io est-elle abonnée à "
                           f"« La Bonne Boite v2 » ? ({dernier_msg})")

    def get(self, params):
        for essai in range(4):
            attente = self.dernier + DELAI - time.time()
            if attente > 0:
                time.sleep(attente)
            r = self.s.get(URL, params=params, timeout=90,
                           headers={"Authorization": f"Bearer {self._jeton()}", "Accept": "application/json"})
            self.dernier = time.time()
            if r.status_code == 200:
                return r.json()
            if r.status_code in (204, 404):
                return None
            if r.status_code == 401:
                self.jeton = None
                continue
            if r.status_code == 429:  # trop d'appels : attendre ce que demande le serveur
                time.sleep(float(r.headers.get("Retry-After") or 2))
                continue
            if r.status_code in (400, 422):
                raise ValueError(f"HTTP {r.status_code} : {r.text[:200]}")
            time.sleep(2 * (essai + 1))
        raise RuntimeError(f"La Bonne Boite ne répond pas (HTTP {r.status_code})")


# ----------------------------------------------------------------------------- lecture défensive
def _cherche(d, *cles):
    for c in cles:
        x = d
        for morceau in c.split("."):
            x = x.get(morceau) if isinstance(x, dict) else None
        if x not in (None, "", []):
            return x
    return None


def _coord(it):
    lat, lon = _cherche(it, "location.lat", "lat", "latitude", "location.latitude", "coordinates.lat"), \
        _cherche(it, "location.lon", "location.lng", "lon", "lng", "longitude", "location.longitude")
    if lat is None:
        c = _cherche(it, "location.coordinates", "geometry.coordinates", "coordinates")
        if isinstance(c, (list, tuple)) and len(c) == 2:
            lon, lat = c
    try:
        return float(lat), float(lon)
    except (TypeError, ValueError):
        return None, None


def normaliser(it, rome, rome_lib):
    lat, lon = _coord(it)
    pot = _cherche(it, "hiring_potential", "hiringPotential", "potentiel", "score", "stars")
    try:
        pot = float(pot)
    except (TypeError, ValueError):
        pot = None
    fort = _cherche(it, "is_high_potential", "isHighPotential", "high_potential")
    return {
        "siret": str(_cherche(it, "siret") or ""),
        "nom": _cherche(it, "company_name", "name", "raison_sociale", "raisonSociale", "nom", "enseigne") or "(sans nom)",
        "naf": _cherche(it, "naf", "naf_code", "codeNaf"),
        "activite": _cherche(it, "naf_label", "naf_text", "nafLabel", "naf_libelle", "libelleNaf"),
        "rome": rome, "metier": rome_lib or _cherche(it, "rome_label", "romeLabel") or rome,
        "effectif": _cherche(it, "headcount_text", "headcount", "headcount_range", "effectif", "tranche_effectif"),
        "commune": _cherche(it, "city", "ville", "commune", "location.city", "address.city"),
        "code_commune": str(_cherche(it, "citycode", "city_code", "code_commune", "insee", "location.citycode") or ""),
        "code_postal": _cherche(it, "postcode", "zipcode", "code_postal", "location.postcode"),
        "potentiel": pot, "fort_potentiel": bool(fort) if fort is not None else (pot is not None and pot >= 70),
        "distance_km": _cherche(it, "distance"), "lat": lat, "lon": lon,
        "url": _cherche(it, "url", "lbb_url"),
    }


def _items(js):
    if isinstance(js, list):
        return js, len(js)
    js = js or {}
    items = _cherche(js, "items", "results", "companies", "entreprises", "data") or []
    hits = _cherche(js, "hits", "total", "nbResults", "count")
    try:
        hits = int(hits)
    except (TypeError, ValueError):
        hits = None
    return items, hits


# ----------------------------------------------------------------------------- recherche
def distance_km(a, b):
    """Distance à vol d'oiseau entre deux points (lon, lat)."""
    r = 6371
    p1, p2 = math.radians(a[1]), math.radians(b[1])
    dp, dl = p2 - p1, math.radians(b[0] - a[0])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def zone_recherche(centres):
    """centres : {code commune: (lon, lat)} des communes de l'EPCI.
    -> (commune la plus centrale, rayon couvrant toutes les communes + 3 km)."""
    if not centres:
        return None, None
    lon = sum(c[0] for c in centres.values()) / len(centres)
    lat = sum(c[1] for c in centres.values()) / len(centres)
    pivot = min(centres, key=lambda k: distance_km(centres[k], (lon, lat)))
    rayon = max(distance_km(centres[pivot], c) for c in centres.values()) + 3
    return pivot, min(200, math.ceil(rayon))


def rechercher(session, romes, centres, log, progression=None):
    """romes : {code ROME: libellé}. centres : {code commune de l'EPCI: (lon, lat)}.
    -> {"items": [...], "pivot", "rayon", "requetes", "scope", "champs"} ; les entreprises hors EPCI sont écartées."""
    lbb = ClientLBB(session, log)
    pivot, rayon = zone_recherche(centres)
    if not pivot:
        raise RuntimeError("communes de l'EPCI inconnues (contours) : zone de recherche impossible à définir")
    log(f"      recherche autour de la commune {pivot}, rayon {rayon} km, {len(romes)} métiers")
    codes = set(centres)
    cle_rome, sonde_ecrite, n_req = "rome", False, 0
    trouves, hors, sans_lieu, champs = {}, 0, 0, []
    for i, (rome, lib) in enumerate(romes.items()):
        page = 1
        while page <= MAX_PAGES:
            params = {cle_rome: rome, "citycode": pivot, "distance": rayon, "page": page, "page_size": PAGE}
            try:
                js = lbb.get(params)
            except ValueError as e:
                if cle_rome == "rome" and page == 1:  # autre écriture du paramètre (tableau)
                    log(f"      paramètre « rome » refusé ({str(e)[:90]}) : essai avec « rome[] »")
                    cle_rome = "rome[]"
                    continue
                log(f"      {rome} : requête refusée ({str(e)[:120]})")
                break
            n_req += 1
            if js is not None and not sonde_ecrite:
                try:
                    SONDE.write_text(json.dumps({"parametres": params, "scope": lbb.scope, "reponse": js},
                                                ensure_ascii=False, indent=1)[:200000], encoding="utf-8")
                except OSError:
                    pass
                sonde_ecrite = True
            items, hits = _items(js)
            if items and not champs and isinstance(items[0], dict):
                champs = sorted(items[0].keys())
                log(f"      champs reçus : {', '.join(champs)[:300]}")
            for it in items:
                e = normaliser(it, rome, lib)
                cc = e["code_commune"]
                if cc and cc not in codes:
                    hors += 1
                    continue
                if not cc:
                    sans_lieu += 1
                cle = (e["siret"] or e["nom"], rome)
                trouves[cle] = e
            if len(items) < PAGE or (hits is not None and page * PAGE >= hits):
                break
            page += 1
        if progression:
            progression((i + 1) / len(romes), f"{i + 1}/{len(romes)} métiers : {lib}")
    items = sorted(trouves.values(), key=lambda e: (-(e["potentiel"] or 0), e["nom"]))
    log(f"      {len(items)} couples entreprise x métier dans l'EPCI ({n_req} requêtes ; {hors} résultats hors EPCI "
        f"écartés" + (f" ; {sans_lieu} sans code commune, gardés" if sans_lieu else "") + ")")
    if items and not any(e["lat"] is not None for e in items):
        log("      aucune coordonnée dans les réponses : entreprises placées au centre de leur commune")
    return {"items": items, "pivot": pivot, "rayon": rayon, "requetes": n_req, "scope": lbb.scope, "champs": champs}


def placer_sans_coordonnees(items, centres):
    """Entreprise sans coordonnées : placée au centre de sa commune, légèrement décalée pour rester cliquable."""
    for k, e in enumerate(items):
        if e["lat"] is None and e["code_commune"] in centres:
            lon, lat = centres[e["code_commune"]]
            ang = k * 2.39996
            e["lon"], e["lat"], e["position_approx"] = lon + .0025 * math.cos(ang), lat + .0018 * math.sin(ang), True
    return items


def tester(session, log, citycode="14117"):
    """Test de connexion : jeton dédié puis une recherche (enregistrée dans cache/sonde_labonneboite.json)."""
    lbb = ClientLBB(session, log)
    lbb._jeton()
    log(f"   OK  La Bonne Boite : jeton obtenu (scope « {lbb.scope} »)")
    js = lbb.get({"rome": "G1602", "citycode": citycode, "distance": 15, "page": 1, "page_size": 20})
    items, hits = _items(js)
    try:
        SONDE.write_text(json.dumps({"parametres": "test", "scope": lbb.scope, "reponse": js}, ensure_ascii=False,
                                    indent=1)[:200000], encoding="utf-8")
    except OSError:
        pass
    champs = ", ".join(sorted(items[0].keys())) if items and isinstance(items[0], dict) else "aucun résultat"
    log(f"   OK  La Bonne Boite : {hits if hits is not None else len(items)} résultats (champs : {champs[:200]})")

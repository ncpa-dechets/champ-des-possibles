# -*- coding: utf-8 -*-
"""Couche réseau commune à toutes les sources.

- SessionSuivie : session requests qui compte chaque appel (et les octets reçus) pour la source en cours de
  collecte : c'est ce qui alimente le tableau de progression de l'interface.
- Client : appels avec nouvelles tentatives et délai minimal par serveur (repris de l'outil Emploi).
- Cache : un fichier JSON daté par jeu de données, dans cache/ (repris de l'outil Emploi).
"""
import json
import os
import time
from datetime import datetime

import requests

from .utils import CACHE, SUIVI

VERSION = "1.0"
# Délai minimal entre deux appels au même serveur (secondes)
DELAIS = {"api.insee.fr": 2.1}


class SessionSuivie(requests.Session):
    hors_ligne = False  # mode « Hors ligne » : aucun appel ne part, seules les données en cache servent

    def __init__(self):
        super().__init__()
        self.headers["User-Agent"] = f"ObservatoireEcoEmploiNCPA/{VERSION} (collectivite)"

    def request(self, method, url, *args, **kwargs):
        if self.hors_ligne:
            raise requests.ConnectionError("mode hors ligne : donnée absente du cache")
        r = super().request(method, url, *args, **kwargs)
        n = 0
        if not kwargs.get("stream"):
            try:
                n = len(r.content or b"")
            except Exception:
                n = 0
        SUIVI.appel(n)
        return r


class Client:
    """Interface des modules de l'outil Emploi : get(url, params) -> JSON (ou réponse brute)."""

    def __init__(self, log=print, proxy=None):
        self.s = SessionSuivie()
        if proxy:
            self.s.proxies = {"http": proxy, "https": proxy}
        self.log = log
        self._dernier = {}

    def get(self, url, params=None, timeout=300, essais=3, brut=False, entetes=None):
        hote = url.split("/")[2]
        msg = ""
        for i in range(essais):
            attente = self._dernier.get(hote, 0) + DELAIS.get(hote, 0) - time.time()
            if attente > 0:
                time.sleep(attente)
            try:
                r = self.s.get(url, params=params, timeout=timeout, headers=entetes)
                self._dernier[hote] = time.time()
                if r.status_code == 200:
                    return r if brut else r.json()
                texte = r.text[:200]
                # page d'erreur HTML : le code suffit, le reste encombre le journal
                msg = f"HTTP {r.status_code}" + ("" if texte.lstrip().startswith("<") else f" : {texte}")
                if r.status_code in (400, 401, 403, 404):
                    break
            except requests.RequestException as e:
                msg = str(e)
            self.log(f"   nouvelle tentative ({i + 1}/{essais}) : {msg}")
            time.sleep(2 * (i + 1))
        raise RuntimeError(f"échec de l'appel à {hote} ({msg})")


class Cache:
    """Un fichier JSON par jeu de données, avec sa date de téléchargement."""

    def __init__(self, dossier=None):
        self.dossier = str(dossier or CACHE)
        os.makedirs(self.dossier, exist_ok=True)

    def chemin(self, cle):
        return os.path.join(self.dossier, f"{cle}.json")

    def lire(self, cle, age_max_jours):
        try:
            with open(self.chemin(cle), encoding="utf-8") as f:
                d = json.load(f)
            age = (datetime.now() - datetime.fromisoformat(d["date"])).days
            return (d["donnees"], d["date"][:10]) if age <= age_max_jours else (None, None)
        except (OSError, ValueError, KeyError):
            return None, None

    def date(self, cle):
        """Date du fichier de cache (sans le relire en entier), ou None."""
        p = self.chemin(cle)
        return datetime.fromtimestamp(os.path.getmtime(p)) if os.path.exists(p) else None

    def ecrire(self, cle, donnees):
        try:
            with open(self.chemin(cle), "w", encoding="utf-8") as f:
                json.dump({"date": datetime.now().isoformat(timespec="seconds"), "donnees": donnees},
                          f, ensure_ascii=False, separators=(",", ":"))
        except OSError:
            pass  # poste en lecture seule : on continue sans cache

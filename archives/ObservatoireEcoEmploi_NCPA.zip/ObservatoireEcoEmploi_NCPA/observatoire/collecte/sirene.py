# -*- coding: utf-8 -*-
"""Employeurs de l'EPCI via l'API SIRENE 3.11 (clé personnelle dans cle_sirene.txt, à côté de l'application).
Structure vérifiée par la sonde 2 du 30/09/2026 : en-tête X-INSEE-Api-Key-Integration, coordonnées Lambert 93.

v0.5 (sondes 5 et 5b du 20/10/2026) : periode(...) porte sur TOUTES les périodes de l'historique. La requête de la
v0.4 ramenait donc aussi des établissements fermés (2 586 sur 4 015 pour NCPA). Une recherche sur l'état actuel
(variable historisée hors periode) est refusée par l'API (erreur de syntaxe). On garde donc une requête large et on
lit l'état de la période en cours (la première de periodesEtablissement) pour ne conserver que les établissements
aujourd'hui actifs et employeurs."""
import math
import os

from ..utils import dossier_application

SIRENE = "https://api.insee.fr/api-sirene/3.11/siret"
CHAMPS = ("siret,siren,denominationUniteLegale,nomUniteLegale,prenomUsuelUniteLegale,denominationUsuelleEtablissement,"
          "enseigne1Etablissement,activitePrincipaleEtablissement,activitePrincipaleNAF25Etablissement,"
          "trancheEffectifsEtablissement,anneeEffectifsEtablissement,categorieEntreprise,etablissementSiege,"
          "dateCreationEtablissement,numeroVoieEtablissement,typeVoieEtablissement,libelleVoieEtablissement,"
          "codePostalEtablissement,codeCommuneEtablissement,libelleCommuneEtablissement,"
          "coordonneeLambertAbscisseEtablissement,coordonneeLambertOrdonneeEtablissement,statutDiffusionEtablissement,"
          "etatAdministratifEtablissement,caractereEmployeurEtablissement")

# Tranches d'effectif salarié (code Insee) : libellé, borne basse, borne haute
TRANCHES = {
    "00": ("0 salarié", 0, 0), "01": ("1 ou 2", 1, 2), "02": ("3 à 5", 3, 5), "03": ("6 à 9", 6, 9),
    "11": ("10 à 19", 10, 19), "12": ("20 à 49", 20, 49), "21": ("50 à 99", 50, 99), "22": ("100 à 199", 100, 199),
    "31": ("200 à 249", 200, 249), "32": ("250 à 499", 250, 499), "41": ("500 à 999", 500, 999),
    "42": ("1 000 à 1 999", 1000, 1999), "51": ("2 000 à 4 999", 2000, 4999), "52": ("5 000 à 9 999", 5000, 9999),
    "53": ("10 000 et plus", 10000, 10000),
}
FILTRES_TAILLE = {"Toutes les tailles": None, "Effectif connu": 0, "1 salarié et plus": 1, "10 salariés et plus": 10,
                  "50 salariés et plus": 50}


def lire_cle():
    for chemin in (os.path.join(dossier_application(), "cle_sirene.txt"), "cle_sirene.txt"):
        if os.path.exists(chemin):
            with open(chemin, encoding="utf-8-sig") as f:
                cle = f.read().strip()
            if cle:
                return cle
    return os.environ.get("SIRENE_CLE", "").strip() or None


def lambert93_vers_wgs84(x, y):
    """Projection Lambert 93 (RGF93) vers longitude, latitude en degrés (formules IGN, précision métrique)."""
    n, c, xs, ys = 0.7256077650532670, 11754255.426096, 700000.0, 12655612.049876
    e, lon0 = 0.08181919112824, math.radians(3)
    dx, dy = x - xs, y - ys
    r = math.hypot(dx, dy)
    gamma = math.atan(dx / -dy)
    lon = lon0 + gamma / n
    latiso = -1 / n * math.log(abs(r / c))
    lat = 2 * math.atan(math.exp(latiso)) - math.pi / 2
    for _ in range(12):
        lat = 2 * math.atan(((1 + e * math.sin(lat)) / (1 - e * math.sin(lat))) ** (e / 2) * math.exp(latiso)) \
              - math.pi / 2
    return math.degrees(lon), math.degrees(lat)


def _flottant(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def telecharger(client, cle, codes_communes, log):
    """Établissements ayant été actifs ET employeurs dans une même période de leur histoire, page par page (curseur).
    Contient des établissements aujourd'hui fermés : les trier ensuite avec etat_actuel()."""
    q = (f"codeCommuneEtablissement:({' OR '.join(codes_communes)}) AND "
         f"periode(etatAdministratifEtablissement:A AND caractereEmployeurEtablissement:O)")
    h = {"X-INSEE-Api-Key-Integration": cle, "Accept": "application/json"}
    tous, curseur, avec_champs = [], "*", True
    for page in range(1, 40):
        params = {"q": q, "nombre": 1000, "curseur": curseur}
        if avec_champs:
            params["champs"] = CHAMPS
        try:
            js = client.get(SIRENE, params, entetes=h, timeout=120)
        except RuntimeError as e:
            if avec_champs and page == 1 and "400" in str(e):
                log("      le filtre de champs est refusé : nouvel essai complet")
                avec_champs = False
                continue
            raise
        et = js.get("etablissements", [])
        tous += et
        hd = js.get("header", {})
        log(f"      page {page} : {len(tous)} / {hd.get('total')}")
        suivant = hd.get("curseurSuivant")
        if not et or not suivant or suivant == curseur:
            break
        curseur = suivant
    return tous


def etat_actuel(bruts, log=print):
    """Sépare les établissements selon leur période en cours. -> (actifs et employeurs, comptage par état).
    Si l'état n'est renseigné pour aucun établissement (champ absent de la réponse), tout est gardé et signalé."""
    comptes = {}
    for e in bruts:
        p = (e.get("periodesEtablissement") or [{}])[0]
        cle = (p.get("etatAdministratifEtablissement"), p.get("caractereEmployeurEtablissement"))
        comptes[cle] = comptes.get(cle, 0) + 1
    if bruts and all(k == (None, None) for k in comptes):
        log("      état actuel des établissements absent de la réponse : liste gardée telle quelle (à vérifier)")
        return list(bruts), comptes
    actifs = [e for e in bruts if ((e.get("periodesEtablissement") or [{}])[0].get("etatAdministratifEtablissement")
                                   == "A" and (e.get("periodesEtablissement") or [{}])[0]
                                   .get("caractereEmployeurEtablissement") == "O")]
    return actifs, comptes


def compter(client, cle, q):
    """Nombre d'établissements répondant à une requête (une page d'un seul résultat). 404 = aucun."""
    h = {"X-INSEE-Api-Key-Integration": cle, "Accept": "application/json"}
    try:
        js = client.get(SIRENE, {"q": q, "nombre": 1}, entetes=h, timeout=120, essais=2)
        return (js.get("header") or {}).get("total") or 0
    except RuntimeError as e:
        if "404" in str(e):
            return 0
        raise


def creations_fermetures(client, cle, codes_communes, annees, log=print):
    """Établissements créés et fermés chaque année dans les communes (deux comptages par année).
    Fermeture = début d'une période « fermé » dans l'année (syntaxe validée par la sonde 5)."""
    base = f"codeCommuneEtablissement:({' OR '.join(codes_communes)})"
    out = {}
    for a in annees:
        intervalle = f"[{a}-01-01 TO {a}-12-31]"
        c = compter(client, cle, f"{base} AND dateCreationEtablissement:{intervalle}")
        f = compter(client, cle, f"{base} AND periode(etatAdministratifEtablissement:F AND dateDebut:{intervalle})")
        out[str(a)] = {"creations": c, "fermetures": f}
        log(f"      {a} : {c} établissements créés, {f} fermés")
    return out


def nom_etablissement(e):
    ul = e.get("uniteLegale") or {}
    per = (e.get("periodesEtablissement") or [{}])[0]
    nd = lambda v: v if v and v != "[ND]" else None  # noqa: E731
    raison = nd(ul.get("denominationUniteLegale")) or " ".join(
        x for x in (nd(ul.get("prenomUsuelUniteLegale")), nd(ul.get("nomUniteLegale"))) if x)
    enseigne = nd(per.get("enseigne1Etablissement")) or nd(per.get("denominationUsuelleEtablissement"))
    if enseigne and raison and enseigne.lower() != raison.lower():
        return f"{enseigne} ({raison})"
    return enseigne or raison or "(non diffusible)"


def mettre_en_forme(bruts, libelles_ape):
    """Établissements de l'API -> lignes simples pour l'outil.
    libelles_ape : code APE (ex. 4711D) -> {"libelle", "NA38", "Grand secteur"} tiré du jeu Urssaf."""
    out = []
    for e in bruts:
        adr = e.get("adresseEtablissement") or {}
        per = (e.get("periodesEtablissement") or [{}])[0]
        ape = (per.get("activitePrincipaleEtablissement") or "").replace(".", "")
        info = libelles_ape.get(ape, {})
        tranche = e.get("trancheEffectifsEtablissement")
        t = TRANCHES.get(tranche)
        x, y = _flottant(adr.get("coordonneeLambertAbscisseEtablissement")), \
            _flottant(adr.get("coordonneeLambertOrdonneeEtablissement"))
        lon = lat = None
        if x and y and 1e5 < x < 1.3e6 and 6e6 < y < 7.2e6:
            lon, lat = lambert93_vers_wgs84(x, y)
        voie = " ".join(str(v) for v in (adr.get("numeroVoieEtablissement"), adr.get("typeVoieEtablissement"),
                                         adr.get("libelleVoieEtablissement")) if v and v != "[ND]")
        out.append({
            "siret": e.get("siret"), "nom": nom_etablissement(e), "ape": ape,
            "activite": info.get("libelle") or ape, "secteur": info.get("NA38") or "Non classé",
            "grand_secteur": info.get("Grand secteur") or "Non classé",
            "tranche": tranche or "NN", "tranche_lib": t[0] if t else "Non renseignée",
            "eff_min": t[1] if t else None, "eff_max": t[2] if t else None,
            "annee_effectif": e.get("anneeEffectifsEtablissement"),
            "siege": "oui" if e.get("etablissementSiege") else "",
            "categorie": (e.get("uniteLegale") or {}).get("categorieEntreprise") or "",
            "creation": e.get("dateCreationEtablissement"), "adresse": voie,
            "code_commune": adr.get("codeCommuneEtablissement"), "commune": adr.get("libelleCommuneEtablissement"),
            "lon": lon, "lat": lat, "diffusion": e.get("statutDiffusionEtablissement"),
            "siren": e.get("siren") or str(e.get("siret") or "")[:9],
            "etat": per.get("etatAdministratifEtablissement"),
        })
    out.sort(key=lambda d: (-(d["eff_min"] or -1), d["nom"]))
    return out


def libelles_ape(detail):
    """Tire du jeu Urssaf (champ « ape » = « 4711D Supermarchés ») le libellé et le secteur de chaque code APE."""
    out = {}
    for l in detail:
        txt = l.get("APE") or ""
        code = txt.split(" ", 1)[0].replace(".", "")
        if code and code not in out:
            out[code] = {"libelle": txt, "NA38": l.get("NA38"), "Grand secteur": l.get("Grand secteur")}
    return out


def filtrer(lignes, commune=None, secteur=None, taille=None, texte=""):
    t = (texte or "").lower().strip()
    out = []
    for d in lignes:
        if commune and d["commune"] != commune:
            continue
        if secteur and d["grand_secteur"] != secteur and d["secteur"] != secteur:
            continue
        if taille is not None and (d["eff_min"] is None or d["eff_min"] < taille):
            continue
        if t and t not in (d["nom"] + " " + d["activite"] + " " + (d["siret"] or "")).lower():
            continue
        out.append(d)
    return out


def synthese(lignes):
    """Comptages pour le journal et les exports."""
    geo = sum(1 for d in lignes if d["lat"] is not None)
    connus = [d for d in lignes if d["eff_min"] is not None]
    return {"total": len(lignes), "geolocalises": geo, "effectif_connu": len(connus),
            "eff_min": sum(d["eff_min"] for d in connus), "eff_max": sum(d["eff_max"] for d in connus),
            "non_diffusibles": sum(1 for d in lignes if d["diffusion"] == "P")}

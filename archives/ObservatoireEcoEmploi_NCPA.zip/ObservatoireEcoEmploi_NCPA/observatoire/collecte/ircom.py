"""DGFiP — L'impôt sur le revenu par collectivité territoriale (IRCOM) : pour chaque commune,
montants des traitements et salaires et des pensions et retraites déclarés.

Utilité : l'INSEE ne publie pas la décomposition du revenu des ménages pour NCPA (secret
statistique). L'IRCOM, publié commune par commune, permet de mesurer le poids des pensions
par rapport aux salaires sur NCPA et dans le département, et donc de corriger les parts du
département utilisées par défaut (voir analyses.estimer_base_eco).

Jeu : https://www.data.gouv.fr/datasets/536998cba3a729239d20505e (un zip par millésime)
"""
import io
import re
import zipfile

import pandas as pd

from ..utils import CACHE, MANUELS, age_jours, log, norm

ETAPE = "IRCOM (DGFiP)"
API = "https://www.data.gouv.fr/api/1/datasets/536998cba3a729239d20505e/"


def _annee(txt):
    m = re.search(r"revenus?\s*(?:de\s*)?(20\d\d)", norm(txt)) or re.search(r"(20\d\d)", str(txt))
    return m.group(1) if m else ""


def _code_insee(dep, com):
    dep = str(dep).strip().upper()
    com = re.sub(r"\D", "", str(com).split(".")[0])
    if not dep or dep == "NAN" or not com:
        return None
    if dep.startswith("97") and len(dep) == 3:      # outre-mer : 971 + 2 chiffres
        return dep + com.zfill(2)[-2:]
    if len(dep) == 3 and dep.endswith("0"):          # IRCOM code souvent 140 pour le Calvados
        dep = dep[:2]
    return dep.zfill(2) + com.zfill(3)[-3:]


def _nombre(v):
    if v is None:
        return None
    s = str(v).replace("\u202f", "").replace("\u00a0", "").replace(" ", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None   # « n.c. » = secret statistique


def lire_tableau(d):
    """Une feuille IRCOM lue sans en-tête -> DataFrame commune / salaires / pensions
    (ligne « Total » de chaque commune). En-têtes sur une ou deux lignes, cellules fusionnées."""
    d = d.dropna(how="all").reset_index(drop=True)
    h = next((i for i in range(min(len(d), 30))
              if d.iloc[i].astype(str).map(norm).str.contains("salaires").any()), None)
    if h is None:
        return None
    haut = d.iloc[h].where(d.iloc[h].astype(str).str.strip() != "", None).ffill()
    bas = d.iloc[h + 1] if h + 1 < len(d) else pd.Series([None] * d.shape[1])
    labels = [norm(f"{a if pd.notna(a) else ''} {b if pd.notna(b) else ''}") for a, b in zip(haut, bas)]
    cols = list(d.columns)

    def trouve(*mots, exclure=()):
        cand = [c for c, l in zip(cols, labels) if all(m in l for m in mots) and not any(x in l for x in exclure)]
        return cand

    c_dep = next(iter(trouve("dep")), None)
    c_com = next(iter(trouve("commune", exclure=("libelle", "nom"))), None)
    c_tr = next(iter(trouve("tranche")), None)
    c_sal = trouve("salaires", "montant") or trouve("salaires")[-1:]
    c_pen = trouve("pension", "montant") or trouve("pension")[-1:]
    if not (c_dep is not None and c_com is not None and c_sal and c_pen):
        return None
    corps = d.iloc[h + 1:]
    if c_tr is not None:
        corps = corps[corps[c_tr].astype(str).map(norm).str.startswith("total")]
    out = pd.DataFrame({"commune": [_code_insee(a, b) for a, b in zip(corps[c_dep], corps[c_com])],
                        "salaires": corps[c_sal[0]].map(_nombre), "pensions": corps[c_pen[0]].map(_nombre)})
    return out.dropna(subset=["commune"]).drop_duplicates("commune")


def _lire_fichier(nom, contenu):
    """contenu : bytes d'un xlsx/xls/csv. Toutes les feuilles sont parcourues."""
    if nom.lower().endswith(".csv"):
        feuilles = {"csv": pd.read_csv(io.BytesIO(contenu), sep=None, engine="python", header=None, dtype=str,
                                       encoding="latin-1")}
    else:
        feuilles = pd.read_excel(io.BytesIO(contenu), sheet_name=None, header=None, dtype=str)
    morceaux = [t for t in (lire_tableau(f) for f in feuilles.values()) if t is not None and len(t)]
    return pd.concat(morceaux, ignore_index=True).drop_duplicates("commune") if morceaux else None


def _depuis_zip(octets):
    z = zipfile.ZipFile(io.BytesIO(octets))
    membres = [m for m in z.namelist() if m.lower().endswith((".xlsx", ".xls", ".csv"))]
    # le fichier « communes complètes » couvre toute la France ; sinon le plus gros fichier
    membres.sort(key=lambda m: (not ("commun" in norm(m) and "complet" in norm(m)), -z.getinfo(m).file_size))
    for m in membres[:3]:
        t = _lire_fichier(m, z.read(m))
        if t is not None and len(t) > 100:
            return t, m
    return None, None


def charger_ircom(cfg, session, forcer=False, hors_ligne=False):
    """Renvoie un DataFrame commune / salaires / pensions / annee (communes de la région), ou None."""
    f = CACHE / f"ircom_{cfg['region']}.csv"
    deps = set(cfg["deps_region"])
    manuels = [m for m in MANUELS.iterdir() if m.is_file() and "ircom" in norm(m.name)
               and m.suffix.lower() in (".zip", ".xlsx", ".xls", ".csv")]
    age = age_jours(f)
    a_jour = age is not None and age <= cfg["duree_cache"] and not forcer
    if manuels and not a_jour:
        m = manuels[0]
        try:
            octets = m.read_bytes()
            t, membre = _depuis_zip(octets) if m.suffix.lower() == ".zip" else (_lire_fichier(m.name, octets), m.name)
            if t is None:
                raise ValueError("colonnes salaires / pensions introuvables")
            t["annee"] = _annee(membre or m.name)
            t[t.commune.str[:2].isin(deps)].to_csv(f, index=False)
            log(ETAPE, f"fichier déposé {m.name} lu ({len(t)} communes)", "ok")
        except Exception as e:
            log(ETAPE, f"lecture impossible de {m.name} : {e}", "alerte")
    elif not hors_ligne and not a_jour:
        try:
            meta = session.get(API, timeout=60).json()
            zips = [r for r in meta.get("resources", []) if str(r.get("format", "")).lower() == "zip"
                    or str(r.get("url", "")).lower().endswith(".zip")]
            zips.sort(key=lambda r: r.get("last_modified") or r.get("created_at") or "", reverse=True)
            if not zips:
                raise ValueError("aucune archive dans le jeu data.gouv")
            r = zips[0]
            log(ETAPE, f"téléchargement de « {r.get('title', '')} » (≈ 17 Mo)…")
            octets = session.get(r["url"], timeout=600).content
            t, membre = _depuis_zip(octets)
            if t is None:
                raise ValueError("colonnes salaires / pensions introuvables dans l'archive")
            t["annee"] = _annee(f"{r.get('title', '')} {membre}")
            t[t.commune.str[:2].isin(deps)].to_csv(f, index=False)
            log(ETAPE, f"{membre} : {len(t)} communes (revenus {t.annee.iloc[0] or 'n.d.'})", "ok")
        except Exception as e:
            log(ETAPE, f"IRCOM non récupéré ({str(e)[:150]}) — parts de revenus du département conservées. "
                       "Possibilité : déposer l'archive IRCOM (data.gouv.fr) dans donnees_manuelles/", "alerte")
    if not f.exists():
        return None
    t = pd.read_csv(f, dtype={"commune": str, "annee": str})
    t["annee"] = t["annee"].fillna("")
    return t

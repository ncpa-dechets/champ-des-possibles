# -*- coding: utf-8 -*-
"""Test de bout en bout hors ligne (faux réseau, données FICTIVES) : collecte de tous les thèmes, analyses,
dessin de chaque graphique, cartes, exports Excel et HTML, puis relance en mode hors ligne (cache seul).
Usage : python tests/test_moteur.py"""
import os
import shutil
import sys
import tempfile
import time

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(ICI))
sys.path.insert(0, ICI)

from observatoire.utils import CACHE, RACINE, SUIVI  # noqa: E402

shutil.rmtree(CACHE, ignore_errors=True)
CACHE.mkdir()
CLES = {"cle_sirene.txt": "cle-de-test\n", "identifiants_francetravail.txt": "PAR_test\nsecret\n"}
for nom, contenu in CLES.items():
    (RACINE / nom).write_text(contenu, encoding="utf-8")
# IRCOM : fichier de cache fictif (le faux serveur ne simule pas data.gouv.fr pour ce jeu)
import faux_reseau  # noqa: E402

lignes = ["commune,salaires,pensions,annee"]
for fs in faux_reseau.FC.values():
    for f in fs:
        p = f["properties"]
        lignes.append(f"{p['code']},{p['population'] * 9.0:.0f},{p['population'] * 6.0:.0f},2024")
(CACHE / "ircom_28.csv").write_text("\n".join(lignes), encoding="utf-8")

faux_reseau.installer()
from observatoire import catalogue, moteur  # noqa: E402
from observatoire.rendu import cartes, export_excel, export_html, figures  # noqa: E402

THEMES = list(catalogue.THEMES)
OPTIONS = {"critere": "touristique", "grp_taille": True, "lbb_bmo": True,
           "lbb_metiers": {"G1602": "Personnel de cuisine", "D1505": "Personnel de caisse"}}
erreurs = []
t0 = time.time()
brut = moteur.collecter(THEMES, OPTIONS, "normal")
print(f"Collecte : {time.time() - t0:.1f} s")
for e in SUIVI.instantane():
    print(f"  {e['statut']:8s} {e['appels']:4d} appels  {e['libelle'][:48]:48s} {e['message'][:70]}")
    if e["statut"] in ("erreur", "ignoree") and e["id"] not in ("grille",):
        erreurs.append(("collecte", e["id"], e["message"]))

res = moteur.analyser(brut, THEMES, {"critere": "touristique", "grp_taille": True, "grp_france": True})
print(f"\n{len(res['blocs'])} blocs ; groupes : {res['groupes']}")
par_theme = {}
for b in res["blocs"]:
    par_theme.setdefault(b["theme"], []).append(b["id"])
for t in THEMES:
    print(f"  {t:12s} {par_theme.get(t)}")
    if not par_theme.get(t):
        erreurs.append(("theme vide", t, ""))
print("Journal des analyses :", *res["journal"], sep="\n  ")
print("Chiffres clés :", [c["libelle"] for c in res["cles"]])
print("Synthèse :", len(res["synthese"]), "phrases")

n = 0
for b in res["blocs"]:
    g = b.get("graph")
    if not g:
        continue
    specs = g["variantes"].values() if g["kind"] == "variantes" else [g]
    for s in specs:
        try:
            fig = figures.figure(s, b["titre"], b["source"])
            fig.to_json()
            n += 1
        except Exception as e:
            import traceback
            erreurs.append(("graphique", b["id"], repr(e), traceback.format_exc()[-600:]))
print(f"{n} figures dessinées")
print("Cartes :", {k: (v is not None) for k, v in res["cartes"].items()})
sortie = tempfile.mkdtemp(prefix="obs_test_")
for k, v in res["cartes"].items():
    if v:
        open(os.path.join(sortie, f"carte_{k}.html"), "w", encoding="utf-8").write(cartes.page(k, v, k))
etat = SUIVI.instantane()
export_excel.produire(res, os.path.join(sortie, "test.xlsx"), etat_sources=etat)
export_html.produire(res, os.path.join(sortie, "rapport_complet.html"), THEMES, {"elus", "services", "annexes"},
                     ["communes", "entreprises", "flux"], etat)
export_html.produire(res, os.path.join(sortie, "rapport_elus.html"), ["evolution", "ft", "base_eco"], {"elus"}, [])
print("Exports :", {f: os.path.getsize(os.path.join(sortie, f)) // 1000 for f in sorted(os.listdir(sortie))}, "ko")

# relance hors ligne : tout doit venir du cache
brut2 = moteur.collecter(THEMES, OPTIONS, "hors_ligne")
etats = {e["id"]: e["statut"] for e in SUIVI.instantane()}
print("\nHors ligne :", etats)
for k, s in etats.items():
    if s not in ("cache", "ok", "alerte") and k not in ("grille",):
        erreurs.append(("hors ligne", k, s))
res2 = moteur.analyser(brut2, THEMES, {})
print("Hors ligne :", len(res2["blocs"]), "blocs")

for nom in CLES:
    (RACINE / nom).unlink()
print("Dossier :", sortie)
print("ERREURS :", erreurs or "aucune")
sys.exit(1 if erreurs else 0)

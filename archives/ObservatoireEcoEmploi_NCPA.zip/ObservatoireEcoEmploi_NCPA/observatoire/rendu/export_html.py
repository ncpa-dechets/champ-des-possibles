# -*- coding: utf-8 -*-
"""Rapport HTML autonome, composé à la demande : thèmes et publics cochés dans l'interface.

Publics :
  - elus     : onglet « Synthèse » (chiffres clés, synthèse rédigée, graphiques essentiels) ;
  - services : un onglet par famille de thèmes, toutes les analyses avec leur lecture ;
  - annexes  : tableaux de données sous chaque analyse, onglet « Méthode et sources ».
Les cartes cochées forment un onglet « Cartes ». Plotly, Leaflet et MapLibre sont embarqués : le fichier s'ouvre
hors connexion (seules les tuiles du fond de carte viennent d'internet).
"""
import html
import json
from datetime import date

import pandas as pd

from .. import catalogue
from ..analyses.textes import INTRO_THEMES, METHODE, METHODE_ECO
from ..utils import fmt_nombre
from . import cartes, figures

CSS = """
:root{--rouge:#B91E27;--vert:#B1B993;--gris:#5B6770;--fond:#FAFAF8;--trait:#E3E3DE}
*{box-sizing:border-box}
body{margin:0;font-family:Calibri,Carlito,"Segoe UI",system-ui,sans-serif;color:#222;background:var(--fond);line-height:1.5}
header{background:#fff;border-top:6px solid var(--rouge);border-bottom:1px solid var(--trait);padding:26px 5vw 18px}
.eyebrow{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--rouge);font-weight:700}
h1{margin:6px 0 4px;font-size:29px;color:#111}
.soustitre{color:var(--gris);font-size:15px}
nav.onglets{position:sticky;top:0;z-index:1500;background:#fff;border-bottom:1px solid var(--trait);padding:0 5vw;
  display:flex;gap:4px;flex-wrap:wrap}
nav.onglets button{font-family:inherit;font-size:15px;border:0;background:none;padding:11px 14px;cursor:pointer;
  color:var(--gris);border-bottom:3px solid transparent}
nav.onglets button.actif{color:var(--rouge);border-bottom-color:var(--rouge);font-weight:700}
main{padding:8px 5vw 60px;max-width:1250px}
section.onglet{display:none}section.onglet.actif{display:block}
h2{color:var(--rouge);border-bottom:2px solid var(--vert);padding-bottom:4px;margin-top:38px;font-size:22px}
h3{font-size:17px;margin:4px 0 6px}
.intro{color:var(--gris);font-style:italic;max-width:900px}
.cles{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin:20px 0}
.cle{background:#fff;border-left:4px solid var(--rouge);padding:12px 14px;border-radius:2px;box-shadow:0 1px 2px rgba(0,0,0,.05)}
.cle .lib{font-size:12.5px;color:var(--gris);text-transform:uppercase;letter-spacing:.04em}
.cle .val{font-size:26px;font-weight:700;color:#111;margin:2px 0}
.cle .sous{font-size:12.5px;color:var(--gris)}
.synthese li{margin:6px 0;max-width:950px}
.bloc{background:#fff;border:1px solid var(--trait);border-radius:3px;padding:14px 18px;margin:16px 0}
.grille{display:grid;grid-template-columns:repeat(auto-fit,minmax(520px,1fr));gap:14px}
.lecture{background:#F4F5EE;border-left:3px solid var(--vert);padding:8px 12px;margin:8px 0;font-size:15px}
.source{font-size:12px;color:#777}
details{margin-top:8px}summary{cursor:pointer;color:var(--gris);font-size:13.5px}
.tab-donnees{max-height:420px;overflow:auto}
table.donnees{border-collapse:collapse;font-size:12.5px;margin:8px 0;min-width:50%}
table.donnees th{background:#F1F1EC;text-align:left;padding:4px 8px;border-bottom:1px solid #ccc;position:sticky;top:0}
table.donnees td{padding:3px 8px;border-bottom:1px solid #eee}
.variantes select{font-family:inherit;font-size:14px;padding:3px;margin-bottom:6px}
.avert{background:#FFF6E6;border-left:3px solid #E0A030;padding:8px 12px;font-size:14px}
dl.methode dt{font-weight:700;margin-top:10px}dl.methode dd{margin:2px 0 0 0;max-width:950px}
.carto.plein{height:calc(100vh - 140px);min-height:520px;border:1px solid var(--trait)}
footer{font-size:12px;color:#888;padding:20px 5vw;border-top:1px solid var(--trait)}
@media print{nav.onglets,.carto,details{display:none}section.onglet{display:block!important}body{background:#fff}
  .bloc{break-inside:avoid;border:0}}
"""

JS_ONGLETS = """
function ouvrir(id){document.querySelectorAll("section.onglet").forEach(s=>s.classList.toggle("actif",s.id===id));
  document.querySelectorAll("nav.onglets button").forEach(b=>b.classList.toggle("actif",b.dataset.o===id));
  const s=document.getElementById(id);
  s.querySelectorAll(".js-plotly-plot").forEach(p=>{try{Plotly.Plots.resize(p);}catch(e){}});
  (window.CARTES||[]).forEach(m=>{try{m.invalidateSize();if(m._refit&&m.getContainer().offsetWidth&&!m._cadre){m._refit();m._cadre=true;}}catch(e){}});
  history.replaceState(null,"","#"+id);}
document.querySelectorAll("nav.onglets button").forEach(b=>b.onclick=()=>ouvrir(b.dataset.o));
function variante(sel){const box=sel.closest(".variantes");box.querySelectorAll(".var").forEach(d=>{
  const on=d.dataset.v===sel.value;d.style.display=on?"block":"none";
  if(on)d.querySelectorAll(".js-plotly-plot").forEach(p=>Plotly.Plots.resize(p));});}
ouvrir((location.hash||"").slice(1)&&document.getElementById(location.hash.slice(1))?location.hash.slice(1):
  document.querySelector("section.onglet").id);
"""


def _table(df, max_rows=400):
    if df is None or len(df) == 0:
        return ""
    d = df.head(max_rows).copy()
    for c in d.columns:
        fmt = None
        v = pd.to_numeric(d[c], errors="coerce")
        if v.notna().any() and d[c].dtype != object:
            frac = any(m in str(c) for m in ("Évolution", "Part", "Taux", "Amplitude", "trim.")) and \
                "(%)" not in str(c) and v.abs().max() <= 5
            fmt = (lambda x: f"{x * 100:.1f} %".replace(".", ",")) if frac else \
                (lambda x: fmt_nombre(x, 1 if abs(x) < 100 and x != int(x) else 0))
            d[c] = [("n.d." if pd.isna(x) else fmt(x)) for x in v]
    return f'<div class="tab-donnees">{d.to_html(index=False, classes="donnees", border=0, escape=True, na_rep="")}</div>'


class Compteur:
    def __init__(self):
        self.n = 0

    def __call__(self, p="g"):
        self.n += 1
        return f"{p}{self.n}"


def _fig_html(g, titre, source, nom, ident):
    fig = figures.figure(g, titre, source)
    js = fig.to_json()
    return (f'<div id="{ident}"></div><script>(function(){{const f={js};'
            f'Plotly.newPlot("{ident}",f.data,f.layout,{json.dumps(figures.config(nom))});}})();</script>')


def _graphique(b, ident):
    g = b.get("graph")
    if not g:
        return ""
    if g["kind"] == "variantes":
        opts, divs = [], []
        for i, (lib, spec) in enumerate(g["variantes"].items()):
            opts.append(f'<option value="{i}">{html.escape(lib)}</option>')
            fig = _fig_html(spec, b["titre"] + " · " + lib, b.get("source"), b["id"], ident(b["id"] + "_"))
            vis = "block" if i == 0 else "none"
            divs.append(f'<div class="var" data-v="{i}" style="display:{vis}">{fig}</div>')
        sel = (f'<select onchange="variante(this)">{"".join(opts)}</select>' if len(opts) > 1 else "")
        return f'<div class="variantes">{sel}{"".join(divs)}</div>'
    return _fig_html(g, b["titre"], b.get("source"), b["id"], ident(f"{b['id']}_"))


def _bloc(b, ident, tables=True, lecture=True):
    t = "" if b.get("graph") else f"<h3>{html.escape(b['titre'])}</h3>"
    lec = f'<div class="lecture">{html.escape(b["lecture"])}</div>' if lecture and b.get("lecture") else ""
    donnees = ""
    if tables and ((b.get("table") is not None and len(b["table"])) or (b.get("table2") is not None and len(b["table2"]))):
        donnees = (f"<details><summary>Voir les données</summary>{_table(b.get('table'))}"
                   f"{_table(b.get('table2'))}</details>")
    src = "" if b.get("graph") else f'<div class="source">Source : {html.escape(b.get("source") or "")}</div>'
    return f'<div class="bloc">{t}{_graphique(b, ident)}{lec}{src}{donnees}</div>'


def produire(res, chemin, themes, publics, cartes_choisies=(), etat_sources=None):
    """themes : ids du catalogue ; publics : sous-ensemble de {"elus", "services", "annexes"} ;
    cartes_choisies : sous-ensemble de {"communes", "entreprises", "flux"}."""
    import plotly.offline
    ident = Compteur()
    themes = [t for t in res["themes"] if t in set(themes)]
    blocs = [b for b in res["blocs"] if b["theme"] in themes]
    annexes = "annexes" in publics
    onglets = []

    if "elus" in publics:
        p = ['<h2>Chiffres clés</h2><div class="cles">']
        for c in res["cles"]:
            p.append(f'<div class="cle"><div class="lib">{html.escape(c["libelle"])}</div><div class="val">'
                     f'{html.escape(c["texte"])}</div><div class="sous">{html.escape(c["sous"])}</div></div>')
        p.append("</div>")
        if res["synthese"]:
            p.append('<h2>Synthèse</h2><ul class="synthese">' +
                     "".join(f"<li>{html.escape(s)}</li>" for s in res["synthese"]) + "</ul>")
        ess = [b for b in blocs if b.get("essentiel") and b.get("graph")]
        if ess:
            p.append('<h2>Graphiques essentiels</h2><div class="grille">')
            p += [_bloc(b, ident, tables=False) for b in ess]
            p.append("</div>")
        onglets.append(("synthese", "Synthèse", "".join(p)))

    if "services" in publics:
        for fam in catalogue.FAMILLES:
            ts = [t for t in themes if catalogue.THEMES[t][0] == fam and any(b["theme"] == t for b in blocs)]
            if not ts:
                continue
            p = []
            for t in ts:
                p.append(f'<h2>{html.escape(catalogue.THEMES[t][1])}</h2><p class="intro">'
                         f'{html.escape(INTRO_THEMES.get(t, ""))}</p>')
                if t == "base_eco":
                    p.append('<p class="avert">La base économique est une <b>estimation</b> : les dépenses des résidents '
                             'secondaires et des touristes reposent sur des hypothèses (onglet Base_eco du classeur '
                             'Excel, où elles se modifient). À présenter en ordre de grandeur, avec sa fourchette.</p>')
                p += [_bloc(b, ident, tables=annexes) for b in blocs if b["theme"] == t]
            onglets.append((f"f{catalogue.FAMILLES.index(fam)}", fam, "".join(p)))

    lib_cartes = {"communes": "Communes et EPCI", "entreprises": "Employeurs et entreprises qui recrutent",
                  "flux": "Déplacements domicile-travail"}
    dispo = [c for c in cartes_choisies if res["cartes"].get(c)]
    if dispo:
        p = []
        for c in dispo:
            p.append(f"<h2>{lib_cartes[c]}</h2>" + cartes.fragment(c, res["cartes"][c], ident("carte"), plein=True))
        onglets.append(("cartes", "Cartes", "".join(p)))

    if annexes:
        p = ['<h2>Méthode et sources</h2><dl class="methode">']
        p += [f"<dt>{html.escape(k)}</dt><dd>{html.escape(v)}</dd>" for k, v in METHODE_ECO + METHODE]
        p.append("</dl>")
        be = res.get("base_eco")
        if be and "base_eco" in themes:
            rows = "".join(f"<tr><td>{html.escape(k)}</td><td>{fmt_nombre(v['bas'], 2)}</td><td><b>"
                           f"{fmt_nombre(v['central'], 2)}</b></td><td>{fmt_nombre(v['haut'], 2)}</td>"
                           f"<td>{html.escape(str(v['unite']))}</td><td>{html.escape(str(v['commentaire']))}</td></tr>"
                           for k, v in be["hypotheses"].items())
            p.append('<h2>Hypothèses de la base économique</h2><table class="donnees"><tr><th>Paramètre</th><th>Bas'
                     f'</th><th>Central</th><th>Haut</th><th>Unité</th><th>Commentaire</th></tr>{rows}</table>')
        if etat_sources:
            p.append("<h2>Sources interrogées</h2>" + _table(pd.DataFrame(
                [{"Source": e["libelle"], "Fournisseur": e["api"], "État": e["statut"], "Appels": e["appels"],
                  "Message": e["message"]} for e in etat_sources])))
        if res.get("journal"):
            p.append("<h2>Points d'attention</h2><ul>" + "".join(f"<li>{html.escape(j)}</li>" for j in res["journal"])
                     + "</ul>")
        onglets.append(("annexes", "Méthode et sources", "".join(p)))

    if not onglets:
        raise ValueError("rien à exporter : cocher au moins un public ou une carte")
    css_c, js_c = cartes.bibliotheques() if dispo else ("", "")
    pa = res["params"]
    periode = f" · emploi salarié privé {pa['a1']}-{pa['a2']}" if pa.get("a1") else ""
    corps = (f'<header><div class="eyebrow">{html.escape(res["nom"])} · Économie et emploi</div>'
             f'<h1>Économie et emploi : {html.escape(res["nom_long"])}</h1>'
             f'<div class="soustitre">Données publiques (Insee, Urssaf, France Travail, OFGL, ANCT…) extraites le '
             f'{html.escape(res["date"])}{periode}. Document du {date.today():%d/%m/%Y}.</div></header>'
             '<nav class="onglets">' + "".join(f'<button data-o="{i}">{html.escape(t)}</button>' for i, t, _ in onglets)
             + "</nav><main>" + "".join(f'<section class="onglet" id="{i}">{c}</section>' for i, _, c in onglets)
             + '</main><footer>Produit par l\'outil « Économie et emploi » de NCPA. Les graphiques s\'enregistrent en '
               'image avec l\'icône appareil photo (au survol). Données La Bonne Boite : France Travail, licence '
               'ouverte.</footer>')
    page = (f'<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" '
            f'content="width=device-width,initial-scale=1"><title>Économie et emploi · {html.escape(res["nom"])}</title>'
            f"<style>{CSS}{css_c}{cartes.CSS_CARTES if dispo else ''}</style>"
            f"<script>{plotly.offline.get_plotlyjs()}</script>"
            + (f"<script>{js_c}</script><script>{cartes.JS_CARTES}</script>" if dispo else "")
            + f"</head><body>{corps}<script>{JS_ONGLETS}</script></body></html>")
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(page)
    return chemin

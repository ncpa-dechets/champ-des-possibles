"""Outils Urbanisme · NCPA, interface Streamlit (v0.7).

Même moteur que l'application .exe (dossier modules/) : seule la présentation
change. Lancement : lancer_interface.bat.

Principes :
- chaque thème est indépendant (son choix de communes, son lancement, ses
  résultats) ;
- les extractions tournent dans un fil d'exécution séparé, avec une barre de
  progression alimentée par le moteur (reseau.definir_suivi) ; un clic
  ailleurs ou un rechargement du navigateur ne les interrompt pas ;
- travaux et résultats rangés par « jeton » de session placé dans l'adresse
  (?s=...) : chaque navigateur a les siens (utile si l'outil passe un jour
  sur un serveur) ;
- résultats en cinq vues : Synthèse, Explorer (filtres, graphiques, listes
  détaillées), Carte et Rapport (affichés en grand, bouton plein écran) et
  Téléchargements.
"""
import os
import shutil
import tempfile
import threading
import time
import uuid
from datetime import date, datetime

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

from modules import (carte_friches, carte_permis, carte_zonage, conso_enaf, croisement, export_excel,
                     export_friches, export_geo, export_permis, friches, permis, rapport_friches, rapport_html,
                     rapport_permis, rapport_zonage, reseau, test_connexions, zonage, zonage_complet)
from modules import territoire as T
from modules.chemins import dossier_application
from modules.friches import LIB_STATUT, STATUTS
from modules.zonage import FAMILLES

VERSION = "0.8"
ROUGE, VERT, ENCRE, BRUME = "#B91E27", "#B1B993", "#1F2A2E", "#F3F4EF"
st.set_page_config(page_title="Outils Urbanisme · NCPA", page_icon="🗺️", layout="wide",
                   initial_sidebar_state="collapsed")

st.markdown(f"""
<style>
.block-container{{padding-top:3rem;padding-left:2rem;padding-right:2rem;max-width:100%}}
.bandeau{{background:linear-gradient(100deg,{ENCRE} 0%,#2C3E44 60%,#46585C 100%);color:#fff;border-radius:10px;
  padding:18px 26px;margin-bottom:14px;position:relative;overflow:hidden;border-left:8px solid {ROUGE}}}
.bandeau .eyebrow{{font-size:11.5px;letter-spacing:.09em;text-transform:uppercase;color:{VERT};font-weight:700}}
.bandeau h1{{font-size:28px;margin:2px 0 4px;padding:0;color:#fff}}
.bandeau p{{margin:0;opacity:.85;font-size:14.5px}}
.bandeau .puces{{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px}}
.bandeau .puce{{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.18);border-radius:999px;
  padding:3px 12px;font-size:12.5px}}
.intro{{border:1px solid #DCDDD3;border-left:5px solid var(--c, {ROUGE});border-radius:8px;padding:12px 16px;
  background:#FBFBF8;margin:4px 0 12px}}
.intro b{{font-size:15.5px}} .intro span{{color:#5E6A6E;font-size:13.5px}}
div[data-testid="stMetric"]{{background:{BRUME};border-left:4px solid {ROUGE};border-radius:8px;padding:10px 14px}}
div[data-testid="stMetricValue"]{{font-size:25px}}
button[data-baseweb="tab"] p{{font-size:15.5px;font-weight:600}}
[data-testid="stFileUploaderDropzone"] button > *{{display:none}}
[data-testid="stFileUploaderDropzone"] button::after{{content:"Parcourir…";font-size:14px}}
.stDownloadButton button{{border-radius:8px}}
</style>""", unsafe_allow_html=True)


# =====================================================================
# Travaux en arrière-plan
# =====================================================================
@st.cache_resource
def registre():
    """{jeton: {"taches": {thème: Tache}, "resultats": {thème: {...}}, "sorties": {thème: {nom: octets}}}}."""
    reseau.activer_journal_fichier()
    return {}


class Tache:
    def __init__(self, libelle):
        self.libelle = libelle
        self.lignes, self.erreur = [], None
        self.valeur, self.etape = 0.0, "Démarrage"
        self.stop = reseau.nouvel_evenement_stop()
        self.debut, self.fin, self.vu, self.thread = time.time(), None, False, None

    def log(self, texte):
        self.lignes.append(f"{datetime.now():%H:%M:%S}  {texte}")

    def suivre(self, valeur, texte):
        self.valeur = max(self.valeur, valeur)
        if texte:
            self.etape = texte

    @property
    def en_cours(self):
        return self.thread is not None and self.thread.is_alive()


jeton = st.query_params.get("s")
if not jeton:
    jeton = uuid.uuid4().hex[:12]
    st.query_params["s"] = jeton
ETAT = registre().setdefault(jeton, {"taches": {}, "resultats": {}, "sorties": {}})


def lancer(theme, libelle, fonction, params=None, resultat_principal=True):
    t = ETAT["taches"].get(theme)
    if t and t.en_cours:
        st.warning("Une opération est déjà en cours pour ce thème.")
        return
    t = Tache(libelle)
    ETAT["taches"][theme] = t

    def travail():
        reseau.definir_suivi(t.suivre)
        try:
            res = fonction(t.log, t.stop)
            if resultat_principal:
                ETAT["resultats"][theme] = {"resultat": res, "params": params or {},
                                            "date": datetime.now().strftime("%d/%m/%Y à %H:%M")}
                ETAT["sorties"][theme] = {}
            t.valeur = 1.0
            t.log("Terminé.")
        except reseau.Annulation:
            t.log("Opération annulée.")
        except reseau.ErreurSource as exc:
            t.erreur = str(exc)
        except Exception as exc:          # message lisible plutôt qu'un plantage
            t.erreur = f"{exc.__class__.__name__} : {exc}"
        finally:
            reseau.definir_suivi(None)
            t.fin = time.time()
    t.thread = threading.Thread(target=travail, daemon=True)
    t.thread.start()
    st.rerun()


def duree(secondes):
    s = int(secondes)
    return f"{s // 60} min {s % 60:02d} s" if s >= 60 else f"{s} s"


def suivi(theme):
    """Carte de progression, rafraîchie chaque seconde tant que le travail tourne."""
    t = ETAT["taches"].get(theme)
    if t is None:
        return

    def corps():
        t = ETAT["taches"][theme]
        if t.en_cours:
            with st.container(border=True):
                c1, c2 = st.columns([6, 1])
                ecoule = time.time() - t.debut
                reste = ""
                if t.valeur > 0.05:
                    reste = f" · encore environ {duree(ecoule * (1 - t.valeur) / t.valeur)}"
                c1.markdown(f"**{t.libelle}**  \n<span style='color:#5E6A6E'>{t.etape} · "
                            f"{duree(ecoule)} écoulées{reste}</span>", unsafe_allow_html=True)
                if c2.button("Annuler", key=f"annuler_{theme}", icon=":material/stop_circle:", width="stretch"):
                    t.stop.set()
                    t.log("Annulation demandée...")
                st.progress(min(1.0, t.valeur), text=f"{int(t.valeur * 100)} %")
                st.code("\n".join(t.lignes[-6:]) or "Démarrage...", language=None)
            return
        if not t.vu:
            t.vu = True
            st.rerun()
        if t.erreur:
            st.error(f"{t.libelle} : {t.erreur}", icon=":material/error:")
        with st.expander(f"Journal · {t.libelle} · {duree((t.fin or time.time()) - t.debut)}",
                         icon=":material/receipt_long:", expanded=bool(t.erreur)):
            st.code("\n".join(t.lignes) or "(vide)", language=None)
    st.fragment(run_every=1.0 if t.en_cours else None)(corps)()


def occupe(theme):
    t = ETAT["taches"].get(theme)
    return bool(t and t.en_cours)


# =====================================================================
# Outils communs
# =====================================================================
@st.cache_data(ttl=3600, show_spinner="Chargement de la liste des communes...")
def charger_communes():
    return T.communes_epci(), T.nom_epci()


try:
    COMMUNES, NOM_EPCI = charger_communes()
except reseau.ErreurSource as exc:
    st.error(f"Impossible de charger la liste des communes : {exc}")
    st.stop()
NOMS = {c["code"]: c["nom"] for c in COMMUNES}
TOUS = [c["code"] for c in COMMUNES]


def fr(v, n=1, signe=False, unite=""):
    if v is None:
        return "n.d."
    texte = f"{v:+,.{n}f}" if signe else f"{v:,.{n}f}"
    return texte.replace(",", " ").replace(".", ",") + (f" {unite}" if unite else "")


def r1(v, n=1):
    return round(v, n) if isinstance(v, (int, float)) else v


def choix_communes(theme):
    toutes = st.toggle("Toutes les communes", value=True, key=f"toutes_{theme}")
    if toutes:
        return list(TOUS)
    return st.multiselect("Communes", TOUS, format_func=lambda c: NOMS.get(c, c), key=f"communes_{theme}",
                          placeholder="Choisissez une ou plusieurs communes")


def params_communs(codes):
    noms = [NOMS[c] for c in codes]
    return {"communes": "toutes" if len(codes) == len(TOUS) else ", ".join(noms),
            "titre": NOM_EPCI if len(codes) == len(TOUS) else (noms[0] if len(noms) == 1 else f"{len(noms)} communes"),
            "date": datetime.now().strftime("%d/%m/%Y à %H:%M"), "codes": codes}


def fabriquer(theme, nom, fonction, suffixe):
    """Produit une sortie une seule fois (fonction(chemin) écrit le fichier) et garde ses octets."""
    cache = ETAT["sorties"].setdefault(theme, {})
    if nom not in cache:
        dossier = tempfile.mkdtemp(prefix="urba_")
        chemin = os.path.join(dossier, "sortie" + suffixe)
        try:
            fonction(chemin)
            with open(chemin, "rb") as f:
                cache[nom] = f.read()
            voisins = {}
            for fic in os.listdir(dossier):
                if fic != "sortie" + suffixe:
                    with open(os.path.join(dossier, fic), "rb") as f:
                        voisins[fic.replace("sortie_", "")] = f.read()
            if voisins:
                cache[nom + "_voisins"] = voisins
        finally:
            shutil.rmtree(dossier, ignore_errors=True)
    return cache[nom]


def contours():
    return T.contours_communes()


def nom_fichier(prefixe, ext):
    return f"{prefixe}_{datetime.now():%Y-%m-%d}{ext}"


BOUTON_PLEIN_ECRAN = """
<button id="pe" type="button" style="position:fixed;top:10px;right:12px;z-index:100000;font:600 13px Calibri,'Segoe UI',sans-serif;
 padding:7px 12px;border-radius:8px;border:1px solid #B91E27;background:#fff;color:#B91E27;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.15)">
 ⛶ Plein écran</button>
<script>
(function(){const b=document.getElementById("pe");
 b.onclick=()=>{if(document.fullscreenElement)document.exitFullscreen();else document.documentElement.requestFullscreen();};
 document.addEventListener("fullscreenchange",()=>{b.textContent=document.fullscreenElement?"✕ Quitter le plein écran":"⛶ Plein écran";
   setTimeout(()=>window.dispatchEvent(new Event("resize")),150);});})();
</script>"""


def afficher_html(octets, hauteur, defiler):
    html = octets.decode("utf-8")
    i = html.rfind("</body>")
    html = html[:i] + BOUTON_PLEIN_ECRAN + html[i:] if i > 0 else html + BOUTON_PLEIN_ECRAN
    components.html(html, height=hauteur, scrolling=defiler)


def intro(icone, titre, texte, couleur=ROUGE):
    st.markdown(f"<div class='intro' style='--c:{couleur}'><b>{icone} {titre}</b><br><span>{texte}</span></div>",
                unsafe_allow_html=True)


def deposer_fichier(theme, libelle, types, action):
    fic = st.file_uploader(libelle, type=types, key=f"depot_{theme}")
    if fic is not None and st.session_state.get(f"traite_{theme}") != fic.file_id:
        st.session_state[f"traite_{theme}"] = fic.file_id
        action(fic)


def copier_depot(fic, dossier):
    os.makedirs(dossier, exist_ok=True)
    chemin = os.path.join(dossier, os.path.basename(fic.name))
    with open(chemin, "wb") as f:
        f.write(fic.getbuffer())
    return chemin


VUES = ["Synthèse", "Explorer", "Carte", "Rapport", "Téléchargements"]
ICONES_VUES = {"Synthèse": ":material/table_chart:", "Explorer": ":material/manage_search:",
               "Carte": ":material/map:", "Rapport": ":material/article:", "Téléchargements": ":material/download:"}


def vue_resultats(theme, synthese, explorer, sorties):
    """synthese() et explorer() dessinent leurs vues ; sorties décrit carte, rapport et fichiers."""
    choix = st.segmented_control("Afficher", VUES, default="Synthèse", key=f"vue_{theme}",
                                 format_func=lambda v: f"{ICONES_VUES[v]} {v}", label_visibility="collapsed")
    hauteur = st.session_state.get("hauteur", 850)
    try:
        if choix in (None, "Synthèse"):
            synthese()
        elif choix == "Explorer":
            explorer()
        elif choix in ("Carte", "Rapport"):
            nom = "carte" if choix == "Carte" else "rapport"
            with st.spinner(f"Préparation : {choix.lower()}..."):
                octets = fabriquer(theme, nom, sorties[nom], ".html")
            c1, c2 = st.columns([5, 1])
            c1.caption("Bouton « Plein écran » en haut à droite de la " + choix.lower() + " · hauteur réglable dans la "
                       "barre latérale (flèche en haut à gauche).")
            c2.download_button(f"Télécharger (HTML)", octets, nom_fichier(sorties["prefixe"] + "_" + nom, ".html"),
                               "text/html", key=f"dl_{nom}_{theme}", icon=":material/download:", width="stretch")
            afficher_html(octets, hauteur if nom == "carte" else max(hauteur, 1100), defiler=(nom == "rapport"))
        else:
            cols = st.columns(3)
            k = 0
            for libelle, nom, fonction, ext, mime in sorties["fichiers"]:
                with st.spinner(f"Préparation : {libelle}..."):
                    octets = fabriquer(theme, nom, fonction, ext)
                cols[k % 3].download_button(libelle, octets, nom_fichier(sorties["prefixe"], ext), mime,
                                            key=f"dl_{nom}_{theme}", icon=":material/download:", width="stretch")
                k += 1
                for fic, contenu in ETAT["sorties"][theme].get(nom + "_voisins", {}).items():
                    court = fic.replace(".geojson", "").strip("_")
                    cols[k % 3].download_button(f"GeoJSON des {court.replace('_', ' et ')}", contenu,
                                                nom_fichier(f"{sorties['prefixe']}_{court}", ".geojson"), mime,
                                                key=f"dl_{nom}_{fic}_{theme}", icon=":material/download:",
                                                width="stretch")
                    k += 1
            for nom in ("carte", "rapport"):
                octets = fabriquer(theme, nom, sorties[nom], ".html")
                cols[k % 3].download_button(f"{'Carte' if nom == 'carte' else 'Rapport'} (HTML autonome)", octets,
                                            nom_fichier(sorties["prefixe"] + "_" + nom, ".html"), "text/html",
                                            key=f"dl2_{nom}_{theme}", icon=":material/download:", width="stretch")
                k += 1
            st.caption("GeoJSON : coordonnées WGS84 [longitude, latitude], à reprojeter en Lambert-93 dans QGIS si besoin. "
                       "Les fichiers HTML s'ouvrent sans internet (sauf les fonds de carte) et peuvent être envoyés par courriel.")
    except reseau.ErreurSource as exc:
        st.error(f"Sortie impossible : {exc}")
    except Exception as exc:
        st.error(f"Sortie impossible : {exc.__class__.__name__} : {exc}")


def tableau(lignes, **kw):
    st.dataframe(pd.DataFrame(lignes), hide_index=True, width="stretch",
                 height=kw.pop("height", min(38 * (len(lignes) + 1) + 4, st.session_state.get("hauteur", 850))), **kw)


# =====================================================================
# Barre latérale
# =====================================================================
with st.sidebar:
    st.markdown(f"### 🗺️ Outils Urbanisme\n**NCPA** · version {VERSION}")
    st.caption(f"{NOM_EPCI} · {len(COMMUNES)} communes")
    st.slider("Hauteur des cartes, rapports et listes (pixels)", 600, 1600, 850, 50, key="hauteur")
    with st.expander("Paramètres", icon=":material/settings:"):
        url_api = st.text_input("API de data.gouv.fr", conso_enaf.URL_API)
        if st.button("Recharger la liste des communes"):
            charger_communes.clear()
            T.communes_epci(forcer=True)
            st.rerun()
        if st.button("Vider les caches"):
            dossier, n = dossier_application(), 0
            for f in os.listdir(dossier):
                if f.startswith("cache_") and f.endswith(".json"):
                    os.remove(os.path.join(dossier, f))
                    n += 1
            for sous in ("cache_conso", "cache_cadastre", "cache_friches", "cache_zonage"):
                if os.path.isdir(os.path.join(dossier, sous)):
                    n += len(os.listdir(os.path.join(dossier, sous)))
                    shutil.rmtree(os.path.join(dossier, sous), ignore_errors=True)
            charger_communes.clear()
            st.success(f"{n} fichier(s) de cache supprimé(s).")
        journal = os.path.join(dossier_application(), "journal_technique.log")
        if os.path.exists(journal):
            with open(journal, "rb") as f:
                st.download_button("Journal technique", f.read(), "journal_technique.log", "text/plain")
    with st.expander("Sources", icon=":material/database:"):
        st.markdown("- Cerema, consommation d'espaces NAF (data.gouv.fr)\n"
                    "- SDES, autorisations d'urbanisme, Sitadel (API DiDo)\n"
                    "- Plan cadastral Etalab (localisation des permis)\n"
                    "- Cerema, inventaire des friches Cartofriches\n"
                    "- Géoportail de l'Urbanisme (API Carto IGN)\n"
                    "- geo.api.gouv.fr (communes, contours)")
    st.caption("Auteur : Yves Marti, Service Maîtrise des déchets · y.marti@ncpa.fr")
    st.caption("L'adresse de la page (avec ?s=…) permet de retrouver vos résultats après un rechargement.")

faits = [n for n, th in (("Consommation d'espaces", "conso"), ("Permis", "permis"), ("Friches", "friches"),
                         ("Zonage", "zonage")) if th in ETAT["resultats"]]
puces = "".join(f"<span class='puce'>✓ {n}</span>" for n in faits) or \
        "<span class='puce'>Choisissez un thème, puis lancez l'extraction</span>"
st.markdown(f"""<div class="bandeau"><div class="eyebrow">NCPA · Observatoire foncier</div>
<h1>Outils Urbanisme</h1><p>{NOM_EPCI} · {len(COMMUNES)} communes · chaque thème s'explore indépendamment des autres</p>
<div class="puces">{puces}</div></div>""", unsafe_allow_html=True)

onglet_conso, onglet_permis, onglet_friches, onglet_zonage = st.tabs(
    [":material/landscape: Consommation d'espaces", ":material/construction: Permis",
     ":material/factory: Friches", ":material/map: Zonage"])


# =====================================================================
# Thème 1 : consommation d'espaces
# =====================================================================
COUL_DEST = {"Habitat": "#B5563A", "Activité": "#4F6D7A", "Mixte": VERT, "Routes": "#8A8A80",
             "Voies ferrées": "#3F4448", "Non renseigné": "#D9D6CC"}

with onglet_conso:
    deja = "conso" in ETAT["resultats"]
    intro("🌾", "Consommation d'espaces naturels, agricoles et forestiers",
          "Surfaces consommées chaque année depuis 2011, par destination, rapportées à l'enveloppe indicative de la loi "
          "Climat et résilience. Source : Cerema, d'après les Fichiers fonciers.", "#6F7A4A")
    with st.expander("Paramètres de l'extraction", icon=":material/tune:", expanded=not deja):
        c1, c2 = st.columns([2, 3])
        with c1:
            codes = choix_communes("conso")
            comparer = st.checkbox("Comparer avec la NCPA, le Calvados et la Normandie", True, key="comp_conso")
        with c2:
            meta = conso_enaf.source_en_cache()
            st.caption(f"Fichier prêt : millésime {meta['millesime']}, récupéré le {meta.get('date', '?')}." if meta else
                       "Le fichier national (environ 30 Mo) sera téléchargé à la première extraction, puis gardé 90 jours.")
            b1, b2 = st.columns(2)
            if b1.button("Tester la source", key="test_conso", disabled=occupe("conso"), icon=":material/wifi_find:"):
                lancer("conso", "Test de la source", lambda log, stop: test_connexions.tester(url_api, journal=log),
                       resultat_principal=False)
            if b2.button("Chercher une mise à jour", key="maj_conso", disabled=occupe("conso"), icon=":material/update:"):
                lancer("conso", "Recherche d'une mise à jour",
                       lambda log, stop: conso_enaf.preparer_fichier(True, url_api, stop, log), resultat_principal=False)

            def depot_conso(fic):
                chemin = copier_depot(fic, os.path.join(conso_enaf.dossier_cache(), "local"))
                m = conso_enaf.utiliser_fichier_local(chemin)
                st.success(f"Fichier local retenu (millésime lu dans le nom : {m['millesime']}).")
            deposer_fichier("conso", "Ou déposer le CSV communal du Cerema (téléchargé avec votre navigateur)", ["csv"],
                            depot_conso)
    if st.button("Lancer l'extraction", type="primary", key="go_conso", disabled=occupe("conso") or not codes,
                 icon=":material/play_arrow:"):
        p = params_communs(codes)
        lancer("conso", f"Consommation d'espaces · {len(codes)} commune(s)",
               lambda log, stop: conso_enaf.extraire(COMMUNES, codes, NOM_EPCI, comparer, url_api=url_api,
                                                     stop_event=stop, journal=log), p)
    suivi("conso")

    if deja and not occupe("conso"):
        R = ETAT["resultats"]["conso"]
        res, p = R["resultat"], R["params"]
        terr = res["territoires"]
        tot = next((t for t in terr if t["niveau"] in ("Sélection", "EPCI")), terr[0])
        s = tot["synthese"]
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Consommé 2011-2021", fr(s['ref_ha'], 1, unite="ha"), help=f"Territoire : {tot['nom']}")
        m2.metric(f"Consommé {s['rec_annees']}", fr(s['rec_ha'], 1, unite="ha"))
        m3.metric("Enveloppe indicative consommée", fr(s['part_enveloppe'], 0, unite="%"),
                  help="50 % de la consommation 2011-2021 : repère national ; l'enveloppe applicable relève du "
                       "SRADDET et du SCoT.")
        m4.metric("Évolution du rythme annuel", fr(s['evolution'], 0, signe=True, unite="%"))

        def synthese_conso():
            tableau([{"Territoire": t["nom"], "Niveau": t["niveau"], "2011-2021 (ha)": r1(t["synthese"]["ref_ha"]),
                      "Rythme réf. (ha/an)": r1(t["synthese"]["ref_rythme"], 2),
                      "Depuis 2021 (ha)": r1(t["synthese"]["rec_ha"]),
                      "Rythme récent (ha/an)": r1(t["synthese"]["rec_rythme"], 2),
                      "Évolution (%)": r1(t["synthese"]["evolution"], 0),
                      "Enveloppe consommée (%)": r1(t["synthese"]["part_enveloppe"], 0),
                      "Part de la surface (%)": r1(t["synthese"]["part_surface"], 2)} for t in terr],
                    column_config={"Enveloppe consommée (%)": st.column_config.ProgressColumn(
                        "Enveloppe consommée (%)", min_value=0, max_value=100, format="%d %%")})

        def explorer_conso():
            noms_terr = [t["nom"] for t in terr]
            c1, c2 = st.columns([2, 3])
            choix = c1.selectbox("Territoire", noms_terr, index=noms_terr.index(tot["nom"]), key="exp_conso_terr")
            t = next(x for x in terr if x["nom"] == choix)
            lib = {d: lab for d, lab in conso_enaf.DESTINATIONS}
            donnees = pd.DataFrame([{"Année": str(a), **{lib[d]: round(t["flux"][a][d], 2) for d in res["destinations"]}}
                                    for a in res["annees"]])
            series = [lib[d] for d in res["destinations"]]
            c1.markdown(f"**{choix}** · surface consommée chaque année, par destination (ha). La dernière année est "
                        "provisoire.")
            c1.bar_chart(donnees, x="Année", y=series, color=[COUL_DEST[x] for x in series], stack=True,
                         height=420, x_label="", y_label="hectares")
            comp = [x for x in terr if x["niveau"] != "Commune" or x["nom"] == choix]
            serie = pd.DataFrame([{"Année": str(a), **{x["nom"]: round(x["flux"][a]["total"] / x["surface"] * 1000, 3)
                                                         for x in comp if x.get("surface")}} for a in res["annees"]])
            c2.markdown("**Comparaison** · surface consommée chaque année pour 1 000 ha de territoire")
            n_series = len(serie.columns) - 1
            c2.line_chart(serie, x="Année", height=420, x_label="", y_label="ha / an pour 1 000 ha",
                          color=[ROUGE, "#4F6D7A", "#6F7A4A", "#D6977A", "#3F4448"][:n_series])
            st.markdown("**Toutes les communes, année par année (ha)**")
            tableau([{"Territoire": x["nom"], "Niveau": x["niveau"],
                      **{f"{a}": round(x["flux"][a]["total"], 1) for a in res["annees"]}} for x in terr])

        vue_resultats("conso", synthese_conso, explorer_conso, {
            "prefixe": "Conso_espaces_NCPA",
            "carte": lambda ch: export_geo.exporter_carte(ch, res, contours(), p),
            "rapport": lambda ch: rapport_html.generer(ch, res, p),
            "fichiers": [("Excel", "excel", lambda ch: export_excel.exporter(ch, res, p), ".xlsx",
                          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
                         ("GeoJSON (QGIS)", "geojson", lambda ch: export_geo.exporter_geojson(ch, res, contours()),
                          ".geojson", "application/geo+json")]})
        st.caption(f"Extraction du {R['date']} · millésime {res['meta']['millesime']} · dernière année provisoire.")


# =====================================================================
# Thème 2 : permis
# =====================================================================
with onglet_permis:
    deja = "permis" in ETAT["resultats"]
    intro("🏗️", "Permis de construire, d'aménager et de démolir",
          "Chaque autorisation délivrée depuis 2013, localisée sur sa parcelle : logements autorisés, commencés, "
          "terminés, et logements à venir (futurs foyers à desservir). Source : SDES, base Sitadel.", ROUGE)
    with st.expander("Paramètres de l'extraction", icon=":material/tune:", expanded=not deja):
        c1, c2 = st.columns([2, 3])
        with c1:
            codes_p = choix_communes("permis")
        with c2:
            types = st.multiselect("Types d'autorisation", [t for t, _l in permis.TYPES],
                                   default=[t for t, _l in permis.TYPES], format_func=lambda t: permis.LIB_TYPE[t],
                                   key="types_permis")
            annee = datetime.now().year
            a1, a2 = st.select_slider("Autorisations délivrées de … à …", options=list(range(2013, annee + 1)),
                                      value=(annee - 10, annee), key="annees_permis")
            localiser = st.checkbox("Localiser sur le cadastre (nécessaire pour la carte)", True, key="loc_permis")
            if st.button("Diagnostic de la source", key="diag_permis", disabled=occupe("permis"),
                         icon=":material/wifi_find:"):
                lancer("permis", "Diagnostic de la source", lambda log, stop: permis.diagnostic(stop, log),
                       resultat_principal=False)
    if st.button("Lancer l'extraction", type="primary", key="go_permis",
                 disabled=occupe("permis") or not codes_p or not types, icon=":material/play_arrow:"):
        p = params_communs(codes_p)
        lancer("permis", f"Permis · {len(codes_p)} commune(s) · {a1}-{a2}",
               lambda log, stop: permis.extraire(COMMUNES, codes_p, NOM_EPCI, types, a1, a2, localiser, stop, log), p)
    suivi("permis")

    if deja and not occupe("permis"):
        R = ETAT["resultats"]["permis"]
        res, p = R["resultat"], R["params"]
        t = res["synthese"]["total"]
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Logements autorisés", fr(t['lgt_aut'], 0))
        m2.metric("Logements à venir", fr(t['lgt_a_venir'], 0),
                  help="Chantier ouvert non achevé, ou autorisation de moins de 3 ans sans chantier connu.")
        m3.metric("Permis d'aménager", t["pa_nb"])
        m4.metric("Permis de démolir", t["pd_nb"])

        def synthese_permis():
            tableau([{"Territoire": l["nom"], "Autorisations logement": l["lgt_nb_permis"],
                      "Logements autorisés": r1(l["lgt_aut"], 0), "Individuels": r1(l["lgt_ind"], 0),
                      "Collectifs": r1(l["lgt_col"], 0), "Commencés": r1(l["lgt_commences"], 0),
                      "Terminés": r1(l["lgt_termines"], 0), "À venir": r1(l["lgt_a_venir"], 0),
                      "Permis d'aménager": l["pa_nb"], "Permis de démolir": l["pd_nb"]}
                     for l in res["synthese"]["lignes"]])

        def explorer_permis():
            liste = res["permis"]
            f1, f2, f3, f4 = st.columns([2, 2, 2, 2])
            th = f1.multiselect("Types", res["types"], default=res["types"], format_func=lambda x: permis.LIB_TYPE[x],
                                key="exp_p_types")
            etats = sorted({x["etat"] for x in liste})
            et = f2.multiselect("États", etats, default=[e for e in etats if e != "Annulé"], key="exp_p_etats")
            com = f3.multiselect("Communes", sorted({x["commune"] for x in liste}, key=lambda c: NOMS.get(c, c)),
                                 format_func=lambda c: NOMS.get(c, c), placeholder="Toutes", key="exp_p_com")
            texte = f4.text_input("Recherche (adresse, numéro, demandeur)", key="exp_p_txt").lower()
            venir = st.toggle("Seulement les logements à venir", key="exp_p_venir")
            sel = [x for x in liste if x["theme"] in th and x["etat"] in et and (not com or x["commune"] in com)
                   and (not venir or permis.en_attente(x))
                   and (not texte or texte in f"{x['adresse']} {x['num']} {x['denomination']}".lower())]
            lg = [x for x in sel if x["theme"] == "logements"]
            c1, c2, c3 = st.columns(3)
            c1.metric("Autorisations affichées", fr(len(sel), 0))
            c2.metric("Logements", fr(sum(x["logements"] or 0 for x in lg), 0))
            c3.metric("dont à venir", fr(sum(x["logements"] or 0 for x in lg if permis.en_attente(x)), 0))
            if lg:
                par_an = {}
                for x in lg:
                    if x["annee"]:
                        d = par_an.setdefault(x["annee"], {"Individuels": 0, "Collectifs": 0, "Non ventilés": 0})
                        ind, col, tot_ = x["lgt_ind"] or 0, x["lgt_col"] or 0, x["logements"] or 0
                        d["Individuels"] += ind
                        d["Collectifs"] += col
                        d["Non ventilés"] += max(0, tot_ - ind - col)
                st.bar_chart(pd.DataFrame([{"Année": str(a), **v} for a, v in sorted(par_an.items())]), x="Année",
                             y=["Individuels", "Collectifs", "Non ventilés"], color=[ROUGE, "#D6977A", "#DCDDD3"],
                             stack=True, height=300, x_label="", y_label="logements autorisés")
            tableau([{"Commune": NOMS.get(x["commune"], x["commune"]), "Type": permis.LIB_TYPE[x["theme"]],
                      "Nature": x["type_dau"], "Numéro": x["num"],
                      "Autorisé le": date.fromisoformat(x["date_aut"]) if x["date_aut"] else None, "État": x["etat"],
                      "Logements": x["logements"], "Individuels": x["lgt_ind"], "Collectifs": x["lgt_col"],
                      "À venir": "oui" if permis.en_attente(x) else "", "Demandeur": x["demandeur"],
                      "Dénomination": x["denomination"], "Adresse": x["adresse"],
                      "Parcelles": ", ".join(f"{s_} {n}" for s_, n in x["parcelles"]),
                      "Localisation": x.get("localisation", "")}
                     for x in sorted(sel, key=lambda x: x["date_aut"] or "", reverse=True)],
                    height=st.session_state.get("hauteur", 850),
                    column_config={"Autorisé le": st.column_config.DateColumn(format="DD/MM/YYYY")})

        vue_resultats("permis", synthese_permis, explorer_permis, {
            "prefixe": "Permis_NCPA",
            "carte": lambda ch: carte_permis.exporter_carte(ch, res, COMMUNES, contours(), p),
            "rapport": lambda ch: rapport_permis.generer(ch, res, p),
            "fichiers": [("Excel", "excel", lambda ch: export_permis.exporter_excel(ch, res, COMMUNES, p), ".xlsx",
                          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
                         ("GeoJSON (QGIS)", "geojson", lambda ch: export_permis.exporter_geojson(ch, res, COMMUNES),
                          ".geojson", "application/geo+json")]})
        loc = sum(1 for x in res["permis"] if x.get("lon") is not None)
        st.caption(f"Extraction du {R['date']} · {len(res['permis'])} autorisation(s), {loc} localisée(s) · "
                   "annulations exclues des totaux · dernières années incomplètes.")


# =====================================================================
# Thème 3 : friches
# =====================================================================
with onglet_friches:
    deja = "friches" in ETAT["resultats"]
    intro("🏭", "Friches recensées",
          "Sites de l'inventaire national Cartofriches : statut (sans projet, avec projet, potentiel, reconverti), "
          "surface, pollution, zonage. Inventaire non exhaustif : il dépend des observatoires locaux.", "#4F6D7A")
    with st.expander("Paramètres de l'extraction", icon=":material/tune:", expanded=not deja):
        c1, c2 = st.columns([2, 3])
        with c1:
            codes_f = choix_communes("friches")
            comparer_f = st.checkbox("Comparer avec la NCPA, le Calvados et la Normandie", True, key="comp_friches")
        with c2:
            meta = friches.source_en_cache()
            st.caption(f"Inventaire prêt : version du {meta.get('maj', '?')}." if meta else
                       "L'inventaire (environ 25 Mo) sera téléchargé à la première extraction, puis gardé 30 jours.")
            b1, b2 = st.columns(2)
            if b1.button("Diagnostic de la source", key="diag_friches", disabled=occupe("friches"),
                         icon=":material/wifi_find:"):
                lancer("friches", "Diagnostic de la source", lambda log, stop: friches.diagnostic(stop, log),
                       resultat_principal=False)
            if b2.button("Chercher une mise à jour", key="maj_friches", disabled=occupe("friches"),
                         icon=":material/update:"):
                lancer("friches", "Recherche d'une mise à jour",
                       lambda log, stop: friches.preparer_fichier(True, stop, log), resultat_principal=False)

            def depot_friches(fic):
                friches.utiliser_fichier_local(copier_depot(fic, os.path.join(friches.dossier_cache(), "local")))
                st.success("Fichier local retenu.")
            deposer_fichier("friches", "Ou déposer le CSV « Sites référencés dans Cartofriches »", ["csv"], depot_friches)
    if st.button("Lancer l'extraction", type="primary", key="go_friches", disabled=occupe("friches") or not codes_f,
                 icon=":material/play_arrow:"):
        p = params_communs(codes_f)
        lancer("friches", f"Friches · {len(codes_f)} commune(s)",
               lambda log, stop: friches.extraire(COMMUNES, codes_f, NOM_EPCI, comparer_f, False, stop, log), p)
    suivi("friches")

    if deja and not occupe("friches"):
        R = ETAT["resultats"]["friches"]
        res, p = R["resultat"], R["params"]
        tot = next((l for l in res["lignes"] if l["niveau"] in ("EPCI", "Sélection")), res["lignes"][0])
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Sites recensés", tot["n"])
        m2.metric("Surface totale", fr(tot['surface'], 1, unite="ha"))
        m3.metric("Sans projet", fr(tot.get('s_friche sans projet', 0), 1, unite="ha"),
                  help=f"{tot.get('n_friche sans projet', 0)} site(s)")
        m4.metric("Reconverties", tot.get("n_friche reconvertie", 0))

        def synthese_friches():
            tableau([{"Territoire": l["nom"], "Niveau": l["niveau"], "Sites": l["n"], "Surface (ha)": r1(l["surface"]),
                      "Sans projet": l.get("n_friche sans projet"), "Sans projet (ha)": r1(l.get("s_friche sans projet")),
                      "Avec projet": l.get("n_friche avec projet"), "Potentielles": l.get("n_friche potentielle"),
                      "Reconverties": l.get("n_friche reconvertie")} for l in res["lignes"]])

        def explorer_friches():
            sites = res["sites"]
            f1, f2, f3, f4 = st.columns(4)
            st_ = f1.multiselect("Statuts", [s for s, _l, _c in STATUTS], default=[s for s, _l, _c in STATUTS],
                                 format_func=lambda s: LIB_STATUT[s], key="exp_f_st")
            types_ = sorted({x["type"] or "non renseigné" for x in sites})
            ty = f2.multiselect("Types", types_, placeholder="Tous", key="exp_f_ty")
            com = f3.multiselect("Communes", sorted({x["commune"] for x in sites}, key=lambda c: NOMS.get(c, c)),
                                 format_func=lambda c: NOMS.get(c, c), placeholder="Toutes", key="exp_f_com")
            texte = f4.text_input("Recherche (nom, adresse, activité)", key="exp_f_txt").lower()
            sel = [x for x in sites if x["statut"] in st_ and (not ty or (x["type"] or "non renseigné") in ty)
                   and (not com or x["commune"] in com)
                   and (not texte or texte in f"{x['nom']} {x['attr'].get('site_adresse', '')} "
                                              f"{x['attr'].get('activite_libelle', '')}".lower())]
            if sel:
                par_com = {}
                for x in sel:
                    d = par_com.setdefault(NOMS.get(x["commune"], x["commune"]), {l: 0.0 for _s, l, _c in STATUTS})
                    d[LIB_STATUT[x["statut"]]] += (x["surface_m2"] or 0) / 10000
                donnees = pd.DataFrame([{"Commune": c, **v} for c, v in par_com.items()])
                st.bar_chart(donnees, x="Commune", y=[l for _s, l, _c in STATUTS], color=[c for _s, _l, c in STATUTS],
                             stack=True, horizontal=True, height=max(260, 26 * len(par_com) + 80), x_label="",
                             y_label="hectares")
            tableau([{"Commune": NOMS.get(x["commune"], x["commune"]), "Site": x["nom"],
                      "Statut": LIB_STATUT.get(x["statut"], "Autre"), "Type": x["type"],
                      "Surface (ha)": round(x["surface_m2"] / 10000, 2) if x["surface_m2"] else None,
                      "Occupation": x["attr"].get("site_occupation"), "Pollution des sols": x["attr"].get("sol_pollution_existe"),
                      "Ancienne activité": x["attr"].get("activite_libelle"), "Zone d'urbanisme": x["attr"].get("urba_zone_type"),
                      "Source": x["attr"].get("source_nom"), "Fiche": x["attr"].get("site_url") or None}
                     for x in sorted(sel, key=lambda x: -(x["surface_m2"] or 0))],
                    height=st.session_state.get("hauteur", 850),
                    column_config={"Fiche": st.column_config.LinkColumn(display_text="ouvrir")})

        vue_resultats("friches", synthese_friches, explorer_friches, {
            "prefixe": "Friches_NCPA",
            "carte": lambda ch: carte_friches.exporter_carte(ch, res, COMMUNES, contours(), p),
            "rapport": lambda ch: rapport_friches.generer(ch, res, COMMUNES, p),
            "fichiers": [("Excel", "excel", lambda ch: export_friches.exporter_excel(ch, res, COMMUNES, p), ".xlsx",
                          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
                         ("GeoJSON (QGIS)", "geojson", lambda ch: export_friches.exporter_geojson(ch, res, COMMUNES),
                          ".geojson", "application/geo+json")]})
        st.caption(f"Extraction du {R['date']} · inventaire du {res['meta'].get('maj', '?')} · non exhaustif.")


# =====================================================================
# Thème 4 : zonage
# =====================================================================
with onglet_zonage:
    deja = "zonage" in ETAT["resultats"]
    intro("🗺️", "Zonage, servitudes et prescriptions",
          "Document d'urbanisme de chaque commune, zones U, AU, A et N avec leurs surfaces, servitudes d'utilité "
          "publique, prescriptions, et zone de chaque permis et friche. Sur la carte, vous pouvez ajouter votre "
          "propre couche (GeoJSON) pour voir dans quelle zone tombe chaque objet. Source : Géoportail de "
          "l'Urbanisme (IGN).",
          "#E8A33C")
    with st.expander("Paramètres de l'extraction", icon=":material/tune:", expanded=not deja):
        c1, c2 = st.columns([2, 3])
        with c1:
            codes_z = choix_communes("zonage")
        with c2:
            avec_sup = st.checkbox("Servitudes d'utilité publique", True, key="sup_zonage")
            avec_psc = st.checkbox("Prescriptions (EBC, emplacements réservés…)", True, key="psc_zonage")
            croiser = st.checkbox("Croiser avec les permis et les friches", True, key="croiser_zonage")
            if croiser:
                charges = st.session_state.setdefault("points_charges", {})

                def depot_points(fic):
                    dossier = tempfile.mkdtemp(prefix="urba_")
                    try:
                        pts, genre = croisement.points_geojson(copier_depot(fic, dossier))
                        charges[genre] = pts
                        st.success(f"{len(pts)} point(s) de {genre} chargé(s) : ils remplacent ceux de l'onglet "
                                   f"{genre.capitalize()}.")
                    except Exception as exc:
                        st.error(f"Fichier non reconnu : {exc}")
                    finally:
                        shutil.rmtree(dossier, ignore_errors=True)
                deposer_fichier("zonage", "Facultatif : GeoJSON exporté par l'onglet Permis ou Friches",
                                ["geojson", "json"], depot_points)
            if st.button("Diagnostic de la source (première commune choisie)", key="diag_zonage",
                         disabled=occupe("zonage") or not codes_z, icon=":material/wifi_find:"):
                code = codes_z[0]
                lancer("zonage", f"Diagnostic sur {NOMS[code]}",
                       lambda log, stop: zonage.diagnostic(code, NOMS[code], T.contours_communes(stop_event=stop),
                                                           stop, log), resultat_principal=False)
    points, origines = [], []
    if croiser:
        charges = st.session_state.get("points_charges", {})
        for genre, extraire_pts, lib in (("permis", croisement.points_permis, "Permis"),
                                         ("friches", croisement.points_friches, "Friches")):
            if genre in charges:
                points += charges[genre]
                origines.append(f"{genre} (GeoJSON déposé)")
            elif genre in ETAT["resultats"]:
                pts = extraire_pts(ETAT["resultats"][genre]["resultat"])
                points += pts
                origines.append(f"{genre} (onglet {lib}, {len(pts)} localisés)")
            if occupe(genre):
                st.info(f"L'extraction de l'onglet {lib} est en cours : attendez sa fin pour la croiser avec le zonage.")
        st.caption("Croisement : " + (", ".join(origines) if origines else
                                      "aucun permis ni friche disponible. Lancez l'onglet Permis ou Friches, ou déposez "
                                      "un GeoJSON exporté par ces onglets."))
    if st.button("Lancer l'extraction", type="primary", key="go_zonage", disabled=occupe("zonage") or not codes_z,
                 icon=":material/play_arrow:"):
        p = params_communs(codes_z)
        lancer("zonage", f"Zonage · {len(codes_z)} commune(s)",
               lambda log, stop: zonage_complet.extraire(COMMUNES, codes_z, NOM_EPCI, avec_sup, avec_psc, points,
                                                         origines, stop, log), p)
    suivi("zonage")

    if deja and not occupe("zonage"):
        R = ETAT["resultats"]["zonage"]
        res, p = R["resultat"], R["params"]
        lignes_c = [l for l in res["lignes"] if l["niveau"] == "Commune"]
        tot = next((l for l in res["lignes"] if l["niveau"] != "Commune"), res["lignes"][0])
        statuts = {}
        for l in lignes_c:
            statuts[l["statut"]] = statuts.get(l["statut"], 0) + 1
        couvertes = sum(v for k, v in statuts.items() if k not in ("RNU", "Aucun document en ligne"))
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Communes avec un document", f"{couvertes} / {len(lignes_c)}",
                  help=" · ".join(f"{v} {k}" for k, v in sorted(statuts.items(), key=lambda x: -x[1])))
        m2.metric("Zones à urbaniser", fr(tot['AUc'] + tot['AUs'], 0, unite="ha"),
                  help="dont ouvertes (AUc) : " + fr(tot['AUc'], 0, unite="ha"))
        m3.metric("Servitudes", len(res["servitudes"]["features"]))
        m4.metric("Permis et friches croisés", len(res["points"]))

        def synthese_zonage():
            tableau([{"Territoire": l["nom"], "Document": l["statut"], "U (ha)": r1(l["U"], 0),
                      "AUc (ha)": r1(l["AUc"], 0), "AUs (ha)": r1(l["AUs"], 0), "A (ha)": r1(l["A"], 0),
                      "N (ha)": r1(l["N"], 0), "Carte communale (ha)": r1((l.get("ZC") or 0) + (l.get("ZnC") or 0), 0),
                      "Total zoné (ha)": r1(l["zone"], 0)} for l in res["lignes"]])

        def explorer_zonage():
            choix = st.selectbox("Commune", ["Tout le territoire"] + [l["code"] for l in lignes_c],
                                 format_func=lambda c: c if c == "Tout le territoire" else NOMS.get(c, c), key="exp_z_com")
            dans = (lambda code: True) if choix == "Tout le territoire" else (lambda code: code == choix)
            if choix != "Tout le territoire":
                l = next(x for x in lignes_c if x["code"] == choix)
                doc = l["document"] or {}
                st.markdown(f"**{l['nom']}** · {l['statut']}" + (f" · {doc.get('nom')}" if doc.get("nom") else "")
                            + (f" · approuvé le {carte_zonage._date(doc.get('approbation'))}" if doc.get("approbation") else ""))
            surfaces = {}
            for f in res["zones"]["features"]:
                pp = f["properties"]
                if dans(pp["commune_code"]):
                    surfaces[pp["famille_lib"]] = surfaces.get(pp["famille_lib"], 0) + pp["surface_ha"]
            c1, c2 = st.columns([2, 3])
            if surfaces:
                court = {"Urbaine (U)": "U · urbaine", "À urbaniser ouverte (AUc)": "AUc · à urbaniser ouverte",
                         "À urbaniser fermée (AUs)": "AUs · à urbaniser fermée", "Agricole (A)": "A · agricole",
                         "Naturelle (N)": "N · naturelle", "Constructible (carte communale)": "CC · constructible",
                         "Non constructible (carte communale)": "CC · non constructible", "Autre": "Autre"}
                c1.bar_chart(pd.DataFrame([{"Zone": court.get(lab, lab), "Surface (ha)": round(v, 1)}
                                           for lab, v in surfaces.items()]),
                             x="Zone", y="Surface (ha)", horizontal=True, height=320, x_label="", y_label="hectares",
                             color=ROUGE)
            zones_lib = {}
            for f in res["zones"]["features"]:
                pp = f["properties"]
                if dans(pp["commune_code"]):
                    cle = (pp["libelle"] or pp["typezone"], pp["famille_lib"], pp.get("reglement_url"))
                    zones_lib[cle] = zones_lib.get(cle, 0) + pp["surface_ha"]
            with c2:
                tableau([{"Zone": k[0], "Type": k[1], "Surface (ha)": round(v, 1), "Règlement": k[2]}
                         for k, v in sorted(zones_lib.items(), key=lambda x: -x[1])], height=320,
                        column_config={"Règlement": st.column_config.LinkColumn(display_text="PDF")})
            o1, o2, o3 = st.tabs(["Servitudes", "Prescriptions", "Permis et friches"])
            with o1:
                sup = [f["properties"] for f in res["servitudes"]["features"] if dans(f["properties"]["commune_code"])]
                if sup:
                    tableau([{"Commune": x["commune"], "Catégorie": x["categorie"], "Servitude": x["categorie_lib"],
                              "Objet": x["nom"], "Emprise": x["mesure"], "Unité": x["unite"]} for x in sup])
                else:
                    st.caption("Aucune servitude extraite ici (case non cochée, ou rien de publié sur le Géoportail).")
            with o2:
                psc = [f["properties"] for f in res["prescriptions"]["features"] if dans(f["properties"]["commune_code"])]
                if psc:
                    tableau([{"Commune": x["commune"], "Type": x["type_lib"], "Libellé": x["libelle"],
                              "Emprise": x["mesure"], "Unité": x["unite"]} for x in psc])
                else:
                    st.caption("Aucune prescription extraite ici.")
            with o3:
                pts = [x for x in res["points"] if dans(x.get("commune_code"))]
                if pts:
                    tableau([{"Type": croisement.LIB_THEME.get(x["source"], x["source"]), "Nom": x["nom"],
                              "Commune": NOMS.get(x.get("commune_code"), ""), "Zone": x["zone"],
                              "Type de zone": x["famille_lib"], "Servitudes": x["servitudes"],
                              "Prescriptions": x["prescriptions"], "Logements": x.get("logements") or None,
                              "À venir": x.get("a_venir", "")} for x in pts])
                else:
                    st.caption("Aucun permis ni friche croisé : lancez d'abord l'onglet Permis ou Friches.")

        vue_resultats("zonage", synthese_zonage, explorer_zonage, {
            "prefixe": "Zonage_NCPA",
            "carte": lambda ch: carte_zonage.exporter_carte(ch, res, res["contours"], p),
            "rapport": lambda ch: rapport_zonage.generer(ch, res, p),
            "fichiers": [("GeoJSON des zones (QGIS)", "geojson", lambda ch: carte_zonage.exporter_geojson(ch, res),
                          ".geojson", "application/geo+json")]})
        st.caption(f"Extraction du {R['date']} · AUc : à urbaniser ouverte · AUs : à urbaniser fermée · seul le "
                   "document en vigueur publié sur le Géoportail fait foi.")

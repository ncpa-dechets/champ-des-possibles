# Économie et emploi · NCPA : choix techniques

Version 1.1 du 03/11/2026. Fusion de l'« Observatoire de l'emploi » v0.5.1 (CustomTkinter) et du « Portrait
économique » v1.4 (Streamlit). Refonte complète : un seul moteur, une seule collecte, doublons supprimés.

## Lancement

- `lancer_interface.bat` (ou `python -m streamlit run app.py`). Python requis sur le poste, pas de .exe.
- Dossiers créés à côté de `app.py` : `cache/`, `donnees_manuelles/`, `sorties/`. Réglages : `config.xlsx`
  (territoire, indicateurs Insee, hypothèses de la base économique) et `preferences.json` (dernières cases cochées).

## Architecture

| Fichier | Rôle |
|---|---|
| `app.py` | Interface : Choisir et collecter, Résultats, Entreprises, Exporter, Paramètres |
| `observatoire/catalogue.py` | 21 sources et 17 thèmes ; plan de collecte = union dédoublonnée des sources cochées |
| `observatoire/moteur.py` | Collecte source par source (fil séparé), puis appel des analyses |
| `observatoire/reseau.py` | Session qui compte appels et octets par source ; nouvelles tentatives ; cache JSON daté ; mode hors ligne |
| `observatoire/utils.py` | Journal commun et suivi par source (`SUIVI`), lu chaque seconde par l'interface |
| `observatoire/collecte/` | Modules des deux anciens outils + `urssaf.py` (unifié) et `labonneboite.py` (nouveau) |
| `observatoire/analyses/eco.py` | Analyses du portrait (pandas), inchangées |
| `observatoire/analyses/emploi.py`, `complements.py` | Calculs de l'outil Emploi (Python pur), inchangés |
| `observatoire/analyses/blocs_emploi.py` | Résultats Emploi mis au même format de « blocs » que le portrait |
| `observatoire/analyses/assemblage.py` | Assemblage par thème, chiffres clés, synthèse, arbitrage des doublons |
| `observatoire/rendu/figures.py` | Graphiques Plotly ; barre d'outils réduite à l'icône d'export PNG |
| `observatoire/rendu/cartes.py` | 3 cartes Leaflet (communes, entreprises, flux) ; Positron + orthophoto IGN ; bibliothèques embarquées |
| `observatoire/rendu/export_html.py` | Rapport HTML à onglets composé selon thèmes, publics et cartes cochés |
| `observatoire/rendu/export_excel.py` | Classeur : un onglet par analyse, listes d'entreprises, base économique recalculable |
| `tests/` | Faux réseau (données fictives) et test de bout en bout |

Un **bloc** = id, thème, titre, lecture, source, tableau(x), description du graphique, drapeau « essentiel »
(repris dans l'onglet Synthèse pour les élus). Le même bloc sert à l'écran, au HTML et à l'Excel.

## Doublons supprimés

| Information | Avant | Maintenant |
|---|---|---|
| Urssaf commune × APE | CSV régional (portrait) + JSON de l'EPCI (emploi) | une requête JSON pour les départements de la région ; l'EPCI en est extrait |
| Contours des communes | deux appels geo.api | un seul (région), l'EPCI en est extrait |
| Évolution de l'emploi en base 100 | deux graphiques | version Emploi (avec groupes d'EPCI) |
| Emploi par commune | « concentration » + « emplois par commune » | un bloc : graphique Emploi, lecture et top APE du portrait |
| Domicile-travail | fichier déposé à la main (portrait) + téléchargement (emploi) | téléchargement automatique ; dépôt manuel en secours ; sert aussi à la base économique |
| Résidences secondaires de l'EPCI | dossier complet + appel Melodi | dossier complet ; Melodi seulement pour tous les EPCI (groupe touristique) |
| ANCT : concentration d'emploi, sphère, chômage | ANCT + portrait | retirés du bloc ANCT quand le portrait les calcule |

## Suivi de la collecte

Chaque appel passe par `SessionSuivie`, qui l'impute à la source en cours. Progression : octets reçus / taille
annoncée pour les gros fichiers, métiers traités pour La Bonne Boite, sinon appels réalisés / appels attendus
(estimation, plafonnée à 95 %). États : en attente, en cours, téléchargé, depuis le cache (aucun appel),
partiel (alerte), échec, non interrogée (clé absente ou source préalable en échec). Une source en échec
n'arrête pas les autres.

## La Bonne Boite v2 (nouveau, non vérifié en réel)

- `GET https://api.francetravail.io/partenaire/labonneboite/v2/recherche`, un appel par métier (code ROME) et par
  page de 100, autour de la commune la plus centrale de l'EPCI, rayon couvrant toutes ses communes + 3 km ;
  résultats hors EPCI écartés.
- Jeton **séparé** des deux autres API (un scope refusé fait échouer tout le jeton). Scopes essayés :
  `api_labonneboitev2 search office`, puis `api_labonneboitev2`.
- 2 appels par seconde, respect du `Retry-After` en cas de 429. Paramètre `rome`, repli sur `rome[]`.
- Lecture des champs tolérante (plusieurs noms essayés) ; première réponse brute enregistrée dans
  `cache/sonde_labonneboite.json` : **à m'envoyer après le premier lancement réel**.
- Métiers : liste par défaut de 22 codes ROME (onglet 1, réglages), codes libres, et option « métiers BMO du
  bassin » (correspondance FAP → ROME de l'API Marché du travail, mise en cache).
- Licence ouverte : France Travail cité sur la carte, dans les listes et les exports.

## Graphiques et cartes

- Plotly : survol, zoom, une seule icône (appareil photo) qui enregistre un PNG en double résolution, titre
  et source inclus dans l'image. Plotly est embarqué dans le rapport HTML (≈ 4,6 Mo) : il s'ouvre hors ligne.
- Cartes : une même fonction JavaScript sert à l'aperçu et aux exports ; initialisation différée tant que la
  carte est dans un onglet masqué. Carte des entreprises filtrable (commune, secteur, taille, métier, fort
  potentiel, recherche) avec téléchargement CSV de la sélection.

## Tests

`python tests/test_moteur.py` : faux réseau (structures relevées par les sondes de l'outil Emploi, dossier Insee
fictif, réponse La Bonne Boite supposée), collecte des 21 sources, 17 thèmes, 41 graphiques, 3 cartes, exports,
puis relance hors ligne. Exports ouverts dans Chromium sans erreur JavaScript ; interface pilotée dans le
navigateur. `OBS_FAUX_RESEAU=1` (et `OBS_FAUX_DELAI=0.4` pour voir la progression) lance l'interface sur ces
données fictives. **Pas encore testé sur les vraies API** : premier lancement à surveiller dans le journal.

## Non repris

- Mode démonstration du portrait (remplacé par le faux réseau des tests).
- Graphiques PNG matplotlib et cartes statiques (remplacés par l'export image de chaque graphique).
- Synthèse d'une page séparée de l'outil Emploi : devenue le public « Élus et direction générale » du rapport.

## v1.1 : cartes

- **Fond « Plan »** : OpenFreeMap Positron est un fond vectoriel qui exige WebGL. Sur les postes où WebGL est
  désactivé ou bloqué (accélération matérielle coupée, proxy), le plan restait vide. L'outil bascule désormais
  automatiquement sur le **Plan IGN** (images, sans WebGL) si WebGL est absent ou si le style Positron n'est pas
  chargé en 8 secondes. Le message « Fond Positron indisponible… » apparaît alors dans la console du navigateur (F12).
- Sélecteur Plan / Photographie aérienne toujours déplié ; contours de l'EPCI blancs et fins sur la photographie.
- **Pleine page** : les cartes exportées seules occupent tout l'écran ; filtres et légende flottent par-dessus et se
  replient (bouton « Masquer »). Même présentation, en grand, dans l'onglet Cartes du rapport et dans l'interface.

"""Lance l'outil Économie et emploi : vérifie les bibliothèques, démarre le serveur local
Streamlit et ouvre le navigateur. Fermer la fenêtre de console arrête l'outil."""
import importlib.util
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ICI = Path(__file__).resolve().parent
PORT = 8501
REQUIS = ["streamlit", "pandas", "pyarrow", "duckdb", "geopandas", "shapely", "openpyxl", "xlrd", "requests", "plotly"]


def port_libre(port):
    with socket.socket() as s:
        return s.connect_ex(("localhost", port)) != 0


manquants = [m for m in REQUIS if importlib.util.find_spec(m) is None]
if manquants:
    print(f"Installation des bibliothèques manquantes : {', '.join(manquants)} (une seule fois)…")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(ICI / "requirements.txt")])
    if r.returncode != 0:
        input("\nInstallation impossible : copier le message ci-dessus pour le diagnostic. Entrée pour fermer.")
        sys.exit(1)

port = PORT
if not port_libre(port):  # interface déjà ouverte : on l'affiche plutôt que d'en lancer une 2e
    webbrowser.open(f"http://localhost:{port}")
    print(f"L'interface tourne déjà : http://localhost:{port}")
    time.sleep(3)
    sys.exit(0)

print("Démarrage de l'interface… (laisser cette fenêtre ouverte ; la fermer arrête l'outil)")
proc = subprocess.Popen([sys.executable, "-m", "streamlit", "run", str(ICI / "app.py"),
                         "--server.port", str(port)], cwd=ICI)
for _ in range(60):  # attendre que le serveur réponde (30 s max)
    if not port_libre(port):
        webbrowser.open(f"http://localhost:{port}")
        print(f"Interface ouverte dans le navigateur : http://localhost:{port}")
        break
    time.sleep(0.5)
try:
    proc.wait()
except KeyboardInterrupt:
    proc.terminate()

"""Servitudes d'utilité publique (SUP) et prescriptions des documents d'urbanisme.

Source : API Carto de l'IGN, module GPU.
- Prescriptions (EBC, emplacements réservés, éléments de paysage...) :
  couches prescription-surf / -lin / -pct, téléchargées par document
  (partition), comme les zones.
- Servitudes : couches assiette-sup-s / -l / -p. Elles ne dépendent pas du
  document d'urbanisme (elles sont publiées par les gestionnaires : DDTM,
  ABF, ARS, RTE...) : on les interroge commune par commune, sur le rectangle
  englobant la commune, puis on découpe selon la limite communale.
Caches de 30 jours dans cache_zonage/. Surfaces en Lambert-93 (m²),
longueurs en mètres.
"""
import json
import re

from shapely import make_valid
from shapely.geometry import box, mapping, shape
from shapely.strtree import STRtree

from . import reseau
from .zonage import DUREE_CACHE, _arrondir, _ecrire_cache, _lire_cache, _vers_l93, toutes_les_pages

# Nomenclature nationale des SUP (catégories les plus courantes)
CATEGORIES_SUP = {
    "AC1": "Monuments historiques", "AC2": "Sites inscrits et classés", "AC3": "Réserves naturelles",
    "AC4": "Sites patrimoniaux remarquables", "AS1": "Protection des captages d'eau potable",
    "AS2": "Eaux minérales", "A1": "Bois et forêts", "A4": "Passage le long des cours d'eau non domaniaux",
    "A5": "Canalisations d'eau et d'assainissement", "EL3": "Halage et marchepied", "EL7": "Alignement des voies",
    "EL9": "Passage des piétons sur le littoral", "EL11": "Accès aux voies express",
    "I1": "Canalisations d'hydrocarbures", "I3": "Canalisations de gaz", "I4": "Lignes électriques",
    "INT1": "Voisinage des cimetières", "JS1": "Installations sportives",
    "PM1": "Plans de prévention des risques naturels", "PM2": "Installations classées (ICPE)",
    "PM3": "Plans de prévention des risques technologiques", "PT1": "Télécommunications (perturbations)",
    "PT2": "Télécommunications (obstacles)", "PT3": "Réseaux de télécommunications", "T1": "Voies ferrées",
    "T4": "Balisage aéronautique", "T5": "Dégagement aéronautique", "T7": "Servitudes aéronautiques hors dégagement",
}
# Standard CNIG PLU : types de prescriptions dont le libellé est sûr ; les autres
# prennent le libellé le plus fréquent trouvé dans les données.
TYPES_PSC = {"01": "Espace boisé classé", "05": "Emplacement réservé",
             "07": "Élément de paysage ou de patrimoine protégé"}
COULEURS_PSC = {"01": "#2E7D32", "05": "#7B3FA0", "07": "#8D6E63"}


def categorie_sup(props):
    for cle in ("suptype", "categorie", "typesup", "type_sup"):
        v = props.get(cle)
        if v:
            return str(v).strip().upper()
    m = re.search(r"_SUP_[^_]+_([A-Z0-9]+)$", str(props.get("partition", "")).upper())
    return m.group(1) if m else "?"


def libelle_sup(cat):
    return CATEGORIES_SUP.get(cat, f"Servitude {cat}")


def _decouper_geom(g, forme):
    """Intersection propre selon la dimension de l'objet ; None si vide."""
    try:
        inter = g.intersection(forme)
    except Exception:
        inter = make_valid(g).intersection(forme)
    if inter.is_empty:
        return None
    if g.geom_type in ("Polygon", "MultiPolygon"):
        if inter.geom_type == "GeometryCollection":
            polys = [p for p in inter.geoms if p.geom_type in ("Polygon", "MultiPolygon")]
            if not polys:
                return None
            from shapely.ops import unary_union
            inter = unary_union(polys)
        return inter if inter.geom_type in ("Polygon", "MultiPolygon") else None
    if g.geom_type in ("LineString", "MultiLineString"):
        if inter.geom_type == "GeometryCollection":
            lignes = [p for p in inter.geoms if p.geom_type in ("LineString", "MultiLineString")]
            if not lignes:
                return None
            from shapely.ops import linemerge, unary_union
            inter = unary_union(lignes)
        return inter if inter.geom_type in ("LineString", "MultiLineString") else None
    return inter if inter.geom_type in ("Point", "MultiPoint") else None


def _mesure(g):
    """(valeur, unité) : ha pour une surface, m pour une ligne, 1 pour un point."""
    if g.geom_type in ("Polygon", "MultiPolygon"):
        return _vers_l93(g).area / 10000, "ha"
    if g.geom_type in ("LineString", "MultiLineString"):
        return _vers_l93(g).length, "m"
    return (len(g.geoms) if g.geom_type == "MultiPoint" else 1), "objet"


def _formes(contours, codes):
    return {str(f["properties"]["code"]): make_valid(shape(f["geometry"]))
            for f in contours.get("features", []) if str(f["properties"]["code"]) in codes}


# ------------------------------------------------------------------ prescriptions
def prescriptions_partition(partition, stop_event=None, journal=print):
    nom = f"prescriptions_{partition}.json"
    cache = _lire_cache(nom, DUREE_CACHE)
    if cache is not None:
        journal(f"   {partition} : {sum(len(v) for v in cache.values())} prescriptions (cache)")
        return cache
    res = {}
    for couche in ("prescription-surf", "prescription-lin", "prescription-pct"):
        reseau.verifier_annulation(stop_event)
        res[couche] = toutes_les_pages(couche, {"partition": partition}, stop_event, journal)
    journal(f"   {partition} : {sum(len(v) for v in res.values())} prescriptions reçues")
    _ecrire_cache(nom, res)
    return res


def decouper_prescriptions(par_partition, contours, codes, documents, noms, simplification=0.00002):
    formes = _formes(contours, codes)
    morceaux, bilan, libelles = [], {code: {} for code in codes}, {}
    for partition, couches in par_partition.items():
        cibles = [c for c in codes if ((documents.get(c) or {}).get("document") or {}).get("partition") == partition]
        for couche, objets in couches.items():
            for o in objets:
                p = o.get("properties", {})
                code_type = str(p.get("typepsc") or "").zfill(2) if p.get("typepsc") else "??"
                libelles.setdefault(code_type, {})
                lib = p.get("libelle") or p.get("txt") or ""
                libelles[code_type][lib] = libelles[code_type].get(lib, 0) + 1
                try:
                    g = make_valid(shape(o["geometry"]))
                except Exception:
                    continue
                for code in cibles:
                    if not g.intersects(formes[code]):
                        continue
                    piece = _decouper_geom(g, formes[code])
                    if piece is None:
                        continue
                    valeur, unite = _mesure(piece)
                    b = bilan[code].setdefault(code_type, {"nombre": 0, "ha": 0.0, "m": 0.0})
                    b["nombre"] += 1
                    if unite == "ha":
                        b["ha"] += valeur
                    elif unite == "m":
                        b["m"] += valeur
                    if piece.geom_type not in ("Point", "MultiPoint"):
                        piece = piece.simplify(simplification, preserve_topology=True)
                    morceaux.append({"type": "Feature", "geometry": _arrondir(mapping(piece)), "properties": {
                        "couche": "prescription", "commune_code": code, "commune": noms.get(code, code),
                        "typepsc": code_type, "stypepsc": p.get("stypepsc"), "libelle": lib,
                        "txt": p.get("txt"), "mesure": round(valeur, 2), "unite": unite,
                        "partition": partition, "reglement_url": p.get("urlfic")}})
    noms_types = {}
    for t, libs in libelles.items():
        frequent = max(libs.items(), key=lambda x: x[1])[0] if libs else ""
        noms_types[t] = TYPES_PSC.get(t) or (f"{frequent} (type {t})" if frequent else f"Prescription de type {t}")
    for m in morceaux:
        m["properties"]["type_lib"] = noms_types.get(m["properties"]["typepsc"], m["properties"]["typepsc"])
    return morceaux, bilan, noms_types


# ------------------------------------------------------------------ servitudes
def servitudes_commune(code, forme, stop_event=None, journal=print):
    nom = f"sup_{code}.json"
    cache = _lire_cache(nom, DUREE_CACHE)
    if cache is not None:
        return cache
    minx, miny, maxx, maxy = forme.bounds
    geom = json.dumps(mapping(box(minx, miny, maxx, maxy)))
    res = {}
    for couche in ("assiette-sup-s", "assiette-sup-l", "assiette-sup-p"):
        reseau.verifier_annulation(stop_event)
        res[couche] = toutes_les_pages(couche, {"geom": geom}, stop_event, journal)
        reseau.pause(0.1, stop_event)
    _ecrire_cache(nom, res)
    return res


def recuperer_servitudes(contours, codes, noms, stop_event=None, journal=print, simplification=0.00002):
    formes = _formes(contours, codes)
    morceaux, bilan = [], {code: {} for code in codes}
    journal(f"   servitudes d'utilité publique : {len(formes)} commune(s) à interroger (cache 30 jours)...")
    for i, (code, forme) in enumerate(formes.items(), start=1):
        couches = servitudes_commune(code, forme, stop_event, journal)
        for couche, objets in couches.items():
            for o in objets:
                p = o.get("properties", {})
                cat = categorie_sup(p)
                try:
                    g = make_valid(shape(o["geometry"]))
                except Exception:
                    continue
                piece = _decouper_geom(g, forme)
                if piece is None:
                    continue
                valeur, unite = _mesure(piece)
                if unite == "ha" and valeur < 0.001:
                    continue
                b = bilan[code].setdefault(cat, {"nombre": 0, "ha": 0.0, "m": 0.0})
                b["nombre"] += 1
                if unite == "ha":
                    b["ha"] += valeur
                elif unite == "m":
                    b["m"] += valeur
                if piece.geom_type not in ("Point", "MultiPoint"):
                    piece = piece.simplify(simplification, preserve_topology=True)
                morceaux.append({"type": "Feature", "geometry": _arrondir(mapping(piece)), "properties": {
                    "couche": "servitude", "commune_code": code, "commune": noms.get(code, code),
                    "categorie": cat, "categorie_lib": libelle_sup(cat),
                    "nom": p.get("nomass") or p.get("nomsuplitt") or p.get("nomgen") or p.get("libelle"),
                    "type_assiette": p.get("typeass"), "gestionnaire": p.get("partition"),
                    "mesure": round(valeur, 2), "unite": unite}})
        reseau.avancement(i / len(formes))
        if i % 10 == 0:
            journal(f"      {i} / {len(formes)} communes")
    cats = sorted({c for b in bilan.values() for c in b})
    journal(f"   {len(morceaux)} morceaux de servitudes · catégories : " + (", ".join(cats) if cats else "aucune"))
    return morceaux, bilan


# ------------------------------------------------------------------ test de présence en un point
class Index:
    """Index spatial pour savoir quelles zones, servitudes et prescriptions couvrent un point."""

    def __init__(self, features):
        self.props, geoms = [], []
        for f in features:
            try:
                g = shape(f["geometry"])
            except Exception:
                continue
            if g.geom_type in ("Polygon", "MultiPolygon"):
                geoms.append(g)
                self.props.append(f["properties"])
        self.geoms = geoms
        self.arbre = STRtree(geoms) if geoms else None

    def contenant(self, point):
        if self.arbre is None:
            return []
        return [self.props[int(i)] for i in self.arbre.query(point) if self.geoms[int(i)].covers(point)]

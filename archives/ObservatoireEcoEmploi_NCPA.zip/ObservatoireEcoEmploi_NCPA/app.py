# -*- coding: utf-8 -*-
"""Économie et emploi · NCPA : interface (Streamlit).

Fusion de l'outil « Portrait économique » (Streamlit) et de l'« Observatoire de l'emploi » (CustomTkinter).
Lancement : double-clic sur lancer_interface.bat (ou : python -m streamlit run app.py).
Tout tourne sur le poste : la page du navigateur n'est qu'un tableau de bord local.
"""
import io
import json
import os
import platform
import subprocess
import sys
import threading
import traceback
import webbrowser
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI))
if os.environ.get("OBS_FAUX_RESEAU"):  # tests uniquement : données FICTIVES (tests/faux_reseau.py)
    sys.path.insert(0, str(ICI / "tests"))
    import faux_reseau  # noqa: E402
    faux_reseau.installer()

from observatoire import catalogue, moteur  # noqa: E402
from observatoire.collecte import labonneboite as LBB  # noqa: E402
from observatoire.config import FICHIER as CONFIG, charger_config, enregistrer_config  # noqa: E402
from observatoire.utils import CACHE, JOURNAL, MANUELS, RACINE, SORTIES, SUIVI, horodatage  # noqa: E402
from observatoire.rendu import cartes, export_excel, export_html, figures  # noqa: E402
from observatoire.analyses.textes import INTRO_THEMES  # noqa: E402

st.set_page_config(page_title="Économie et emploi · NCPA", page_icon="📊", layout="wide")
st.markdown("""<style>
html, body, [class*="css"] {font-family: Calibri, Carlito, "Segoe UI", system-ui, sans-serif;}
.bandeau {border-top: 6px solid #B91E27; padding: 10px 0 2px 0; margin-bottom: 2px}
.eyebrow {font-size: 12px; letter-spacing: .14em; text-transform: uppercase; color: #B91E27; font-weight: 700}
.bandeau h1 {font-size: 30px; margin: 2px 0 0 0; padding: 0}
.journal {font-family: Consolas, monospace; font-size: 12.5px; line-height: 1.45; background: #FAFAF8;
          border: 1px solid #E3E3DE; padding: 8px 10px; max-height: 260px; overflow-y: auto}
.niv-ok {color: #3B7A3B} .niv-alerte {color: #B26B00} .niv-erreur {color: #B91E27; font-weight: 700}
.niv-info {color: #5B6770}
.lecture {background: #F4F5EE; border-left: 3px solid #B1B993; padding: 8px 12px; margin: 0 0 6px 0; font-size: 15px}
.famille {color: #B91E27; font-weight: 700; font-size: 15px; margin-bottom: 2px}
.petit {font-size: 12.5px; color: #5B6770}
.cles {display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 12px; margin: 8px 0 14px 0}
.cle {background: #fff; border: 1px solid #E3E3DE; border-left: 4px solid #B91E27; padding: 10px 12px; border-radius: 2px}
.cle .lib {font-size: 12px; color: #5B6770; text-transform: uppercase; letter-spacing: .04em}
.cle .val {font-size: 25px; font-weight: 700; color: #111; margin: 1px 0}
.cle .sous {font-size: 12px; color: #5B6770}
</style>""", unsafe_allow_html=True)

PICTO = {"ok": "✅", "alerte": "⚠️", "erreur": "❌", "info": "·"}
ETATS = {"attente": "⏳ en attente", "en cours": "🔄 en cours", "ok": "✅ téléchargé", "cache": "💾 depuis le cache",
         "alerte": "⚠️ partiel", "erreur": "❌ échec", "ignoree": "⏭ non interrogée"}
PREFS = RACINE / "preferences.json"
CONFIG_PLOTLY = figures.config


# ============================================================================================ utilitaires
def lire_prefs():
    try:
        return json.loads(PREFS.read_text(encoding="utf-8"))
    except Exception:
        return {}


def ecrire_prefs(**kw):
    p = lire_prefs()
    p.update(kw)
    try:
        PREFS.write_text(json.dumps(p, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass


def ouvrir(chemin):
    chemin = Path(chemin)
    try:
        if platform.system() == "Windows":
            os.startfile(chemin)  # noqa
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", chemin])
        elif chemin.suffix == ".html":
            webbrowser.open(chemin.as_uri())
        else:
            subprocess.Popen(["xdg-open", chemin])
    except Exception as e:
        st.error(f"Ouverture impossible : {e}")


def excel_octets(df, feuille="Données"):
    b = io.BytesIO()
    with pd.ExcelWriter(b, engine="openpyxl") as w:
        df.to_excel(w, index=False, sheet_name=feuille[:31])
    return b.getvalue()


def age_txt(d):
    if d is None:
        return "à télécharger"
    j = (datetime.now() - d).days
    return "en cache (aujourd'hui)" if j < 1 else f"en cache (il y a {j} j)"


@st.cache_resource
def tache():
    """État partagé, conservé si on recharge la page ou si on clique ailleurs pendant la collecte."""
    return {"thread": None, "brut": None, "plantage": None, "res": None, "res_cle": None, "etat": None,
            "themes": [], "test": []}


T = tache()
en_cours = T["thread"] is not None and T["thread"].is_alive()
prefs = lire_prefs()
try:
    cfg = charger_config()
except Exception as e:
    st.error(f"Lecture de config.xlsx impossible : {e}. Fermer config.xlsx s'il est ouvert dans Excel, puis recharger "
             "la page (F5).")
    st.stop()


def cles_presentes():
    from observatoire.collecte import sirene
    from observatoire.collecte.francetravail import lire_identifiants
    return bool(sirene.lire_cle()), bool(lire_identifiants()[0])


# ============================================================================================ en-tête
st.markdown(f'<div class="bandeau"><div class="eyebrow">Connaissance du territoire · {cfg["nom_court"]}</div>'
            f'<h1>Économie et emploi</h1></div>', unsafe_allow_html=True)
st.caption("Portrait économique (Insee, Urssaf, DGFiP) et emploi (Urssaf, France Travail, SIRENE, La Bonne Boite, "
           "ANCT) en un seul outil : choisir les thèmes, collecter, consulter, exporter.")

with st.sidebar:
    st.markdown(f"### {cfg['nom_long'] or cfg['nom_court']}")
    st.caption(f"EPCI {cfg['code_epci']} · département {cfg['departement']} · région {cfg['region']}")
    ks, kf = cles_presentes()
    st.markdown(f"{'🟢' if ks else '🔴'} Clé SIRENE  \n{'🟢' if kf else '🔴'} Identifiants France Travail")
    if T["brut"]:
        st.markdown(f"**Dernière collecte** : {T['brut']['date']}  \n"
                    f"{len(T['brut'].get('themes', []))} thèmes")
    st.divider()
    if st.button("📁 Dossier des exports", width="stretch"):
        ouvrir(SORTIES)
    st.caption("Pour arrêter l'outil : fermer la fenêtre noire (console).")

t_col, t_res, t_ent, t_exp, t_par = st.tabs(["① Choisir et collecter", "② Résultats", "③ Entreprises",
                                             "④ Exporter", "⚙ Paramètres"])


# ============================================================================================ 1. COLLECTE
def demarrer(themes, options, mode, forcer):
    T.update(brut=None, plantage=None, res=None, res_cle=None, etat=None, themes=list(themes))

    def travail():
        try:
            T["brut"] = moteur.collecter(themes, options, mode, forcer)
        except Exception as e:
            T["plantage"] = (str(e), traceback.format_exc())
        finally:
            T["etat"] = SUIVI.instantane()
    SUIVI.preparer(catalogue.plan(themes, options))
    T["thread"] = threading.Thread(target=travail, daemon=True)
    T["thread"].start()


def tableau_suivi(etat):
    df = pd.DataFrame([{"État": ETATS.get(e["statut"], e["statut"]), "Source": e["libelle"], "Fournisseur · API": e["api"],
                        "Progression": e["fraction"] if e["fraction"] is not None else (0.0 if e["statut"] != "en cours" else None),
                        "Appels": e["appels"], "Reçu (Mo)": round(e["octets"] / 1e6, 1),
                        "Durée (s)": round(e["duree"]) if e["duree"] is not None else None,
                        "Dernier message": e["message"]} for e in etat])
    st.dataframe(df, hide_index=True, width="stretch", height=min(40 + 35 * len(df), 780),
                 column_config={"Progression": st.column_config.ProgressColumn("Progression", min_value=0, max_value=1,
                                                                              format="percent", width="small"),
                                "Dernier message": st.column_config.TextColumn(width="large")})


@st.fragment(run_every=1.0)
def suivi():
    if not (T["thread"] and T["thread"].is_alive()):
        st.rerun()
    etat = SUIVI.instantane()
    finies = sum(e["statut"] in ("ok", "cache", "alerte", "erreur", "ignoree") for e in etat)
    cours = next((e for e in etat if e["statut"] == "en cours"), None)
    total = (finies + ((cours or {}).get("fraction") or 0)) / max(len(etat), 1)
    st.progress(min(total, 1.0), text=f"{finies}/{len(etat)} sources" +
                (f" · en cours : {cours['libelle']} ({cours['api']})" if cours else ""))
    tableau_suivi(etat)
    lignes = list(JOURNAL)[-12:]
    st.markdown('<div class="journal">' + "".join(
        f'<div class="niv-{x["niveau"]}">{x["heure"]} {PICTO.get(x["niveau"], "")} <b>{x["etape"]}</b> — '
        f'{str(x["message"])[:220]}</div>' for x in lignes) + "</div>", unsafe_allow_html=True)


def panneau_suivi():
    if en_cours:
        st.markdown("#### Progression de la collecte")
        st.info("Collecte en cours : vous pouvez consulter les autres onglets, elle continue.")
        suivi()
    elif T["plantage"]:
        st.error(f"La collecte s'est arrêtée : {T['plantage'][0]}")
        with st.expander("Détail technique (à copier pour le diagnostic)"):
            st.code(T["plantage"][1], language=None)
    elif T["etat"]:
        etat = T["etat"]
        ne = sum(e["statut"] == "erreur" for e in etat)
        na = sum(e["statut"] in ("alerte", "ignoree") for e in etat)
        duree = (T["brut"] or {}).get("duree_collecte", 0)
        msg = f"Collecte terminée en {duree:.0f} s : {len(etat) - ne - na} sources complètes"
        (st.error if ne else st.warning if na else st.success)(
            msg + (f", {na} partielles ou non interrogées" if na else "") + (f", {ne} en échec" if ne else "")
            + ". Résultats : onglet ② Résultats.")
        tableau_suivi(etat)
        j = pd.DataFrame((T["brut"] or {}).get("journal_collecte") or [])
        if len(j):
            with st.expander(f"Journal complet ({len(j)} lignes)"):
                filtre = st.segmented_control("Afficher", ["tout", "alertes et erreurs"], default="alertes et erreurs")
                if filtre == "alertes et erreurs":
                    j = j[j.niveau.isin(["alerte", "erreur"])]
                j.insert(0, "", j.niveau.map(PICTO))
                st.dataframe(j, hide_index=True, width="stretch")
    if en_cours or T["plantage"] or T["etat"]:
        st.divider()


with t_col:
    panneau_suivi()
    themes_pref = set(prefs.get("themes") or ["recensement", "spheres", "base_eco", "evolution", "secteurs", "communes",
                                               "ft", "bmo", "employeurs"])
    c1, c2 = st.columns([5, 4], gap="large")
    choisis = []
    with c1:
        st.markdown("#### Quelles informations récupérer ?")
        st.caption("Chaque thème indique les sources qu'il interroge. Une source commune à plusieurs thèmes n'est "
                   "interrogée qu'une fois.")
        cols = st.columns(2)
        for i, fam in enumerate(catalogue.FAMILLES):
            with cols[i % 2].container(border=True):
                st.markdown(f'<div class="famille">{fam}</div>', unsafe_allow_html=True)
                for t, (f, lib, desc, srcs) in catalogue.THEMES.items():
                    if f != fam:
                        continue
                    fournisseurs = sorted({catalogue.SOURCES[s][1].split(" · ")[0] for s in srcs})
                    if st.checkbox(lib, value=t in themes_pref, key=f"th_{t}", disabled=en_cours,
                                   help=f"{desc}\n\nSources : " + " ; ".join(catalogue.SOURCES[s][0] for s in srcs)):
                        choisis.append(t)
                    st.markdown(f'<div class="petit" style="margin:-12px 0 6px 28px">{", ".join(fournisseurs)}</div>',
                                unsafe_allow_html=True)
        with st.expander("Réglages qui modifient les sources interrogées", expanded=False):
            crit_lib = {"emplois": "Emplois", "population": "Population", "touristique": "Littoraux et touristiques"}
            g1, g2 = st.columns(2)
            grp_taille = g1.checkbox("Groupe d'EPCI « taille similaire »", value=prefs.get("grp_taille", True),
                                     disabled=en_cours)
            critere = g2.selectbox("Critère", list(crit_lib), format_func=crit_lib.get,
                                   index=list(crit_lib).index(prefs.get("critere", "emplois")), disabled=en_cours,
                                   help="« Littoraux et touristiques » ajoute les capacités d'hébergement, la liste des "
                                        "communes littorales et les résidences secondaires de tous les EPCI.")
            st.markdown("**La Bonne Boite : métiers recherchés**")
            codes_def = list(LBB.METIERS_DEFAUT)
            sel = st.multiselect("Métiers (codes ROME)", codes_def,
                                 default=[c for c in prefs.get("lbb_codes", codes_def[:12]) if c in codes_def],
                                 format_func=lambda c: f"{c} · {LBB.METIERS_DEFAUT[c]}", disabled=en_cours)
            autres = st.text_input("Autres codes ROME (séparés par des virgules)", value=prefs.get("lbb_autres", ""),
                                   disabled=en_cours, placeholder="ex. H2102, N4105")
            lbb_bmo = st.checkbox("Ajouter les métiers qui recrutent le plus dans le bassin (enquête BMO)",
                                  value=prefs.get("lbb_bmo", False), disabled=en_cours)
            st.caption("2 appels par seconde : compter environ une seconde par métier et par page de résultats.")
    metiers = {c: LBB.METIERS_DEFAUT[c] for c in sel}
    for c in [x.strip().upper() for x in autres.split(",") if x.strip()]:
        metiers.setdefault(c, c)
    options = {"grp_taille": grp_taille, "critere": critere, "lbb_metiers": metiers, "lbb_bmo": lbb_bmo,
               "bassin": prefs.get("bassin")}

    with c2:
        st.markdown("#### Ce qui sera interrogé")
        plan = catalogue.plan(choisis, options)
        if not plan:
            st.info("Cocher au moins un thème.")
        else:
            usage = catalogue.themes_par_source(choisis)
            ks, kf = cles_presentes()
            lignes = []
            for p in plan:
                s = catalogue.SOURCES[p["id"]]
                cle = {"sirene": "🟢" if ks else "🔴 clé manquante", "ft": "🟢" if kf else "🔴 identifiants manquants"}.get(s[3], "")
                lignes.append({"Source": s[0], "Fournisseur · API": s[1], "Cache": age_txt(catalogue.date_cache(p["id"])),
                               "Volume / durée": s[4], "Clé": cle, "Sert à": ", ".join(usage.get(p["id"], ["(préalable)"]))})
            st.dataframe(pd.DataFrame(lignes), hide_index=True, width="stretch",
                         height=min(40 + 35 * len(lignes), 560))
            st.caption(f"{len(plan)} sources pour {len(choisis)} thèmes. Les données en cache récentes ne sont pas "
                       f"retéléchargées (durée réglable dans config.xlsx : {cfg['duree_cache']:.0f} jours pour les "
                       "fichiers Insee et Urssaf régionaux, 30 à 365 jours selon les API).")
        mode_lib = st.radio("Mode", ["Normal", "Hors ligne"], horizontal=True, disabled=en_cours,
                            captions=["télécharge ce qui manque ou a vieilli", "cache seulement, aucun appel réseau"])
        forcer = []
        if mode_lib == "Normal" and plan:
            forcer = st.multiselect("Forcer le retéléchargement de :", [p["id"] for p in plan],
                                    format_func=lambda k: catalogue.SOURCES[k][0], disabled=en_cours,
                                    placeholder="aucune source (par défaut)")
        if st.button("▶ Lancer la collecte", type="primary", disabled=en_cours or not plan, width="stretch"):
            ecrire_prefs(themes=choisis, grp_taille=grp_taille, critere=critere, lbb_codes=sel, lbb_autres=autres,
                         lbb_bmo=lbb_bmo)
            demarrer(choisis, options, "hors_ligne" if mode_lib == "Hors ligne" else "normal", forcer)
            st.rerun()



# ============================================================================================ analyses (cache)
def resultat(params):
    brut = T["brut"]
    if not brut:
        return None
    cle = json.dumps(params, sort_keys=True, default=str) + brut["date"]
    if T["res_cle"] != cle:
        with st.spinner("Calcul des analyses…"):
            T["res"] = moteur.analyser(brut, brut.get("themes", []), params)
            T["res_cle"] = cle
    return T["res"]


def afficher_graphique(b, cle):
    g = b.get("graph")
    if not g:
        return
    if g["kind"] == "variantes":
        if not g["variantes"]:
            return
        choix = st.selectbox("Groupe d'EPCI", list(g["variantes"]), key=f"var_{cle}", label_visibility="collapsed")
        spec, titre = g["variantes"][choix], f"{b['titre']} · {choix}"
    else:
        spec, titre = g, b["titre"]
    try:
        st.plotly_chart(figures.figure(spec, titre, b.get("source")), theme=None, width="stretch",
                        config=figures.config(b["id"]), key=f"fig_{cle}")
    except Exception as e:
        st.warning(f"Graphique non dessiné : {e}")


def afficher_bloc(b, cle):
    with st.container(border=True):
        if not b.get("graph"):
            st.markdown(f"**{b['titre']}**")
        afficher_graphique(b, cle)
        if b.get("lecture"):
            st.markdown(f'<div class="lecture">{b["lecture"]}</div>', unsafe_allow_html=True)
        if not b.get("graph"):
            st.caption(f"Source : {b.get('source', '')}")
        tables = [t for t in (b.get("table"), b.get("table2")) if t is not None and len(t)]
        if tables:
            with st.expander("Données"):
                for k, t in enumerate(tables):
                    st.dataframe(t, hide_index=True, width="stretch")
                    st.download_button("⬇ Excel", excel_octets(t), file_name=f"{b['id']}{'_2' if k else ''}.xlsx",
                                       key=f"dl_{cle}_{k}", help="Télécharger ce tableau")


with t_res:
    if not T["brut"]:
        st.info("Lancer une collecte (onglet ①) pour afficher les résultats.")
    else:
        brut = T["brut"]
        ans = (brut.get("urssaf") or {}).get("annees") or []
        pp = prefs.get("params") or {}
        with st.expander("Réglages de l'analyse (période, secteurs, groupes d'EPCI, bassin d'emploi)", expanded=False):
            r1, r2, r3 = st.columns(3)
            params = {}
            if ans:
                a1d = pp.get("a1") if pp.get("a1") in ans else ans[max(0, len(ans) - 11)]
                a2d = pp.get("a2") if pp.get("a2") in ans else ans[-1]
                params["a1"], params["a2"] = r1.select_slider("Période (emploi salarié privé)", ans, value=(a1d, a2d))
            niveaux = {"Grand secteur": "Grands secteurs", "NA17": "17 secteurs", "NA38": "38 secteurs", "NA88": "88 secteurs"}
            params["niveau"] = r2.selectbox("Niveau de secteurs", list(niveaux), format_func=niveaux.get,
                                            index=list(niveaux).index(pp.get("niveau", "NA38")))
            params["tolerance"] = r3.slider("Tolérance « taille similaire » (%)", 10, 60, pp.get("tolerance", 30), 5)
            g1, g2, g3, g4 = st.columns(4)
            params["grp_dep"] = g1.checkbox("EPCI du département", pp.get("grp_dep", True))
            params["grp_reg"] = g2.checkbox("EPCI de la région", pp.get("grp_reg", True))
            params["grp_taille"] = g3.checkbox("Taille similaire", (brut.get("options") or {}).get("grp_taille", True))
            params["grp_france"] = g4.checkbox("France entière", pp.get("grp_france", False))
            params["critere"] = (brut.get("options") or {}).get("critere", "emplois")
            res0 = T["res"]
            bassins = (res0 or {}).get("bassins") or {}
            if bassins:
                codes = list(bassins)
                b0 = pp.get("bassin") if pp.get("bassin") in codes else codes[0]
                params["bassin"] = st.selectbox("Bassin d'emploi (enquête BMO)", codes, index=codes.index(b0),
                                                format_func=lambda k: f"{bassins[k]} ({k})")
            if params != pp:
                ecrire_prefs(params=params, bassin=params.get("bassin", prefs.get("bassin")))
        res = resultat(params)
        if res["cles"]:
            st.markdown('<div class="cles">' + "".join(
                f'<div class="cle"><div class="lib">{k["libelle"]}</div><div class="val">{k["texte"]}</div>'
                f'<div class="sous">{k["sous"]}</div></div>' for k in res["cles"]) + "</div>", unsafe_allow_html=True)
        if res["synthese"]:
            with st.expander("Synthèse rédigée", expanded=False):
                st.markdown("\n".join(f"- {s}" for s in res["synthese"]))
        fams = [f for f in catalogue.FAMILLES if any(b["famille"] == f for b in res["blocs"])]
        if fams:
            onglets = st.tabs(fams)
            for fam, ong in zip(fams, onglets):
                with ong:
                    for t in [t for t in res["themes"] if catalogue.THEMES[t][0] == fam]:
                        blocs = [b for b in res["blocs"] if b["theme"] == t]
                        if not blocs:
                            continue
                        st.markdown(f"### {catalogue.THEMES[t][1]}")
                        st.caption(INTRO_THEMES.get(t, ""))
                        if t == "base_eco":
                            st.warning("La base économique est une estimation fondée sur des hypothèses (onglet "
                                       "Paramètres et onglet Base_eco du classeur Excel) : à présenter en ordre de "
                                       "grandeur, avec sa fourchette.")
                        for k in range(0, len(blocs), 2):
                            cc = st.columns(2)
                            for j, b in enumerate(blocs[k:k + 2]):
                                with cc[j]:
                                    afficher_bloc(b, f"{t}_{k + j}")
                        if t == "communes" and res["cartes"].get("communes"):
                            st.markdown("**Carte des communes et des EPCI**")
                            components.html(cartes.page("communes", res["cartes"]["communes"], "Communes", 600),
                                            height=630)
                        if t == "mobilites" and res["cartes"].get("flux"):
                            st.markdown("**Carte des déplacements domicile-travail**")
                            components.html(cartes.page("flux", res["cartes"]["flux"], "Flux", 600), height=630)
        else:
            st.warning("Aucune analyse : vérifier l'état des sources dans l'onglet ①.")
        if res["journal"]:
            with st.expander(f"Points d'attention ({len(res['journal'])})"):
                st.markdown("\n".join(f"- {j}" for j in res["journal"]))


# ============================================================================================ 3. ENTREPRISES
with t_ent:
    res = T["res"]
    if not res or not (res.get("employeurs") or res.get("lbb")):
        st.info("Cocher les thèmes « Employeurs » et/ou « Entreprises susceptibles d'embaucher » (famille Entreprises), "
                "puis lancer la collecte.")
    else:
        if res["cartes"].get("entreprises"):
            components.html(cartes.page("entreprises", res["cartes"]["entreprises"], "Entreprises", 640), height=670)
            st.caption("Filtres de la carte dans son panneau de gauche. Fond : OpenFreeMap Positron, photographie "
                       "aérienne IGN en bascule (icône en haut à droite).")
        noms_o = ([f"Employeurs ({len(res['employeurs'])})"] if res["employeurs"] else []) + \
            ([f"Susceptibles d'embaucher ({len(res['lbb'])})"] if res["lbb"] else [])
        ongl = st.tabs(noms_o)
        o_e = ongl[0] if res["employeurs"] else None
        o_b = ongl[-1] if res["lbb"] else None
        if o_e is not None:
            with o_e:
                df = pd.DataFrame(res["employeurs"])
                if len(df):
                    f1, f2, f3, f4 = st.columns(4)
                    com = f1.multiselect("Commune", sorted(df.commune.dropna().unique()), key="e_com")
                    sec = f2.multiselect("Grand secteur", sorted(df.grand_secteur.dropna().unique()), key="e_sec")
                    tmin = f3.selectbox("Taille minimale", [0, 1, 10, 50, 250], key="e_t",
                                        format_func=lambda v: "toutes" if not v else f"{v} salariés ou plus")
                    txt = f4.text_input("Recherche", key="e_txt", placeholder="nom, activité, SIRET")
                    d = df
                    if com:
                        d = d[d.commune.isin(com)]
                    if sec:
                        d = d[d.grand_secteur.isin(sec)]
                    if tmin:
                        d = d[d.eff_min.fillna(-1) >= tmin]
                    if txt:
                        m = (d.nom + " " + d.activite.fillna("") + " " + d.siret.fillna("")).str.lower().str.contains(
                            txt.lower(), regex=False)
                        d = d[m]
                    cols = [c for c in export_excel.COLS_EMPLOYEURS if c in d.columns]
                    vue = d[cols].rename(columns=export_excel.COLS_EMPLOYEURS)
                    st.caption(f"{len(vue)} établissements sur {len(df)} · Insee, SIRENE · usage interne")
                    st.dataframe(vue, hide_index=True, width="stretch", height=420)
                    st.download_button("⬇ Exporter la sélection en Excel", excel_octets(vue, "Employeurs"),
                                       file_name=f"employeurs_{horodatage()}.xlsx")
        if o_b is not None:
            with o_b:
                df = pd.DataFrame(res["lbb"])
                if not len(df):
                    st.info("Aucune entreprise La Bonne Boite (thème non coché, ou aucun résultat : voir "
                            "cache/sonde_labonneboite.json).")
                else:
                    f1, f2, f3, f4 = st.columns(4)
                    met = f1.multiselect("Métier", sorted(df.metier.dropna().unique()), key="b_met")
                    com = f2.multiselect("Commune", sorted(df.commune.dropna().astype(str).unique()), key="b_com")
                    fort = f3.checkbox("Fort potentiel seulement", key="b_fort")
                    txt = f4.text_input("Recherche", key="b_txt", placeholder="nom, activité, SIRET")
                    d = df
                    if met:
                        d = d[d.metier.isin(met)]
                    if com:
                        d = d[d.commune.astype(str).isin(com)]
                    if fort:
                        d = d[d.fort_potentiel]
                    if txt:
                        d = d[(d.nom + " " + d.activite.fillna("").astype(str) + " " + d.siret.fillna(""))
                              .str.lower().str.contains(txt.lower(), regex=False)]
                    cols = [c for c in export_excel.COLS_LBB if c in d.columns]
                    vue = d[cols].rename(columns=export_excel.COLS_LBB)
                    st.caption(f"{len(vue)} couples entreprise × métier · {d.siret.nunique()} entreprises · "
                               "Source : France Travail, La Bonne Boite (licence ouverte). Prévision d'embauche à partir "
                               "des recrutements passés : ce ne sont pas des offres d'emploi.")
                    st.dataframe(vue, hide_index=True, width="stretch", height=420,
                                 column_config={"Potentiel d'embauche (0-100)": st.column_config.ProgressColumn(
                                     min_value=0, max_value=100, format="%d")})
                    st.download_button("⬇ Exporter la sélection en Excel", excel_octets(vue, "La Bonne Boite"),
                                       file_name=f"susceptibles_embaucher_{horodatage()}.xlsx")


# ============================================================================================ 4. EXPORTS
with t_exp:
    res = T["res"]
    if not res:
        st.info("Lancer une collecte puis ouvrir l'onglet ② Résultats : les exports reprennent ses réglages.")
    else:
        pe = prefs.get("export") or {}
        c1, c2 = st.columns([3, 2], gap="large")
        with c1:
            st.markdown("#### Thèmes à exporter")
            th_exp = []
            cols = st.columns(2)
            dispo = [t for t in res["themes"] if any(b["theme"] == t for b in res["blocs"])]
            for i, fam in enumerate([f for f in catalogue.FAMILLES if any(catalogue.THEMES[t][0] == f for t in dispo)]):
                with cols[i % 2].container(border=True):
                    st.markdown(f'<div class="famille">{fam}</div>', unsafe_allow_html=True)
                    for t in [t for t in dispo if catalogue.THEMES[t][0] == fam]:
                        if st.checkbox(catalogue.THEMES[t][1], value=t in pe.get("themes", dispo), key=f"ex_{t}"):
                            th_exp.append(t)
        with c2:
            st.markdown("#### Publics (rapport HTML)")
            publics = [k for k, (lib, desc) in catalogue.PUBLICS.items()
                       if st.checkbox(lib, value=k in pe.get("publics", ["elus", "services", "annexes"]), key=f"pu_{k}",
                                      help=desc)]
            st.markdown("#### Cartes (rapport HTML)")
            lib_c = {"communes": "Communes et EPCI", "entreprises": "Employeurs et entreprises qui recrutent",
                     "flux": "Déplacements domicile-travail"}
            cartes_exp = [k for k in lib_c if res["cartes"].get(k) and
                          st.checkbox(lib_c[k], value=k in pe.get("cartes", list(lib_c)), key=f"ca_{k}")]
            listes = st.checkbox("Classeur Excel : inclure les listes d'entreprises", value=pe.get("listes", True))
        ecrire_prefs(export={"themes": th_exp, "publics": publics, "cartes": cartes_exp, "listes": listes})
        b1, b2 = st.columns(2)
        etat = T["etat"]
        nom_base = f"economie_emploi_{res['nom']}_{horodatage()}"
        if b1.button("📄 Créer le rapport HTML", type="primary", width="stretch",
                     disabled=not (publics or cartes_exp) or not th_exp):
            try:
                with st.spinner("Rédaction du rapport…"):
                    T["dernier_html"] = export_html.produire(res, SORTIES / f"{nom_base}.html", th_exp, set(publics),
                                                             cartes_exp, etat)
            except Exception as e:
                st.error(f"Rapport non produit : {e}")
        if b2.button("📊 Créer le classeur Excel", type="primary", width="stretch", disabled=not th_exp):
            try:
                with st.spinner("Écriture du classeur…"):
                    T["dernier_xlsx"] = export_excel.produire(res, SORTIES / f"{nom_base}.xlsx", th_exp, listes, etat)
            except PermissionError:
                st.error("Fichier ouvert dans Excel : le fermer puis recommencer.")
            except Exception as e:
                st.error(f"Classeur non produit : {e}")
        for cle, col, lib in (("dernier_html", b1, "rapport"), ("dernier_xlsx", b2, "classeur")):
            f = T.get(cle)
            if f and Path(f).exists():
                col.success(f"{Path(f).name}")
                x, y = col.columns(2)
                if x.button(f"Ouvrir le {lib}", key=f"o_{cle}", width="stretch"):
                    ouvrir(f)
                y.download_button("Télécharger", Path(f).read_bytes(), file_name=Path(f).name, key=f"t_{cle}",
                                  width="stretch")
        if res["cartes"]:
            st.markdown("#### Cartes seules (HTML autonome)")
            cc = st.columns(3)
            for i, (k, v) in enumerate([(k, v) for k, v in res["cartes"].items() if v]):
                cc[i % 3].download_button(f"⬇ {lib_c.get(k, k)}", cartes.page(k, v, lib_c.get(k, k)).encode("utf-8"),
                                          file_name=f"carte_{k}_{res['nom']}.html", width="stretch", key=f"dc_{k}")
        fichiers = sorted([f for f in SORTIES.glob("*") if f.suffix in (".html", ".xlsx")],
                          key=lambda f: f.stat().st_mtime, reverse=True)[:10]
        if fichiers:
            with st.expander(f"Exports précédents ({len(fichiers)} plus récents)"):
                for f in fichiers:
                    a, b = st.columns([5, 1])
                    a.markdown(f"{'📄' if f.suffix == '.html' else '📊'} {f.name}  \n<small>"
                               f"{datetime.fromtimestamp(f.stat().st_mtime):%d/%m/%Y %H:%M} · "
                               f"{f.stat().st_size / 1e6:.1f} Mo</small>", unsafe_allow_html=True)
                    if b.button("Ouvrir", key=f"op_{f.name}", width="stretch"):
                        ouvrir(f)


# ============================================================================================ 5. PARAMÈTRES
with t_par:
    st.markdown("#### Clés d'accès aux API")
    k1, k2 = st.columns(2)
    with k1.container(border=True):
        ks, kf = cles_presentes()
        st.markdown(f"**API SIRENE (Insee)** {'🟢 enregistrée' if ks else '🔴 absente'}")
        cle = st.text_input("Clé API SIRENE", type="password", key="k_sirene")
        if st.button("Enregistrer la clé SIRENE", disabled=not cle):
            (RACINE / "cle_sirene.txt").write_text(cle.strip() + "\n", encoding="utf-8")
            st.success("Clé enregistrée dans cle_sirene.txt")
            st.rerun()
    with k2.container(border=True):
        st.markdown(f"**francetravail.io** {'🟢 enregistrés' if kf else '🔴 absents'}")
        st.caption("Une seule application francetravail.io pour les trois API : Marché du travail, Informations sur un "
                   "territoire, La Bonne Boite v2.")
        ident = st.text_input("Identifiant client (PAR_…)", key="k_id")
        secret = st.text_input("Clé secrète", type="password", key="k_sec")
        if st.button("Enregistrer les identifiants", disabled=not (ident and secret)):
            (RACINE / "identifiants_francetravail.txt").write_text(f"{ident.strip()}\n{secret.strip()}\n",
                                                                   encoding="utf-8")
            st.success("Identifiants enregistrés dans identifiants_francetravail.txt")
            st.rerun()
    if st.button("🔌 Tester les connexions", disabled=en_cours):
        lignes = []
        from observatoire.collecte.sources import tester_connexions
        from observatoire.reseau import Client
        cl = Client(log=lignes.append, proxy=cfg.get("proxy"))
        with st.spinner("Test des connexions…"):
            try:
                tester_connexions(cl, lignes.append)
            except Exception as e:
                lignes.append(f"   ECHEC  test général : {e}")
            try:
                LBB.tester(cl.s, lignes.append)
            except Exception as e:
                lignes.append(f"   ECHEC  La Bonne Boite : {e}")
        T["test"] = lignes
    if T.get("test"):
        st.code("\n".join(T["test"]), language=None)

    st.markdown("#### Territoire et hypothèses (config.xlsx)")
    st.caption(f"Fermer {CONFIG.name} dans Excel avant d'enregistrer ici.")
    try:
        x = pd.read_excel(CONFIG, sheet_name=None, dtype=str)
        terr_ed = st.data_editor(x["Territoire"].fillna(""), hide_index=True, width="stretch",
                                 disabled=["parametre", "commentaire"], key="ed_terr")
        hyp = pd.read_excel(CONFIG, sheet_name="Hypotheses")
        hyp_ed = st.data_editor(hyp, hide_index=True, width="stretch", disabled=["parametre", "unite", "commentaire"],
                                key="ed_hyp")
        incoherences = [r.parametre for r in hyp_ed.itertuples() if not (r.bas <= r.central <= r.haut)]
        if incoherences:
            st.warning("Bas ≤ central ≤ haut non respecté pour : " + ", ".join(incoherences))
        if st.button("💾 Enregistrer les paramètres", disabled=bool(incoherences)):
            try:
                enregistrer_config(territoire=dict(zip(terr_ed.parametre, terr_ed.valeur)),
                                   hypotheses={r.parametre: {"bas": r.bas, "central": r.central, "haut": r.haut}
                                               for r in hyp_ed.itertuples()})
                st.success("Enregistré. S'applique à la prochaine collecte.")
            except PermissionError:
                st.error("config.xlsx est ouvert dans Excel : le fermer puis réessayer.")
    except Exception as e:
        st.error(f"Lecture de config.xlsx impossible : {e}")

    st.markdown("#### Fichiers à déposer (facultatifs)")
    st.caption("Série officielle des sphères (Observatoire des territoires, nom contenant « spheres »), archive IRCOM "
               "ou grille INSEE des sphères si le réseau bloque leur téléchargement, dossier_complet.parquet si le "
               "téléchargement de la base Insee échoue.")
    depot = st.file_uploader("Déposer dans donnees_manuelles/", type=["csv", "xlsx", "xls", "zip", "parquet", "txt"])
    if depot is not None:
        (MANUELS / depot.name).write_bytes(depot.getbuffer())
        st.success(f"{depot.name} enregistré : pris en compte à la prochaine collecte.")
    d1, d2, d3 = st.columns(3)
    if d1.button("📁 donnees_manuelles", width="stretch"):
        ouvrir(MANUELS)
    if d2.button("📁 cache", width="stretch"):
        ouvrir(CACHE)
    if d3.button("📁 exports", width="stretch"):
        ouvrir(SORTIES)

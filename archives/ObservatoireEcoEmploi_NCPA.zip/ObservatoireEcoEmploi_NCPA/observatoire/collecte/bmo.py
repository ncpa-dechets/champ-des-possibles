# -*- coding: utf-8 -*-
"""Enquête Besoins en main-d'œuvre (BMO) de France Travail : projets de recrutement par métier et bassin d'emploi,
dont projets jugés difficiles et projets saisonniers. Fichier national publié sur data.gouv.fr (repéré par la sonde 3)."""
import io
import re
import unicodedata

URLS_BMO = {
    2026: "https://www.francetravail.org/files/live/sites/peorg/files/documents/Statistiques-et-analyses/Open-data/BMO/Base-open-data-BMO-2026.xlsx",
    2025: "https://www.francetravail.org/files/live/sites/peorg/files/documents/Statistiques-et-analyses/Open-data/BMO/Base_open_data_BMO_2025.xlsx",
}


def _n(s):
    return re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", str(s or "")).encode("ascii", "ignore").decode().lower())


def _num(v):
    if v in (None, "", "*"):
        return None
    try:
        return float(str(v).replace(",", ".").replace(" ", ""))
    except ValueError:
        return None


def lire(contenu, log=print):
    """-> liste de lignes {metier, code_metier, famille, dep, bassin, nom_bassin, reg, projets, difficiles, saisonniers}.
    Colonnes reconnues par leur nom (met, xmet, smet, BE.., NOMBE.., Dept, REG...)."""
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(contenu), read_only=True, data_only=True)
    for ws in wb.worksheets:
        lignes = ws.iter_rows(values_only=True)
        entete, idx = None, {}
        for _ in range(15):
            l = next(lignes, None)
            if l is None:
                break
            noms = [_n(x) for x in l]
            if "met" in noms and "xmet" in noms:
                entete = l
                break
        if not entete:
            continue
        noms = [_n(x) for x in entete]

        def col(*cands, contient=None):
            for c in cands:
                if c in noms:
                    return noms.index(c)
            if contient:
                for i, nm in enumerate(noms):
                    if all(k in nm for k in contient):
                        return i
            return None
        idx = {"projets": col("met"), "difficiles": col("xmet"), "saisonniers": col("smet"),
               "code_metier": col("codemetierbmo", contient=["code", "metier"]),
               "metier": col("nommetierbmo", "libellemetier", contient=["nom", "metier"]),
               "famille": col("lblfammet", contient=["fam"]),
               "reg": col("reg"), "nom_reg": col("nomreg"), "dep": col("dept", "dep"),
               "nom_dep": col("nomdept"),
               "bassin": next((i for i, nm in enumerate(noms) if re.fullmatch(r"be\d*", nm)), None),
               "nom_bassin": next((i for i, nm in enumerate(noms) if re.fullmatch(r"nombe\d*", nm)), None)}
        log(f"      feuille « {ws.title} », colonnes : {[entete[i] for i in idx.values() if i is not None]}")
        out = []
        for l in lignes:
            if not l or l[idx["projets"]] is None:
                continue
            g = lambda k: l[idx[k]] if idx.get(k) is not None and idx[k] < len(l) else None  # noqa: E731
            out.append({"code_metier": g("code_metier"), "metier": g("metier"), "famille": g("famille"),
                        "reg": str(g("reg") or ""), "dep": str(g("dep") or "").zfill(2), "nom_dep": g("nom_dep"),
                        "bassin": str(g("bassin") or ""), "nom_bassin": g("nom_bassin"),
                        "projets": _num(g("projets")), "difficiles": _num(g("difficiles")),
                        "saisonniers": _num(g("saisonniers"))})
        return out
    raise RuntimeError("tableau BMO non reconnu (colonnes met / xmet introuvables)")


def telecharger(client, log):
    for annee, url in URLS_BMO.items():
        try:
            r = client.get(url, brut=True, timeout=300, essais=2)
            lignes = lire(r.content, log)
            log(f"      BMO {annee} : {len(lignes)} lignes")
            return {"annee": annee, "lignes": lignes}
        except Exception as e:
            log(f"      BMO {annee} indisponible ({e})")
    return {"annee": None, "lignes": []}


def bassins(bmo, dep):
    vus = {}
    for l in bmo.get("lignes", []):
        if l["dep"] == dep and l["bassin"]:
            vus[l["bassin"]] = l["nom_bassin"] or l["bassin"]
    return dict(sorted(vus.items(), key=lambda x: str(x[1])))


def _totaux(lignes):
    p = sum(l["projets"] or 0 for l in lignes)
    d = sum(l["difficiles"] or 0 for l in lignes)
    s = sum(l["saisonniers"] or 0 for l in lignes)
    return {"projets": p, "part_difficiles": d / p if p else None, "part_saisonniers": s / p if p else None}


def analyser(bmo, bassin, dep, reg):
    L = bmo.get("lignes", [])
    sel = [l for l in L if l["bassin"] == bassin]
    par_metier = {}
    for l in sel:
        m = par_metier.setdefault(l["metier"], {"metier": l["metier"], "code_metier": l["code_metier"],
                                                 "famille": l["famille"], "projets": 0,
                                                 "difficiles": 0, "saisonniers": 0})
        for k in ("projets", "difficiles", "saisonniers"):
            m[k] += l[k] or 0
    metiers = sorted(par_metier.values(), key=lambda m: -m["projets"])
    for m in metiers:
        m["part_difficiles"] = m["difficiles"] / m["projets"] if m["projets"] else None
        m["part_saisonniers"] = m["saisonniers"] / m["projets"] if m["projets"] else None
    return {"annee": bmo.get("annee"), "bassin": bassin,
            "nom_bassin": next((l["nom_bassin"] for l in sel if l["nom_bassin"]), bassin),
            "totaux": {"Bassin": _totaux(sel), "Département": _totaux([l for l in L if l["dep"] == dep]),
                       "Région": _totaux([l for l in L if l["reg"] == reg]), "France": _totaux(L)},
            "metiers": metiers}

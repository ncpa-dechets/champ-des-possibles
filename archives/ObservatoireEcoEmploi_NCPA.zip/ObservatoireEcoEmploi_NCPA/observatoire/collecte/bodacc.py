# -*- coding: utf-8 -*-
"""Procédures collectives publiées au BODACC (API ouverte de la DILA, plateforme Opendatasoft).

Vérifié par la sonde 5 du 20/10/2026 : jeu « annonces-commerciales », champs familleavis (« collective »),
numerodepartement, dateparution, cp, ville, registre (liste : SIREN sans puis avec espaces, parfois vide pour un
entrepreneur individuel), commercant, jugement (texte JSON : type, famille, nature, date). Calvados : 1 100 à
2 100 annonces de procédures collectives par an, dont 600 environ sont des ouvertures (2025 : 396 liquidations,
209 redressements). Une même entreprise génère plusieurs annonces : on ne garde que les jugements d'ouverture.
Export en un seul appel par année (/exports/json), sans la limite de 10 000 résultats des requêtes paginées."""
import json
import re

BODACC = "https://bodacc-datadila.opendatasoft.com/api/explore/v2.1/catalog/datasets/annonces-commerciales"
CHAMPS = "dateparution,cp,ville,registre,jugement,commercant"


def _type(nature):
    n = (nature or "").lower()
    if "liquidation" in n:
        return "Liquidation judiciaire"
    if "redressement" in n:
        return "Redressement judiciaire"
    if "sauvegarde" in n:
        return "Sauvegarde"
    return "Autre"


def _siren(registre):
    if isinstance(registre, str):
        registre = [registre]
    for r in registre or []:
        s = re.sub(r"\D", "", str(r))
        if len(s) == 9:
            return s
    return None


def lire(lignes):
    """Annonces -> ouvertures de procédures (une par entreprise et par année)."""
    out, vus = [], set()
    for x in lignes:
        j = x.get("jugement")
        try:
            j = json.loads(j) if isinstance(j, str) else (j or {})
        except ValueError:
            j = {}
        nature = j.get("nature") or ""
        if not nature.lower().startswith("jugement d'ouverture"):
            continue
        date = str(x.get("dateparution") or "")[:10]
        siren = _siren(x.get("registre"))
        cle = (siren or str(x.get("commercant")), date[:4])
        if cle in vus:
            continue
        vus.add(cle)
        out.append({"date": date, "annee": date[:4], "date_jugement": j.get("date"), "siren": siren,
                    "nom": x.get("commercant"), "cp": str(x.get("cp") or ""), "ville": x.get("ville"),
                    "nature": nature, "type": _type(nature)})
    return out


def telecharger(client, dep, annees, log=print):
    """Ouvertures de procédures collectives du département, année par année."""
    out = []
    for a in annees:
        w = (f'familleavis="collective" AND numerodepartement="{dep}" AND dateparution>=date\'{a}-01-01\' '
             f'AND dateparution<date\'{int(a) + 1}-01-01\'')
        lignes = client.get(f"{BODACC}/exports/json", {"where": w, "select": CHAMPS}, timeout=180, essais=2)
        ouv = lire(lignes)
        log(f"      {a} : {len(lignes)} annonces, {len(ouv)} ouvertures de procédure")
        out += ouv
    return out

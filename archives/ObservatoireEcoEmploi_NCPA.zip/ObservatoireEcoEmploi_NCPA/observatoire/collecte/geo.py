"""Contours des communes (API Découpage administratif, geo.api.gouv.fr) et
reconstitution des contours d'EPCI par fusion des communes."""
import json

import geopandas as gpd
import pandas as pd

from ..utils import CACHE, MANUELS, age_jours, log

ETAPE = "Géographie"
API = "https://geo.api.gouv.fr"


def _telecharger_communes(cfg, session):
    feats = []
    for dep in cfg["deps_region"]:
        url = f"{API}/departements/{dep}/communes"
        params = {"fields": "nom,code,codeEpci,codeDepartement,population,codesPostaux",
                  "format": "geojson", "geometry": "contour"}
        r = session.get(url, params=params, timeout=120)
        r.raise_for_status()
        fc = r.json()
        feats += fc["features"]
        log(ETAPE, f"département {dep} : {len(fc['features'])} communes", "info")
    return {"type": "FeatureCollection", "features": feats}


def _noms_epci(session):
    r = session.get(f"{API}/epcis", params={"fields": "nom,code"}, timeout=60)
    r.raise_for_status()
    return {e["code"]: e["nom"] for e in r.json()}


def charger_geo(cfg, session, forcer=False, hors_ligne=False):
    """Renvoie (communes GeoDataFrame, epcis GeoDataFrame).
    communes : code, nom, code_epci, dep, population, geometry (WGS84)
    epcis    : code, nom, deps, population, geometry"""
    f_com = CACHE / "communes_region.geojson"
    f_noms = CACHE / "noms_epci.json"
    manuel = MANUELS / "communes.geojson"

    age = age_jours(f_com)
    besoin = forcer or age is None or (age > cfg["duree_cache"] and not hors_ligne)
    if besoin and not hors_ligne:
        try:
            fc = _telecharger_communes(cfg, session)
            f_com.write_text(json.dumps(fc), encoding="utf-8")
            try:
                f_noms.write_text(json.dumps(_noms_epci(session), ensure_ascii=False), encoding="utf-8")
            except Exception as e:  # noms non bloquants : repris de l'INSEE ensuite
                log(ETAPE, f"noms des EPCI non récupérés ({e}) — libellés INSEE utilisés", "alerte")
            log(ETAPE, "contours communaux téléchargés", "ok")
        except Exception as e:
            log(ETAPE, f"échec du téléchargement des contours : {e}", "erreur")

    if f_com.exists():
        src = f_com
    elif manuel.exists():
        src = manuel
        log(ETAPE, "contours lus dans donnees_manuelles/communes.geojson", "alerte")
    else:
        raise RuntimeError("Aucun contour communal disponible (ni téléchargement, ni fichier manuel). "
                           "Voir donnees_manuelles/LISEZMOI.txt")

    com = gpd.read_file(src)
    noms = json.loads(f_noms.read_text(encoding="utf-8")) if f_noms.exists() else {}
    return preparer(com, cfg, noms)


def preparer(com, cfg, noms):
    """Harmonise les champs, contrôle la qualité et reconstitue les EPCI."""
    # harmonisation des noms de champs (fichier manuel éventuellement différent)
    ren = {}
    for c in com.columns:
        lc = c.lower()
        if lc in ("code", "insee_com", "code_insee", "codgeo"):
            ren[c] = "code"
        elif lc in ("nom", "nom_com", "libgeo", "nom_m"):
            ren[c] = "nom"
        elif lc in ("codeepci", "siren_epci", "code_epci", "epci"):
            ren[c] = "code_epci"
        elif lc in ("codedepartement", "insee_dep", "dep"):
            ren[c] = "dep"
        elif lc == "population":
            ren[c] = "population"
    com = com.rename(columns=ren)
    if "dep" not in com:
        com["dep"] = com["code"].str[:2]
    if "population" not in com:
        com["population"] = pd.NA
    com = com[["code", "nom", "code_epci", "dep", "population", "geometry"]].copy()
    com = com.set_crs(4326, allow_override=True) if com.crs is None else com.to_crs(4326)
    com["population"] = pd.to_numeric(com["population"], errors="coerce")

    # contrôle qualité : doublons de codes, communes sans EPCI
    dbl = com["code"].duplicated().sum()
    if dbl:
        log(ETAPE, f"{dbl} code(s) commune en doublon — premier conservé", "alerte")
        com = com.drop_duplicates("code")
    sans = com["code_epci"].isna().sum()
    if sans:
        log(ETAPE, f"{sans} commune(s) sans EPCI (îles, etc.) — ignorées pour les EPCI", "alerte")

    # EPCI par fusion (projection Lambert-93 pour une fusion propre, retour en WGS84)
    e = com.dropna(subset=["code_epci"]).to_crs(2154)
    e["geometry"] = e.buffer(0)
    epcis = e.dissolve(by="code_epci", aggfunc={"population": "sum",
                                               "dep": lambda s: ",".join(sorted(set(s)))})
    epcis = epcis.reset_index().rename(columns={"code_epci": "code", "dep": "deps"}).to_crs(4326)
    epcis["nom"] = epcis["code"].map(noms)
    if cfg["code_epci"] not in set(epcis["code"]):
        log(ETAPE, f"l'EPCI cible {cfg['code_epci']} est absent des contours", "erreur")
    n_cible = (com["code_epci"] == cfg["code_epci"]).sum()
    log(ETAPE, f"{len(com)} communes, {len(epcis)} EPCI ; {n_cible} communes dans l'EPCI cible", "ok")
    return com, epcis

"""Sorties cartographiques du thème « Consommation d'espaces ».

- GeoJSON (WGS84, [longitude, latitude]) réimportable dans QGIS : contours
  des communes + indicateurs en propriétés (une colonne par année).
- Carte HTML autonome (Leaflet) : bibliothèque embarquée dans le fichier,
  seuls les fonds de carte demandent internet. Charte NCPA, fonds Plan IGN
  et photographies aériennes IGN (modules/fonds_carte.py).
"""
import json

from . import conso_enaf as C
from .chemins import chemin_ressource
from .fonds_carte import FONDS_CSS, FONDS_JS

INDICATEURS_CARTE = [
    ("ref_ha", "Consommation 2011-2021 (ha)"),
    ("rec_ha", "Consommation depuis 2021 (ha)"),
    ("ref_rythme", "Rythme 2011-2021 (ha/an)"),
    ("rec_rythme", "Rythme depuis 2021 (ha/an)"),
    ("evolution", "Évolution du rythme annuel (%)"),
    ("part_enveloppe", "Part de l'enveloppe indicative consommée (%)"),
    ("part_surface", "Consommation 2011-2021 rapportée à la surface (%)"),
    ("annuel", "Consommation d'une année (ha)"),
]


def _r(v, n=3):
    return round(v, n) if isinstance(v, (int, float)) else v


def entites(resultat, contours):
    """Features GeoJSON des communes présentes dans le résultat."""
    par_code = {t["code"]: t for t in resultat["territoires"] if t["niveau"] == "Commune"}
    sortie = []
    for f in contours.get("features", []):
        code = str(f.get("properties", {}).get("code", ""))
        t = par_code.get(code)
        if not t:
            continue
        s = t["synthese"]
        props = {"code_insee": code, "nom": t["nom"], "surface_ha": _r(t["surface"], 1)}
        for cle, _lib in INDICATEURS_CARTE[:-1]:
            props[cle] = _r(s.get(cle))
        props["periode_recente"] = s.get("rec_annees")
        for a in resultat["annees"]:
            props[f"conso_{a}_ha"] = _r(t["flux"][a]["total"])
        sortie.append({"type": "Feature", "geometry": f["geometry"], "properties": props})
    return sortie


def exporter_geojson(chemin, resultat, contours):
    feats = entites(resultat, contours)
    meta = resultat["meta"]
    fc = {"type": "FeatureCollection",
          "name": "consommation_espaces_ncpa",
          "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
          "metadata": {"source": "Cerema, consommation d'ENAF (Fichiers fonciers), data.gouv.fr",
                       "millesime": meta.get("millesime"), "unite": "hectares"},
          "features": feats}
    with open(chemin, "w", encoding="utf-8") as f:
        json.dump(fc, f, ensure_ascii=False)
    return len(feats)


def _lire(relatif):
    with open(chemin_ressource(relatif), encoding="utf-8") as f:
        return f.read()


def exporter_carte(chemin, resultat, contours, params):
    feats = entites(resultat, contours)
    if not feats:
        raise ValueError("aucune commune à cartographier (contours absents ?)")
    comparaison = [{"nom": t["nom"], "niveau": t["niveau"],
                    **{k: _r(t["synthese"].get(k)) for k, _l in INDICATEURS_CARTE[:-1]}}
                   for t in resultat["territoires"] if t["niveau"] != "Commune"]
    donnees = {
        "type": "FeatureCollection", "features": feats,
        "annees": resultat["annees"], "indicateurs": INDICATEURS_CARTE,
        "comparaison": comparaison,
        "millesime": resultat["meta"].get("millesime"),
        "tranche_debut": C.TRANCHE_DEBUT,
    }
    html = (GABARIT
            .replace("/*LEAFLET_CSS*/", _lire("donnees/leaflet.css"))
            .replace("/*FONDS_CSS*/", FONDS_CSS)
            .replace("/*LEAFLET_JS*/", _lire("donnees/leaflet.js"))
            .replace("/*FONDS_JS*/", FONDS_JS)
            .replace("__TITRE__", params.get("titre", "NCPA"))
            .replace("__DATE__", params.get("date", ""))
            .replace("__DONNEES__", json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")))
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(html)
    return len(feats)


GABARIT = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Consommation d'espaces · __TITRE__</title>
<style>/*LEAFLET_CSS*/</style>
<style>/*FONDS_CSS*/</style>
<style>
:root{--rouge:#B91E27;--vert:#B1B993;--encre:#1F2A2E;--doux:#5E6A6E;--brume:#F3F4EF;--trait:#DCDDD3;
      font-family:Calibri,"Segoe UI",system-ui,sans-serif;color:var(--encre)}
*{box-sizing:border-box}
html,body{margin:0;height:100%}
body{display:flex;flex-direction:column;height:100vh;background:#fff}
header{border-left:6px solid var(--rouge);border-bottom:1px solid var(--trait);padding:10px 18px 10px 16px}
.eyebrow{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--rouge);font-weight:700}
h1{font-size:21px;margin:2px 0 0;font-weight:700}
.sous{font-size:13px;color:var(--doux)}
#corps{flex:1 1 auto;display:flex;min-height:0}
#panneau{width:300px;flex:0 0 300px;border-right:1px solid var(--trait);padding:14px;overflow-y:auto;background:var(--brume)}
#droite{flex:1 1 auto;display:flex;flex-direction:column;min-width:0}
#map{position:relative;flex:1 1 auto;height:0}
label.titre{display:block;font-weight:700;font-size:13px;margin:12px 0 4px}
select,input[type=search]{width:100%;padding:6px;border:1px solid var(--trait);border-radius:4px;font:inherit;background:#fff}
.fonds label{margin-right:12px;font-size:14px}
.legende{margin-top:6px;font-size:13px}
.legende div{display:flex;align-items:center;gap:8px;margin:3px 0}
.legende span.c{width:22px;height:14px;border:1px solid #999;display:inline-block}
.stats{margin-top:14px;padding:10px;background:#fff;border:1px solid var(--trait);border-radius:4px;font-size:13px;line-height:1.5}
.stats b{font-size:15px}
.note{font-size:12px;color:var(--doux);margin-top:12px;line-height:1.4}
button{font:inherit;padding:6px 10px;border:1px solid var(--rouge);background:#fff;color:var(--rouge);border-radius:4px;cursor:pointer;margin-top:12px}
button:hover,button:focus-visible{background:var(--rouge);color:#fff;outline:none}
#zoneTable{display:none;flex:0 0 38%;overflow:auto;border-top:2px solid var(--vert)}
table{border-collapse:collapse;width:100%;font-size:13px}
th{position:sticky;top:0;background:var(--encre);color:#fff;text-align:right;padding:6px 8px;cursor:pointer;white-space:nowrap}
th:first-child,td:first-child{text-align:left}
td{padding:4px 8px;border-bottom:1px solid var(--trait);text-align:right}
tr.actif td{background:#F6E3E4}
tr.comp td{background:var(--brume);font-weight:700}
tbody tr:hover td{background:#EEF0E6;cursor:pointer}
.leaflet-popup-content{font-family:Calibri,"Segoe UI",sans-serif;font-size:13px;min-width:230px}
.leaflet-popup-content h3{margin:0 0 6px;font-size:15px;color:var(--rouge)}
.leaflet-popup-content table td{border:none;padding:1px 4px}
@media (max-width:840px){#corps{flex-direction:column}#panneau{width:auto;flex:0 0 auto;border-right:none;border-bottom:1px solid var(--trait)}#map{min-height:60vh}}
</style>
</head>
<body>
<header>
  <div class="eyebrow">NCPA · Observatoire foncier</div>
  <h1>Consommation d'espaces naturels, agricoles et forestiers</h1>
  <div class="sous" id="sousTitre"></div>
</header>
<div id="corps">
  <aside id="panneau">
    <label class="titre" for="choixInd">Indicateur</label>
    <select id="choixInd"></select>
    <div id="blocAnnee" style="display:none">
      <label class="titre" for="choixAnnee">Année</label>
      <select id="choixAnnee"></select>
    </div>
    <label class="titre">Légende</label>
    <div class="legende" id="legende"></div>
    <div class="stats" id="stats"></div>
    <button id="btnTable" type="button" aria-expanded="false">Afficher le tableau</button>
    <p class="note">Une année « 2021 » correspond au flux du 1er janvier 2021 au 1er janvier 2022.
      La dernière année est provisoire. L'enveloppe indicative vaut 50 % de la consommation 2011-2021 ;
      l'enveloppe réellement applicable est fixée par le SRADDET puis le SCoT.</p>
    <p class="note">Source : Cerema, Fichiers fonciers, millésime <span id="mill"></span> · Carte générée le __DATE__.</p>
  </aside>
  <div id="droite">
    <div id="map"></div>
    <div id="zoneTable">
      <input type="search" id="filtre" placeholder="Filtrer les communes..." style="margin:6px;width:calc(100% - 12px)">
      <table id="table"><thead></thead><tbody></tbody></table>
    </div>
  </div>
</div>
<script>/*LEAFLET_JS*/</script>
<script>/*FONDS_JS*/</script>
<script>
const D = __DONNEES__;
const IND = Object.fromEntries(D.indicateurs);
const SEQ = ["#F3EFE0","#E6C9A8","#D6977A","#C65A4B","#9E1620"];
const DIV = ["#4E6B3A","#94A36B","#E9E6D8","#D6977A","#B91E27"];
const FIXES = {
  evolution: {bornes:[-50,-25,0,25], couleurs:DIV, suffixe:" %"},
  part_enveloppe: {bornes:[25,40,60,100], couleurs:SEQ, suffixe:" %"},
};
const fmt = (v, d=1) => v==null || isNaN(v) ? "n.d." : v.toLocaleString("fr-FR",{maximumFractionDigits:d, minimumFractionDigits:d});
document.getElementById("mill").textContent = D.millesime;
document.getElementById("sousTitre").textContent =
  `${D.features.length} commune(s) · flux annuels ${D.annees[0]} à ${D.annees[D.annees.length-1]+1} · millésime ${D.millesime}`;

// ---------- fonds de carte
const map = L.map("map", {zoomSnap:0.25});
const fonds = installerFonds(map, estPhoto => surFond(estPhoto));

// ---------- indicateur courant
const choixInd = document.getElementById("choixInd"), choixAnnee = document.getElementById("choixAnnee");
D.indicateurs.forEach(([k,l]) => choixInd.add(new Option(l,k)));
D.annees.slice().reverse().forEach(a => choixAnnee.add(new Option(`${a}-${a+1}`, a)));
function valeur(p) {
  const k = choixInd.value;
  return k === "annuel" ? p[`conso_${choixAnnee.value}_ha`] : p[k];
}
function classes() {
  const k = choixInd.value;
  if (FIXES[k]) return FIXES[k];
  const vals = D.features.map(f => valeur(f.properties)).filter(v => v!=null).sort((a,b)=>a-b);
  const q = p => vals.length ? vals[Math.min(vals.length-1, Math.floor(p*vals.length))] : 0;
  const bornes = [...new Set([q(.2),q(.4),q(.6),q(.8)].map(v => Math.round(v*100)/100))];
  return {bornes, couleurs:SEQ.slice(SEQ.length-bornes.length-1), suffixe:" ha"};
}
let CL = classes();
function couleur(v) {
  if (v==null) return "#FFFFFF";
  let i = 0; while (i < CL.bornes.length && v >= CL.bornes[i]) i++;
  return CL.couleurs[i];
}
function style(f) {
  const actif = f.properties.code_insee === codeActif;
  const photo = fonds.photo();
  return {color: actif ? "#B91E27" : (photo ? "#FFFFFF" : "#444"), weight: actif ? 3 : (photo ? 1.4 : 0.8),
          fillOpacity: photo ? .6 : .78, fillColor: couleur(valeur(f.properties)), opacity:1};
}
function surFond() { couche.setStyle(style); }
let codeActif = null;
const couche = L.geoJSON(D, {style, onEachFeature:(f, l) => {
  l.bindPopup(() => popup(f.properties));
  l.on("click", () => activer(f.properties.code_insee, false));
  l.bindTooltip(f.properties.nom, {sticky:true});
}}).addTo(map);
map.fitBounds(couche.getBounds(), {padding:[12,12]});
setTimeout(() => map.invalidateSize(), 50);

function popup(p) {
  const l = (t,v,u) => `<tr><td>${t}</td><td style="text-align:right"><b>${v}</b>${u||""}</td></tr>`;
  return `<h3>${p.nom}</h3><table>
    ${l("Conso. 2011-2021", fmt(p.ref_ha), " ha")}
    ${l("Rythme 2011-2021", fmt(p.ref_rythme,2), " ha/an")}
    ${l(`Conso. ${p.periode_recente}`, fmt(p.rec_ha), " ha")}
    ${l("Rythme récent", fmt(p.rec_rythme,2), " ha/an")}
    ${l("Évolution du rythme", p.evolution==null?"n.d.":(p.evolution>0?"+":"")+fmt(p.evolution,0), " %")}
    ${l("Enveloppe indicative consommée", fmt(p.part_enveloppe,0), " %")}
    ${l("Surface communale", fmt(p.surface_ha,0), " ha")}</table>`;
}

function legende() {
  const el = document.getElementById("legende"); el.innerHTML = "";
  const b = CL.bornes, s = CL.suffixe || "", d = s.includes("%") ? 0 : 1;
  CL.couleurs.slice(0, b.length+1).forEach((c,i) => {
    const txt = i===0 ? `moins de ${fmt(b[0],d)}${s}` : i===b.length ? `${fmt(b[i-1],d)}${s} et plus` : `${fmt(b[i-1],d)} à ${fmt(b[i],d)}${s}`;
    el.insertAdjacentHTML("beforeend", `<div><span class="c" style="background:${c}"></span>${txt}</div>`);
  });
  el.insertAdjacentHTML("beforeend", `<div><span class="c" style="background:#fff"></span>non disponible</div>`);
}

// ---------- statistiques (suivent le filtre du tableau)
function visibles() {
  const t = document.getElementById("filtre").value.toLowerCase();
  return D.features.filter(f => f.properties.nom.toLowerCase().includes(t));
}
function stats() {
  const v = visibles().map(f => f.properties);
  const s = k => v.reduce((a,p) => a + (p[k]||0), 0);
  const ref = s("ref_ha"), rec = s("rec_ha");
  const env = ref * 0.5;
  document.getElementById("stats").innerHTML =
    `<div>${v.length} commune(s) affichée(s)</div>
     <div>2011-2021 : <b>${fmt(ref)}</b> ha</div>
     <div>Depuis ${D.tranche_debut} : <b>${fmt(rec)}</b> ha</div>
     <div>Enveloppe indicative consommée : <b>${env ? fmt(rec/env*100,0) : "n.d."}</b> %</div>`;
}

// ---------- tableau lié à la carte
const COLS = [["nom","Commune"],["ref_ha","2011-2021 (ha)"],["rec_ha","Depuis 2021 (ha)"],
  ["ref_rythme","Rythme réf. (ha/an)"],["rec_rythme","Rythme récent (ha/an)"],["evolution","Évolution (%)"],
  ["part_enveloppe","Enveloppe consommée (%)"],["part_surface","Part de la surface (%)"]];
let tri = ["ref_ha", -1];
function tableau() {
  const th = document.querySelector("#table thead"), tb = document.querySelector("#table tbody");
  th.innerHTML = "<tr>" + COLS.map(([k,l]) => `<th data-k="${k}" scope="col">${l}${tri[0]===k?(tri[1]>0?" ▲":" ▼"):""}</th>`).join("") + "</tr>";
  const lignes = visibles().map(f => f.properties).sort((a,b) => {
    const x=a[tri[0]], y=b[tri[0]];
    if (typeof x === "string") return x.localeCompare(y)*tri[1];
    return ((x??-1e9) - (y??-1e9))*tri[1];
  });
  const cell = (k,v) => k==="nom" ? v : fmt(v, k.includes("rythme")?2:(k==="part_enveloppe"||k==="evolution")?0:(k==="part_surface"?2:1));
  tb.innerHTML = lignes.map(p => `<tr data-code="${p.code_insee}" class="${p.code_insee===codeActif?"actif":""}">` +
    COLS.map(([k]) => `<td>${cell(k,p[k])}</td>`).join("") + "</tr>").join("") +
    D.comparaison.map(c => `<tr class="comp">` + COLS.map(([k]) => `<td>${k==="nom"?c.nom+" ("+c.niveau+")":cell(k,c[k])}</td>`).join("") + "</tr>").join("");
  th.querySelectorAll("th").forEach(h => h.onclick = () => {
    tri = [h.dataset.k, tri[0]===h.dataset.k ? -tri[1] : (h.dataset.k==="nom"?1:-1)]; tableau(); });
  tb.querySelectorAll("tr[data-code]").forEach(r => r.onclick = () => activer(r.dataset.code, true));
}
function activer(code, depuisTable) {
  codeActif = code;
  couche.setStyle(style);
  couche.eachLayer(l => {
    if (l.feature.properties.code_insee === code) {
      l.bringToFront();
      if (depuisTable) { map.fitBounds(l.getBounds(), {maxZoom:14, padding:[30,30]}); l.openPopup(); }
    }
  });
  tableau();
  const ligne = document.querySelector(`tr[data-code="${code}"]`);
  if (ligne && !depuisTable) ligne.scrollIntoView({block:"nearest"});
}

function rafraichir() {
  document.getElementById("blocAnnee").style.display = choixInd.value === "annuel" ? "block" : "none";
  CL = classes(); couche.setStyle(style); legende();
}
choixInd.onchange = rafraichir; choixAnnee.onchange = rafraichir;
document.getElementById("filtre").oninput = () => { tableau(); stats(); };
document.getElementById("btnTable").onclick = e => {
  const z = document.getElementById("zoneTable"), ouvert = z.style.display === "block";
  z.style.display = ouvert ? "none" : "block";
  e.target.textContent = ouvert ? "Afficher le tableau" : "Masquer le tableau";
  e.target.setAttribute("aria-expanded", String(!ouvert));
  setTimeout(() => map.invalidateSize(), 50);
};
rafraichir(); stats(); tableau();
</script>
</body>
</html>
"""

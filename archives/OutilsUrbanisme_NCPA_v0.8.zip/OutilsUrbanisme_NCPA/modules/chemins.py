"""Ressources embarquées (dans le .exe) vs fichiers utilisateur (à côté du .exe).

Ne jamais confondre les deux : le dossier _MEIPASS de PyInstaller est
temporaire et effacé à la fermeture de l'application.
"""
import os
import sys


def chemin_ressource(relatif):
    """Fichier livré avec l'application (donnees/...)."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(base, relatif)


def dossier_application():
    """Dossier où écrire les fichiers utilisateur (cache, config, journaux)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

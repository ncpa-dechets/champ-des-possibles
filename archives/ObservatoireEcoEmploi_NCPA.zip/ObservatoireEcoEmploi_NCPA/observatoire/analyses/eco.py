"""Calcul des analyses. Chaque analyse produit un « bloc » :
  id, titre, theme, lecture (texte), table (DataFrame exporté en Excel),
  graph (description du graphique, dessiné par graphiques.py), source.
"""
import numpy as np
import pandas as pd

from ..utils import dans, de, fmt_nombre, fmt_pct, log, sans_article

ETAPE = "Analyses"


# ======================================================================= accès
class Donnees:
    """Accès simplifié au tableau tidy des indicateurs INSEE."""

    def __init__(self, tidy, cfg, epcis):
        self.t = tidy
        self.cfg = cfg
        self.cible = cfg["code_epci"]
        self.dep = cfg["departement"]
        self.reg = cfg["region"]
        self.epcis = epcis
        self.epci_dep = sorted(epcis[epcis.deps.str.contains(self.dep)].code)
        self.epci_reg = sorted(epcis.code)
        self.noms = dict(zip(epcis.code, epcis.nom))
        lib = tidy[tidy.niveau == "EPCI"].drop_duplicates("geo").set_index("geo")["libgeo"]
        for k, v in lib.items():  # libellés INSEE si l'API géo n'a pas fourni de nom
            if not isinstance(self.noms.get(k), str):
                self.noms[k] = v
        self.noms[self.cible] = cfg["nom_court"]
        # libellés avec article (config.xlsx), à défaut nom INSEE précédé de « le département »
        lib_insee = lambda niv, g: next(iter(tidy[(tidy.niveau == niv) & (tidy.geo == g)].libgeo.dropna()), g)
        self.art_dep = cfg.get("nom_departement") or f"le département {lib_insee('DEP', self.dep)}"
        self.art_reg = cfg.get("nom_region") or f"la région {lib_insee('REG', self.reg)}"
        self.lib_dep, self.lib_reg = sans_article(self.art_dep), sans_article(self.art_reg)

    def nom(self, code):
        n = self.noms.get(code, code)
        return _abrege(n) if code != self.cible else n

    def serie(self, code, niveau, geo):
        s = self.t[(self.t.code == code) & (self.t.niveau == niveau) & (self.t.geo == str(geo))]
        return s.set_index("annee")["valeur"].sort_index()

    def val(self, code, niveau, geo, annee=None):
        s = self.serie(code, niveau, geo)
        if s.empty:
            return np.nan
        if annee is None:
            return float(s.iloc[-1])
        return float(s.get(str(annee), np.nan))

    def val_repli(self, code, annee=None):
        """Valeur pour l'EPCI cible ; à défaut (secret statistique, non publiée), valeur du
        département puis de la région. Renvoie (valeur, niveau d'origine)."""
        for niv, g in (("EPCI", self.cible), ("DEP", self.dep), ("REG", self.reg)):
            v = self.val(code, niv, g, annee)
            if v == v:
                return v, niv
        return np.nan, None

    def an(self, code, niveau="EPCI", geo=None):
        s = self.serie(code, niveau, geo or self.cible)
        return s.index[-1] if len(s) else None

    def a(self, code):
        return code in set(self.t.code)

    def ref(self, code, annee=None):
        """Valeurs cible / département / région."""
        return {self.cfg["nom_court"]: self.val(code, "EPCI", self.cible, annee),
                self.lib_dep: self.val(code, "DEP", self.dep, annee),
                self.lib_reg: self.val(code, "REG", self.reg, annee)}


def _abrege(n):
    if not isinstance(n, str):
        return str(n)
    for a, b in (("Communauté d'agglomération", "CA"), ("Communauté de communes", "CC"),
                 ("Communauté urbaine", "CU"), ("CC du ", "CC "), ("CC de la ", "CC "), ("CC de ", "CC ")):
        n = n.replace(a, b)
    return n


def _ratio(a, b):
    return a / b * 100 if (b and b == b and a == a) else np.nan


# ======================================================================= sphères (URSSAF)
def classer_spheres(apes, regles):
    """Préfixe le plus long → P (présentielle) / N (productive)."""
    prefixes = sorted(regles, key=len, reverse=True)
    cache = {}

    def un(a):
        if a in cache:
            return cache[a]
        a2 = str(a)
        r = next((regles[p] for p in prefixes if a2.startswith(p)), "N")
        cache[a] = r
        return r
    return apes.map(un)


def preparer_urssaf(u, com, cfg, grille=None):
    """Rattache chaque ligne URSSAF à son EPCI et à sa sphère. Sphère : grille officielle INSEE
    par code d'activité exact si disponible, sinon table approximative par préfixe (config.xlsx)."""
    if u is None:
        return None
    u = u.copy()
    m = com.set_index("code")
    u["epci"] = u.commune.map(m["code_epci"])
    u["dep"] = u.commune.str[:2]
    an = u.annee.max()
    perdus = u[u.epci.isna()]
    if len(perdus):
        part = perdus[perdus.annee == an].effectifs.sum() / max(u[u.annee == an].effectifs.sum(), 1) * 100
        log(ETAPE, f"URSSAF : {perdus.commune.nunique()} codes commune sans correspondance EPCI "
                   f"({part:.2f} % des effectifs {an}) — fusions de communes ?", "alerte" if part > 1 else "info")
    approx = classer_spheres(u.ape.fillna(""), cfg["spheres"])
    if grille:
        officiel = u.ape.fillna("").str.upper().map(grille)
        u["sphere"] = officiel.fillna(approx)
        u["sphere_source"] = np.where(officiel.notna(), "grille INSEE", "approximation")
        hors = u[(u.annee == an) & officiel.isna()]
        part = hors.effectifs.sum() / max(u[u.annee == an].effectifs.sum(), 1) * 100
        log(ETAPE, f"sphères : grille officielle INSEE appliquée ; {fmt_pct(part)} des effectifs {an} ont un code "
                   "absent de la grille (classés par approximation)"
            + (" — changement de nomenclature (NAF 2025) ? Mettre la grille à jour" if part > 5 else ""),
            "alerte" if part > 5 else "ok")
    else:
        u["sphere"] = approx
        u["sphere_source"] = "approximation"
    return u


# ======================================================================= analyses
def analyser(tidy, urssaf, com, epcis, cfg, navettes=None, spheres_off=None, grille=None, ircom=None):
    D = Donnees(tidy, cfg, epcis)
    U = preparer_urssaf(urssaf, com, cfg, grille)
    officielle = U is not None and (U.sphere_source == "grille INSEE").any()
    qualif = "grille officielle INSEE par code d'activité" if officielle else "approximation par code d'activité"
    nom = cfg["nom_court"]
    blocs, cles = [], []
    lib_dep, lib_reg = D.lib_dep, D.lib_reg          # étiquettes : « Calvados »
    art_dep, art_reg = D.art_dep, D.art_reg          # dans les phrases : « le Calvados »

    # ------------------------------------------------ chiffres clés
    def cle(lib, v, txt, sous=""):
        cles.append({"libelle": lib, "valeur": v, "texte": txt, "sous": sous})

    if D.a("pop"):
        an = D.an("pop")
        cle("Population", D.val("pop", "EPCI", D.cible), fmt_nombre(D.val("pop", "EPCI", D.cible)), f"habitants (RP {an})")
    if D.a("emplois_lt"):
        an = D.an("emplois_lt")
        cle("Emplois", D.val("emplois_lt", "EPCI", D.cible), fmt_nombre(D.val("emplois_lt", "EPCI", D.cible)),
            f"au lieu de travail (RP {an})")
    if D.a("ice"):
        v = D.val("ice", "EPCI", D.cible)
        cle("Concentration d'emploi", v, fmt_nombre(v, 1), f"emplois pour 100 actifs occupés résidents ({lib_dep} : "
            f"{fmt_nombre(D.val('ice', 'DEP', D.dep), 1)})")
    if D.a("log_rs") and D.a("log_total"):
        v = _ratio(D.val("log_rs", "EPCI", D.cible), D.val("log_total", "EPCI", D.cible))
        cle("Résidences secondaires", v, fmt_pct(v), f"du parc de logements ({lib_dep} : "
            f"{fmt_pct(_ratio(D.val('log_rs', 'DEP', D.dep), D.val('log_total', 'DEP', D.dep)))})")
    if D.a("niv_vie_med"):
        v = D.val("niv_vie_med", "EPCI", D.cible)
        cle("Niveau de vie médian", v, fmt_nombre(v) + " €", f"par an et par UC ({D.an('niv_vie_med')})")
    if D.a("chomage"):
        v = D.val("chomage", "EPCI", D.cible)
        cle("Taux de chômage", v, fmt_pct(v), f"des 15-64 ans, RP {D.an('chomage')} ({lib_dep} : "
            f"{fmt_pct(D.val('chomage', 'DEP', D.dep))})")
    if D.a("part_pres_off") and D.val("part_pres_off", "EPCI", D.cible) == D.val("part_pres_off", "EPCI", D.cible):
        v = D.val("part_pres_off", "EPCI", D.cible)
        cle("Sphère présentielle", v, fmt_pct(v), f"des salariés, public compris, fin {D.an('part_pres_off')} "
            f"(INSEE ; {lib_dep} : {fmt_pct(D.val('part_pres_off', 'DEP', D.dep))})")
    lits = lits_marchands(D, cfg["hypotheses"])
    if lits["total"] > 0:
        cle("Lits touristiques marchands", lits["total"], fmt_nombre(lits["total"]),
            f"hôtels, campings, résidences de tourisme… (INSEE {lits['annee']}, estimation)")

    # ------------------------------------------------ 1. emploi et actifs (RP)
    if D.a("emplois_lt") and D.a("actifs_occ"):
        e, a = D.serie("emplois_lt", "EPCI", D.cible), D.serie("actifs_occ", "EPCI", D.cible)
        ice = D.serie("ice", "EPCI", D.cible) if D.a("ice") else (e / a * 100)
        tb = pd.DataFrame({"Année": e.index, "Emplois au lieu de travail": e.values,
                           "Actifs occupés résidents": a.reindex(e.index).values,
                           "Indicateur de concentration d'emploi": ice.reindex(e.index).values})
        an0, an1 = e.index[0], e.index[-1]
        ev_e = (e.iloc[-1] / e.iloc[0] - 1) * 100 if len(e) > 1 else np.nan
        ev_a = (a.iloc[-1] / a.iloc[0] - 1) * 100 if len(a) > 1 else np.nan
        lect = (f"Entre {an0} et {an1}, le nombre d'emplois localisés sur {nom} évolue de {fmt_pct(ev_e)} "
                f"et celui des actifs occupés qui y résident de {fmt_pct(ev_a)}. "
                f"En {an1}, le territoire compte {fmt_nombre(ice.iloc[-1], 1)} emplois pour 100 actifs occupés "
                f"résidents : {'il offre moins d’emplois qu’il ne loge d’actifs, une partie des habitants travaille donc à l’extérieur' if ice.iloc[-1] < 100 else 'il est pôle d’emploi pour les territoires voisins'}.")
        blocs.append({"id": "emploi_actifs", "theme": "Emploi", "titre": "Emplois et actifs occupés",
                      "lecture": lect, "table": tb, "source": "INSEE, recensements de la population (dossier complet)",
                      "graph": {"kind": "emploi_actifs", "x": list(e.index), "emplois": list(e.values),
                                "actifs": list(a.reindex(e.index).values), "ice": list(ice.reindex(e.index).values)},
                      "excel": {"type": "bar", "cats": "Année", "series": ["Emplois au lieu de travail", "Actifs occupés résidents"]}})

    # ------------------------------------------------ 2. ICE comparé
    if D.a("ice"):
        rows = [(D.nom(c), D.val("ice", "EPCI", c), c == D.cible) for c in D.epci_dep]
        rows = [r for r in rows if r[1] == r[1]]
        tb = pd.DataFrame(rows, columns=["Territoire", "ICE", "cible"]).sort_values("ICE")
        rang = tb.reset_index(drop=True).query("cible").index
        v_dep, v_reg = D.val("ice", "DEP", D.dep), D.val("ice", "REG", D.reg)
        lect = (f"Avec un indicateur de concentration d'emploi de {fmt_nombre(D.val('ice', 'EPCI', D.cible), 1)}, {nom} se situe "
                f"au {len(tb) - rang[0] if len(rang) else '?'}ᵉ rang sur {len(tb)} intercommunalités {de(art_dep)} "
                f"(moyenne départementale {fmt_nombre(v_dep, 1)}, régionale {fmt_nombre(v_reg, 1)}). "
                "Un indicateur inférieur à 100 signale un territoire à dominante résidentielle.")
        blocs.append({"id": "ice_compare", "theme": "Emploi", "titre": f"Concentration d'emploi des EPCI {de(art_dep)} ({D.an('ice')})",
                      "lecture": lect, "table": tb.drop(columns="cible").iloc[::-1],
                      "source": "INSEE, RP (dossier complet)",
                      "graph": {"kind": "barh_compare", "labels": list(tb.Territoire), "values": list(tb.ICE),
                                "cible": list(tb.cible), "refs": {lib_dep: v_dep, lib_reg: v_reg},
                                "xlabel": "Emplois pour 100 actifs occupés résidents", "dec": 0},
                      "excel": {"type": "barh", "cats": "Territoire", "series": ["ICE"]}})

    # ------------------------------------------------ 3. secteurs (RP)
    secteurs = [("emp_agri", "Agriculture"), ("emp_indus", "Industrie"), ("emp_constr", "Construction"),
                ("emp_comm", "Commerce, transports, services"), ("emp_admin", "Adm. publique, enseign., santé, social")]
    if all(D.a(c) for c, _ in secteurs):
        lignes = []
        for lib, (niv, g) in {nom: ("EPCI", D.cible), lib_dep: ("DEP", D.dep), lib_reg: ("REG", D.reg)}.items():
            vals = {s: D.val(c, niv, g) for c, s in secteurs}
            tot = sum(v for v in vals.values() if v == v)
            lignes.append({"Territoire": lib, **{s: v / tot * 100 if tot else np.nan for s, v in vals.items()}})
        tb = pd.DataFrame(lignes)
        ind = tb.iloc[0]["Industrie"]
        lect = (f"L'industrie représente {fmt_pct(ind)} des emplois de {nom} ({lib_dep} : {fmt_pct(tb.iloc[1]['Industrie'])}), "
                f"le commerce, les transports et services {fmt_pct(tb.iloc[0]['Commerce, transports, services'])}. "
                "Ce découpage en grands secteurs ne recoupe pas exactement la distinction présentiel/productif "
                "(voir volet sphères).")
        blocs.append({"id": "secteurs_rp", "theme": "Emploi", "titre": f"Répartition des emplois par grand secteur ({D.an('emp_indus')})",
                      "lecture": lect, "table": tb, "source": "INSEE, RP exploitation complémentaire, lieu de travail",
                      "graph": {"kind": "stack100", "labels": list(tb.Territoire),
                                "series": {s: list(tb[s]) for _, s in secteurs}},
                      "excel": {"type": "stack100", "cats": "Territoire", "series": [s for _, s in secteurs]}})

    # ------------------------------------------------ 4. URSSAF : dynamique annuelle
    if U is not None:
        ux = U[U.epci == D.cible]
        pv = ux.pivot_table(index="annee", columns="secteur", values="effectifs", aggfunc="sum").fillna(0)
        pv = pv[pv.sum().sort_values(ascending=False).index]
        tb = pv.reset_index().rename(columns={"annee": "Année"})
        tb["Total"] = pv.sum(axis=1).values
        a0, a1 = pv.index[0], pv.index[-1]
        tot = pv.sum(axis=1)
        dix = str(int(a1) - 10)
        ev10 = (tot.iloc[-1] / tot.get(dix, np.nan) - 1) * 100 if dix in tot.index else np.nan
        lect = (f"Fin {a1}, {nom} compte {fmt_nombre(tot.iloc[-1])} salariés du secteur privé (hors agriculture), "
                f"soit {fmt_pct((tot.iloc[-1] / tot.iloc[0] - 1) * 100)} depuis {a0}"
                + (f" et {fmt_pct(ev10)} sur dix ans." if ev10 == ev10 else "."))
        blocs.append({"id": "urssaf_secteurs", "theme": "Emploi", "titre": f"Emploi salarié privé par secteur, {a0}–{a1}",
                      "lecture": lect, "table": tb, "source": "URSSAF, effectifs salariés au 31/12 (commune × APE)",
                      "graph": {"kind": "area", "x": list(pv.index), "series": {c: list(pv[c]) for c in pv.columns},
                                "ylabel": "Salariés au 31/12"},
                      "excel": {"type": "area", "cats": "Année", "series": list(pv.columns)}})

        # indice base 100 : cible / département / région
        base = {}
        base[nom] = ux.groupby("annee").effectifs.sum()
        base[lib_dep] = U[U.dep == D.dep].groupby("annee").effectifs.sum()
        base[lib_reg] = U.groupby("annee").effectifs.sum()
        idx = pd.DataFrame({k: v / v.iloc[0] * 100 for k, v in base.items()})
        tb = idx.reset_index().rename(columns={"annee": "Année"})
        lect = (f"Base 100 en {idx.index[0]} : en {idx.index[-1]}, l'indice atteint {fmt_nombre(idx[nom].iloc[-1], 1)} pour {nom}, "
                f"{fmt_nombre(idx[lib_dep].iloc[-1], 1)} pour {art_dep} et {fmt_nombre(idx[lib_reg].iloc[-1], 1)} pour {art_reg}.")
        blocs.append({"id": "urssaf_indice", "theme": "Emploi", "titre": "Évolution comparée de l'emploi salarié privé (base 100)",
                      "lecture": lect, "table": tb, "source": "URSSAF, effectifs salariés au 31/12",
                      "graph": {"kind": "lines", "x": list(idx.index), "series": {c: list(idx[c]) for c in idx.columns},
                                "cible": nom, "ylabel": f"Indice base 100 en {idx.index[0]}"},
                      "excel": {"type": "line", "cats": "Année", "series": list(idx.columns)}})

        # ------------------------------------------------ 5. sphères (URSSAF, grille INSEE ou approximation)
        def part_p(df):
            g = df.groupby(["annee", "sphere"]).effectifs.sum().unstack(fill_value=0)
            return (g.get("P", 0) / g.sum(axis=1) * 100)
        sp = pd.DataFrame({nom: part_p(ux), lib_dep: part_p(U[U.dep == D.dep]), lib_reg: part_p(U)})
        an_s = sp.index[-1]
        comp = []
        for c in D.epci_dep:
            sub = U[(U.epci == c) & (U.annee == an_s)]
            if len(sub):
                comp.append((D.nom(c), float(part_p(sub).iloc[-1]), c == D.cible))
        cp = pd.DataFrame(comp, columns=["Territoire", "Part présentielle (%)", "cible"]).sort_values("Part présentielle (%)")
        off = D.val("part_pres_off", "EPCI", D.cible) if D.a("part_pres_off") else np.nan
        lect = (f"D'après les codes d'activité URSSAF ({qualif}), {fmt_pct(sp[nom].iloc[-1])} des salariés privés "
                f"de {nom} travaillent en {an_s} dans la sphère présentielle (activités répondant aux besoins des personnes "
                f"présentes : commerce de détail, hébergement-restauration, construction, services à la personne…), "
                f"contre {fmt_pct(sp[lib_dep].iloc[-1])} {dans(art_dep)}. Champ : salariés privés hors agriculture ; "
                "l'emploi public, majoritairement présentiel, n'y figure pas. "
                + (f"Pour comparaison, la mesure officielle INSEE (salariés du public et du privé) donne {fmt_pct(off)} "
                   f"fin {D.an('part_pres_off')} : c'est elle qu'il faut citer ; la série URSSAF sert à suivre l'évolution "
                   "depuis 2006." if off == off else
                   "La série officielle INSEE (tous emplois) est à privilégier pour une publication."))
        cle("Salariés du privé", float(tot.iloc[-1]), fmt_nombre(tot.iloc[-1]), f"au 31/12/{a1} (URSSAF, hors agriculture)")
        if not any(k["libelle"] == "Sphère présentielle" for k in cles):
            cle("Sphère présentielle", float(sp[nom].iloc[-1]), fmt_pct(sp[nom].iloc[-1]),
                f"des salariés privés en {an_s} (URSSAF ; {lib_dep} : {fmt_pct(sp[lib_dep].iloc[-1])})")
        tb = sp.reset_index().rename(columns={"annee": "Année"})
        blocs.append({"id": "spheres_evol", "theme": "Sphères", "titre": "Part de l'emploi salarié privé dans la sphère présentielle (URSSAF)",
                      "lecture": lect, "table": tb, "source": f"URSSAF ; classement des codes APE par sphère : {qualif}",
                      "graph": {"kind": "lines", "x": list(sp.index), "series": {c: list(sp[c]) for c in sp.columns},
                                "cible": nom, "ylabel": "% des salariés privés"},
                      "excel": {"type": "line", "cats": "Année", "series": list(sp.columns)}})
        blocs.append({"id": "spheres_compare", "theme": "Sphères", "titre": f"Part présentielle de l'emploi salarié privé, EPCI {de(art_dep)} ({an_s})",
                      "lecture": f"Comparaison des intercommunalités sur le même champ (salariés privés) et le même classement ({qualif}).",
                      "table": cp.drop(columns="cible").iloc[::-1], "source": f"URSSAF ; {qualif}",
                      "graph": {"kind": "barh_compare", "labels": list(cp.Territoire), "values": list(cp["Part présentielle (%)"]),
                                "cible": list(cp.cible), "refs": {lib_dep: sp[lib_dep].iloc[-1]},
                                "xlabel": "% des salariés privés dans la sphère présentielle", "dec": 0},
                      "excel": {"type": "barh", "cats": "Territoire", "series": ["Part présentielle (%)"]}})

        # ------------------------------------------------ 6. concentration
        last = ux[ux.annee == ux.annee.max()]
        parc = last.groupby("commune").effectifs.sum().sort_values(ascending=False)
        noms_c = com.set_index("code")["nom"]
        tbc = pd.DataFrame({"Commune": parc.index.map(lambda c: noms_c.get(c, c)), "Salariés privés": parc.values,
                            "Part (%)": parc.values / parc.sum() * 100})
        tbc["Part cumulée (%)"] = tbc["Part (%)"].cumsum()
        apes = (last.groupby("ape_lib" if "ape_lib" in last else "ape").effectifs.sum()
                .sort_values(ascending=False).head(10))
        tba = pd.DataFrame({"Activité (APE)": apes.index, "Salariés": apes.values,
                            "Part (%)": apes.values / parc.sum() * 100})
        top = tbc.head(3)
        lect = (f"Les salariés privés sont concentrés : {top.iloc[0].Commune} en accueille {fmt_pct(top.iloc[0]['Part (%)'])}, "
                f"les trois premières communes {fmt_pct(top['Part (%)'].sum())}. La première activité (code APE {tba.iloc[0, 0]}) "
                f"pèse {fmt_pct(tba.iloc[0]['Part (%)'])} de l'emploi salarié privé : un indicateur de dépendance "
                "à quelques établissements, donc de vulnérabilité.")
        blocs.append({"id": "concentration", "theme": "Résilience", "titre": f"Concentration de l'emploi salarié privé ({ux.annee.max()})",
                      "lecture": lect, "table": tbc, "table2": tba, "source": "URSSAF, effectifs au 31/12",
                      "graph": {"kind": "barh_simple", "labels": list(tbc.head(12).Commune)[::-1],
                                "values": list(tbc.head(12)["Salariés privés"])[::-1], "xlabel": "Salariés privés"},
                      "excel": {"type": "barh", "cats": "Commune", "series": ["Salariés privés"], "max_rows": 12}})

    if spheres_off is not None:
        so = spheres_off[spheres_off.geo.isin([D.cible, D.dep, D.reg])]
        if len(so):
            pv = so.pivot_table(index="annee", columns="geo", values="part_presentielle", aggfunc="first")
            pv = pv.rename(columns={D.cible: nom, D.dep: lib_dep, D.reg: lib_reg})
            tb = pv.reset_index().rename(columns={"annee": "Année"})
            blocs.append({"id": "spheres_officielles", "theme": "Sphères", "titre": "Part de l'emploi dans la sphère présentielle — série officielle",
                          "lecture": f"Série officielle INSEE (tous emplois, recensements) : {fmt_pct(pv[nom].dropna().iloc[-1]) if nom in pv else 'n.d.'} "
                                     f"en {pv.index[-1]} pour {nom}.",
                          "table": tb, "source": "INSEE, RP 1975-2021 (Observatoire des territoires)",
                          "graph": {"kind": "lines", "x": list(pv.index), "series": {c: list(pv[c]) for c in pv.columns},
                                    "cible": nom, "ylabel": "% des emplois"},
                          "excel": {"type": "line", "cats": "Année", "series": list(pv.columns)}})

    # ------------------------------------------------ 6 bis. sphères, mesure officielle INSEE (établissements employeurs)
    if D.a("part_pres_off") and D.val("part_pres_off", "EPCI", D.cible) == D.val("part_pres_off", "EPCI", D.cible):
        an = D.an("part_pres_off")
        rows = [(D.nom(c), D.val("part_pres_off", "EPCI", c), D.val("eff_etab", "EPCI", c), c == D.cible) for c in D.epci_dep]
        rows = [r for r in rows if r[1] == r[1]]
        tb = pd.DataFrame(rows, columns=["Territoire", "Part présentielle (%)", "Salariés", "cible"]).sort_values(
            "Part présentielle (%)")
        v, v_dep, v_reg = (D.val("part_pres_off", "EPCI", D.cible), D.val("part_pres_off", "DEP", D.dep),
                           D.val("part_pres_off", "REG", D.reg))
        rang = tb.reset_index(drop=True).query("cible").index
        lect = (f"Fin {an}, {fmt_pct(v)} des {fmt_nombre(D.val('eff_etab', 'EPCI', D.cible))} salariés des établissements "
                f"de {nom} travaillent dans la sphère présentielle ({lib_dep} : {fmt_pct(v_dep)}, {lib_reg} : {fmt_pct(v_reg)}). "
                f"{nom} se classe au {len(tb) - rang[0] if len(rang) else '?'}ᵉ rang sur {len(tb)} intercommunalités "
                f"{de(art_dep)}. Mesure officielle de l'INSEE, public et privé compris (hors particuliers employeurs), "
                "établie selon l'activité de chaque établissement.")
        blocs.append({"id": "spheres_insee", "theme": "Sphères",
                      "titre": f"Part des salariés dans la sphère présentielle, EPCI {de(art_dep)} ({an})",
                      "lecture": lect, "table": tb.drop(columns="cible").iloc[::-1],
                      "source": "INSEE, REE/Flores — établissements selon les sphères de l'économie (dossier complet, RES_T3)",
                      "graph": {"kind": "barh_compare", "labels": list(tb.Territoire), "values": list(tb["Part présentielle (%)"]),
                                "cible": list(tb.cible), "refs": {lib_dep: v_dep, lib_reg: v_reg},
                                "xlabel": "% des salariés dans la sphère présentielle", "dec": 0},
                      "excel": {"type": "barh", "cats": "Territoire", "series": ["Part présentielle (%)"]}})

    # ------------------------------------------------ 7. résidences secondaires
    if D.a("log_rs") and D.a("log_total"):
        rows = []
        for c in D.epci_dep:
            v = _ratio(D.val("log_rs", "EPCI", c), D.val("log_total", "EPCI", c))
            if v == v:
                rows.append((D.nom(c), v, c == D.cible))
        tb = pd.DataFrame(rows, columns=["Territoire", "Part des résidences secondaires (%)", "cible"]).sort_values(
            "Part des résidences secondaires (%)")
        rs = D.val("log_rs", "EPCI", D.cible)
        lect = (f"{fmt_nombre(rs)} résidences secondaires, soit {fmt_pct(_ratio(rs, D.val('log_total', 'EPCI', D.cible)))} des logements : "
                "leurs occupants dépensent sur place une partie de revenus gagnés ailleurs, ce qui en fait une composante "
                "majeure de la base économique résidentielle.")
        blocs.append({"id": "residences_secondaires", "theme": "Base économique", "titre": f"Poids des résidences secondaires, EPCI {de(art_dep)} ({D.an('log_rs')})",
                      "lecture": lect, "table": tb.drop(columns="cible").iloc[::-1], "source": "INSEE, RP",
                      "graph": {"kind": "barh_compare", "labels": list(tb.Territoire), "values": list(tb.iloc[:, 1]),
                                "cible": list(tb.cible), "refs": {lib_dep: _ratio(D.val("log_rs", "DEP", D.dep), D.val("log_total", "DEP", D.dep))},
                                "xlabel": "% du parc de logements", "dec": 0},
                      "excel": {"type": "barh", "cats": "Territoire", "series": ["Part des résidences secondaires (%)"]}})

    # ------------------------------------------------ 8. structure des revenus
    comp = [("part_activite", "Revenus d'activité"), ("part_pensions", "Pensions, retraites, rentes"),
            ("part_patrimoine", "Revenus du patrimoine"), ("part_prestations", "Prestations sociales")]
    if all(D.a(c) for c, _ in comp):
        lignes = []
        for lib, (niv, g) in {nom: ("EPCI", D.cible), lib_dep: ("DEP", D.dep), lib_reg: ("REG", D.reg)}.items():
            lignes.append({"Territoire": lib, **{s: D.val(c, niv, g) for c, s in comp}})
        tb = pd.DataFrame(lignes)
        publie = tb.iloc[0, 1:].notna().any()
        if not publie:
            tb = tb.iloc[1:].reset_index(drop=True)
        an = D.an("part_pensions", "DEP", D.dep) if not publie else D.an("part_pensions")
        if publie:
            lect = (f"En {an}, les pensions et retraites représentent {fmt_pct(tb.iloc[0]['Pensions, retraites, rentes'])} du revenu "
                    f"disponible des ménages de {nom} ({lib_dep} : {fmt_pct(tb.iloc[1]['Pensions, retraites, rentes'])}), "
                    f"les revenus du patrimoine {fmt_pct(tb.iloc[0]['Revenus du patrimoine'])}. Parts avant impôts : leur somme dépasse 100 %.")
        else:
            lect = (f"L'INSEE ne publie pas la décomposition du revenu disponible pour {nom} (secret statistique ou "
                    f"couverture Filosofi). À titre de repère, {dans(art_dep)} les pensions et retraites représentent "
                    f"{fmt_pct(tb.iloc[0]['Pensions, retraites, rentes'])} du revenu disponible et les revenus du patrimoine "
                    f"{fmt_pct(tb.iloc[0]['Revenus du patrimoine'])}. Compte tenu de la structure par âge de {nom}, la part "
                    "des pensions y est vraisemblablement plus élevée.")
        blocs.append({"id": "revenus", "theme": "Base économique",
                      "titre": f"Composition du revenu disponible des ménages ({an})" + ("" if publie else f" — repères {lib_dep} et {lib_reg}"),
                      "lecture": lect, "table": tb, "source": "INSEE-DGFiP-Cnaf-Cnav-CCMSA, Filosofi",
                      "graph": {"kind": "bars_group", "labels": list(tb.Territoire), "cible": nom,
                                "series": {s: list(tb[s]) for _, s in comp}, "ylabel": "% du revenu disponible"},
                      "excel": {"type": "bar", "cats": "Territoire", "series": [s for _, s in comp]}})

    # ------------------------------------------------ 9. navettes
    part_hors = None
    if navettes is not None:
        cm = com.set_index("code")
        n = navettes.copy()
        n["epci_o"] = n.origine.map(cm["code_epci"])
        n["epci_d"] = n.destination.map(cm["code_epci"])
        sortants = n[n.epci_o == D.cible]
        if len(sortants):
            tot = sortants.flux.sum()
            internes = sortants[sortants.epci_d == D.cible].flux.sum()
            part_hors = 1 - internes / tot
            dest = sortants[sortants.epci_d != D.cible].copy()
            dest["lib"] = dest.epci_d.map(lambda c: D.nom(c) if isinstance(c, str) else "Hors région")
            top = dest.groupby("lib").flux.sum().sort_values(ascending=False)
            tb = pd.DataFrame({"Lieu de travail": top.index, "Actifs résidents": top.values,
                               "Part des sortants (%)": top.values / top.sum() * 100})
            lect = (f"{fmt_pct(part_hors * 100)} des actifs occupés résidant sur {nom} travaillent hors de l'intercommunalité. "
                    f"Premier lieu de travail extérieur : {tb.iloc[0, 0]} ({fmt_pct(tb.iloc[0, 2])} des sortants). "
                    "Les salaires ainsi « importés » alimentent la base résidentielle.")
            blocs.append({"id": "navettes", "theme": "Base économique", "titre": "Où travaillent les actifs qui résident sur le territoire ?",
                          "lecture": lect, "table": tb, "source": "INSEE, RP, flux de mobilité domicile-travail",
                          "graph": {"kind": "barh_simple", "labels": list(tb.head(10).iloc[::-1, 0]),
                                    "values": list(tb.head(10).iloc[::-1, 1]), "xlabel": "Actifs occupés"},
                          "excel": {"type": "barh", "cats": "Lieu de travail", "series": ["Actifs résidents"], "max_rows": 10}})

    # ------------------------------------------------ 10. base économique estimée
    base_eco = estimer_base_eco(D, U, cfg, part_hors, ircom, com)
    if base_eco:
        blocs.append(base_eco["bloc"])
        ir = base_eco.get("ircom")
        for bl in blocs:
            if bl["id"] == "revenus" and ir:
                bl["lecture"] += (f" Les montants déclarés au fisc {'le confirment' if ir['r_epci'] > ir['r_dep'] else 'ne le confirment pas'}"
                                  f" (DGFiP, IRCOM {ir['annee']}) : les pensions "
                                  f"représentent {fmt_pct(ir['r_epci'] * 100)} des salaires et pensions déclarés sur {nom}, "
                                  f"contre {fmt_pct(ir['r_dep'] * 100)} {dans(art_dep)}.")

    log(ETAPE, f"{len(blocs)} analyses produites", "ok")
    return {"D": D, "U": U, "blocs": blocs, "cles": cles, "base_eco": base_eco,
            "lib_dep": lib_dep, "lib_reg": lib_reg, "de_dep": de(art_dep)}


def lits_marchands(D, H, sc="central"):
    """Capacité d'hébergement marchand en lits : places d'hôtel et de camping converties
    (hypothèses lits_par_place_*), plus les place-lits des autres hébergements collectifs."""
    c = D.cible
    d = {"hotels": D.val("hotels_places", "EPCI", c) if D.a("hotels_places") else np.nan,
         "campings": D.val("camping_places", "EPCI", c) if D.a("camping_places") else np.nan,
         "autres": D.val("autres_lits", "EPCI", c) if D.a("autres_lits") else np.nan}
    d = {k: (0.0 if v != v else v) for k, v in d.items()}
    kh = H.get("lits_par_place_hotel", {}).get(sc, 2)
    kc = H.get("lits_par_place_camping", {}).get(sc, 3)
    d["total"] = d["hotels"] * kh + d["campings"] * kc + d["autres"]
    d["annee"] = D.an("hotels_places") or D.an("camping_places") or D.an("autres_lits") or ""
    return d


# libellés des données d'entrée de la base économique (repris tels quels dans l'onglet Base_eco)
E_POP = "Personnes dans les ménages fiscaux"
E_NV = "Niveau de vie médian (€/an/UC)"
E_ACT = "Part des revenus d'activité (%)"
E_PEN = "Part des pensions, retraites, rentes (%)"
E_PAT = "Part des revenus du patrimoine (%)"
E_PRE = "Part des prestations sociales (%)"
E_RS = "Résidences secondaires"
E_HOT = "Places en hôtel"
E_CAMP = "Places en camping"
E_AUT = "Place-lits des autres hébergements collectifs"
E_PUB = "Part des emplois publics, enseignement, santé, social (%)"
E_AGRI = "Part de l'agriculture dans l'emploi (%)"
E_PROD = "Part productive de l'emploi salarié privé hors agriculture (%)"


def corriger_par_ircom(D, parts, ircom, com):
    """Les parts « activité » et « pensions » du département (Filosofi) sont corrigées avec le
    rapport pensions / (salaires + pensions) déclarés, mesuré par l'IRCOM sur les communes de
    l'EPCI et sur celles du département. Hypothèse : l'écart entre EPCI et département est le
    même dans Filosofi que dans l'IRCOM. La somme activité + pensions est conservée."""
    if ircom is None or not len(ircom):
        return None
    t = ircom.dropna(subset=["salaires", "pensions"])
    t = t[(t.salaires + t.pensions) > 0].copy()
    cm = com.set_index("code")
    t["epci"] = t.commune.map(cm["code_epci"])
    e, d = t[t.epci == D.cible], t[t.commune.str[:2] == D.dep]
    pop = cm["population"]
    pop_epci = pop[cm.code_epci == D.cible].sum()
    couv = pop.reindex(e.commune).sum() / pop_epci * 100 if pop_epci else 0
    if len(d) < 10 or couv < 60:
        log(ETAPE, f"IRCOM : couverture insuffisante pour corriger les parts de revenus ({len(e)} communes de "
                   f"l'EPCI, {couv:.0f} % de sa population)", "alerte")
        return None
    r_e = e.pensions.sum() / (e.salaires.sum() + e.pensions.sum())
    r_d = d.pensions.sum() / (d.salaires.sum() + d.pensions.sum())
    somme = parts["part_activite"] + parts["part_pensions"]
    k = (parts["part_pensions"] / somme) / r_d
    pen = min(somme * k * r_e, somme * 0.95)
    an = str(next(iter(t.annee.dropna()), "") or "")
    log(ETAPE, f"IRCOM {an} : pensions = {fmt_pct(r_e * 100)} des salaires + pensions déclarés sur l'EPCI "
               f"({len(e)} communes, {fmt_pct(couv, 0)} de la population) contre {fmt_pct(r_d * 100)} "
               f"{de(D.art_dep)} — part des pensions corrigée de {fmt_pct(parts['part_pensions'])} à {fmt_pct(pen)}", "ok")
    return {"part_pensions": pen, "part_activite": somme - pen, "r_epci": r_e, "r_dep": r_d,
            "communes": len(e), "couverture": couv, "annee": an}


def estimer_base_eco(D, U, cfg, part_hors_mesuree=None, ircom=None, com=None):
    """Estimation (ordre de grandeur) des 4 bases de Davezies pour l'EPCI cible.
    Toutes les entrées et hypothèses sont restituées dans le classeur Excel, où le calcul
    est refait par formules : modifier une hypothèse y met tout à jour."""
    need = ["niv_vie_med", "part_activite", "part_pensions", "part_patrimoine", "part_prestations"]
    if not all(D.a(k) for k in need):
        log(ETAPE, "base économique non estimée : indicateurs Filosofi manquants ("
                   + ", ".join(k for k in need if not D.a(k)) + ")", "alerte")
        return None
    H = cfg["hypotheses"]
    c = D.cible
    notes, defauts, sources = [], [], {}
    parts, origines = {}, {}
    for k in need:
        v, origine = D.val_repli(k)
        parts[k], origines[k] = v, origine
        if origine and origine != "EPCI":
            notes.append(k)
    if notes:
        lib = de(D.art_dep) if all(origines[k] == "DEP" for k in notes) else "du département ou de la région"
        log(ETAPE, f"base économique : valeurs {lib} utilisées faute de publication pour l'EPCI ({', '.join(notes)})",
            "alerte")
    ircom_info = None
    if {"part_activite", "part_pensions"} <= set(notes) and com is not None:
        ircom_info = corriger_par_ircom(D, parts, ircom, com)
        if ircom_info:
            parts["part_activite"], parts["part_pensions"] = ircom_info["part_activite"], ircom_info["part_pensions"]

    def src_filo(k, lib):
        o = origines.get(k)
        txt = f"INSEE Filosofi {D.an(k, o or 'EPCI', {'EPCI': c, 'DEP': D.dep, 'REG': D.reg}.get(o, c)) or ''}".strip()
        if o and o != "EPCI":
            txt += f" — valeur {de(D.art_dep) if o == 'DEP' else de(D.art_reg)} (non publiée pour l'EPCI)"
        if ircom_info and k in ("part_activite", "part_pensions"):
            txt += f", corrigée par l'IRCOM {ircom_info['annee']} (DGFiP)"
        sources[lib] = txt

    # population : personnes des ménages fiscaux (même source et même année que le niveau de vie)
    v_pm = D.val("pers_menfisc", "EPCI", c) if D.a("pers_menfisc") else np.nan
    if v_pm == v_pm:
        pop_fisc = v_pm
        sources[E_POP] = f"INSEE Filosofi {D.an('pers_menfisc')}"
    else:
        pop_fisc = D.val("pop", "EPCI", c)
        sources[E_POP] = (f"INSEE RP {D.an('pop')} — population totale, à défaut du nombre de personnes des ménages "
                          f"fiscaux ; années différentes du niveau de vie (Filosofi {D.an('niv_vie_med') or 'n.d.'})")
        log(ETAPE, "base économique : personnes des ménages fiscaux non trouvées — population du recensement utilisée "
                   f"(RP {D.an('pop')}, niveau de vie {D.an('niv_vie_med')})", "info")
    for k, lib in (("niv_vie_med", E_NV), ("part_activite", E_ACT), ("part_pensions", E_PEN),
                   ("part_patrimoine", E_PAT), ("part_prestations", E_PRE)):
        src_filo(k, lib)

    lits = lits_marchands(D, H)
    if D.a("emp_admin") and D.a("emp_total_t8") and D.val("emp_total_t8", "EPCI", c) == D.val("emp_total_t8", "EPCI", c):
        p_pub = _ratio(D.val("emp_admin", "EPCI", c), D.val("emp_total_t8", "EPCI", c))
        sources[E_PUB] = f"INSEE RP {D.an('emp_admin')} (secteurs O à Q, y compris santé et enseignement privés)"
    else:
        p_pub = 25.0
        defauts.append("part des emplois publics fixée à 25 % (emplois par secteur non disponibles)")
        sources[E_PUB] = "VALEUR PAR DÉFAUT (25 %) — donnée INSEE indisponible"
    if D.a("emp_agri") and D.a("emp_total_t8") and D.val("emp_agri", "EPCI", c) == D.val("emp_agri", "EPCI", c):
        p_agri = _ratio(D.val("emp_agri", "EPCI", c), D.val("emp_total_t8", "EPCI", c))
        sources[E_AGRI] = f"INSEE RP {D.an('emp_agri')} (agriculture absente des données URSSAF, comptée productive)"
    else:
        p_agri = 0.0
        defauts.append("part de l'agriculture fixée à 0 % (emplois agricoles non disponibles)")
        sources[E_AGRI] = "VALEUR PAR DÉFAUT (0 %) — donnée INSEE indisponible"
    p_prod = np.nan
    if U is not None:
        ux = U[(U.epci == c) & (U.annee == U.annee.max())]
        g = ux.groupby("sphere").effectifs.sum()
        if g.sum() > 0:
            p_prod = g.get("N", 0) / g.sum() * 100
            sources[E_PROD] = f"URSSAF {U.annee.max()} ({'grille INSEE' if (ux.sphere_source == 'grille INSEE').any() else 'approximation'} des sphères)"
    if p_prod != p_prod:
        p_prod = 35.0
        defauts.append("part productive de l'emploi privé fixée à 35 % (données URSSAF indisponibles)")
        sources[E_PROD] = "VALEUR PAR DÉFAUT (35 %) — données URSSAF indisponibles"
    for d_ in defauts:
        log(ETAPE, f"base économique : {d_}", "alerte")
    an_log = D.an("log_rs") or ""
    an_tou = lits["annee"]
    sources.update({E_RS: f"INSEE RP {an_log}", E_HOT: f"INSEE tourisme {an_tou}",
                    E_CAMP: f"INSEE tourisme {an_tou}", E_AUT: f"INSEE tourisme {an_tou}"})

    entrees = {
        E_POP: pop_fisc, E_NV: parts["niv_vie_med"], E_ACT: parts["part_activite"], E_PEN: parts["part_pensions"],
        E_PAT: parts["part_patrimoine"], E_PRE: parts["part_prestations"],
        E_RS: D.val("log_rs", "EPCI", c) if D.a("log_rs") else 0,
        E_HOT: lits["hotels"], E_CAMP: lits["campings"], E_AUT: lits["autres"],
        E_PUB: p_pub, E_AGRI: p_agri, E_PROD: p_prod,
    }
    if part_hors_mesuree is not None:
        H = {**H, "part_actifs_hors_epci": {**H["part_actifs_hors_epci"], "bas": part_hors_mesuree,
                                             "central": part_hors_mesuree, "haut": part_hors_mesuree,
                                             "commentaire": "Mesurée sur le fichier des navettes INSEE fourni"}}

    # part productive des revenus d'activité locaux hors emplois publics : l'agriculture (absente
    # de l'URSSAF) est entièrement productive ; le reste suit la part productive de l'emploi privé
    frac_prod = (p_agri + (100 - p_agri - p_pub) * p_prod / 100) / (100 - p_pub) if p_pub < 100 else 0
    res = {}
    for sc in ("bas", "central", "haut"):
        h = {k: v[sc] for k, v in H.items()}
        rd = entrees[E_POP] * entrees[E_NV] * h["coef_moyenne_mediane"] / h["personnes_par_uc"]
        act = rd * entrees[E_ACT] / 100
        hors = act * h["part_actifs_hors_epci"]
        loc = act - hors
        pub = loc * p_pub / 100
        prod = (loc - pub) * frac_prod
        res[sc] = {
            "Productive : revenus d'activité liés aux activités exportatrices": prod,
            "Publique : revenus des emplois publics locaux": pub,
            "Résidentielle : salaires gagnés hors du territoire": hors,
            "Résidentielle : pensions et retraites": rd * entrees[E_PEN] / 100,
            "Résidentielle : revenus du patrimoine": rd * entrees[E_PAT] / 100,
            "Résidentielle : dépenses des résidents secondaires": entrees[E_RS] * h["nuits_occupees_par_rs"]
                                                                 * h["personnes_par_sejour_rs"] * h["depense_jour_rs"],
            "Résidentielle : dépenses touristiques (hébergement marchand)": (
                entrees[E_HOT] * h["lits_par_place_hotel"] + entrees[E_CAMP] * h["lits_par_place_camping"]
                + entrees[E_AUT]) * h["nuitees_par_lit_marchand"] * h["depense_par_nuitee_marchande"],
            "Sociale : prestations sociales": rd * entrees[E_PRE] / 100,
        }
    tb = pd.DataFrame(res) / 1e6
    tb.index.name = "Composante (M€/an)"
    tot = tb.sum()
    grp = tb.groupby(tb.index.str.split(" :").str[0]).sum()
    parts_b = grp["central"] / tot["central"] * 100
    lect = (f"Ordre de grandeur (scénario central) : environ {fmt_nombre(tot['central'])} M€ de revenus « basiques » "
            f"entrent chaque année sur le territoire (fourchette {fmt_nombre(tot['bas'])}–{fmt_nombre(tot['haut'])} M€). "
            f"La base résidentielle en représente {fmt_pct(parts_b.get('Résidentielle', np.nan), 0)}, la base productive "
            f"{fmt_pct(parts_b.get('Productive', np.nan), 0)}, la base publique {fmt_pct(parts_b.get('Publique', np.nan), 0)} "
            f"et la base sociale {fmt_pct(parts_b.get('Sociale', np.nan), 0)}. Estimation fondée sur des hypothèses explicites "
            "(onglet Base_eco du classeur Excel, recalculable) : à présenter comme un ordre de grandeur.")
    if notes:
        lect += (f" Attention : la décomposition du revenu disponible n'étant pas publiée pour {cfg['nom_court']}, "
                 f"les parts de revenus utilisées sont celles {de(D.art_dep)}")
        if ircom_info:
            lect += (f", la part des pensions étant corrigée d'après les montants déclarés au fisc (IRCOM "
                     f"{ircom_info['annee']} : pensions = {fmt_pct(ircom_info['r_epci'] * 100)} des salaires et pensions "
                     f"sur {cfg['nom_court']}, contre {fmt_pct(ircom_info['r_dep'] * 100)} {dans(D.art_dep)}).")
        else:
            lect += " ; la part des pensions et du patrimoine est probablement sous-estimée pour un territoire plus âgé."
    if defauts:
        lect += " Valeurs par défaut utilisées faute de données : " + " ; ".join(defauts) + "."
    bloc = {"id": "base_eco", "theme": "Base économique", "titre": "Base économique estimée (approche Davezies)",
            "lecture": lect, "table": tb.reset_index(),
            "source": "Estimation à partir d'INSEE (Filosofi, RP), URSSAF" + (", DGFiP (IRCOM)" if ircom_info else "")
                      + " et hypothèses (config.xlsx)",
            "graph": {"kind": "base_eco", "labels": list(tb.index), "central": list(tb["central"]),
                      "bas": list(tb["bas"]), "haut": list(tb["haut"])},
            "excel": None}
    return {"bloc": bloc, "entrees": entrees, "sources": sources, "hypotheses": H, "resultats": tb,
            "parts": parts_b, "replis": notes, "defauts": defauts, "ircom": ircom_info,
            "lib_repli": de(D.art_dep)}

# -*- coding: utf-8 -*-
"""Catalogue de l'outil : sources interrogées et thèmes proposés à l'utilisateur.

Un thème liste les sources dont il a besoin ; le plan de collecte est l'union des sources des thèmes cochés,
chaque source n'étant interrogée qu'une fois même si plusieurs thèmes s'en servent (c'est là que se fait le
dédoublonnage entre les deux anciens outils).
"""
import glob
import os
from datetime import datetime

from .utils import CACHE

# ------------------------------------------------------------------------------------------------ sources
# id : (libellé, fournisseur · API, ce qui est récupéré, clé requise, volume indicatif, appels attendus, dépendances,
#       motifs des fichiers de cache)
SOURCES = {
    "geo": ("Contours des communes", "État · geo.api.gouv.fr",
            "communes de la région, EPCI reconstitués", None, "≈ 15 Mo", 7, [],
            ["communes_region.geojson"]),
    "urssaf": ("Emploi salarié privé (commune × activité)", "Urssaf · open.urssaf.fr",
               "effectifs et établissements au 31/12 depuis 2006, région + totaux France", None,
               "≈ 60 Mo la 1re fois", 5, [], ["urssaf_region_*.json", "urssaf_totaux_epci.json"]),
    "urssaf_masse": ("Masse salariale des EPCI", "Urssaf · open.urssaf.fr", "effectif moyen et masse salariale",
                     None, "≈ 10 Mo", 1, [], ["urssaf_masse_salariale.json"]),
    "ofgl": ("Population des EPCI", "OFGL · data.ofgl.fr", "population totale de chaque EPCI", None, "< 1 Mo", 1, [],
             ["ofgl_population.json"]),
    "insee": ("Dossier complet (recensement, revenus, logement, tourisme)", "Insee · fichier national",
              "indicateurs communes, EPCI, département, région", None, "≈ 300 Mo la 1re fois", 1, [],
              ["insee_extrait_*.parquet", "dossier_complet.parquet"]),
    "grille": ("Grille des sphères par activité", "Insee · fichier", "classement présentiel / productif", None,
               "< 1 Mo", 1, [], ["sphere_NAF_rev2.xls"]),
    "ircom": ("Salaires et pensions déclarés (IRCOM)", "DGFiP · data.gouv.fr", "montants par commune", None,
              "≈ 20 Mo", 3, [], ["ircom_*.csv"]),
    "tourisme": ("Capacités d'hébergement touristique", "Insee · Melodi (fichier national)",
                 "chambres, emplacements, lits par EPCI", None, "≈ 7 Mo", 1, [], ["tourisme_epci.json"]),
    "littoral": ("Communes loi Littoral", "État · data.gouv.fr", "liste des communes littorales", None, "< 1 Mo", 3,
                 [], ["littoral.json"]),
    "rs_epci": ("Résidences secondaires de tous les EPCI", "Insee · Melodi", "pour le groupe « touristique »",
                None, "plusieurs minutes la 1re fois", 30, ["urssaf"], ["rs_epci.json"]),
    "flores": ("Emploi tous employeurs (Flores)", "Insee · Melodi", "postes salariés publics et privés", None,
               "< 1 Mo", 2, [], ["flores_*.json"]),
    "side": ("Créations et stocks d'entreprises", "Insee · Melodi", "EPCI et département", None, "< 1 Mo", 4, [],
             ["side_*.json"]),
    "mobilites": ("Déplacements domicile-travail", "Insee · recensement (fichier)", "flux de et vers l'EPCI",
                  None, "≈ 12 Mo", 8, ["geo"], ["mobilites_*.json"]),
    "bmo": ("Besoins en main-d'œuvre (enquête BMO)", "France Travail · fichier", "projets de recrutement par métier",
            None, "≈ 15 Mo", 1, [], ["bmo.json"]),
    "ft": ("Demandeurs, offres, embauches", "France Travail · API Marché du travail + Informations territoire",
           "EPCI, département, région, France ; séries trimestrielles", "ft", "< 1 Mo", 32, [], ["ft2_*.json"]),
    "ft_tensions": ("Difficultés de recrutement par métier", "France Travail · API Marché du travail",
                    "indices de tension des métiers BMO", "ft", "< 1 Mo", 40, ["bmo"], ["ft_tensions_*.json"]),
    "sirene": ("Employeurs actifs", "Insee · API SIRENE", "établissements employeurs géolocalisés", "sirene",
               "1 à 2 min", 8, ["geo"], ["sirene2_*.json"]),
    "sirene_demo": ("Créations et fermetures d'établissements", "Insee · API SIRENE", "comptages par année",
                    "sirene", "≈ 1 min", 22, ["geo"], ["sirene_demo_*.json"]),
    "bodacc": ("Procédures collectives", "DILA · BODACC", "jugements d'ouverture du département", None, "≈ 5 Mo",
               11, [], ["bodacc_*.json"]),
    "lbb": ("Entreprises susceptibles d'embaucher", "France Travail · API La Bonne Boite v2",
            "par métier (code ROME), dans l'EPCI", "ft", "≈ 1 min (2 appels/s)", 25, ["geo"], ["lbb_*.json"]),
    "anct": ("Indicateurs de l'Observatoire des territoires", "ANCT · observatoire-des-territoires.gouv.fr",
             "17 indicateurs, tous les EPCI", None, "< 5 Mo", 17, [], ["anct2_indicateurs.json"]),
}
ORDRE = ["geo", "urssaf", "urssaf_masse", "ofgl", "insee", "grille", "ircom", "tourisme", "littoral", "rs_epci",
         "flores", "side", "mobilites", "bmo", "ft", "ft_tensions", "sirene", "sirene_demo", "bodacc", "lbb", "anct"]
CLES = {"sirene": ("cle_sirene.txt", "clé API SIRENE"),
        "ft": ("identifiants_francetravail.txt", "identifiants francetravail.io")}

# ------------------------------------------------------------------------------------------------ thèmes
# id : (famille, libellé, description, sources)
THEMES = {
    "recensement": ("Portrait du territoire", "Emploi et actifs (recensement)",
                    "Emplois et actifs, concentration d'emploi comparée aux EPCI du département, grands secteurs.",
                    ["geo", "insee"]),
    "spheres": ("Portrait du territoire", "Économie présentielle et productive",
                "Part présentielle de l'emploi (Urssaf depuis 2006 et mesure officielle Insee), comparaison des EPCI.",
                ["geo", "insee", "urssaf", "grille"]),
    "base_eco": ("Portrait du territoire", "Revenus et base économique",
                 "Résidences secondaires, composition des revenus, base économique estimée (Davezies).",
                 ["geo", "insee", "urssaf", "ircom", "mobilites"]),
    "evolution": ("Emploi salarié privé", "Évolution et comparaison aux autres EPCI",
                  "Base 100 face au département, à la région, à la France et aux groupes d'EPCI ; classements.",
                  ["urssaf", "ofgl"]),
    "secteurs": ("Emploi salarié privé", "Secteurs d'activité",
                 "Poids des secteurs, spécificités, secteurs qui gagnent ou perdent, décomposition de la variation.",
                 ["urssaf"]),
    "communes": ("Emploi salarié privé", "Communes",
                 "Emplois par commune, concentration, évolution ; carte des communes.", ["urssaf", "geo"]),
    "salaires": ("Emploi salarié privé", "Salaires", "Salaire brut annuel moyen par salarié, comparé aux groupes.",
                 ["urssaf", "urssaf_masse"]),
    "flores": ("Emploi salarié privé", "Emploi tous employeurs (Flores)",
               "Postes salariés publics compris, face au champ Urssaf.", ["urssaf", "flores"]),
    "ft": ("Marché du travail", "Demandeurs, offres, embauches",
           "Chiffres clés France Travail de l'EPCI, du département, de la région et de la France.", ["ft"]),
    "saison": ("Marché du travail", "Saisonnalité", "Profil trimestriel des demandeurs, embauches et offres ; "
               "recrutements saisonniers prévus.", ["ft", "bmo"]),
    "bmo": ("Marché du travail", "Recrutements prévus (enquête BMO)",
            "Métiers qui recrutent le plus dans le bassin, part des projets difficiles.", ["bmo"]),
    "tensions": ("Marché du travail", "Difficultés de recrutement par métier",
                 "Indicateurs de tension France Travail pour les métiers BMO du bassin.", ["bmo", "ft_tensions"]),
    "employeurs": ("Entreprises", "Employeurs (liste et carte)",
                   "Établissements employeurs actifs, filtrables, sur carte.", ["geo", "urssaf", "sirene"]),
    "lbb": ("Entreprises", "Entreprises susceptibles d'embaucher",
            "La Bonne Boite : entreprises à potentiel d'embauche par métier, sur la carte des employeurs.",
            ["geo", "lbb"]),
    "demographie": ("Entreprises", "Créations et défaillances",
                    "Taux de création, créations et fermetures d'établissements, procédures collectives.",
                    ["geo", "side", "sirene_demo", "bodacc"]),
    "mobilites": ("Mobilités et comparaisons", "Déplacements domicile-travail",
                  "Où travaillent les habitants, d'où viennent les actifs ; carte des flux.",
                  ["geo", "urssaf", "mobilites"]),
    "anct": ("Mobilités et comparaisons", "Indicateurs de l'Observatoire des territoires",
             "17 indicateurs ANCT comparés aux médianes des groupes d'EPCI.", ["urssaf", "anct"]),
}
FAMILLES = ["Portrait du territoire", "Emploi salarié privé", "Marché du travail", "Entreprises",
            "Mobilités et comparaisons"]
PUBLICS = {
    "elus": ("Élus et direction générale", "Chiffres clés, synthèse rédigée et graphiques essentiels"),
    "services": ("Services (développement économique)", "Toutes les analyses de chaque thème, avec lecture"),
    "annexes": ("Annexes", "Tableaux de données, méthode et sources, journal de production"),
}


def sources_des_themes(themes, options=None):
    """Union des sources des thèmes (dépendances comprises), dans l'ordre de collecte."""
    options = options or {}
    voulu = set()
    for t in themes:
        voulu |= set(THEMES[t][3])
    if "evolution" in themes or "anct" in themes:
        if options.get("critere") == "touristique" and options.get("grp_taille"):
            voulu |= {"tourisme", "littoral", "rs_epci"}
    if "lbb" in themes and options.get("lbb_bmo"):
        voulu.add("bmo")
    changement = True
    while changement:
        avant = len(voulu)
        for s in list(voulu):
            voulu |= set(SOURCES[s][6])
        changement = len(voulu) != avant
    return [s for s in ORDRE if s in voulu]


def themes_par_source(themes):
    out = {}
    for t in themes:
        for s in THEMES[t][3]:
            out.setdefault(s, []).append(THEMES[t][1])
    return out


def date_cache(sid):
    """Date du fichier de cache le plus récent de la source, ou None."""
    fichiers = []
    for motif in SOURCES[sid][7]:
        fichiers += glob.glob(os.path.join(str(CACHE), motif))
    if not fichiers:
        return None
    return datetime.fromtimestamp(max(os.path.getmtime(f) for f in fichiers))


def plan(themes, options=None):
    return [{"id": s, "libelle": SOURCES[s][0], "api": SOURCES[s][1], "appels": SOURCES[s][5]}
            for s in sources_des_themes(themes, options)]

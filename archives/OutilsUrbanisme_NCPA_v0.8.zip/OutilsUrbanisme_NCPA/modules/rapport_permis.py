"""Rapport HTML autonome du thème « Permis » (Chart.js embarqué, charte NCPA).

Élément central : le parcours des logements autorisés (autorisés, commencés,
terminés) et les logements « à venir », c'est-à-dire les futurs foyers.
"""
import json
from collections import defaultdict

from . import permis as P
from .chemins import chemin_ressource


def generer(chemin, resultat, params):
    syn = resultat["synthese"]
    communes = [l for l in syn["lignes"] if l["niveau"] == "Commune"]
    groupes = defaultdict(float)
    for p in resultat["permis"]:
        if p["theme"] == "logements" and p["etat_code"] != "4":
            groupes[p["groupe_dem"]] += p["logements"] or 0
    donnees = {
        "nom": syn["nom_total"], "total": syn["total"], "annees": resultat["annees"],
        "par_annee": {str(a): v for a, v in syn["par_annee"].items()},
        "communes": [{"nom": c["nom"], "aut": c["lgt_aut"], "venir": c["lgt_a_venir"],
                      "pa": c["pa_nb"], "pd": c["pd_nb"]} for c in communes],
        "groupes": sorted(groupes.items(), key=lambda x: -x[1]),
        "types": resultat["types"], "lignes": syn["lignes"],
        "millesimes": ", ".join(f"{P.LIB_TYPE[t]} : {m}" for t, m in resultat["millesimes"].items()),
    }
    with open(chemin_ressource("donnees/chart.umd.min.js"), encoding="utf-8") as f:
        chartjs = f.read()
    html = (GABARIT.replace("/*CHARTJS*/", chartjs)
            .replace("__TITRE__", params.get("titre", "NCPA"))
            .replace("__DATE__", params.get("date", ""))
            .replace("__COMMUNES__", params.get("communes", ""))
            .replace("__DONNEES__", json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")))
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(html)


GABARIT = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Permis · __TITRE__</title>
<style>
:root{--rouge:#B91E27;--vert:#B1B993;--olive:#5E7A2E;--encre:#1F2A2E;--doux:#5E6A6E;--brume:#F3F4EF;--trait:#DCDDD3}
*{box-sizing:border-box}
body{margin:0;font-family:Calibri,"Segoe UI",system-ui,sans-serif;color:var(--encre);background:#fff;line-height:1.45}
header{border-left:8px solid var(--rouge);padding:22px 32px 18px;border-bottom:1px solid var(--trait)}
.eyebrow{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--rouge);font-weight:700}
h1{font-size:30px;margin:4px 0 2px;font-weight:700}
.sous{color:var(--doux);font-size:15px}
main{max-width:1080px;margin:0 auto;padding:8px 32px 48px}
h2{font-size:21px;margin:40px 0 4px}
.chapo{color:var(--doux);margin:0 0 14px;max-width:72ch}
.parcours{margin-top:28px;padding:24px 28px;background:var(--brume);border-radius:6px}
.phrase{font-size:24px;max-width:38ch;margin:0 0 22px;line-height:1.3}
.phrase b{color:var(--rouge)}
.etape{display:grid;grid-template-columns:150px 1fr 80px;align-items:center;gap:12px;margin:8px 0;font-size:15px}
.etape .barre{height:26px;background:#fff;border:1px solid var(--trait);border-radius:3px;position:relative}
.etape .barre span{position:absolute;left:0;top:0;bottom:0;border-radius:2px}
.etape .val{text-align:right;font-weight:700}
.cadre{position:relative;height:340px}
.cadre.grand{height:auto}
table{border-collapse:collapse;width:100%;font-size:14px;margin-top:8px}
th{background:var(--encre);color:#fff;padding:7px 8px;text-align:right;font-weight:700}
th:first-child,td:first-child{text-align:left}
td{padding:5px 8px;border-bottom:1px solid var(--trait);text-align:right}
tr.comp td{background:var(--brume);font-weight:700}
.tableau{overflow-x:auto}
.methode{font-size:14px;color:var(--doux);max-width:80ch}
.methode li{margin-bottom:6px}
footer{margin-top:40px;font-size:13px;color:var(--doux);border-top:1px solid var(--trait);padding-top:10px}
@media print{.parcours,.cadre{break-inside:avoid}h2{break-after:avoid}}
@media (max-width:700px){main,header{padding-left:16px;padding-right:16px}.phrase{font-size:19px}h1{font-size:24px}.etape{grid-template-columns:110px 1fr 60px}}
</style>
</head>
<body>
<header>
  <div class="eyebrow">NCPA · Observatoire foncier</div>
  <h1>Permis et autorisations d'urbanisme</h1>
  <div class="sous" id="sous"></div>
</header>
<main>
  <section class="parcours" id="blocParcours">
    <p class="phrase" id="phrase"></p>
    <div id="etapes"></div>
  </section>

  <section id="blocAnnuel">
    <h2>Logements autorisés chaque année</h2>
    <p class="chapo">Par type de logement, selon l'année d'autorisation. La courbe indique ceux dont le chantier a été ouvert. Les deux dernières années sont incomplètes : des autorisations sont transmises avec retard.</p>
    <div class="cadre"><canvas id="gAnnuel"></canvas></div>
  </section>

  <section id="blocAutres">
    <h2>Permis d'aménager et de démolir</h2>
    <p class="chapo">Nombre d'autorisations délivrées chaque année. Un permis d'aménager annonce souvent un lotissement, donc de futurs logements.</p>
    <div class="cadre"><canvas id="gAutres"></canvas></div>
  </section>

  <section id="blocCommunes">
    <h2>Commune par commune</h2>
    <p class="chapo">Logements autorisés sur la période, et part encore à venir (chantier en cours ou autorisation de moins de trois ans).</p>
    <div class="cadre grand" id="cadreCommunes"><canvas id="gCommunes"></canvas></div>
  </section>

  <section id="blocDemandeurs">
    <h2>Qui construit ?</h2>
    <p class="chapo">Logements autorisés selon la catégorie du demandeur.</p>
    <div class="cadre" style="height:260px"><canvas id="gDemandeurs"></canvas></div>
  </section>

  <h2>Tableau de synthèse</h2>
  <div class="tableau"><table id="table"></table></div>

  <h2>Méthode et précautions</h2>
  <ul class="methode">
    <li>Source : SDES, liste des permis de construire et autres autorisations d'urbanisme (base Sitadel). Millésimes : <span id="mill"></span>.</li>
    <li>Les autorisations annulées sont exclues des totaux. Un logement « commencé » a une ouverture de chantier connue ; « terminé », une déclaration d'achèvement. Ces déclarations arrivent souvent tard : les chiffres de chantier et d'achèvement sont des minimums.</li>
    <li>Logements à venir : chantier ouvert et non achevé, ou autorisation de moins de trois ans sans ouverture de chantier connue (une autorisation est valable trois ans, hors prorogation).</li>
    <li>Le code commune est celui du dépôt du dossier : les permis déposés sous l'ancien code d'une commune fusionnée ne sont pas comptés.</li>
  </ul>
  <footer>Rapport produit le __DATE__ par Outils Urbanisme · NCPA · Communes : __COMMUNES__</footer>
</main>
<script>/*CHARTJS*/</script>
<script>
const D = __DONNEES__, T = D.total, A = D.annees;
const f = v => (v==null || isNaN(v)) ? "n.d." : Math.round(v).toLocaleString("fr-FR");
Chart.defaults.font.family = 'Calibri, "Segoe UI", system-ui, sans-serif';
Chart.defaults.font.size = 13; Chart.defaults.color = "#1F2A2E";
document.getElementById("sous").textContent = `${D.nom} · autorisations délivrées de ${A[0]} à ${A[A.length-1]}`;
document.getElementById("mill").textContent = D.millesimes;
const aLog = D.types.includes("logements");

// ---------- parcours des logements
if (aLog && T.lgt_aut > 0) {
  document.getElementById("phrase").innerHTML =
    `<b>${f(T.lgt_aut)} logements</b> autorisés de ${A[0]} à ${A[A.length-1]}, dont <b>${f(T.lgt_a_venir)}</b> encore à venir : autant de futurs foyers à desservir.`;
  const etapes = [["Autorisés", T.lgt_aut, "#B91E27"], ["Commencés", T.lgt_commences, "#D6977A"],
                  ["Terminés", T.lgt_termines, "#B1B993"], ["À venir", T.lgt_a_venir, "#1F2A2E"]];
  document.getElementById("etapes").innerHTML = etapes.map(([l, v, c]) =>
    `<div class="etape"><span>${l}</span><div class="barre" role="img" aria-label="${l} : ${f(v)} logements"><span style="width:${Math.min(100, v / T.lgt_aut * 100)}%;background:${c}"></span></div><span class="val">${f(v)}</span></div>`).join("");
} else if (aLog) {
  document.getElementById("phrase").textContent = "Aucun logement autorisé sur la période et les communes choisies.";
} else { document.getElementById("blocParcours").style.display = "none"; }

// ---------- annuel
if (aLog) {
  const pa = a => D.par_annee[a].logements;
  new Chart(document.getElementById("gAnnuel"), {
    data: {labels: A.map(String), datasets: [
      {type:"line", label:"dont chantier ouvert", data:A.map(a => pa(a).commences), borderColor:"#1F2A2E", backgroundColor:"#1F2A2E", tension:.2, pointRadius:3},
      {type:"bar", label:"Individuels", data:A.map(a => pa(a).ind), backgroundColor:"#B91E27", stack:"s"},
      {type:"bar", label:"Collectifs", data:A.map(a => pa(a).col), backgroundColor:"#D6977A", stack:"s"},
      {type:"bar", label:"Non ventilés", data:A.map(a => pa(a).autre), backgroundColor:"#DCDDD3", stack:"s"}]},
    options: {maintainAspectRatio:false, plugins:{legend:{position:"bottom"}},
      scales:{x:{stacked:true, grid:{display:false}}, y:{stacked:true, title:{display:true, text:"logements"}}}}
  });
} else { document.getElementById("blocAnnuel").style.display = "none"; }

// ---------- PA / PD
const ds = [];
if (D.types.includes("amenager")) ds.push({label:"Permis d'aménager", data:A.map(a => D.par_annee[a].amenager), backgroundColor:"#5E7A2E"});
if (D.types.includes("demolir")) ds.push({label:"Permis de démolir", data:A.map(a => D.par_annee[a].demolir), backgroundColor:"#3F4448"});
if (ds.length) {
  new Chart(document.getElementById("gAutres"), {type:"bar", data:{labels:A.map(String), datasets:ds},
    options:{maintainAspectRatio:false, plugins:{legend:{position:"bottom"}},
      scales:{x:{grid:{display:false}}, y:{title:{display:true, text:"autorisations"}, ticks:{precision:0}}}}});
} else { document.getElementById("blocAutres").style.display = "none"; }

// ---------- communes
const C = D.communes.slice().sort((a,b) => b.aut - a.aut);
if (aLog && C.length > 1) {
  document.getElementById("cadreCommunes").style.height = (C.length * 24 + 80) + "px";
  new Chart(document.getElementById("gCommunes"), {type:"bar",
    data:{labels:C.map(c => c.nom), datasets:[
      {label:"Logements autorisés", data:C.map(c => c.aut), backgroundColor:"#B1B993"},
      {label:"dont à venir", data:C.map(c => c.venir), backgroundColor:"#B91E27"}]},
    options:{indexAxis:"y", maintainAspectRatio:false, plugins:{legend:{position:"top"}},
      scales:{x:{title:{display:true, text:"logements"}}, y:{grid:{display:false}, ticks:{autoSkip:false}}}}});
} else { document.getElementById("blocCommunes").style.display = "none"; }

// ---------- demandeurs
if (aLog && D.groupes.length) {
  new Chart(document.getElementById("gDemandeurs"), {type:"bar",
    data:{labels:D.groupes.map(g => g[0]), datasets:[{label:"Logements autorisés", data:D.groupes.map(g => g[1]), backgroundColor:"#B91E27"}]},
    options:{indexAxis:"y", maintainAspectRatio:false, plugins:{legend:{display:false}},
      scales:{x:{title:{display:true, text:"logements"}}, y:{grid:{display:false}}}}});
} else { document.getElementById("blocDemandeurs").style.display = "none"; }

// ---------- tableau
const COLS = [["lgt_aut","Logements autorisés"],["lgt_ind","Individuels"],["lgt_col","Collectifs"],
  ["lgt_commences","Commencés"],["lgt_termines","Terminés"],["lgt_a_venir","À venir"],["pa_nb","Permis d'aménager"],["pd_nb","Permis de démolir"]];
document.getElementById("table").innerHTML =
  `<thead><tr><th scope="col">Territoire</th>${COLS.map(c => `<th scope="col">${c[1]}</th>`).join("")}</tr></thead><tbody>` +
  D.lignes.map(l => `<tr class="${l.niveau!=="Commune"?"comp":""}"><td>${l.nom}</td>${COLS.map(([k]) => `<td>${f(l[k])}</td>`).join("")}</tr>`).join("") + "</tbody>";
</script>
</body>
</html>
"""

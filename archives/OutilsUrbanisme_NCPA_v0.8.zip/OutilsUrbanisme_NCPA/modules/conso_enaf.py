"""Consommation d'espaces naturels, agricoles et forestiers (ENAF).

Source : fichier communal du Cerema publié chaque année sur data.gouv.fr
(millésime courant : « du 1er janvier 2011 au 1er janvier 2025 », publié
en juillet 2026). Données issues des Fichiers fonciers, en accès libre.

Principe :
1. trouver le millésime le plus récent via l'API de data.gouv.fr (recherche
   des jeux du Cerema dont le titre contient « 1er janvier AAAA ») ; adresse
   de secours si la recherche échoue ; ou fichier CSV local choisi par
   l'utilisateur (repli manuel, toujours possible) ;
2. télécharger le CSV national (environ 30 Mo) une seule fois, puis cache
   local de 90 jours ;
3. lire le fichier en ne gardant que : les communes demandées, et les sommes
   du Calvados et de la Normandie ;
4. calculer les indicateurs ZAN localement.

Noms de colonnes : reconnus par leur forme, pas codés en dur.
  naf11art12      = flux ENAF -> artificialisé entre le 1/1/2011 et le 1/1/2012
  art11hab12      = dont habitat (idem act, mix, rou, fer, inc)
Les colonnes pluriannuelles (ex. naf16art22) sont ignorées : on recalcule.
L'année « 2011 » désigne donc le flux du 1/1/2011 au 1/1/2012.
"""
import csv
import io
import json
import os
import re
import time

from . import reseau
from .chemins import dossier_application

URL_API = "https://www.data.gouv.fr/api/1/datasets/"
RECHERCHE = "consommation espaces naturels agricoles forestiers"
# Millésime 2011-2025 (juillet 2026), utilisé si la recherche automatique échoue
URL_SECOURS = "https://www.data.gouv.fr/api/1/datasets/r/b258feec-f8ff-4e0a-93b3-baf1fe46ef66"
MILLESIME_SECOURS = "2011-2025"
DUREE_CACHE = 90 * 24 * 3600

DESTINATIONS = [("hab", "Habitat"), ("act", "Activité"), ("mix", "Mixte"),
                ("rou", "Routes"), ("fer", "Voies ferrées"), ("inc", "Non renseigné")]
LIB_DEST = dict(DESTINATIONS)

# Loi Climat et résilience : décennie de référence et première tranche
REF_DEBUT, REF_FIN = 2011, 2020          # flux 1/1/2011 -> 1/1/2021
TRANCHE_DEBUT = 2021                     # flux à partir du 1/1/2021
REDUCTION = 0.5                          # -50 % (objectif national, indicatif localement)

RE_TOTAL = re.compile(r"^naf(\d{2})art(\d{2})$")
RE_DEST = re.compile(r"^art(\d{2})(hab|act|mix|rou|fer|inc)(\d{2})$")
RE_SURFACE = re.compile(r"^surfcom\d*$")


# ------------------------------------------------------------------ cache
def dossier_cache():
    chemin = os.path.join(dossier_application(), "cache_conso")
    os.makedirs(chemin, exist_ok=True)
    return chemin


def _chemin_meta():
    return os.path.join(dossier_cache(), "source.json")


def source_en_cache():
    """{'fichier', 'millesime', 'titre', 'url', 'date'} ou None."""
    try:
        with open(_chemin_meta(), encoding="utf-8") as f:
            meta = json.load(f)
        if os.path.exists(meta.get("fichier", "")):
            return meta
    except (OSError, ValueError):
        pass
    return None


def _ecrire_meta(meta):
    try:
        with open(_chemin_meta(), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=1)
    except OSError:
        pass


# ------------------------------------------------------------------ recherche du millésime
def trouver_millesime(url_api=URL_API, stop_event=None, journal=print):
    """Cherche sur data.gouv le jeu Cerema le plus récent. -> {url, millesime, titre, taille}."""
    rep = reseau.get(url_api, params={"q": RECHERCHE, "page_size": 50}, stop_event=stop_event)
    candidats = []
    for jeu in rep.get("data", []):
        org = jeu.get("organization") or {}
        if "cerema" not in (str(org.get("slug", "")) + str(org.get("name", ""))).lower():
            continue
        m = re.search(r"(\d{4})\D+1er janvier (\d{4})", jeu.get("title", ""))
        if not m:
            continue
        csvs = [r for r in jeu.get("resources", [])
                if str(r.get("format", "")).lower() == "csv" and "carr" not in str(r.get("title", "")).lower()]
        if not csvs:
            continue
        principal = max(csvs, key=lambda r: r.get("filesize") or 0)
        candidats.append({"fin": int(m.group(2)), "millesime": f"{m.group(1)}-{m.group(2)}",
                          "titre": jeu.get("title", ""), "url": principal.get("url"),
                          "taille": principal.get("filesize") or 0,
                          "maj": principal.get("last_modified", "")})
    if not candidats:
        raise reseau.ErreurSource("aucun jeu « consommation d'espaces » du Cerema trouvé sur data.gouv.fr")
    meilleur = max(candidats, key=lambda c: (c["fin"], c["maj"]))
    journal(f"   millésime le plus récent sur data.gouv : {meilleur['millesime']} "
            f"({meilleur['taille'] / 1048576:.0f} Mo)" if meilleur["taille"] else
            f"   millésime le plus récent sur data.gouv : {meilleur['millesime']}")
    return meilleur


def preparer_fichier(forcer_verification=False, url_api=URL_API, stop_event=None, journal=print):
    """Chemin local du CSV (téléchargé si besoin) et ses métadonnées."""
    meta = source_en_cache()
    if meta and meta.get("origine") == "local" and not forcer_verification:
        journal(f"   fichier local choisi par l'utilisateur : {meta['fichier']}")
        return meta
    if meta and not forcer_verification and time.time() - os.path.getmtime(meta["fichier"]) < DUREE_CACHE:
        journal(f"   fichier en cache : millésime {meta['millesime']} (téléchargé le {meta.get('date', '?')})")
        return meta

    try:
        cible = trouver_millesime(url_api, stop_event, journal)
    except reseau.ErreurSource as exc:
        if meta:
            journal(f"   recherche impossible ({exc}) : utilisation du fichier en cache")
            return meta
        journal(f"   recherche impossible ({exc}) : adresse de secours (millésime {MILLESIME_SECOURS})")
        cible = {"url": URL_SECOURS, "millesime": MILLESIME_SECOURS,
                 "titre": f"Consommation d'espaces NAF {MILLESIME_SECOURS} (adresse de secours)"}

    if meta and meta.get("millesime") == cible["millesime"] and meta.get("origine") != "local":
        journal(f"   le fichier en cache est déjà le plus récent ({meta['millesime']})")
        os.utime(meta["fichier"])
        return meta

    chemin = os.path.join(dossier_cache(), f"conso_enaf_{cible['millesime']}.csv")
    dernier = [0]

    def progression(octets):
        if octets - dernier[0] > 5 * 1048576:
            dernier[0] = octets
            journal(f"      téléchargement : {octets / 1048576:.0f} Mo...")
    journal(f"   téléchargement du fichier communal ({cible['millesime']})...")
    if not reseau.telecharger(cible["url"], chemin, stop_event, progression):
        raise reseau.ErreurSource(f"fichier introuvable (HTTP 404) · adresse : {cible['url']}")
    meta = {"fichier": chemin, "millesime": cible["millesime"], "titre": cible.get("titre", ""),
            "url": cible["url"], "date": time.strftime("%d/%m/%Y"), "origine": "data.gouv"}
    _ecrire_meta(meta)
    return meta


def utiliser_fichier_local(chemin):
    """L'utilisateur fournit lui-même le CSV (téléchargé depuis son navigateur)."""
    nom = os.path.basename(chemin)
    m = re.search(r"(20\d{2})\D{0,3}(20\d{2})", nom)
    meta = {"fichier": chemin, "millesime": f"{m.group(1)}-{m.group(2)}" if m else "fichier local",
            "titre": f"Fichier local : {nom}", "url": chemin, "date": time.strftime("%d/%m/%Y"),
            "origine": "local"}
    _ecrire_meta(meta)
    return meta


# ------------------------------------------------------------------ lecture
def _ouvrir_texte(chemin):
    """Détecte l'encodage (UTF-8 ou Windows-1252) et renvoie un flux texte."""
    with open(chemin, "rb") as f:
        debut = f.read(200000)
    for encodage in ("utf-8-sig", "cp1252"):
        try:
            debut.decode(encodage)
            return open(chemin, encoding=encodage, newline="", errors="replace")
        except UnicodeDecodeError:
            continue
    return open(chemin, encoding="latin-1", newline="")


def _compter_lignes(chemin):
    """Nombre de lignes du fichier (rapide, pour la barre de progression)."""
    with open(chemin, "rb") as f:
        return max(1, sum(bloc.count(b"\n") for bloc in iter(lambda: f.read(1 << 20), b"")))


def _nombre(texte):
    if texte is None:
        return None
    t = str(texte).strip().replace(" ", "").replace(",", ".")
    if t == "" or t.lower() in ("na", "nan", "null", "s", "secret"):
        return None
    try:
        return float(t)
    except ValueError:
        return None


def analyser_entetes(entetes):
    """Repère les colonnes utiles. -> dict ou lève ErreurSource."""
    bas = [h.strip().strip('"').lstrip("\ufeff").lower() for h in entetes]
    idx = {h: i for i, h in enumerate(bas)}

    def premiere(*noms, motif=None):
        for n in noms:
            if n in idx:
                return idx[n]
        if motif:
            for h, i in idx.items():
                if re.match(motif, h):
                    return i
        return None

    col = {
        "code": premiere("idcom", "codgeo", "code_insee", "insee_com", "com"),
        "nom": premiere("idcomtxt", "libgeo", "nom_commune", "nom"),
        "dep": premiere("iddep", "dep", "code_dep"),
        "reg": premiere("idreg", "reg", "code_reg"),
        "surface": None,
        "total": {}, "dest": {},
    }
    surfaces = [(h, i) for h, i in idx.items() if RE_SURFACE.match(h)]
    if surfaces:
        col["surface"] = sorted(surfaces)[-1][1]          # la plus récente
    for h, i in idx.items():
        m = RE_TOTAL.match(h)
        if m and int(m.group(2)) == int(m.group(1)) + 1:  # flux annuels uniquement
            col["total"][2000 + int(m.group(1))] = i
            continue
        m = RE_DEST.match(h)
        if m and int(m.group(3)) == int(m.group(1)) + 1:
            col["dest"].setdefault(2000 + int(m.group(1)), {})[m.group(2)] = i
    if col["code"] is None:
        raise reseau.ErreurSource("colonne du code commune (idcom) introuvable dans le fichier")
    if not col["total"]:
        raise reseau.ErreurSource("aucune colonne de flux annuel (du type naf11art12) dans le fichier")
    return col


def _vide(annees):
    return {"surface": 0.0, "flux": {a: {"total": 0.0, **{d: 0.0 for d, _l in DESTINATIONS}} for a in annees}}


def _ajouter(cible, ligne, col, annees):
    s = _nombre(ligne[col["surface"]]) if col["surface"] is not None else None
    if s:
        cible["surface"] += s
    for a in annees:
        v = _nombre(ligne[col["total"][a]])
        if v:
            cible["flux"][a]["total"] += v
        for d, i in col["dest"].get(a, {}).items():
            v = _nombre(ligne[i])
            if v:
                cible["flux"][a][d] += v


def lire(chemin, codes, comparer=True, stop_event=None, journal=print):
    """Lit le CSV national. -> dict brut (unités d'origine) :
    {"annees", "communes": {code: {nom, surface, flux}}, "dep", "reg", "colonnes"}"""
    with _ouvrir_texte(chemin) as f:
        premiere = f.readline()
        separateur = ";" if premiere.count(";") >= premiere.count(",") else ","
        f.seek(0)
        lecteur = csv.reader(f, delimiter=separateur)
        entetes = next(lecteur)
        col = analyser_entetes(entetes)
        annees = sorted(col["total"])
        presentes = {d for v in col["dest"].values() for d in v}
        dests = [d for d, _l in DESTINATIONS if d in presentes]
        journal(f"   {len(entetes)} colonnes · flux annuels {annees[0]} à {annees[-1]} · destinations : "
                + (", ".join(LIB_DEST[d] for d in dests) if dests else "non détaillées"))
        voulus = set(codes)
        res = {"annees": annees, "communes": {}, "dep": _vide(annees), "reg": _vide(annees),
               "n_dep": 0, "n_reg": 0, "destinations": dests}
        n, total = 0, _compter_lignes(chemin)
        for ligne in lecteur:
            n += 1
            if n % 2000 == 0:
                reseau.verifier_annulation(stop_event)
                reseau.avancement(n / total)
            if len(ligne) < len(entetes):
                continue
            code = ligne[col["code"]].strip().zfill(5)
            dep = ligne[col["dep"]].strip().zfill(2) if col["dep"] is not None else code[:2]
            reg = ligne[col["reg"]].strip() if col["reg"] is not None else None
            if code in voulus:
                c = res["communes"][code] = _vide(annees)
                c["nom"] = ligne[col["nom"]].strip() if col["nom"] is not None else code
                _ajouter(c, ligne, col, annees)
            if comparer:
                if dep == "14":
                    _ajouter(res["dep"], ligne, col, annees)
                    res["n_dep"] += 1
                if reg == "28" or (reg is None and dep in ("14", "27", "50", "61", "76")):
                    _ajouter(res["reg"], ligne, col, annees)
                    res["n_reg"] += 1
    journal(f"   {n} communes lues dans le fichier national")
    manquantes = voulus - set(res["communes"])
    if manquantes:
        journal(f"   ATTENTION : {len(manquantes)} commune(s) absente(s) du fichier : {', '.join(sorted(manquantes))} "
                "(code commune différent dans le millésime ?)")
    res["unite"] = _deviner_unite(res, comparer)
    journal(f"   unité détectée : {'m² (convertis en hectares)' if res['unite'] == 'm2' else 'hectares'}")
    return res


def _deviner_unite(res, comparer):
    """Le Cerema diffuse les flux en m². Contrôle : le Calvados consomme de l'ordre
    de quelques centaines d'hectares par an ; en m², la somme dépasse 50 000."""
    if comparer and res["n_dep"]:
        valeurs = [v["total"] for v in res["dep"]["flux"].values()]
    else:
        valeurs = [v["total"] for c in res["communes"].values() for v in c["flux"].values()]
        valeurs = [sum(valeurs)] if valeurs else [0]
    valeurs = sorted(valeurs)
    mediane = valeurs[len(valeurs) // 2] if valeurs else 0
    return "m2" if mediane > 50000 or (not comparer and mediane > 5000) else "ha"


# ------------------------------------------------------------------ indicateurs
def _en_ha(entite, unite):
    k = 10000.0 if unite == "m2" else 1.0
    return {"surface": (entite["surface"] / k) if entite.get("surface") else None,
            "flux": {a: {d: v / k for d, v in f.items()} for a, f in entite["flux"].items()}}


def _synthese(flux, surface, annees):
    ref = [a for a in annees if REF_DEBUT <= a <= REF_FIN]
    rec = [a for a in annees if a >= TRANCHE_DEBUT]
    s = {}
    s["ref_ha"] = sum(flux[a]["total"] for a in ref) if len(ref) == REF_FIN - REF_DEBUT + 1 else None
    s["ref_rythme"] = s["ref_ha"] / len(ref) if s["ref_ha"] is not None else None
    s["ref_hab_part"] = (sum(flux[a]["hab"] for a in ref) / s["ref_ha"] * 100) if s["ref_ha"] else None
    s["rec_ha"] = sum(flux[a]["total"] for a in rec) if rec else None
    s["rec_annees"] = f"{rec[0]}-{rec[-1] + 1}" if rec else ""
    s["rec_rythme"] = s["rec_ha"] / len(rec) if rec else None
    s["evolution"] = ((s["rec_rythme"] / s["ref_rythme"] - 1) * 100) if (s["ref_rythme"] and rec) else None
    s["enveloppe"] = s["ref_ha"] * REDUCTION if s["ref_ha"] is not None else None
    s["part_enveloppe"] = (s["rec_ha"] / s["enveloppe"] * 100) if (s["enveloppe"] and rec) else None
    s["part_surface"] = (s["ref_ha"] / surface * 100) if (surface and s["ref_ha"] is not None) else None
    s["total_ha"] = sum(flux[a]["total"] for a in annees)
    return s


def construire(brut, communes, codes, nom_epci, comparer=True):
    """Liste de territoires {niveau, code, nom, surface, flux (ha), synthese}."""
    annees = brut["annees"]
    infos = {c["code"]: c for c in communes}
    territoires = []

    def ajouter(niveau, code, nom, entite, surface_geo=None):
        e = _en_ha(entite, brut["unite"])
        surface = e["surface"] or surface_geo
        territoires.append({"niveau": niveau, "code": code, "nom": nom, "surface": surface,
                            "flux": e["flux"], "synthese": _synthese(e["flux"], surface, annees)})

    for code in codes:
        if code in brut["communes"]:
            info = infos.get(code, {})
            ajouter("Commune", code, info.get("nom") or brut["communes"][code]["nom"],
                    brut["communes"][code], info.get("surface_ha"))

    def somme(liste):
        tot = _vide(annees)
        for code in liste:
            c = brut["communes"].get(code)
            if not c:
                continue
            tot["surface"] += c["surface"]
            for a in annees:
                for k, v in c["flux"][a].items():
                    tot["flux"][a][k] += v
        return tot

    presents = [c for c in codes if c in brut["communes"]]
    tous = [c["code"] for c in communes]
    if 1 < len(presents) < len(tous):
        ajouter("Sélection", "SEL", f"Sélection ({len(presents)} communes)", somme(presents))
    ajouter("EPCI", "200065563", nom_epci, somme(tous))
    if comparer and brut.get("n_dep"):
        ajouter("Département", "14", "Calvados", brut["dep"])
    if comparer and brut.get("n_reg"):
        ajouter("Région", "28", "Normandie", brut["reg"])
    return territoires


def extraire(communes, codes, nom_epci, comparer, fichier_local=None, forcer_verification=False,
             url_api=URL_API, stop_event=None, journal=print):
    """Enchaînement complet (exécuté dans un thread)."""
    if fichier_local:
        meta = utiliser_fichier_local(fichier_local)
        journal(f"   fichier local : {fichier_local}")
    else:
        with reseau.etape(0, 0.6, "Téléchargement du fichier national"):
            meta = preparer_fichier(forcer_verification, url_api, stop_event, journal)
    journal(f"Lecture du fichier (millésime {meta['millesime']})...")
    # On lit toujours les communes de tout l'EPCI (le total NCPA en a besoin) ;
    # seules les communes cochées apparaissent ligne par ligne.
    with reseau.etape(0.6, 0.97, "Lecture du fichier national"):
        brut = lire(meta["fichier"], [c["code"] for c in communes], comparer, stop_event, journal)
    reseau.avancement(0.98, "Calcul des indicateurs")
    territoires = construire(brut, communes, codes, nom_epci, comparer)
    return {"territoires": territoires, "annees": brut["annees"], "meta": meta,
            "destinations": brut["destinations"], "unite": brut["unite"]}

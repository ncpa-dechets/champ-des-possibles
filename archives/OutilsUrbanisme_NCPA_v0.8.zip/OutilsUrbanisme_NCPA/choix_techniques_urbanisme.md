# Outils Urbanisme — NCPA · Journal des choix techniques

> Document de référence pour comprendre, maintenir ou faire évoluer l'outil
> sans avoir à tout relire. Version 0.8, octobre 2026.
> Auteur : Yves Marti, Service Maîtrise des déchets — contact : y.marti@ncpa.fr

## 1. Principe : un onglet par thème, chacun indépendant

Chaque thème (consommation d'espaces, permis, friches, zonage) a sa propre
liste de communes, son propre bouton d'extraction, son test de source et
ses sorties. Rien n'oblige à tout extraire : un thème en panne n'empêche
pas les autres de fonctionner.

Sorties prévues pour chaque thème : Excel, GeoJSON (QGIS), carte HTML
(Leaflet) et rapport HTML avec graphiques.

Mêmes conventions que les outils SIRENE et Habitat : Python + CustomTkinter,
.exe autonome (PyInstaller), pas de pandas, modules métier séparés de
l'interface, appels réseau dans un thread, journal technique
(`journal_technique.log`) à côté du .exe.

## 2. Thème 1 (v0.1) : consommation d'espaces NAF

### Source

Cerema, « Consommation d'espaces naturels, agricoles et forestiers »,
d'après les Fichiers fonciers, publiée chaque année sur data.gouv.fr.
Millésime courant : **du 1er janvier 2011 au 1er janvier 2025** (publié en
juillet 2026, CSV communal d'environ 31 Mo). Accès libre, sans clé.

Pourquoi pas l'API Données foncières du Cerema : elle est toujours en
version « beta » et a déjà renvoyé des erreurs HTTP 503 (cf. outil Habitat).

### Récupération (`modules/conso_enaf.py`), trois niveaux de repli

1. **Recherche automatique** du millésime le plus récent via l'API de
   data.gouv.fr : jeux du Cerema dont le titre contient « 1er janvier AAAA »,
   on garde l'année de fin la plus grande, puis le plus gros CSV (hors
   carroyage). Un nouveau millésime est donc pris en compte sans modifier
   le code (bouton « Chercher une mise à jour »).
2. **Adresse de secours** codée en dur (`URL_SECOURS`, millésime 2011-2025)
   si la recherche échoue.
3. **Fichier local** : l'utilisateur télécharge le CSV avec son navigateur
   et le désigne (bouton « Utiliser un fichier CSV local »). Toujours possible,
   même si le proxy bloque les téléchargements automatiques.

Le fichier est conservé 90 jours dans `cache_conso/` (avec `source.json` qui
décrit son origine et son millésime).

### Lecture : colonnes reconnues par leur forme

Pas de noms codés en dur, pour résister aux changements de millésime :

| Forme | Sens |
|---|---|
| `naf11art12` | flux total ENAF → artificialisé, du 1/1/2011 au 1/1/2012 |
| `art11hab12` | dont habitat (idem `act`, `mix`, `rou`, `fer`, `inc`) |
| `idcom`, `idcomtxt`, `iddep`, `idreg` | commune, nom, département, région |
| `surfcom…` | surface communale (la plus récente) |

Seuls les flux **annuels** (années consécutives) sont lus ; les cumuls
pluriannuels du fichier (ex. `naf16art22`) sont ignorés et recalculés.
Encodage (UTF-8 ou Windows-1252) et séparateur (`;` ou `,`) détectés.

Le fichier national est lu en une passe : on garde les 38 communes de la
NCPA (toujours, car le total EPCI en a besoin) et on cumule au passage le
Calvados et la Normandie. Aucune donnée d'une autre commune n'est conservée.

**Unité** : le Cerema diffuse des m². Contrôle automatique : si la
consommation annuelle du Calvados dépasse 50 000 unités, ce sont des m²
(convertis en hectares). L'unité retenue est écrite dans le journal.

### Indicateurs (`construire`, `_synthese`)

| Indicateur | Calcul |
|---|---|
| Consommation 2011-2021 | somme des flux 2011 à 2020 (période de référence de la loi Climat et résilience) |
| Rythme de référence | ÷ 10 ans |
| Consommation depuis 2021 | somme des flux à partir de 2021 (millésime 2011-2025 : 4 années, 2021-2025) |
| Évolution du rythme | rythme récent ÷ rythme de référence − 1 |
| Enveloppe indicative | 50 % de 2011-2021 |
| Part de l'enveloppe consommée | consommation depuis 2021 ÷ enveloppe |
| Part de la surface | consommation 2011-2021 ÷ surface communale |

**Précautions affichées partout** (interface, Excel, carte, rapport) :
- l'enveloppe à −50 % est l'objectif national ; l'enveloppe applicable est
  territorialisée par le SRADDET de Normandie puis le SCoT : c'est un repère ;
- la dernière année est provisoire (révisée à la hausse, stabilisation en
  3 ans environ selon le Cerema).

Niveaux produits : chaque commune cochée, « Sélection » (si plusieurs
communes mais pas toutes), EPCI (somme des 38 communes), Calvados,
Normandie.

### Sorties

- **Excel** (`export_excel.py`) : Synthèse ZAN, Annuel (ha), Par destination
  (format long, prêt pour un tableau croisé dynamique), Lisez-moi.
- **GeoJSON** (`export_geo.py`) : contours des communes (geo.api.gouv.fr,
  cache 30 jours) + indicateurs + une propriété par année (`conso_2021_ha`...).
  WGS84 [longitude, latitude] ; reprojeter en Lambert-93 dans QGIS si besoin.
- **Carte HTML** : charte NCPA (rouge #B91E27, vert #B1B993, Calibri), fonds
  Plan IGN ou photographies aériennes IGN (voir « Fonds de carte », v0.8).
  Choix de l'indicateur (dont une année au choix), légende synchronisée,
  statistiques qui suivent le filtre, tableau triable lié à la carte dans
  les deux sens. Leaflet est **embarqué** dans le fichier : seuls les fonds
  de carte demandent internet.
- **Rapport HTML** (`rapport_html.py`) : Chart.js embarqué. Élément central :
  la jauge de l'enveloppe indicative, mise en regard du temps écoulé sur la
  décennie 2021-2031. Puis : consommation annuelle par destination
  (dernière année atténuée), comparaison NCPA / Calvados / Normandie en
  ha/an pour 1 000 ha de territoire, classement des communes, tableau,
  méthode.

## 3. Thème 2 (v0.2) : permis détaillés

### Source

SDES, jeu DiDo « Liste des permis de construire et autres autorisations
d'urbanisme » (identifiant `6513f0189d7d312c80ec5b5b`), mis à jour chaque
mois. Un fichier par type ; l'outil utilise : PC et DP créant des logements,
permis d'aménager, permis de démolir (pas les locaux non résidentiels).

Accès commun à DiDo dans `modules/dido.py`, avec les leçons de l'outil
Habitat : millésime le plus récent **déjà diffusé** (un millésime annoncé
avec une date de diffusion future renvoie HTTP 400), nouvel essai sans
millésime en cas de refus, séparateur du CSV détecté. Métadonnées en cache
24 heures.

### Lecture (`modules/permis.py`)

- Fichiers reconnus par leur titre (« démol », « aménag », « logement »).
- Colonnes reconnues par leur nom (`COMM`, `Num_DAU`, `Etat_DAU`,
  `DATE_REELLE_AUTORISATION`, `DATE_REELLE_DOC`, `DATE_REELLE_DAACT`,
  `CAT_DEM`, `ADR_*_TER`, `SEC_CADASTRE1..3`, `NUM_CADASTRE1..3`,
  `NB_LGT_TOT_CREES`, `NB_LGT_IND_CREES`, `NB_LGT_COL_CREES`,
  `NB_LGT_DEMOLIS`, `SURF_HAB_CREEE`...), avec repli par motif. Le bouton
  **Diagnostic de la source** liste ce que l'outil reconnaît pour chaque
  fichier : c'est le premier réflexe si le SDES change son format.
- Filtre par commune côté serveur (`COMM=in:...`), filtre par année
  d'autorisation en local.
- Limite connue : le code commune est celui du dépôt ; un permis déposé sous
  l'ancien code d'une commune fusionnée n'est pas retrouvé.

### Indicateurs

| Indicateur | Définition |
|---|---|
| Logements autorisés | somme de `NB_LGT_TOT_CREES`, hors autorisations annulées (état 4) |
| Commencés | ouverture de chantier connue (état 5 ou 6, ou date de DOC) |
| Terminés | achèvement connu (état 6 ou date de DAACT) |
| **À venir** | chantier ouvert non achevé, ou autorisation de moins de 3 ans sans ouverture de chantier connue (validité d'une autorisation, hors prorogation) : repère des futurs foyers à desservir |
| Permis d'aménager | nombre, surface de terrain (ha), lots si la colonne existe |
| Permis de démolir | nombre, logements démolis si la colonne existe |

Les déclarations d'ouverture et d'achèvement arrivent souvent tard : les
logements commencés et terminés sont des minimums, les « à venir » plutôt un
maximum.

### Localisation (`modules/cadastre.py`)

Sitadel ne donne pas de coordonnées mais jusqu'à 3 parcelles. Le plan
cadastral Etalab de chaque commune concernée est téléchargé une fois
(`cadastre.data.gouv.fr/data/etalab-cadastre/latest/geojson/communes/...`),
le centre de chaque parcelle est calculé et conservé dans `cache_cadastre/`
(180 jours). Le permis est placé au centre de sa parcelle (moyenne si
plusieurs). Correspondance sur section + numéro, tous préfixes confondus.
Les permis sans parcelle reconnue restent dans l'Excel, pas sur la carte.

### Sorties

- **Excel** : Synthèse (par commune + total), Par année, une liste par type
  (colonnes lisibles, puis toutes les colonnes d'origine du SDES préfixées
  `[source]`), Lisez-moi.
- **GeoJSON** : un point par autorisation localisée, avec ses attributs.
- **Carte HTML** : même charte que la carte de consommation d'espaces ; filtres
  par type, années et état (dont « logements à venir »), taille des cercles
  selon le nombre de logements, limites communales, tableau lié à la carte,
  statistiques qui suivent les filtres.
- **Rapport HTML** : parcours des logements (autorisés, commencés, terminés,
  à venir), logements par année et par type, permis d'aménager et de démolir,
  classement des communes, catégories de demandeurs, tableau, méthode.

## 3 bis. Thème 3 (v0.3) : friches

### Source

Cerema, inventaire national des friches **Cartofriches**, jeu data.gouv
« Sites référencés dans Cartofriches » (`sites-references-dans-cartofriches`),
CSV national d'environ 25 Mo au format du **standard CNIG Friches**
(github.com/cnigfr/schema-friches, v1.0.6), mis à jour plusieurs fois par an.

Pourquoi pas l'API Données foncières du Cerema : version beta, et elle
renvoie des erreurs 503 depuis le 2 octobre 2026.

Mêmes replis que pour la consommation d'espaces (`modules/friches.py`) :
adresse du CSV lue via l'API de data.gouv (le plus gros CSV du jeu, hors
dictionnaire), cache 30 jours (`cache_friches/`), fichier local en dernier
recours. Bouton « Diagnostic de la source » : présence du fichier sur
data.gouv, colonnes clés reconnues, colonnes du standard absentes.

### Lecture

- Colonnes du standard CNIG : `comm_insee`, `site_statut`, `site_type`,
  `unite_fonciere_surface` (m²), `geompoint` et `geomsurf` (WKT)...
- **Géométries** (`modules/geometrie.py`, sans dépendance) : lecture du WKT
  (POINT, POLYGON, MULTIPOLYGON), puis correction automatique des deux
  pièges vus dans les données : latitude et longitude inversées (l'exemple
  officiel du standard les inverse) et coordonnées en Lambert-93
  (conversion vers WGS84 par les formules de l'IGN). Les corrections sont
  comptées dans le journal.
- Surface : celle de l'unité foncière déclarée ; à défaut, calculée à partir
  du contour (approximation sphérique, précise à mieux que 1 % à cette
  échelle).
- Le fichier est lu en une passe : sites des communes demandées, et cumuls
  Calvados et Normandie (nombre, surface, sites sans projet).

### Statuts

Sans projet, avec projet, potentielle, reconvertie ; les autres valeurs
(« inconnu », « autre », « sans objet ») sont regroupées.

### Précaution affichée partout

L'inventaire n'est pas exhaustif : il dépend des observatoires locaux
transmis au Cerema. Une commune sans site recensé n'est pas forcément une
commune sans friche ; les comparaisons reflètent aussi la couverture des
observatoires.

### Sorties

- **Excel** : synthèse par commune et par statut (nombre et surface),
  liste des sites (colonnes lisibles puis colonnes d'origine), Lisez-moi.
- **GeoJSON** : contour du site s'il existe, sinon point.
- **Carte HTML** : contour (visible en zoomant) et repère au centre, couleurs
  par statut, filtres par statut et par type, tableau lié, statistiques qui
  suivent les filtres.
- **Rapport HTML** : bande de répartition des surfaces par statut (le
  « gisement » sans projet), surfaces par commune, types de friches,
  pollution des sols, comparaison, liste des sites.

## 3 ter. Thème 4, étape 1 (v0.4) : documents d'urbanisme et zonage

### Source

Géoportail de l'Urbanisme via l'**API Carto de l'IGN**, module GPU
(`https://apicarto.ign.fr/api/gpu/...`), gratuite et sans clé. Couches :
`municipality` (commune au RNU ?), `document` (document applicable et ses
dates), `zone-urba` (zones des PLU et PLUi), `secteur-cc` (cartes
communales). 1 000 objets au plus par appel : pagination `_start` /
`_limit`, avec arrêt de sécurité si l'API renvoie des objets déjà reçus.

### Démarche (`modules/zonage.py`)

1. Pour chaque commune : statut RNU, puis document couvrant un point
   **intérieur** à la commune (`representative_point` de shapely, toujours
   dans le polygone même pour une commune de forme irrégulière). On garde
   PLUi, PLU, POS, CC ou PSMV (les SCoT sont écartés). Cache 7 jours.
2. Zones téléchargées **une fois par document** (partition `DU_<insee>`
   ou `DU_<siren>`), cache 30 jours (`cache_zonage/`).
3. **Découpage par commune** : chaque document n'est découpé que sur les
   communes qui lui sont rattachées (pas de double compte). Les surfaces
   sont mesurées en **Lambert-93** (projection directe ajoutée à
   `geometrie.py`, vérifiée par aller-retour). Les éclats de moins de
   0,01 ha le long des limites communales sont ignorés. Contours simplifiés
   (environ 2 m) pour la carte et le GeoJSON.
4. Familles de zones : U, AUc (à urbaniser ouverte), AUs (fermée), A, N ;
   cartes communales : constructible (codes 01 à 03) ou non (99).

### Pourquoi shapely

Découper des milliers de polygones selon les limites communales demande une
bibliothèque géométrique fiable (gestion des géométries invalides, index
spatial). shapely est la référence en Python ; elle est intégrée au .exe
(`--collect-all shapely` dans `fabriquer_exe.bat`) : rien à installer sur
les postes.

### Limites signalées

- Une commune nouvelle couverte par plusieurs documents n'est rattachée
  qu'à l'un d'eux ; le journal signale les recouvrements notables.
- Petits écarts entre surface zonée et surface communale : tracés
  différents entre limites communales (geo.api) et documents d'urbanisme.
- Seul le document en vigueur publié sur le Géoportail fait foi.

### Sorties (choix de l'utilisateur : pas d'Excel pour ce thème)

- **Carte HTML** : zones colorées selon le standard CNIG, choix de la
  commune (zoom, document et dates), surfaces par famille dans la légende,
  communes au RNU grisées, lien vers le règlement de chaque zone (PDF),
  tableau par commune lié à la carte.
- **Rapport HTML** : couverture par les documents et répartition des
  surfaces, profil de chaque commune, zones à urbaniser (AUc / AUs), tableau
  des documents (type, approbation, état), zones les plus étendues.
- **GeoJSON** : morceaux de zones découpés par commune, avec libellé, type,
  famille, surface, document et lien vers le règlement.

### Étape 2 (v0.5) : servitudes, prescriptions, croisement

Module `modules/servitudes.py` :

- **Prescriptions** (`prescription-surf`, `-lin`, `-pct`) téléchargées par
  document, comme les zones, puis découpées sur les communes rattachées.
  Libellés des types d'après le standard CNIG PLU v2017 pour les plus
  courants (01 espace boisé classé, 05 emplacement réservé, 07 élément de
  paysage ou de patrimoine) ; pour les autres codes, libellé le plus
  fréquent trouvé dans le document, suivi du code, pour ne rien inventer.
- **Servitudes** (`assiette-sup-s`, `-l`, `-p`) : elles ne dépendent pas du
  document d'urbanisme (publiées par l'État, l'ABF, l'ARS, les gestionnaires
  de réseaux). Interrogation commune par commune sur le rectangle englobant,
  puis découpage selon la limite communale. Catégorie lue dans `suptype`
  (ou, à défaut, dans le nom de la partition `..._SUP_14_AC1`) ; libellés
  de la nomenclature nationale pour les catégories courantes.
- Mesures : surfaces en ha (Lambert-93), longueurs en m pour les objets
  linéaires (lignes électriques, canalisations...), nombre pour les points.
- Caches de 30 jours (par document pour les prescriptions, par commune pour
  les servitudes).

Module `modules/croisement.py` :

- Points pris dans les onglets Permis et Friches de la séance, ou chargés
  depuis un GeoJSON exporté par ces onglets (bouton « Charger un GeoJSON ») :
  le thème Zonage reste utilisable seul. Le type de fichier est reconnu par
  ses propriétés (`theme_code` pour les permis, `statut_code` pour les friches).
- Pour chaque point : zone qui le contient (index spatial), servitudes et
  prescriptions surfaciques qui le couvrent. Synthèses : autorisations,
  logements et logements à venir par famille de zone ; friches et friches
  sans projet par famille de zone ; points dans l'emprise d'une servitude.

Sorties enrichies :

- **Carte** : trois couches supplémentaires à cocher (servitudes par
  catégorie, prescriptions par type, permis et friches par type), chacune
  avec sa légende et ses comptes ; info-bulles avec la zone, les servitudes
  et prescriptions de chaque point et le lien vers le règlement.
- **Rapport** : tableaux des servitudes et des prescriptions (synthèse et
  détail commune par commune repliable), part des logements autorisés hors
  des zones urbaines, répartition des permis et friches par zone, points
  concernés par une servitude.
- **GeoJSON** : le fichier choisi contient les zones ; trois fichiers voisins
  sont créés au même endroit : `_servitudes`, `_prescriptions`,
  `_permis_friches`.

## 4. Organisation de l'interface (v0.2)

Chaque thème est un onglet autonome dérivé de `OngletTheme` (liste de
communes, source, options, lancement, résultats, exports, journal). Un seul
travail à la fois, tous thèmes confondus : le journal et la fin du travail
sont renvoyés vers l'onglet qui l'a lancé.

## 4 bis. Deux interfaces sur le même moteur (v0.6)

Le dossier `modules/` contient tout le travail (sources, calculs, cartes,
rapports). Deux façades l'utilisent, à choisir selon le poste :

| | Application `.exe` | Interface Streamlit |
|---|---|---|
| Fichier | `app_urbanisme.py` | `interface_streamlit.py` |
| Lancement | `dist\OutilsUrbanisme_NCPA.exe` (après `fabriquer_exe.bat`) | `lancer_interface.bat` |
| Prérequis | aucun sur le poste | Python installé ; les bibliothèques manquantes s'installent seules dans le dossier de l'utilisateur (`pip --user`, sans droits administrateur) |
| Sorties | fichiers enregistrés sur le poste | carte et rapport affichés dans la page, et boutons de téléchargement |

Toute correction dans `modules/` profite aux deux. L'enchaînement complet du
zonage (zones, prescriptions, servitudes, croisement) est dans
`modules/zonage_complet.py` pour ne pas être écrit deux fois.

### Choix propres à Streamlit

- **Travaux en arrière-plan** (même méthode que l'outil économique) : chaque
  extraction tourne dans un fil séparé ; un encadré de suivi se rafraîchit
  chaque seconde (`st.fragment(run_every=1)`) avec les dernières lignes du
  journal et un bouton Annuler. Cliquer ailleurs ou recharger la page
  n'interrompt rien.
- **Jeton de session dans l'adresse** (`?s=...`) : les travaux et résultats
  sont rangés par jeton dans une mémoire partagée du serveur
  (`st.cache_resource`). Recharger la page avec la même adresse retrouve
  les résultats ; deux navigateurs ont chacun les leurs. Ce choix rend
  l'outil utilisable plus tard sur un serveur NCPA, à plusieurs, sans
  modification.
- Un travail à la fois **par thème** (on peut lancer les permis pendant que
  les friches tournent). Le croisement du zonage prend les résultats
  disponibles au moment du lancement ; un message prévient si les permis
  ou les friches sont encore en cours.
- **Sorties préparées une seule fois** puis gardées en mémoire (carte,
  rapport, Excel, GeoJSON) ; seule la vue choisie (Tableau, Carte, Rapport,
  Téléchargements) est affichée, pour garder la page fluide.
- Dépôt de fichiers (CSV du Cerema, CSV Cartofriches, GeoJSON de permis ou
  de friches) à la place des boîtes de dialogue ; taille maximale 200 Mo
  (`.streamlit/config.toml`).
- Charte : rouge NCPA (`#B91E27`) comme couleur principale, même en-tête que
  les cartes et rapports.

### Améliorations de la v0.7

- **Plus de question « adresse e-mail »** au premier lancement : Streamlit la
  pose s'il ne trouve pas `~/.streamlit/credentials.toml`. `lancer_interface.py`
  crée ce fichier (vide) et lance le serveur en mode sans invite
  (`headless = true`, aussi inscrit dans `.streamlit/config.toml`), puis ouvre
  lui-même le navigateur quand le serveur répond. Relancer le .bat alors que
  l'outil tourne déjà ouvre simplement la page.
- **Barre de progression réelle** : `reseau.py` offre un suivi par étapes
  imbriquées (`definir_suivi`, `etape`, `avancement`), propre à chaque fil
  d'exécution (deux thèmes en parallèle ne se mélangent pas). Les modules
  découpent leur travail (téléchargement à l'octet près quand le serveur
  donne la taille, lecture des gros fichiers ligne à ligne, communes une à
  une pour le cadastre, les documents et les servitudes). Streamlit affiche
  l'étape, le pourcentage, le temps écoulé et une estimation du temps
  restant ; l'application .exe passe d'une barre animée à une vraie jauge.
- **Présentation** : bandeau d'en-tête aux couleurs NCPA rappelant les thèmes
  déjà extraits, onglets avec icônes, présentation de chaque thème, paramètres
  repliés une fois les résultats obtenus (les résultats remontent), indicateurs
  en cartes, boutons avec icônes, bouton de dépôt traduit (« Parcourir… »).
- **Consultation des données** : cinq vues par thème. **Explorer** ajoute des
  filtres (types, états, communes, recherche texte, logements à venir…), des
  graphiques natifs et la liste détaillée (permis un par un, sites de friches
  avec lien vers leur fiche, zones avec lien vers leur règlement, servitudes,
  prescriptions, permis et friches croisés). La page utilise toute la
  largeur ; la **hauteur** des cartes, rapports et listes se règle dans la
  barre latérale (600 à 1 600 pixels) ; la carte et le rapport ont un bouton
  **Plein écran** (l'iframe des composants Streamlit autorise le plein écran).

### Usage sur un serveur (si un jour décidé)

`python -m streamlit run interface_streamlit.py --server.port 8512
--server.address 0.0.0.0`, depuis ce dossier. Les caches sont communs à
tous les utilisateurs (c'est voulu : les données téléchargées servent à
tous). À valider avec le service informatique (accès réseau sortant vers
data.gouv.fr, le SDES, l'IGN et geo.api.gouv.fr).

## 4 ter. Fonds de carte et couche personnelle (v0.8)

### Fonds de carte (`modules/fonds_carte.py`, commun aux quatre cartes)

- **Plan IGN** (Plan IGN v2, Géoplateforme, tuiles raster sans clé) remplace
  le fond vectoriel OpenFreeMap : sur le poste de l'utilisateur, ce dernier
  ne s'affichait pas (seules les limites communales apparaissaient), et le
  fond IGN est celui qu'il souhaite. MapLibre n'étant plus utile, il est
  retiré : chaque carte pèse environ 1 Mo de moins.
- **Photo aérienne** : orthophotographies IGN.
- **Sélecteur posé sur la carte** (en haut à droite), au lieu d'un choix en
  bas du panneau latéral qui pouvait passer inaperçu quand le panneau est
  long (carte du zonage notamment).
- **Limites communales adaptées au fond** (`styleLimite`) : trait sombre en
  pointillés sur le plan, trait blanc fin et continu sur la photo. Sur la
  carte de consommation d'espaces, les contours deviennent blancs et
  l'aplat de couleur un peu plus transparent ; sur la carte du zonage, les
  contours des zones passent aussi en blanc.

### Couche personnelle sur la carte du zonage

Bouton « Choisir un fichier GeoJSON… » dans le panneau : un ou plusieurs
fichiers, lus dans le navigateur (rien n'est envoyé). Points, lignes ou
surfaces. Coordonnées en WGS84 ou en **Lambert-93** (détectées et converties
avec les formules de l'IGN, comme dans `geometrie.py`) ; latitude et
longitude inversées corrigées. Chaque couche a sa couleur, un bouton Zoom et
un bouton Retirer, et un résumé de la répartition de ses points par type de
zone. Au clic, l'info-bulle donne tous les attributs, la zone du document
d'urbanisme qui contient l'objet (test point dans polygone, avec présélection
par rectangle englobant), la commune et le lien vers le règlement.

## 5. Thèmes suivants (préparés dans l'interface)

| Thème | Source pressentie | Remarque |
|---|---|---|

## 6. Fichiers

```
app_urbanisme.py            interface .exe (CustomTkinter)
interface_streamlit.py      interface Streamlit (même moteur)
lancer_interface.bat / .py  lancement de l'interface Streamlit
requirements_streamlit.txt  bibliothèques de l'interface Streamlit
.streamlit/config.toml      thème et réglages Streamlit
modules/zonage_complet.py   enchaînement du zonage commun aux deux interfaces
modules/conso_enaf.py       thème consommation d'espaces : source, lecture, indicateurs
modules/export_excel.py     classeur Excel
modules/export_geo.py       GeoJSON et carte Leaflet
modules/rapport_html.py     rapport graphique
modules/permis.py           thème permis : fichiers, colonnes, indicateurs
modules/dido.py             accès commun au serveur DiDo du SDES (millésimes sous embargo)
modules/cadastre.py         localisation des permis au centre de leur parcelle
modules/export_permis.py    Excel et GeoJSON des permis
modules/carte_permis.py     carte Leaflet des permis
modules/rapport_permis.py   rapport graphique des permis
modules/friches.py          thème friches : source Cartofriches, lecture, indicateurs
modules/geometrie.py        WKT, Lambert-93 vers WGS84, surfaces (réutilisable pour le zonage)
modules/export_friches.py   Excel et GeoJSON des friches
modules/carte_friches.py    carte Leaflet des friches
modules/rapport_friches.py  rapport graphique des friches
modules/zonage.py           thème zonage : documents, zones, découpage par commune (shapely)
modules/servitudes.py       servitudes d'utilité publique et prescriptions
modules/croisement.py       zone, servitudes et prescriptions de chaque permis et friche
modules/carte_zonage.py     carte Leaflet et GeoJSON du zonage
modules/rapport_zonage.py   rapport graphique du zonage
modules/territoire.py       communes, surfaces, contours (geo.api.gouv.fr)
modules/reseau.py           requêtes, relances, journal technique (repris de l'outil Habitat)
modules/test_connexions.py  bouton « Tester la source »
modules/chemins.py          fichiers embarqués vs fichiers à côté du .exe
donnees/                    Chart.js 4.4.1, Leaflet 1.9.4
modules/fonds_carte.py      fonds Plan IGN et photo aérienne, sélecteur sur la carte, style des limites
```

## 7. Fabrication

Lancer `fabriquer_exe.bat` depuis ce dossier (Python installé). Le .exe
apparaît dans `dist\`. Les caches et le journal technique s'écrivent à côté
du .exe : le placer dans un dossier où l'utilisateur a le droit d'écrire.

## 8. Validation

- Moteur testé avec un fichier au format du Cerema reconstitué (2 000
  communes, colonnes annuelles et pluriannuelles, séparateur `;`), sur trois
  cas : 38 communes, 3 communes, 1 commune.
- Recherche du millésime testée avec une réponse data.gouv simulée (deux
  millésimes Cerema + un jeu d'un autre producteur), cache, et panne de l'API
  (bascule sur l'adresse de secours).
- Interface lancée sur écran virtuel (modes clair et sombre) ; carte et
  rapport ouverts dans un navigateur sans erreur JavaScript.
- Thème Permis (v0.2) testé avec des réponses DiDo simulées au format Sitadel
  (3 fichiers, millésime sous embargo, colonnes propres à chaque type) et un
  cadastre reconstitué : extraction, localisation, cache, quatre sorties,
  diagnostic, interface.
- Thème Friches (v0.3) testé avec un inventaire reconstitué au format CNIG
  (3 300 sites, géométries ponctuelles et surfaciques, coordonnées inversées
  ou en Lambert-93, surfaces manquantes) : lecture, corrections, cumuls,
  quatre sorties, diagnostic, interface. Projection Lambert-93 vérifiée sur
  le point d'origine (3° E, 46,5° N).
- Thème Zonage (v0.4) testé avec une API Carto simulée : PLUi de 2 500
  zones (pagination sur 3 pages), un PLU, une carte communale, deux
  communes au RNU, documents SCoT à écarter ; découpage par commune sans
  double compte, surfaces, trois sorties, diagnostic, interface.
- Étape 2 du Zonage (v0.5) testée avec une API simulée : 380 prescriptions
  (surfaces, lignes, points ; types connus et inconnus), 60 servitudes de 6
  catégories (surfaces et lignes), croisement de 260 points issus des
  onglets ou d'un GeoJSON, cache, trois sorties, interface.
- Interface Streamlit (v0.6) pilotée dans un navigateur avec des sources
  simulées : quatre thèmes, suivi en direct, permis et friches lancés en
  parallèle, croisement dans le zonage, carte et rapport affichés dans la
  page, téléchargements, résultats retrouvés après rechargement. L'appli
  .exe a été relancée après la mise en commun du zonage.
- v0.7 : lanceur testé avec un dossier personnel vierge (aucune invite,
  fichier d'identifiants créé) ; progression observée en direct sur les
  quatre thèmes ; vues Explorer, carte en plein écran et sortie du plein
  écran pilotées dans un navigateur ; application .exe relancée avec la jauge.
- v0.8 : bascule plan / photo et style des limites vérifiés sur les quatre
  cartes ; couche de 15 points en Lambert-93 chargée sur la carte du zonage
  (conversion, résumé par zone, info-bulle avec la zone et le règlement).
- **Reste à valider sur poste** : le téléchargement réel depuis data.gouv.fr
  et les vrais noms de colonnes du millésime 2011-2025 (validé depuis) ; pour les permis, les vrais titres de fichiers et colonnes du SDES (bouton Diagnostic).

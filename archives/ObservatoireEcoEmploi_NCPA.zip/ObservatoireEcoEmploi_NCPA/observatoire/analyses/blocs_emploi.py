# -*- coding: utf-8 -*-
"""Blocs d'analyse issus de l'ancien outil Emploi (Urssaf, France Travail, BMO, SIRENE, La Bonne Boite...).

Un bloc a la même forme que ceux du portrait économique : id, theme (id du catalogue), titre, lecture, source,
table (DataFrame), table2 facultative, graph (description dessinée par rendu/figures.py), essentiel (repris dans la
synthèse pour les élus).
"""
import pandas as pd

from ..utils import fmt_nombre


def _n(v, d=0):
    return fmt_nombre(v, d) if v is not None else "n.d."


def _p(v, signe=False, d=1):
    if v is None:
        return "n.d."
    return (f"{v * 100:+.{d}f} %" if signe else f"{v * 100:.{d}f} %").replace(".", ",")


def _court(s, n=48):
    s = str(s or "")
    return s if len(s) <= n else s[:n - 1] + "…"


def bloc(theme, id_, titre, lecture, source, table=None, graph=None, table2=None, essentiel=False):
    return {"id": id_, "theme": theme, "titre": titre, "lecture": lecture, "source": source,
            "table": table if table is not None else pd.DataFrame(), "table2": table2, "graph": graph,
            "essentiel": essentiel}


SRC_URSSAF = "Urssaf, effectifs salariés du secteur privé au 31/12 (commune x APE)"


# ============================================================================================ évolution
def b_evolution(r):
    out = []
    nom, a1, a2 = r["ref_nom"], r["a_deb"], r["a_fin"]
    terr = list(dict.fromkeys(s["territoire"] for s in r["serie"]))
    series = {t: [s["base100"] for s in r["serie"] if s["territoire"] == t] for t in terr}
    x = [s["annee"] for s in r["serie"] if s["territoire"] == nom]
    tb = pd.DataFrame([{"Territoire": s["territoire"], "Année": s["annee"], "Salariés": s["eff"],
                        "Établissements": s["etab"], "Indice base 100": s["base100"]} for s in r["serie"]])
    lect = r["synthese"][0] if r.get("synthese") else ""
    out.append(bloc("evolution", "emploi_base100", f"Évolution de l'emploi salarié privé, base 100 en {a1}", lect,
                    SRC_URSSAF, tb, {"kind": "lines", "x": x, "series": series, "cible": nom,
                                     "ylabel": f"Indice base 100 en {a1}", "ligne_ref": 100, "fmt": "nombre1"},
                    essentiel=True))
    if r["groupes"]:
        series = {nom: series.get(nom)}
        for g in r["groupes"]:
            series[f"Médiane : {g}"] = [next((m["base100"] for m in r["medianes_groupes"]
                                              if m["groupe"] == g and m["annee"] == a), None) for a in x]
        st = [s for s in r["stats"] if s["indicateur"] == "evol"]
        lect = " ".join(f"Groupe « {s['groupe']} » : {nom} se classe {s['rang_ref'] or '?'}e sur {s['nb']} EPCI "
                        f"(évolution {_p(s['valeur_ref'], True)}, médiane {_p(s['mediane'], True)})."
                        for s in st)
        tb = pd.DataFrame([{"Année": a, **{k: v[i] for k, v in series.items()}} for i, a in enumerate(x)])
        out.append(bloc("evolution", "emploi_base100_groupes", "Évolution comparée aux groupes d'EPCI (médianes)",
                        lect, SRC_URSSAF, tb, {"kind": "lines", "x": x, "series": series, "cible": nom,
                                               "ylabel": f"Indice base 100 en {a1}", "ligne_ref": 100,
                                               "fmt": "nombre1"}))
        variantes, tables = {}, []
        for g, t in r["comparaisons"].items():
            tt = sorted([d for d in t if d["evol"] is not None], key=lambda d: d["evol"])
            autres = sorted(d["evol"] for d in tt if not d["est_ref"])
            med = autres[len(autres) // 2] if autres else None
            variantes[f"{g} ({len(tt)} EPCI)"] = {
                "kind": "barh_compare", "labels": [_court(d["nom"], 42) for d in tt], "values": [d["evol"] for d in tt],
                "cible": [d["est_ref"] for d in tt], "refs": {"Médiane": med} if med is not None else {},
                "xlabel": f"Évolution de l'emploi salarié privé {a1}-{a2}", "fmt": "frac_s"}
            for d in t:
                tables.append({"Groupe": g, "Rang (évolution)": d["rang"], "EPCI": d["nom"], "SIREN": d["code_epci"],
                               "Salariés": d["eff"], "Évolution": d["evol"], "Évolution annuelle moyenne": d["tcam"],
                               "Taille moyenne des établissements": d["taille_moy"], "Population": d["pop"],
                               "Emplois privés pour 100 hab.": d["emplois_100hab"], "Salaire moyen (€)": d["salaire"],
                               "Lits touristiques pour 100 hab.": d["lits_100hab"], "Littoral": "oui" if d["littoral"] else "",
                               "Référence": "oui" if d["est_ref"] else ""})
        out.append(bloc("evolution", "emploi_classement", f"Classement des EPCI : évolution de l'emploi {a1}-{a2}",
                        "Barre rouge : le territoire étudié ; trait : médiane des autres EPCI du groupe. Choisir le "
                        "groupe dans la liste.", SRC_URSSAF, pd.DataFrame(tables),
                        {"kind": "variantes", "variantes": variantes}))
        LIB = {"evol": ("Évolution de l'emploi", "frac_s"), "tcam": ("Évolution annuelle moyenne", "frac_s"),
               "taille_moy": ("Salariés par établissement", "nombre1"),
               "emplois_100hab": ("Emplois privés pour 100 habitants", "nombre1"),
               "salaire": ("Salaire brut annuel moyen (€)", "nombre"),
               "evol_salaire": ("Évolution du salaire moyen", "frac_s"),
               "lits_100hab": ("Lits touristiques pour 100 habitants", "nombre1")}
        lignes = [{"Groupe": s["groupe"], "Indicateur": LIB[s["indicateur"]][0], "EPCI étudié": s["valeur_ref"],
                   "Médiane du groupe": s["mediane"], "Rang (1 = plus élevé)": f"{s['rang_ref'] or '?'}/{s['nb']}"}
                  for s in r["stats"]]
        out.append(bloc("evolution", "emploi_indicateurs_groupes", "Indicateurs comparés aux groupes d'EPCI",
                        "Médiane calculée sans l'EPCI étudié ; rang 1 = valeur la plus élevée.",
                        "Urssaf, OFGL (population), Insee (capacités touristiques)", pd.DataFrame(lignes)))
    return out


# ============================================================================================ secteurs
def b_secteurs(r):
    out, nom, a1, a2, niv = [], r["ref_nom"], r["a_deb"], r["a_fin"], r["niveau"]
    st = r["structure"]
    tb = pd.DataFrame([{"Secteur": s["secteur"], f"Salariés {a2}": s["eff_ref"], f"Salariés {a1}": s["eff_ref_deb"],
                        "Variation": s["var_ref"], "Évolution": s["var_ref_pct"], "Part EPCI": s["part_ref"],
                        "Part département": s["part_dep"], "Part France": s["part_fr"],
                        "Indice de spécificité (France)": s["spec_fr"], "Évolution France": s["var_fr_pct"],
                        "Effet local": s["effet_local"]} for s in st])
    top = st[:15][::-1]
    out.append(bloc("secteurs", "secteurs_poids", f"Poids des secteurs en {a2} : {nom} et France",
                    f"Les 15 premiers secteurs ({niv}) du territoire. " + (r["synthese"][2] if len(r.get("synthese", [])) > 2
                                                                          and "Secteurs" in r["synthese"][2] else ""),
                    SRC_URSSAF, tb, {"kind": "barh_groupes", "labels": [_court(s["secteur"]) for s in top],
                                     "series": {nom: [s["part_ref"] for s in top], "France": [s["part_fr"] for s in top]},
                                     "fmt": "frac"}))
    sp = sorted([s for s in st if s["spec_fr"] is not None and s["eff_ref"] > 0], key=lambda s: s["spec_fr"])
    sur = [s for s in sp if s["spec_fr"] >= 1.2 and s["eff_ref"] >= 50][::-1][:3]
    lect = ("Au-dessus de 1, le secteur pèse davantage dans l'emploi local qu'en France. "
            + ("Secteurs les plus spécifiques (50 salariés ou plus) : "
               + ", ".join(f"{s['secteur']} ({s['spec_fr']:.1f})".replace(".", ",") for s in sur) + "." if sur else ""))
    out.append(bloc("secteurs", "secteurs_specificite", "Secteurs sur- et sous-représentés (indice de spécificité)",
                    lect, SRC_URSSAF, None,
                    {"kind": "barh_simple", "labels": [_court(s["secteur"]) for s in sp],
                     "values": [s["spec_fr"] for s in sp], "ligne_v": 1, "fmt": "nombre2",
                     "couleurs": ["cible" if s["spec_fr"] >= 1 else "neutre" for s in sp],
                     "xlabel": "Part dans l'EPCI / part en France"}, essentiel=True))
    v = sorted(st, key=lambda s: s["var_ref"])
    v = list({s["secteur"]: s for s in v[:8] + v[-8:]}.values())
    g = sorted(st, key=lambda s: -s["var_ref"])
    lect = (f"Secteur qui a le plus créé d'emplois : « {g[0]['secteur']} » ({g[0]['var_ref']:+,.0f})".replace(",", " ")
            + (f" ; le plus perdu : « {g[-1]['secteur']} » ({g[-1]['var_ref']:+,.0f}).".replace(",", " ")
               if g[-1]["var_ref"] < 0 else ".")) if g else ""
    out.append(bloc("secteurs", "secteurs_variation", f"Secteurs qui gagnent ou perdent des emplois, {a1}-{a2}",
                    lect, SRC_URSSAF, None,
                    {"kind": "barh_simple", "labels": [_court(s["secteur"]) for s in v],
                     "values": [s["var_ref"] for s in v], "ligne_v": 0, "fmt": "nombre_s",
                     "couleurs": ["positif" if s["var_ref"] >= 0 else "negatif" for s in v],
                     "xlabel": "Variation du nombre de salariés"}))
    sh = r["shift"]
    lect = (r["synthese"][1] if len(r.get("synthese", [])) > 1 and "effet local" in r["synthese"][1] else "") + \
        (" Tendance nationale : variation qu'aurait connue le territoire si son emploi avait évolué comme en France. "
         "Effet de structure : poids local de secteurs qui progressent ou reculent nationalement. Effet local : le reste, "
         "la dynamique propre du territoire.")
    out.append(bloc("secteurs", "shift_share", f"D'où vient la variation de l'emploi ({a1}-{a2}) ?", lect.strip(),
                    SRC_URSSAF, pd.DataFrame([{"Composante": k, "Emplois": sh[c]} for k, c in
                                              (("Variation réelle", "variation"), ("Tendance nationale", "effet_national"),
                                               ("Effet de structure", "effet_structurel"), ("Effet local", "effet_local"))]),
                    {"kind": "bars", "labels": ["Variation réelle", "Tendance nationale", "Effet de structure",
                                                "Effet local"],
                     "values": [sh["variation"], sh["effet_national"], sh["effet_structurel"], sh["effet_local"]],
                     "couleurs": ["navy", "neutre", "accent", "positif" if sh["effet_local"] >= 0 else "negatif"],
                     "fmt": "nombre_s", "ylabel": "Emplois"}, essentiel=True))
    if r.get("activites"):
        ta = pd.DataFrame([{"Activité (APE)": a["APE"], "Salariés": a["eff"], "Établissements": a["etab"],
                            f"Salariés {a1}": a["eff_deb"], "Variation": a["var"], "Évolution": a["evol"],
                            "Part de l'emploi": a["part"]} for a in r["activites"]])
        out.append(bloc("secteurs", "activites_ape", "Activités détaillées (code APE)",
                        f"{len(r['activites'])} activités ; les premières concentrent l'essentiel de l'emploi.",
                        SRC_URSSAF, ta))
    return out


# ============================================================================================ communes
def b_communes(r, conc=None):
    nom, a1, a2 = r["ref_nom"], r["a_deb"], r["a_fin"]
    c = sorted([x for x in r["communes"] if x["eff"] is not None], key=lambda x: x["eff"])
    tb = pd.DataFrame([{"Commune": x["commune"], "Code": x["code_commune"], f"Salariés {a2}": x["eff"],
                        "Établissements": x["etab"], f"Salariés {a1}": x["eff_deb"], "Variation": x["var"],
                        "Évolution": x["evol"], "Part de l'EPCI": x["part_epci"],
                        "Secteur principal": x["secteur_principal"], "Part du secteur principal": x["part_secteur_principal"]}
                       for x in r["communes"]])
    lect = (conc or {}).get("lecture") or (f"{c[-1]['commune']} accueille {_p(c[-1]['part_epci'])} des salariés privés "
                                           f"de {nom}." if c else "")
    return [bloc("communes", "communes", f"Emploi salarié privé par commune ({a2})", lect, SRC_URSSAF, tb,
                 {"kind": "barh_simple", "labels": [x["commune"] for x in c], "values": [x["eff"] for x in c],
                  "fmt": "nombre", "xlabel": "Salariés privés au 31/12"},
                 table2=(conc or {}).get("table2"))]


# ============================================================================================ salaires
def b_salaires(r):
    s = [x for x in r["serie_salaire"] if x["salaire"] is not None]
    if not s:
        return []
    nom = r["ref_nom"]
    x = [v["annee"] for v in s]
    series = {nom: [v["salaire"] for v in s]}
    for g in dict.fromkeys(m["groupe"] for m in r["medianes_salaire"]):
        lib = g if g.startswith("France") else f"Médiane : {g}"
        series[lib] = [next((m["salaire"] for m in r["medianes_salaire"] if m["groupe"] == g and m["annee"] == a), None)
                       for a in x]
    lect = next((p for p in r.get("synthese", []) if p.startswith("Le salaire")), "")
    lect += (" Masse salariale brute divisée par l'effectif moyen : salaire par poste, pas en équivalent temps plein ; "
             "le temps partiel le fait baisser.")
    tb = pd.DataFrame([{"Année": a, **{k: v[i] for k, v in series.items()},
                        "Effectif moyen (EPCI)": s[i]["eff_moy"], "Masse salariale (EPCI, €)": s[i]["masse"]}
                       for i, a in enumerate(x)])
    return [bloc("salaires", "salaires", "Salaire brut annuel moyen par salarié", lect.strip(),
                 "Urssaf, masse salariale et effectif moyen du secteur privé par EPCI", tb,
                 {"kind": "lines", "x": x, "series": series, "cible": nom, "fmt": "eur", "ylabel": "€ par an"})]


# ============================================================================================ Flores
def b_flores(r):
    h = r.get("hors_champ")
    if not h:
        return []
    st = [x for x in h["secteurs"] if (x["flores"] or 0) > 0][:22][::-1]
    lect = " ".join(p for p in r.get("synthese", []) if p.startswith(("Tous employeurs", "Flores compte")))
    tb = pd.DataFrame([{"Secteur": x["secteur"], f"Flores {h['annee']}": x["flores"],
                        f"Urssaf {h['annee_urssaf']}": x["urssaf"], "Écart": x["ecart"],
                        "Hors champ Urssaf": x["hors_champ"]} for x in h["secteurs"]])
    return [bloc("flores", "flores", f"Emploi tous employeurs (Flores {h['annee']}) et champ Urssaf, par secteur",
                 lect + " Secteurs marqués * : surtout publics, agricoles ou particuliers employeurs.",
                 "Insee, Flores ; Urssaf", tb,
                 {"kind": "barh_groupes", "labels": [("* " if x["hors_champ"] else "") + _court(x["secteur"]) for x in st],
                  "series": {"Tous employeurs (Flores)": [x["flores"] or 0 for x in st],
                             "Privé, régime général (Urssaf)": [x["urssaf"] or 0 for x in st]}, "fmt": "nombre"})]


# ============================================================================================ France Travail
LIGNES_FT = [("de_abc", "Demandeurs d'emploi A, B, C (fin de trimestre)", "nombre"),
             ("de_a", "dont catégorie A (sans activité)", "nombre"),
             ("de_pour_100_actifs", "Demandeurs A, B, C pour 100 actifs", "nombre1"),
             ("entrants_12m", "Nouveaux inscrits sur 12 mois", "nombre"),
             ("offres_12m", "Offres d'emploi sur 12 mois (toutes origines)", "nombre"),
             ("offres_ft_12m", "dont déposées à France Travail", "nombre"),
             ("offres_pour_100_de", "Offres sur 12 mois pour 100 demandeurs", "nombre1"),
             ("embauches", "Embauches du trimestre (hors intérim)", "nombre"),
             ("dynamique", "Indicateur de dynamique de l'emploi", "nombre1"),
             ("pop_active", "Population active", "nombre"), ("salaries", "Salariés", "nombre")]


def b_ft(r, ft):
    terr = (ft or {}).get("territoires") or {}
    if not terr:
        return []
    nom = r["ref_nom"]
    lib = {"EPCI": nom}
    tb = pd.DataFrame([{"Indicateur": l, **{lib.get(t, t): d.get(c) for t, d in terr.items()}} for c, l, _ in LIGNES_FT])
    e = terr.get("EPCI") or {}
    lect = " ".join(p for p in r.get("synthese", []) if p.startswith(("France Travail compte", "Sur les 12 derniers")))
    out = [bloc("ft", "ft_cles", f"Chiffres clés France Travail ({e.get('periode_de') or 'dernière période'})",
                lect or "Demandeurs, offres et embauches du territoire et de ses territoires de référence.",
                "France Travail, API Marché du travail et Informations sur un territoire", tb,
                {"kind": "bars_group", "labels": [lib.get(t, t) for t in terr],
                 "series": {"Demandeurs pour 100 actifs": [d.get("de_pour_100_actifs") for d in terr.values()],
                            "Offres pour 100 demandeurs": [d.get("offres_pour_100_de") for d in terr.values()]},
                 "cible": nom, "fmt": "nombre1"})]
    series, x = {}, None
    for t, d in terr.items():
        s = sorted((d.get("serie_abc") or {}).items())
        if s and s[0][1]:
            series[lib.get(t, t)] = {k: v / s[0][1] * 100 for k, v in s}
    if series:
        x = sorted({k for v in series.values() for k in v})
        out.append(bloc("ft", "ft_demandeurs", "Demandeurs d'emploi A, B, C : évolution (base 100)",
                        "Base 100 au premier trimestre disponible ; données brutes (non corrigées des variations "
                        "saisonnières) : les oscillations reflètent la saisonnalité.",
                        "France Travail, API Marché du travail",
                        pd.DataFrame([{"Trimestre": k, **{t: v.get(k) for t, v in series.items()}} for k in x]),
                        {"kind": "lines", "x": x, "series": {t: [v.get(k) for k in x] for t, v in series.items()},
                         "cible": nom, "ligne_ref": 100, "fmt": "nombre1", "ylabel": "Base 100"}, essentiel=True))
    if e.get("profil"):
        out.append(bloc("ft", "ft_profil", f"Profil des demandeurs d'emploi de {nom}", "",
                        "France Travail", pd.DataFrame([{"Type": p["type"], "Caractéristique": p["caracteristique"],
                                                         "Nombre": p["nombre"], "Part (%)": p["pourcentage"]}
                                                        for p in e["profil"]])))
    return out


# ============================================================================================ saisonnalité
def b_saison(r):
    s, out, nom = r.get("saison"), [], r["ref_nom"]
    if not s:
        return out
    from .complements import SERIES_SAISON
    lect = " ".join(p for p in r.get("synthese", []) if p.startswith(("Le chômage suit", "Les embauches de plus",
                                                                       "Dans l'enquête Besoins")))
    if s["lignes"]:
        panneaux = []
        for cle, titre in SERIES_SAISON:
            lig = [l for l in s["lignes"] if l["cle"] == cle and l["code_terr"] in ("EPCI", "Département", "France")]
            if lig and cle in ("serie_a", "serie_embauches_long", "serie_embauches_court", "serie_offres"):
                panneaux.append({"titre": titre, "territoires": {
                    f"{_court(l['territoire'], 30)} (amplitude {l['amplitude'] * 100:.0f} %)": [l[f"T{q}"] for q in range(1, 5)]
                    for l in lig}, "cible": nom})
        tb = pd.DataFrame([{"Série": l["serie"], "Territoire": l["territoire"], "1er trim.": l["T1"],
                            "2e trim.": l["T2"], "3e trim.": l["T3"], "4e trim.": l["T4"], "Amplitude": l["amplitude"],
                            "Pic": l["pic"], "Creux": l["creux"], "Années": l["annees"]} for l in s["lignes"]])
        out.append(bloc("saison", "saison_profil", "Saisonnalité : écart de chaque trimestre à la moyenne de l'année",
                        lect or f"Moyenne des années complètes depuis {s['annee_min']}.",
                        "France Travail, séries trimestrielles brutes", tb,
                        {"kind": "saison", "panneaux": panneaux}, essentiel=True))
    b = [x for x in s.get("brut", []) if x.get("embauches") is not None or x.get("demandeurs_a")]
    if b:
        x = [p["periode"] for p in b]
        out.append(bloc("saison", "saison_trimestres", f"Embauches par trimestre : {nom}",
                        "Les embauches de plus d'un mois et d'un mois ou moins ne suivent pas le même calendrier.",
                        "France Travail", pd.DataFrame([{"Trimestre": p["periode"], "Embauches": p["embauches"],
                                                         "Plus d'un mois": p["embauches_long"],
                                                         "Un mois ou moins": p["embauches_court"],
                                                         "Demandeurs A (fin de trimestre)": p["demandeurs_a"],
                                                         "Offres": p["offres"]} for p in b]),
                        {"kind": "lines", "x": x, "series": {
                            "Toutes durées": [p["embauches"] for p in b],
                            "Plus d'un mois": [p["embauches_long"] for p in b],
                            "Un mois ou moins": [p["embauches_court"] for p in b]}, "fmt": "nombre",
                         "bandes_t3": True}))
        if any(p.get("demandeurs_a") for p in b):
            out.append(bloc("saison", "saison_demandeurs", f"Demandeurs d'emploi sans activité (catégorie A) : {nom}",
                            "Comptés le dernier jour du trimestre ; bandes grises : 3e trimestre (juillet à septembre).",
                            "France Travail", None,
                            {"kind": "lines", "x": x, "series": {"Demandeurs A": [p["demandeurs_a"] for p in b]},
                             "fmt": "nombre", "bandes_t3": True}))
    m = (s.get("bmo_metiers") or [])[:15][::-1]
    if m and r.get("bmo"):
        bm = r["bmo"]
        tt = s.get("bmo_totaux") or {}
        ps = lambda k: (tt.get(k) or {}).get("part_saisonniers")  # noqa: E731
        out.append(bloc("saison", "saison_bmo", f"Recrutements saisonniers prévus en {bm['annee']}, bassin {bm['nom_bassin']}",
                        f"{_p(ps('Bassin'), d=0)} des projets du bassin sont saisonniers (France : {_p(ps('France'), d=0)}).",
                        "France Travail, enquête Besoins en main-d'œuvre",
                        pd.DataFrame([{"Métier": x["metier"], "Projets": x["projets"], "Saisonniers": x["saisonniers"]}
                                      for x in m[::-1]]),
                        {"kind": "barh_stack", "labels": [_court(x["metier"], 50) for x in m],
                         "series": {"Projets saisonniers": [x["saisonniers"] for x in m],
                                    "Autres projets": [x["projets"] - x["saisonniers"] for x in m]}, "fmt": "nombre"}))
    return out


# ============================================================================================ BMO et tensions
def b_bmo(r):
    b = r.get("bmo")
    if not b:
        return []
    m = b["metiers"][:15][::-1]
    t = b["totaux"]["Bassin"]
    lect = (f"{_n(t['projets'])} projets de recrutement déclarés pour {b['annee']} dans le bassin {b['nom_bassin']}, "
            f"dont {_p(t['part_difficiles'], d=0)} jugés difficiles et {_p(t['part_saisonniers'], d=0)} saisonniers "
            f"(France : {_p(b['totaux']['France']['part_difficiles'], d=0)} difficiles). Couleur : part des projets "
            "difficiles. Ce sont des intentions d'embauche, pas des embauches réalisées.")
    tb = pd.DataFrame([{"Métier": x["metier"], "Code FAP": x["code_metier"], "Famille": x["famille"],
                        "Projets": x["projets"], "Difficiles": x["difficiles"], "Saisonniers": x["saisonniers"],
                        "Part difficiles": x["part_difficiles"], "Part saisonniers": x["part_saisonniers"]}
                       for x in b["metiers"]])
    t2 = pd.DataFrame([{"Territoire": k, "Projets": v["projets"], "Part difficiles": v["part_difficiles"],
                        "Part saisonniers": v["part_saisonniers"]} for k, v in b["totaux"].items()])
    return [bloc("bmo", "bmo_metiers", f"Recrutements prévus en {b['annee']} : métiers du bassin {b['nom_bassin']}",
                 lect, "France Travail, enquête Besoins en main-d'œuvre", tb,
                 {"kind": "barh_simple", "labels": [_court(x["metier"], 50) for x in m],
                  "values": [x["projets"] for x in m], "intensite": [x["part_difficiles"] or 0 for x in m],
                  "textes": [f"{(x['part_difficiles'] or 0) * 100:.0f} % difficiles, "
                             f"{(x['part_saisonniers'] or 0) * 100:.0f} % saisonniers" for x in m],
                  "fmt": "nombre", "xlabel": "Projets de recrutement"}, table2=t2, essentiel=True)]


def b_tensions(r, ft_tensions):
    t = (ft_tensions or {}).get("tensions") or []
    if not t:
        return []
    tb = pd.DataFrame(t).rename(columns={"metier_bmo": "Métier (BMO)", "projets_bmo": "Projets BMO", "rome": "Code ROME",
                                        "metier_rome": "Métier (ROME)", "annee": "Année"})
    terr = (ft_tensions or {}).get("tensions_territoire")
    num = [c for c in tb.columns if c not in ("Métier (BMO)", "Projets BMO", "Code ROME", "Métier (ROME)", "Année")
           and pd.to_numeric(tb[c], errors="coerce").notna().mean() > .5]
    col = next((c for c in num if "tension" in c.lower()), num[0] if num else None)
    graph = None
    if col:
        d = tb.dropna(subset=[col]).sort_values(col)
        graph = {"kind": "barh_simple", "labels": [_court(f"{a} ({b})", 55) for a, b in zip(d["Métier (ROME)"], d["Code ROME"])],
                 "values": list(pd.to_numeric(d[col], errors="coerce")), "fmt": "nombre1", "xlabel": col}
    return [bloc("tensions", "tensions", "Difficultés de recrutement des métiers qui recrutent le plus",
                 f"Indicateurs France Travail et Dares (indices de 1 à 5 : plus l'indice est élevé, plus la tension est "
                 f"forte), calculés au niveau {'du bassin' if terr and terr[0] == 'BASBMO' else 'du département'}.",
                 "France Travail, API Marché du travail (perspectives employeurs)", tb, graph)]


# ============================================================================================ entreprises
def b_employeurs(r, employeurs):
    if not employeurs:
        return []
    from ..collecte import sirene
    sy = sirene.synthese(employeurs)
    df = pd.DataFrame(employeurs)
    par = df.groupby("grand_secteur").agg(n=("siret", "count"), emin=("eff_min", "sum"), emax=("eff_max", "sum")) \
        .sort_values("n")
    t2 = df.groupby(["secteur"]).agg(**{"Établissements": ("siret", "count"), "Effectif min": ("eff_min", "sum"),
                                         "Effectif max": ("eff_max", "sum")}).sort_values("Établissements",
                                                                                       ascending=False).reset_index()
    t2 = t2.rename(columns={"secteur": "Secteur"})
    lect = (f"{sy['total']} établissements employeurs actifs, dont {sy['geolocalises']} localisés ; effectif connu pour "
            f"{sy['effectif_connu']} d'entre eux, soit entre {_n(sy['eff_min'])} et {_n(sy['eff_max'])} salariés "
            f"(tranches SIRENE). {sy['non_diffusibles']} établissements non diffusibles. Liste filtrable et carte : "
            "onglet Entreprises. Usage interne.")
    return [bloc("employeurs", "employeurs", "Établissements employeurs actifs par grand secteur", lect,
                 "Insee, répertoire SIRENE (API)", t2,
                 {"kind": "barh_simple", "labels": list(par.index), "values": list(par["n"]), "fmt": "nombre",
                  "xlabel": "Établissements employeurs"})]


def b_lbb(r, lbb):
    items = (lbb or {}).get("items") or []
    if not lbb:
        return []
    if not items:
        return [bloc("lbb", "lbb", "Entreprises susceptibles d'embaucher (La Bonne Boite)",
                     "Aucune entreprise renvoyée par l'API pour les métiers demandés dans l'EPCI. Vérifier le fichier "
                     "cache/sonde_labonneboite.json (structure de la réponse).", "France Travail, La Bonne Boite", None)]
    df = pd.DataFrame(items)
    g = df.groupby("metier").agg(n=("siret", "nunique"), fort=("fort_potentiel", "sum")).sort_values("n")
    n_ent = df["siret"].replace("", pd.NA).dropna().nunique() or len(df)
    lect = (f"{n_ent} entreprises de l'EPCI sont repérées par La Bonne Boite comme susceptibles d'embaucher sur au moins "
            f"un des {df['rome'].nunique()} métiers recherchés ; {int(df['fort_potentiel'].sum())} couples "
            "entreprise-métier ont un fort potentiel d'embauche. Prévision de France Travail à partir des embauches "
            "passées (données mises à jour chaque mois) : ce ne sont pas des offres d'emploi. Carte et liste filtrable "
            "par métier : onglet Entreprises.")
    tb = df[["nom", "siret", "metier", "rome", "activite", "effectif", "commune", "potentiel", "fort_potentiel"]] \
        .rename(columns={"nom": "Entreprise", "siret": "SIRET", "metier": "Métier", "rome": "Code ROME",
                         "activite": "Activité", "effectif": "Effectif", "commune": "Commune",
                         "potentiel": "Potentiel d'embauche (0-100)", "fort_potentiel": "Fort potentiel"})
    return [bloc("lbb", "lbb", "Entreprises susceptibles d'embaucher, par métier (La Bonne Boite)", lect,
                 "France Travail, La Bonne Boite (licence ouverte)", tb,
                 {"kind": "barh_groupes", "labels": [_court(i, 46) for i in g.index],
                  "series": {"Entreprises": list(g["n"]), "dont fort potentiel": list(g["fort"])}, "fmt": "nombre"},
                 essentiel=True)]


def b_demographie(r):
    d = r.get("demographie")
    if not d:
        return []
    nom, out = r["ref_nom"], []
    t = d["tableau"]
    lect = " ".join(p for p in r.get("synthese", []) if "entreprises ont été créées" in p or "procédure collective" in p)
    tb = pd.DataFrame([{"Année": x["annee"] + (" (en cours)" if x["partiel"] else ""), "Créations d'entreprises": x["crea"],
                        "dont entrepreneurs individuels": x["part_ei"], "Taux de création": x["taux_crea"],
                        "Taux de création (département)": x["taux_crea_dep"],
                        "Établissements créés (SIRENE)": x["etab_crees"], "Établissements fermés": x["etab_fermes"],
                        "Procédures collectives": x["defaillances"],
                        "Procédures pour 1 000 entreprises": x["def_1000"],
                        "idem (département)": x["def_1000_dep"]} for x in t])
    tc = [x for x in t if x["taux_crea"] is not None and not x["partiel"]]
    if tc:
        out.append(bloc("demographie", "demo_taux", "Taux de création d'entreprises", lect,
                        "Insee, démographie des entreprises (SIDE)", tb,
                        {"kind": "lines", "x": [x["annee"] for x in tc],
                         "series": {nom: [x["taux_crea"] for x in tc],
                                    f"Département ({r.get('dep_nom') or ''})": [x["taux_crea_dep"] for x in tc]},
                         "cible": nom, "fmt": "frac", "ylabel": "Créations / stock au 31/12 précédent"},
                        essentiel=True))
    lig = [x for x in t if x["etab_crees"] is not None or x["defaillances"] is not None]
    if lig:
        out.append(bloc("demographie", "demo_flux", f"Créations, fermetures et défaillances : {nom}",
                        "Une fermeture d'établissement peut être un simple déménagement. Procédures collectives : "
                        "jugements d'ouverture (BODACC), l'année en cours est incomplète.",
                        "Insee (SIRENE) ; BODACC", None if tc else tb,
                        {"kind": "bars_line", "x": [x["annee"] + (" (en cours)" if x["partiel"] else "") for x in lig],
                         "barres": {"Établissements créés": [x["etab_crees"] or 0 for x in lig],
                                    "Établissements fermés": [-(x["etab_fermes"] or 0) for x in lig]},
                         "ligne": {"Procédures collectives (axe droit)": [x["defaillances"] for x in lig]},
                         "fmt": "nombre"}))
    if d.get("defaillances"):
        out.append(bloc("demographie", "defaillances", "Procédures collectives rattachées au territoire", "",
                        "BODACC", pd.DataFrame(d["defaillances"])))
    return out


# ============================================================================================ mobilités
def b_mobilites(r):
    m = r.get("mobilites")
    if not m:
        return []
    out = []
    lect = " ".join(p for p in r.get("synthese", []) if p.startswith("Sur ") and "actifs occupés" in p)
    for cle, cle_c, titre, lib in (("dest_epci", "dest_communes", f"Où travaillent les {_n(m['sortants'])} actifs qui "
                                    "habitent le territoire et travaillent ailleurs ?", "Lieu de travail"),
                                   ("orig_epci", "orig_communes", f"D'où viennent les {_n(m['entrants'])} actifs qui "
                                    "y travaillent sans y habiter ?", "Lieu de résidence")):
        d = m[cle][:12][::-1]
        tb = pd.DataFrame([{lib: x["territoire"], "Actifs": x["actifs"], "Part": x["part"]} for x in m[cle]])
        t2 = pd.DataFrame([{"Commune": x["commune"], "Code": x["code"], "Actifs": x["actifs"], "Part": x["part"],
                            "Ordre de grandeur (< 200)": "oui" if x["indicatif"] else ""} for x in m[cle_c]])
        out.append(bloc("mobilites", "mob_" + cle[:4], titre, lect if cle == "dest_epci" else
                        "Regroupement par EPCI d'origine ; les flux de moins de 200 actifs sont des ordres de grandeur.",
                        f"Insee, recensement {m['annee']}, flux domicile-travail", tb,
                        {"kind": "barh_simple", "labels": [_court(x["territoire"], 40) for x in d],
                         "values": [x["actifs"] for x in d], "textes": [f"{x['part'] * 100:.0f} %" for x in d],
                         "fmt": "nombre", "xlabel": "Actifs occupés"}, table2=t2, essentiel=cle == "dest_epci"))
    out.append(bloc("mobilites", "mob_communes", "Actifs résidents par commune : où travaillent-ils ?", "",
                    "Insee, recensement", pd.DataFrame([{"Commune": x["commune"], "Actifs résidents": x["actifs"],
                                                         "Travaillent dans leur commune": x["meme_commune"],
                                                         "Travaillent hors de l'EPCI": x["hors_epci"],
                                                         "Part hors EPCI": x["part_hors_epci"],
                                                         "Emplois au lieu de travail": x["emplois_lt"]}
                                                        for x in m["communes"]])))
    return out


# ============================================================================================ ANCT
DOUBLONS_ANCT = {"concentr": "ice_compare", "sphere": "spheres_insee", "tx_chom": "ice_compare"}


def b_anct(r, ids_eco):
    lignes = [l for l in (r.get("anct") or []) if not (DOUBLONS_ANCT.get(l["code"]) in ids_eco)]
    if not lignes or not any(l["valeur"] is not None for l in lignes):
        return []
    variantes = {}
    for g in r["groupes"]:
        d = [(l["indicateur"], l["valeur"], l.get(f"med::{g}"), l["sens"]) for l in lignes
             if l["valeur"] is not None and l.get(f"med::{g}")]
        if d:
            d = d[::-1]
            variantes[g] = {"kind": "barh_simple", "labels": [_court(x[0], 55) for x in d],
                            "values": [x[1] / x[2] - 1 for x in d], "ligne_v": 0, "fmt": "frac_s",
                            "textes": [f"{x[1]:.1f} / {x[2]:.1f}".replace(".", ",") for x in d],
                            "couleurs": ["neutre" if x[3] == 0 else ("positif" if ((x[1] / x[2] - 1) >= 0) == (x[3] > 0)
                                                                     else "negatif") for x in d],
                            "xlabel": "Écart à la médiane du groupe"}
    tb = pd.DataFrame([{"Indicateur": l["indicateur"], "Année": l["annee"], "EPCI étudié": l["valeur"],
                        **{f"Médiane {g}": l.get(f"med::{g}") for g in r["groupes"]},
                        **{f"Rang {g}": l.get(f"rang::{g}") for g in r["groupes"]},
                        "Médiane France": l.get("med::France")} for l in lignes])
    retires = [l["indicateur"] for l in (r.get("anct") or []) if DOUBLONS_ANCT.get(l["code"]) in ids_eco]
    lect = ("Vert : écart plutôt favorable ; rouge : plutôt défavorable ; gris : neutre. Valeur de l'EPCI / médiane du "
            "groupe indiquée à droite des barres." + (f" Indicateurs déjà présentés dans le portrait du territoire, "
                                                      f"retirés ici : {', '.join(retires)}." if retires else ""))
    return [bloc("anct", "anct", "Indicateurs de l'Observatoire des territoires : écart à la médiane", lect,
                 "ANCT, Observatoire des territoires (maille EPCI)", tb,
                 {"kind": "variantes", "variantes": variantes} if variantes else None)]

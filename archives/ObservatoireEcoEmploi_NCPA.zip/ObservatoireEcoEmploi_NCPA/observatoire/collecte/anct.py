# -*- coding: utf-8 -*-
"""Indicateurs de l'Observatoire des territoires (ANCT), à la maille EPCI.
Codes relevés par la sonde 3 du 01/10/2026 dans les pages de l'Observatoire. Téléchargement CSV
(colonnes codgeo;libgeo;an;[sexe];valeur), dernière année disponible, tous les EPCI de France."""
import csv
import io

OT_API = ("https://www.observatoire-des-territoires.gouv.fr/outils/cartographie-interactive/api/v1/functions/"
          "GC_API_download.php")

# (code interne, libellé, dataset, indicateur, maille, format d'affichage, sens : +1 si « plus » = favorable)
INDICATEURS = [
    ("tx_chom", "Taux de chômage des 15-64 ans (recensement)", "indic_sex_rp", "tx_chom1564", "epci2025", "pct100", -1),
    ("tx_chom_j", "Taux de chômage des 15-24 ans (recensement)", "indic_sex_rp", "tx_chom1524", "epci_ept2025", "pct100", -1),
    ("tx_emploi", "Taux d'emploi des 15-64 ans", "indic_sex_rp", "tx_emploi1564", "epci2025", "pct100", 1),
    ("tx_emploi_s", "Taux d'emploi des 55-64 ans", "indic_sex_rp", "tx_emploi5564", "epci_ept2025", "pct100", 1),
    ("concentr", "Indice de concentration de l'emploi (emplois pour 100 actifs occupés résidents)",
     "insee_rp_hist_1975", "ind_concentr_emp", "epci_ept2025", "num1", 0),
    ("evol_emp", "Taux d'évolution annuel de l'emploi", "insee_rp_evol_1975", "var_an_emp", "epci2025", "pct100s", 1),
    ("sphere", "Part des emplois de la sphère présentielle", "emp_sphere", "part_sphere", "epci_ept2025", "pct100", 0),
    ("cfm", "Part des cadres des fonctions métropolitaines dans l'emploi", "cfm", "part_cfm", "epci2025", "pct100", 0),
    ("precaire", "Part des salariés de 15-64 ans en emploi précaire", "indic_sex_rp", "p_salprec1564", "epci2025", "pct100", -1),
    ("tps_partiel", "Part des actifs de 15-64 ans à temps partiel", "indic_sex_rp", "p_tpspart1564", "epci_ept2025", "pct100", -1),
    ("navette", "Part des actifs occupés travaillant dans une autre commune", "insee_rp_hist_xxxx",
     "tx_actocc_autre_com", "epci_ept2025", "pct100", 0),
    ("agri", "Part des emplois dans l'agriculture", "insee_rp_hist_xxxx", "part_emplt_agri", "epci_ept2025", "pct100", 0),
    ("btp", "Part des emplois dans la construction", "insee_rp_hist_xxxx", "part_emplt_btp", "epci_ept2025", "pct100", 0),
    ("indus", "Part des emplois dans l'industrie", "insee_rp_hist_xxxx", "part_emplt_indus", "epci2025", "pct100", 0),
    ("tertiaire", "Part des emplois dans le tertiaire", "insee_rp_hist_xxxx", "part_emplt_tertiaire", "epci_ept2025",
     "pct100", 0),
    ("artisans", "Part des artisans, commerçants et chefs d'entreprise (15-64 ans)", "indic_sex_rp", "p_csp_arcomce",
     "epci2025", "pct100", 0),
    ("pauvrete", "Taux de pauvreté (seuil à 60 % du revenu médian)", "filosofi", "tx_pauv_60", "epci_ept2025", "pct100", -1),
]
LIBELLES = {i[0]: i[1] for i in INDICATEURS}
FORMATS = {i[0]: i[5] for i in INDICATEURS}


def _num(v):
    try:
        return float(str(v).replace(",", "."))
    except (TypeError, ValueError):
        return None


def lire_csv(contenu, indic):
    """-> ({code EPCI: (valeur, année, libellé)}, dimensions, modalité retenue). Garde le total (sexe = T) ;
    si une autre dimension existe (ex. sphère présentielle ou productive), garde la modalité « présentielle »
    si elle existe, sinon la première rencontrée."""
    texte = contenu.decode("utf-8-sig", errors="replace")
    lecteur = csv.DictReader(io.StringIO(texte), delimiter=";")
    cols = lecteur.fieldnames or []
    c_val = indic if indic in cols else (cols[-1] if cols else None)
    autres = [c for c in cols if c not in ("codgeo", "libgeo", "an", "sexe", c_val)]
    par_modalite = {}
    for r in lecteur:
        if r.get("sexe") not in (None, "", "T"):
            continue
        cle = tuple(r.get(d) for d in autres)
        code = (r.get("codgeo") or "").strip().strip('"')
        v = _num(r.get(c_val))
        if code and v is not None:
            par_modalite.setdefault(cle, {})[code] = (v, r.get("an"), r.get("libgeo"))
    if not par_modalite:
        return {}, autres, []
    retenue = next((k for k in par_modalite if any("pres" in str(x).lower() for x in k)), next(iter(par_modalite)))
    return par_modalite[retenue], autres, [retenue] if autres else []


def parametres(ds, ind, niv):
    return {"lang": "fr", "type": "stat", "dataset": ds, "indic": ind, "nivgeo": niv, "filter": "last",
            "format": "csv"}


def telecharger(client, log):
    """Indicateurs de l'Observatoire. Si les deux premiers appels échouent, le service est jugé en panne : on
    s'arrête (inutile d'essayer les 15 autres) et on lève une erreur, pour que le cache ne garde pas un résultat
    vide pendant 90 jours (v0.5.1 : HTTP 500 sur tous les indicateurs le 20/10/2026)."""
    resultats, echecs = {}, 0
    for code, lib, ds, ind, niv, _, _ in INDICATEURS:
        try:
            r = client.get(OT_API, parametres(ds, ind, niv), brut=True, timeout=120, essais=1)
            valeurs, dims, mod = lire_csv(r.content, ind)
            if dims:
                log(f"      {lib} : dimension {dims} = {mod}")
            resultats[code] = {k: list(v) for k, v in valeurs.items()}
            echecs = 0
        except Exception as e:
            echecs += 1
            msg = str(e).split("<", 1)[0].strip()
            log(f"      {lib} : indisponible ({msg[:120]})")
            if echecs >= 2 and not resultats:
                raise RuntimeError("service de l'Observatoire des territoires en panne (deux échecs d'affilée), "
                                   "indicateurs ignorés pour ce lancement ; nouvel essai au prochain lancement")
    if not resultats:
        raise RuntimeError("aucun indicateur de l'Observatoire des territoires")
    return resultats


def comparer(donnees, groupes, ref):
    """Valeur de l'EPCI, médiane et rang dans chaque groupe, pour chaque indicateur."""
    from statistics import median
    lignes = []
    for code, lib, *_ , sens in INDICATEURS:
        d = donnees.get(code) or {}
        v = d.get(ref)
        ligne = {"code": code, "indicateur": lib, "valeur": v[0] if v else None, "annee": v[1] if v else None,
                 "format": FORMATS[code], "sens": sens}
        for gn, membres in groupes.items():
            vals = [d[c][0] for c in membres if c in d and c != ref]
            ligne[f"med::{gn}"] = median(vals) if vals else None
            if v:
                tous = [d[c][0] for c in membres if c in d]
                ligne[f"rang::{gn}"] = f"{1 + sum(1 for x in tous if x > v[0])}/{len(tous)}"
        fr = [x[0] for x in d.values()]
        ligne["med::France"] = median(fr) if fr else None
        lignes.append(ligne)
    return lignes

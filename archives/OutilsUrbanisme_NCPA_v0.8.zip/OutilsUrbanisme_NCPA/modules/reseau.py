"""Outils réseau communs à toutes les sources (data.gouv, geo.api, et les suivantes).

- une session requests partagée (connexions réutilisées = plus rapide) ;
- relances progressives sur HTTP 429 / 5xx et coupures réseau ;
- pauses interruptibles : le bouton « Annuler » agit entre deux appels
  (un appel déjà parti va jusqu'à sa réponse ou son délai maximal) ;
- JOURNAL TECHNIQUE : chaque appel (adresse complète, code HTTP, durée,
  taille) est écrit dans journal_technique.log à côté du .exe, et peut être
  relayé dans l'interface (mode « journal détaillé ») ;
- aucune exception technique brute ne remonte : on lève ErreurSource
  avec un message lisible.
"""
import logging
import os
import threading
import time

import requests

from .chemins import dossier_application

DELAI_RELANCES = [3, 10]          # secondes entre deux tentatives (3 essais au total)
TIMEOUT = (10, 45)                # (connexion, lecture) en secondes
ENTETES = {"User-Agent": "OutilsUrbanisme-NCPA/0.6 (collectivite territoriale)",
           "Accept": "application/json, text/csv, */*"}

_session = requests.Session()
_session.headers.update(ENTETES)

# ---------------------------------------------------------------- journal technique
_log = logging.getLogger("urbanisme.reseau")
_log.setLevel(logging.INFO)
_ecouteur = None          # fonction(texte) : relais vers l'interface (mode détaillé)


def activer_journal_fichier():
    """Écrit journal_technique.log à côté du .exe (remis à zéro à chaque lancement)."""
    if _log.handlers:
        return
    try:
        chemin = os.path.join(dossier_application(), "journal_technique.log")
        h = logging.FileHandler(chemin, mode="w", encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s  %(message)s", "%H:%M:%S"))
        _log.addHandler(h)
    except OSError:
        pass


def definir_ecouteur(fonction):
    """fonction(texte) ou None. Appelée depuis le thread : doit être thread-safe (queue)."""
    global _ecouteur
    _ecouteur = fonction


def _tracer(texte):
    _log.info(texte)
    if _ecouteur:
        try:
            _ecouteur(texte)
        except Exception:
            pass


# ---------------------------------------------------------------- erreurs
class ErreurSource(Exception):
    """Erreur lisible (message destiné au journal de l'interface)."""

    def __init__(self, message, code_http=None, serveur_hs=False):
        super().__init__(message)
        self.code_http = code_http
        self.serveur_hs = serveur_hs      # True = le serveur ne répond pas / est saturé


class Annulation(Exception):
    """Levée quand l'utilisateur clique sur « Annuler »."""


def pause(secondes, stop_event=None):
    """time.sleep interruptible par l'événement d'annulation."""
    if stop_event is None:
        time.sleep(secondes)
        return
    if stop_event.wait(secondes):
        raise Annulation()


def verifier_annulation(stop_event):
    if stop_event is not None and stop_event.is_set():
        raise Annulation()


def _adresse(url, params):
    """URL complète telle qu'envoyée (pour la copier dans un navigateur)."""
    try:
        return requests.Request("GET", url, params=params).prepare().url
    except Exception:
        return url


def get(url, params=None, stop_event=None, attendu="json", accepter_404=False, relances=True):
    """GET avec relances et traçage. attendu = "json" ou "texte".

    Retourne None si accepter_404 et que la ressource n'existe pas.
    """
    adresse = _adresse(url, params)
    derniere, serveur_hs, code = None, False, None
    delais = DELAI_RELANCES if relances else []
    for tentative in range(len(delais) + 1):
        verifier_annulation(stop_event)
        debut = time.time()
        try:
            rep = _session.get(url, params=params, timeout=TIMEOUT)
        except requests.Timeout:
            duree = time.time() - debut
            derniere, serveur_hs = f"pas de réponse du serveur après {duree:.0f} s (délai dépassé)", True
            _tracer(f"GET {adresse}  →  DÉLAI DÉPASSÉ ({duree:.0f} s), essai {tentative + 1}")
        except requests.ConnectionError as exc:
            derniere, serveur_hs = _message_connexion(exc), True
            _tracer(f"GET {adresse}  →  CONNEXION IMPOSSIBLE ({exc.__class__.__name__}), essai {tentative + 1}")
        except requests.RequestException as exc:
            derniere = f"erreur réseau ({exc.__class__.__name__})"
            _tracer(f"GET {adresse}  →  {derniere}")
        else:
            duree = time.time() - debut
            code = rep.status_code
            _tracer(f"GET {adresse}  →  HTTP {code} en {duree:.1f} s, {len(rep.content) / 1024:.0f} Ko")
            if code == 200:
                if attendu == "json":
                    try:
                        return rep.json()
                    except ValueError:
                        debut_rep = rep.text[:150].replace("\n", " ")
                        raise ErreurSource(f"réponse qui n'est pas du JSON (début : « {debut_rep} »)", code)
                return rep.content.decode("utf-8-sig", errors="replace")
            if code == 404 and accepter_404:
                return None
            if code in (429, 500, 502, 503, 504):
                derniere = {429: "trop de requêtes, le serveur demande de ralentir (HTTP 429)",
                            503: "service momentanément indisponible (HTTP 503)",
                            502: "serveur intermédiaire en erreur (HTTP 502)",
                            504: "le serveur a mis trop de temps à répondre (HTTP 504)"}.get(
                    code, f"erreur interne du serveur (HTTP {code})")
                serveur_hs = True
            elif code in (403, 407):
                detail = rep.text[:150].replace("\n", " ")
                raise ErreurSource(
                    f"accès refusé (HTTP {code}) : filtrage par le proxy ou le pare-feu de la collectivité, "
                    f"ou blocage côté serveur · réponse : « {detail} » · adresse : {adresse}", code, True)
            else:
                detail = rep.text[:200].replace("\n", " ")
                raise ErreurSource(f"HTTP {code} : {detail} · adresse : {adresse}", code)
        if tentative < len(delais):
            pause(delais[tentative], stop_event)
    raise ErreurSource(f"{derniere} · adresse : {adresse}", code, serveur_hs)


def _message_connexion(exc):
    texte = str(exc).lower()
    if "proxy" in texte:
        return "le proxy de la collectivité bloque la connexion"
    if "name resolution" in texte or "getaddrinfo" in texte or "nodename" in texte:
        return "adresse du serveur introuvable (DNS) : pas d'accès internet ou filtrage réseau"
    if "certificate" in texte or "ssl" in texte:
        return "problème de certificat de sécurité (filtrage HTTPS de la collectivité ?)"
    return "connexion impossible au serveur (coupure réseau ou pare-feu)"


# ------------------------------------------------------------------ progression
# Chaque fil d'exécution peut déclarer une fonction de suivi (valeur 0-1, texte).
# Les modules découpent leur travail en étapes imbriquées ; sans fonction de
# suivi déclarée, ces appels ne font rien (aucun effet sur l'application .exe
# si elle ne s'en sert pas).
_suivi = threading.local()


def definir_suivi(fonction):
    """fonction(valeur entre 0 et 1, texte) pour le fil courant ; None pour arrêter le suivi."""
    _suivi.f = fonction
    _suivi.pile = [(0.0, 1.0, "")]


def avancement(fraction, texte=None):
    f = getattr(_suivi, "f", None)
    if not f:
        return
    a, b, libelle = _suivi.pile[-1]
    try:
        f(a + (b - a) * min(1.0, max(0.0, fraction)), texte or libelle)
    except Exception:
        pass


class etape:
    """with etape(0.2, 0.6, "Téléchargement") : sous-partie de l'étape en cours."""

    def __init__(self, debut, fin, libelle=None):
        self.debut, self.fin, self.libelle = debut, fin, libelle

    def __enter__(self):
        if getattr(_suivi, "f", None):
            a, b, lib = _suivi.pile[-1]
            _suivi.pile.append((a + (b - a) * self.debut, a + (b - a) * self.fin, self.libelle or lib))
            avancement(0)
        return self

    def __exit__(self, *exc):
        if getattr(_suivi, "f", None):
            if not exc[0]:
                avancement(1)
            if len(_suivi.pile) > 1:
                _suivi.pile.pop()
        return False


def nouvel_evenement_stop():
    return threading.Event()


def telecharger(url, chemin, stop_event=None, progression=None):
    """Télécharge un fichier en flux vers `chemin` (écriture dans un .part puis renommage).

    progression(octets_recus) est appelée régulièrement. Retourne False si 404.
    """
    import os
    verifier_annulation(stop_event)
    debut = time.time()
    try:
        rep = _session.get(url, stream=True, timeout=TIMEOUT)
    except requests.Timeout:
        _tracer(f"GET {url}  →  DÉLAI DÉPASSÉ")
        raise ErreurSource(f"pas de réponse du serveur (délai dépassé) · adresse : {url}", None, True)
    except requests.ConnectionError as exc:
        _tracer(f"GET {url}  →  CONNEXION IMPOSSIBLE ({exc.__class__.__name__})")
        raise ErreurSource(f"{_message_connexion(exc)} · adresse : {url}", None, True)
    if rep.status_code == 404:
        _tracer(f"GET {url}  →  HTTP 404 (fichier absent)")
        return False
    if rep.status_code != 200:
        _tracer(f"GET {url}  →  HTTP {rep.status_code}")
        raise ErreurSource(f"HTTP {rep.status_code} · adresse : {url}", rep.status_code,
                           rep.status_code in (403, 407, 429, 500, 502, 503, 504))
    recu, temporaire = 0, chemin + ".part"
    total = int(rep.headers.get("Content-Length") or 0)
    try:
        with open(temporaire, "wb") as f:
            for bloc in rep.iter_content(chunk_size=256 * 1024):
                if stop_event is not None and stop_event.is_set():
                    raise Annulation()
                f.write(bloc)
                recu += len(bloc)
                if progression:
                    progression(recu)
                if total:
                    avancement(recu / total, None)
        os.replace(temporaire, chemin)
    except requests.RequestException as exc:
        raise ErreurSource(f"téléchargement interrompu ({exc.__class__.__name__}) · adresse : {url}", None, True)
    finally:
        if os.path.exists(temporaire):
            try:
                os.remove(temporaire)
            except OSError:
                pass
    _tracer(f"GET {url}  →  HTTP 200 en {time.time() - debut:.1f} s, {recu / 1048576:.1f} Mo")
    return True

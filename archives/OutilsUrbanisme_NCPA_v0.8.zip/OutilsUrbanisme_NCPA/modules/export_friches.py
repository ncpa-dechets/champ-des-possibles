"""Exports Excel et GeoJSON du thème « Friches »."""
import json

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from . import friches as F

NAVY = "1B3A5C"
ENTETE = Font(bold=True, color="FFFFFF")
FOND_ENTETE = PatternFill("solid", fgColor=NAVY)
FOND_TOTAL = PatternFill("solid", fgColor="E8EEF5")


def _entete(ws, valeurs, largeurs):
    for j, v in enumerate(valeurs, start=1):
        c = ws.cell(row=1, column=j, value=v)
        c.font, c.fill = ENTETE, FOND_ENTETE
        c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(j)].width = largeurs[j - 1]
    ws.row_dimensions[1].height = 45
    ws.freeze_panes = "B2"


def colonnes_synthese():
    cols = [("nom", "Territoire", 32, None), ("niveau", "Niveau", 12, None),
            ("n", "Sites recensés", 10, "0"), ("surface", "Surface (ha)", 11, "#,##0.0")]
    for st, lib, _c in F.STATUTS:
        cols.append((f"n_{st}", f"{lib} (nombre)", 11, "0"))
        cols.append((f"s_{st}", f"{lib} (ha)", 11, "#,##0.0"))
    return cols


def exporter_excel(chemin, resultat, communes, params):
    noms = {c["code"]: c["nom"] for c in communes}
    wb = Workbook()
    ws = wb.active
    ws.title = "Synthèse"
    cols = colonnes_synthese()
    _entete(ws, [c[1] for c in cols], [c[2] for c in cols])
    for i, l in enumerate(resultat["lignes"], start=2):
        for j, (cle, _lib, _w, fmt) in enumerate(cols, start=1):
            v = l.get(cle)
            cell = ws.cell(row=i, column=j, value=round(v, 3) if isinstance(v, float) else v)
            if fmt:
                cell.number_format = fmt
            if l["niveau"] != "Commune":
                cell.fill, cell.font = FOND_TOTAL, Font(bold=True)

    ws = wb.create_sheet("Liste des sites")
    lisibles = [c for c in F.COLONNES if c[0] in resultat["colonnes"]]
    autres = [h for h in resultat["colonnes"] if h not in {c for c, _l in F.COLONNES} and not h.startswith("geom")]
    entetes = ["Commune (NCPA)", "Statut simplifié", "Surface (ha)", "Origine de la surface", "Longitude", "Latitude"] \
        + [l for _c, l in lisibles] + [f"[source] {h}" for h in autres]
    _entete(ws, entetes, [22, 16, 10, 12, 11, 11] + [18] * (len(lisibles) + len(autres)))
    for i, s in enumerate(sorted(resultat["sites"], key=lambda s: (s["commune"], s["nom"])), start=2):
        c = s["centre"] or [None, None]
        valeurs = [noms.get(s["commune"], s["commune"]), F.LIB_STATUT.get(s["statut"], "Autre"),
                   round(s["surface_m2"] / 10000, 3) if s["surface_m2"] else None, s["origine_surface"], c[0], c[1]] \
            + [s["attr"].get(k) for k, _l in lisibles] + [s["attr"].get(h) for h in autres]
        for j, v in enumerate(valeurs, start=1):
            ws.cell(row=i, column=j, value=v)
    ws.auto_filter.ref = f"A1:{get_column_letter(len(entetes))}{len(resultat['sites']) + 1}"

    ws = wb.create_sheet("Lisez-moi")
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 110
    meta = resultat["meta"]
    lignes = [
        ("Source", "Cerema, inventaire national des friches Cartofriches (jeu « Sites référencés dans "
                   "Cartofriches », data.gouv.fr) · Licence Ouverte 2.0"),
        ("Version", f"{meta.get('maj', '?')} · {meta.get('url', '')} (récupéré le {meta.get('date', '?')})"),
        ("Communes", params.get("communes", "")),
        ("Extraction", params.get("date", "")),
        ("", ""),
        ("Exhaustivité", "L'inventaire n'est pas exhaustif : il rassemble des sources nationales et les "
                         "observatoires locaux transmis au Cerema. Une commune sans site recensé n'est pas "
                         "forcément une commune sans friche. Les comparaisons avec le Calvados et la Normandie "
                         "reflètent aussi la couverture des observatoires."),
        ("Statuts", "Sans projet, avec projet, potentielle (à confirmer), reconvertie ; « autre ou inconnu » "
                    "regroupe les autres valeurs."),
        ("Surface", "Surface de l'unité foncière déclarée dans l'inventaire ; à défaut, surface calculée à "
                    "partir du contour du site (colonne « Origine de la surface »)."),
        ("Lien avec le ZAN", "Une friche reconvertie permet de construire sans consommer d'espaces naturels, "
                             "agricoles ou forestiers : les friches sans projet sont un gisement à examiner."),
    ]
    for i, (a, b) in enumerate(lignes, start=1):
        ws.cell(row=i, column=1, value=a).font = Font(bold=True, color=NAVY)
        ws.cell(row=i, column=2, value=b).alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(chemin)


def entites(resultat, communes, contours_seuls=False):
    """Features GeoJSON : contour du site s'il existe, sinon point."""
    noms = {c["code"]: c["nom"] for c in communes}
    feats = []
    for s in resultat["sites"]:
        if not s["geom"]:
            continue
        props = {k: s["attr"].get(k) for k, _l in F.COLONNES if k in s["attr"]}
        props.update({"commune_ncpa": noms.get(s["commune"], s["commune"]),
                      "statut_simplifie": F.LIB_STATUT.get(s["statut"], "Autre"), "statut_code": s["statut"],
                      "surface_ha": round(s["surface_m2"] / 10000, 3) if s["surface_m2"] else None,
                      "origine_surface": s["origine_surface"], "site_nom": s["nom"] or None})
        feats.append({"type": "Feature", "properties": props, "geometry": s["geom"]})
    return feats


def exporter_geojson(chemin, resultat, communes):
    feats = entites(resultat, communes)
    fc = {"type": "FeatureCollection", "name": "friches_ncpa",
          "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
          "metadata": {"source": "Cerema, Cartofriches (data.gouv.fr)", "version": resultat["meta"].get("maj")},
          "features": feats}
    with open(chemin, "w", encoding="utf-8") as f:
        json.dump(fc, f, ensure_ascii=False)
    return len(feats), len(resultat["sites"]) - len(feats)

"""Carte HTML autonome des friches (Leaflet), charte NCPA.
Contour du site quand il existe (visible en zoomant) et repère au centre
(visible à toutes les échelles) ; couleurs par statut ; filtres par statut
et par type ; tableau lié à la carte."""
import json

from . import friches as F
from . import geometrie as G
from .export_friches import entites
from .export_geo import _lire
from .fonds_carte import FONDS_CSS, FONDS_JS


def exporter_carte(chemin, resultat, communes, contours, params):
    feats = entites(resultat, communes)
    if not feats:
        raise ValueError("aucune friche localisée sur les communes choisies")
    for f in feats:
        f["properties"]["_centre"] = G.centre(f["geometry"])
    codes = {s["commune"] for s in resultat["sites"]} | set(params.get("codes", []))
    limites = {"type": "FeatureCollection",
               "features": [f for f in (contours or {}).get("features", [])
                            if str(f.get("properties", {}).get("code")) in codes]}
    donnees = {"sites": {"type": "FeatureCollection", "features": feats}, "limites": limites,
               "statuts": [(s, l, c) for s, l, c in F.STATUTS],
               "version": resultat["meta"].get("maj"), "sans_geo": len(resultat["sites"]) - len(feats)}
    html = (GABARIT
            .replace("/*LEAFLET_CSS*/", _lire("donnees/leaflet.css"))
            .replace("/*FONDS_CSS*/", FONDS_CSS)
            .replace("/*LEAFLET_JS*/", _lire("donnees/leaflet.js"))
            .replace("/*FONDS_JS*/", FONDS_JS)
            .replace("__TITRE__", params.get("titre", "NCPA"))
            .replace("__DATE__", params.get("date", ""))
            .replace("__DONNEES__", json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")))
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(html)
    return len(feats)


GABARIT = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Friches · __TITRE__</title>
<style>/*LEAFLET_CSS*/</style>
<style>/*FONDS_CSS*/</style>
<style>
:root{--rouge:#B91E27;--vert:#B1B993;--encre:#1F2A2E;--doux:#5E6A6E;--brume:#F3F4EF;--trait:#DCDDD3;
      font-family:Calibri,"Segoe UI",system-ui,sans-serif;color:var(--encre)}
*{box-sizing:border-box}
html,body{margin:0;height:100%}
body{display:flex;flex-direction:column;height:100vh;background:#fff}
header{border-left:6px solid var(--rouge);border-bottom:1px solid var(--trait);padding:10px 18px 10px 16px}
.eyebrow{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--rouge);font-weight:700}
h1{font-size:21px;margin:2px 0 0;font-weight:700}
.sous{font-size:13px;color:var(--doux)}
#corps{flex:1 1 auto;display:flex;min-height:0}
#panneau{width:300px;flex:0 0 300px;border-right:1px solid var(--trait);padding:14px;overflow-y:auto;background:var(--brume)}
#droite{flex:1 1 auto;display:flex;flex-direction:column;min-width:0}
#map{position:relative;flex:1 1 auto;height:0}
label.titre{display:block;font-weight:700;font-size:13px;margin:12px 0 4px}
select,input[type=search]{padding:6px;border:1px solid var(--trait);border-radius:4px;font:inherit;background:#fff}
.statuts label{display:flex;align-items:center;gap:8px;margin:4px 0;font-size:14px}
.pastille{width:14px;height:14px;border-radius:3px;display:inline-block;border:1px solid #fff;box-shadow:0 0 0 1px #888}
.fonds label{margin-right:12px;font-size:14px}
.stats{margin-top:14px;padding:10px;background:#fff;border:1px solid var(--trait);border-radius:4px;font-size:13px;line-height:1.55}
.stats b{font-size:15px}
.note{font-size:12px;color:var(--doux);margin-top:12px;line-height:1.4}
button{font:inherit;padding:6px 10px;border:1px solid var(--rouge);background:#fff;color:var(--rouge);border-radius:4px;cursor:pointer;margin-top:12px}
button:hover,button:focus-visible{background:var(--rouge);color:#fff;outline:none}
#zoneTable{display:none;flex:0 0 38%;overflow:auto;border-top:2px solid var(--vert)}
table{border-collapse:collapse;width:100%;font-size:13px}
th{position:sticky;top:0;background:var(--encre);color:#fff;text-align:left;padding:6px 8px;cursor:pointer;white-space:nowrap}
td{padding:4px 8px;border-bottom:1px solid var(--trait)}
td.n{text-align:right}
tr.actif td{background:#F6E3E4}
tbody tr:hover td{background:#EEF0E6;cursor:pointer}
.leaflet-popup-content{font-family:Calibri,"Segoe UI",sans-serif;font-size:13px;min-width:250px}
.leaflet-popup-content h3{margin:0 0 6px;font-size:15px}
.leaflet-popup-content table td{border:none;padding:1px 4px;vertical-align:top}
@media (max-width:840px){#corps{flex-direction:column}#panneau{width:auto;flex:0 0 auto;border-right:none;border-bottom:1px solid var(--trait)}#map{min-height:60vh}}
</style>
</head>
<body>
<header>
  <div class="eyebrow">NCPA · Observatoire foncier</div>
  <h1>Friches recensées</h1>
  <div class="sous" id="sousTitre"></div>
</header>
<div id="corps">
  <aside id="panneau">
    <label class="titre">Statut (légende)</label>
    <div class="statuts" id="statuts"></div>
    <label class="titre" for="type">Type de friche</label>
    <select id="type" style="width:100%"><option value="">Tous les types</option></select>
    <div class="stats" id="stats"></div>
    <button id="btnTable" type="button" aria-expanded="false">Afficher le tableau</button>
    <p class="note" id="noteGeo"></p>
    <p class="note">Inventaire non exhaustif : il dépend des observatoires locaux transmis au Cerema. Une commune sans site recensé n'est pas forcément une commune sans friche. Le contour du site apparaît en zoomant.</p>
    <p class="note">Source : Cerema, Cartofriches (version du <span id="version"></span>) · Carte générée le __DATE__.</p>
  </aside>
  <div id="droite">
    <div id="map"></div>
    <div id="zoneTable">
      <input type="search" id="filtre" placeholder="Filtrer par commune, nom ou adresse..." style="margin:6px;width:calc(100% - 12px)">
      <table id="table"><thead></thead><tbody></tbody></table>
    </div>
  </div>
</div>
<script>/*LEAFLET_JS*/</script>
<script>/*FONDS_JS*/</script>
<script>
const D = __DONNEES__;
const COUL = Object.fromEntries(D.statuts.map(([k,l,c]) => [k,c]));
const fmt = (v, d=1) => v==null || v==="" ? "" : Number(v).toLocaleString("fr-FR",{maximumFractionDigits:d, minimumFractionDigits:d});
const F = D.sites.features;
document.getElementById("version").textContent = D.version || "?";
document.getElementById("sousTitre").textContent = `${F.length} site(s) localisé(s)`;
document.getElementById("noteGeo").textContent = D.sans_geo ? `${D.sans_geo} site(s) sans localisation ne figurent pas sur la carte (ils sont dans l'export Excel).` : "";

const map = L.map("map", {zoomSnap:0.25});
const fonds = installerFonds(map, estPhoto => surFond(estPhoto));
function surFond(estPhoto) { limites.setStyle(() => styleLimite(estPhoto)); }
const limites = L.geoJSON(D.limites, {style:() => styleLimite(fonds.photo()), interactive:false}).addTo(map);

// filtres
const stEl = document.getElementById("statuts");
D.statuts.forEach(([k,l,c]) => {
  const n = F.filter(f => f.properties.statut_code === k).length;
  stEl.insertAdjacentHTML("beforeend", `<label><input type="checkbox" value="${k}" checked><span class="pastille" style="background:${c}"></span>${l} (${n})</label>`);
});
const typeEl = document.getElementById("type");
[...new Set(F.map(f => f.properties.site_type).filter(Boolean))].sort().forEach(t => typeEl.add(new Option(t, t)));
function garde() {
  const st = [...stEl.querySelectorAll("input:checked")].map(i => i.value), ty = typeEl.value;
  const t = document.getElementById("filtre").value.toLowerCase();
  return f => { const p = f.properties;
    return st.includes(p.statut_code) && (!ty || p.site_type === ty) &&
      (!t || `${p.commune_ncpa} ${p.site_nom||""} ${p.site_adresse||""}`.toLowerCase().includes(t)); };
}

function popup(p) {
  const l = (t,v) => v==null || v==="" ? "" : `<tr><td>${t}</td><td><b>${v}</b></td></tr>`;
  return `<h3 style="color:${COUL[p.statut_code]}">${p.site_nom || "Site sans nom"}</h3><table>
    ${l("Commune", p.commune_ncpa)}${l("Adresse", p.site_adresse)}${l("Statut", p.statut_simplifie)}
    ${l("Type", p.site_type)}${l("Surface", p.surface_ha!=null ? fmt(p.surface_ha,2)+" ha" + (p.origine_surface==="calculée"?" (calculée)":"") : "")}
    ${l("Occupation", p.site_occupation)}${l("Ancienne activité", p.activite_libelle)}
    ${l("Pollution des sols", p.sol_pollution_existe)}${l("Propriétaire", p.proprio_type)}
    ${l("Zone d'urbanisme", [p.urba_zone_type, p.urba_zone_lib].filter(Boolean).join(" · "))}
    ${l("Reconversion", [p.site_reconv_type, p.site_reconv_annee].filter(Boolean).join(" · "))}
    ${l("Source", p.source_nom)}${l("Actualisé le", p.site_actu_date)}
    ${p.site_url ? `<tr><td colspan="2"><a href="${p.site_url}" target="_blank" rel="noopener">Fiche du site</a></td></tr>` : ""}</table>`;
}
let couches = {}, actif = null;
const groupe = L.layerGroup().addTo(map);
function dessiner() {
  groupe.clearLayers(); couches = {};
  const g = garde();
  F.forEach((f, i) => {
    if (!g(f)) return;
    const p = f.properties, c = COUL[p.statut_code], [x, y] = p._centre;
    const repere = L.circleMarker([y, x], {radius:7, color:"#fff", weight:1.5, fillColor:c, fillOpacity:.95})
      .bindPopup(() => popup(p)).bindTooltip(p.site_nom || p.commune_ncpa)
      .on("click", () => { actif = i; tableau(); });
    groupe.addLayer(repere);
    if (f.geometry.type !== "Point") {
      groupe.addLayer(L.geoJSON(f, {style:{color:c, weight:2, fillColor:c, fillOpacity:.25}})
        .bindPopup(() => popup(p)).on("click", () => { actif = i; tableau(); }));
    }
    couches[i] = repere;
  });
  stats(); tableau();
}
function stats() {
  const v = F.filter(garde()).map(f => f.properties);
  const s = v.reduce((a,p) => a + (+p.surface_ha || 0), 0);
  const sp = v.filter(p => p.statut_code === "friche sans projet");
  document.getElementById("stats").innerHTML =
    `<div><b>${v.length}</b> site(s) affiché(s)</div><div><b>${fmt(s)}</b> ha au total</div>
     <div>dont sans projet : <b>${sp.length}</b> site(s), <b>${fmt(sp.reduce((a,p) => a + (+p.surface_ha || 0), 0))}</b> ha</div>`;
}
const COLS = [["commune_ncpa","Commune"],["site_nom","Nom"],["statut_simplifie","Statut"],["site_type","Type"],["surface_ha","Surface (ha)"],["site_occupation","Occupation"]];
let tri = ["surface_ha", -1];
function tableau() {
  const th = document.querySelector("#table thead"), tb = document.querySelector("#table tbody");
  th.innerHTML = "<tr>" + COLS.map(([k,l]) => `<th data-k="${k}" scope="col">${l}${tri[0]===k?(tri[1]>0?" ▲":" ▼"):""}</th>`).join("") + "</tr>";
  const lignes = F.map((f,i) => [f,i]).filter(([f,i]) => couches[i] !== undefined).sort(([a],[b]) => {
    const x = a.properties[tri[0]], y = b.properties[tri[0]];
    if (typeof x === "number" || typeof y === "number") return ((x||0)-(y||0))*tri[1];
    return String(x||"").localeCompare(String(y||""))*tri[1]; });
  tb.innerHTML = lignes.map(([f,i]) => { const p = f.properties;
    return `<tr data-i="${i}" class="${i===actif?"actif":""}"><td>${p.commune_ncpa}</td><td>${p.site_nom||""}</td><td>${p.statut_simplifie}</td><td>${p.site_type||""}</td><td class="n">${fmt(p.surface_ha,2)}</td><td>${p.site_occupation||""}</td></tr>`; }).join("");
  th.querySelectorAll("th").forEach(h => h.onclick = () => { tri = [h.dataset.k, tri[0]===h.dataset.k ? -tri[1] : 1]; tableau(); });
  tb.querySelectorAll("tr").forEach(r => r.onclick = () => {
    const i = +r.dataset.i, m = couches[i]; actif = i;
    if (m) { map.setView(m.getLatLng(), Math.max(map.getZoom(), 16)); m.openPopup(); }
    tableau();
  });
}
[stEl, typeEl].forEach(el => el.addEventListener("change", dessiner));
document.getElementById("filtre").addEventListener("input", dessiner);
document.getElementById("btnTable").onclick = e => {
  const z = document.getElementById("zoneTable"), ouvert = z.style.display === "block";
  z.style.display = ouvert ? "none" : "block";
  e.target.textContent = ouvert ? "Afficher le tableau" : "Masquer le tableau";
  e.target.setAttribute("aria-expanded", String(!ouvert));
  setTimeout(() => map.invalidateSize(), 50);
};
dessiner();
const b = D.limites.features.length ? limites.getBounds() : L.latLngBounds(F.map(f => [f.properties._centre[1], f.properties._centre[0]]));
map.fitBounds(b, {padding:[12,12], maxZoom:15});
setTimeout(() => map.invalidateSize(), 50);
</script>
</body>
</html>
"""

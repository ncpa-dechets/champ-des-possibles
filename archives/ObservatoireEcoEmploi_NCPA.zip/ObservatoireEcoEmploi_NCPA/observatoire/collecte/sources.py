# -*- coding: utf-8 -*-
"""Accès aux sources de données. Ce module télécharge et met en forme, il ne calcule rien.

Sources (structures vérifiées par les sondes du 30/09/2026) :
  - Urssaf, communes x APE : emplois et établissements au 31/12 depuis 2006 (format large) ;
  - Urssaf, EPCI : effectif moyen et masse salariale depuis 1998 (format long) ;
  - OFGL : population des EPCI ;
  - geo.api.gouv.fr : contours des communes de l'EPCI ;
  - Insee Melodi DS_TOUR_CAP : capacités d'hébergement touristique (fichier national) ;
  - data.gouv.fr : liste des communes soumises à la loi Littoral.
v0.5 (sondes 5 et 5b du 20/10/2026) :
  - Insee Melodi, API par territoire : logements (résidences secondaires), Flores, créations et stocks d'entreprises ;
  - Insee, base flux de mobilité domicile-travail 2022 ;
  - SIRENE : créations et fermetures d'établissements par année ; BODACC : procédures collectives.
"""
import csv
import io
import re
import unicodedata
import zipfile

URSSAF = "https://open.urssaf.fr/api/explore/v2.1/catalog/datasets"
DS_COMMUNES = "etablissements-et-effectifs-salaries-au-niveau-commune-x-ape-last"
DS_EPCI_MS = "nombre-etab-effectifs-salaries-et-masse-salariale-secteur-prive-epci"
OFGL = "https://data.ofgl.fr/api/explore/v2.1/catalog/datasets"
DS_OFGL_GFP = "ofgl-base-gfp-consolidee"
GEO = "https://geo.api.gouv.fr"
MELODI = "https://api.insee.fr/melodi"
URL_TOURISME = "https://api.insee.fr/melodi/file/DS_TOUR_CAP/DS_TOUR_CAP_2026_CSV_FR"
DATAGOUV = "https://www.data.gouv.fr/api/1"
JEUX_LITTORAL = ["communes-de-la-loi-littoral-30383009",
                 "communes-de-la-loi-littoral-au-code-officiel-geographique-cog-2020-2022"]
URL_LITTORAL_SECOURS = ("https://static.data.gouv.fr/resources/communes-de-la-loi-littoral-au-code-officiel-"
                        "geographique-cog-2020/20210118-071041/dgaln-bcsi-opendata-loi-littoral-1986-cog-2020.xlsx")

AGE_CACHE = {"urssaf": 30, "masse": 60, "ofgl": 90, "geo": 180, "tourisme": 180, "littoral": 365,
             "sirene": 30, "anct": 90, "bmo": 180, "ft": 30, "logement": 365, "flores": 180, "side": 90,
             "mobilites": 365, "bodacc": 30}

# ---------------------------------------------------------------------------
# Reconnaissance des champs du jeu communes x APE
# ---------------------------------------------------------------------------
CANDIDATS = {
    "code_commune": (["code_commune"], ["code", "commune"]),
    "commune": (["commune", "intitule_commune", "libelle_commune", "nom_commune"], None),
    "code_epci": (["code_epci"], ["code", "epci"]),
    "epci": (["epci", "intitule_epci", "libelle_epci"], None),
    "code_dep": (["code_departement"], ["code", "departement"]),
    "dep": (["departement", "intitule_departement", "libelle_departement"], None),
    "code_reg": (["code_region"], ["code", "region"]),
    "reg": (["region", "intitule_region", "libelle_region"], None),
}
NIV_CANDIDATS = {
    "Grand secteur": (["grand_secteur_d_activite", "grand_secteur"], ["grand", "secteur"]),
    "NA17": (["secteur_na17", "secteur_na17j"], ["na17"]),
    "NA38": (["secteur_na38", "secteur_na38i"], ["na38"]),
    "NA88": (["secteur_na88", "secteur_na88i"], ["na88"]),
    "APE": (["ape", "libelle_ape"], ["ape"]),
}
NIVEAUX_LIB = {
    "Grand secteur": "Grands secteurs (industrie, construction, commerce, services)",
    "NA17": "17 secteurs (NA17)",
    "NA38": "38 secteurs (NA38)",
    "NA88": "88 secteurs (NA88)",
}
LARGEURS = {"code_commune": 5, "code_dep": 2, "code_reg": 2, "code_epci": 9}


def normaliser(s):
    return unicodedata.normalize("NFD", str(s or "")).encode("ascii", "ignore").decode().lower()


def detecter_schema(fields):
    noms = [f["name"] for f in fields]
    labels = {f["name"]: normaliser(f.get("label", "")) for f in fields}
    re_annee = re.compile(r"(\d{4})$")
    non_annuels = [n for n in noms if not re_annee.search(n)]

    def cherche(exacts, contient):
        for e in exacts:
            if e in noms:
                return e
        for n in non_annuels if contient else []:
            if all(k in normaliser(n) + " " + labels[n] for k in contient):
                return n
        return None

    sc = {"types": {f["name"]: f.get("type", "text") for f in fields}}
    for role, (ex, ct) in CANDIDATS.items():
        sc[role] = cherche(ex, ct)
    sc["niveaux"] = {}
    for niv, (ex, ct) in NIV_CANDIDATS.items():
        f = cherche(ex, ct)
        if f and f not in sc["niveaux"].values():
            sc["niveaux"][niv] = f
    eff, etab = {}, {}
    for n in noms:
        m = re_annee.search(n)
        if m:
            h = normaliser(n) + " " + labels[n]
            if "effectif" in h:
                eff[int(m.group(1))] = n
            elif "etablissement" in h:
                etab[int(m.group(1))] = n
    sc["eff"], sc["etab"], sc["annees"] = eff, etab, sorted(eff)
    manquants = [r for r in ("code_commune", "code_epci") if not sc.get(r)]
    if manquants or not eff:
        raise RuntimeError("structure du jeu Urssaf non reconnue (manque : "
                           + ", ".join(manquants + ([] if eff else ["effectifs par année"])) + ")")
    return sc


def decrire_schema(sc):
    t = [f"   {r} : {sc.get(r) or '(absent)'}" for r in CANDIDATS]
    t += [f"   {n} : {f}" for n, f in sc["niveaux"].items()]
    t.append(f"   années : {sc['annees'][0]} à {sc['annees'][-1]}")
    return "\n".join(t)


def _code(v, largeur=None):
    if v is None or v == "":
        return None
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    s = str(v).strip()
    if largeur and s.isdigit() and len(s) < largeur:
        s = s.zfill(largeur)
    return s


def _num(v):
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def convertir(rows, sc, groupe):
    """Lignes de l'API -> {roles, secteurs, 'eff': {annee: v}, 'etab': {annee: v}}."""
    effc = {a: f"eff_{a}" for a in sc["eff"]} if groupe else sc["eff"]
    etabc = {a: f"etab_{a}" for a in sc["etab"]} if groupe else sc["etab"]
    ren = {sc[r]: r for r in CANDIDATS if sc.get(r)}
    ren.update({f: n for n, f in sc["niveaux"].items()})
    out = []
    for r in rows:
        d = {role: _code(r.get(f), LARGEURS.get(role)) for f, role in ren.items() if f in r}
        d["eff"] = {a: _num(r.get(c)) for a, c in effc.items()}
        d["etab"] = {a: _num(r.get(c)) for a, c in etabc.items()}
        out.append(d)
    return out


def _sommes(sc):
    return ([f"sum({f}) as eff_{a}" for a, f in sc["eff"].items()]
            + [f"sum({f}) as etab_{a}" for a, f in sc["etab"].items()])


# ---------------------------------------------------------------------------
# Téléchargements (chacun passe par le cache)
# ---------------------------------------------------------------------------
class Sources:
    def __init__(self, client, cache, log=print, forcer=False):
        self.c, self.cache, self.log, self.forcer = client, cache, log, forcer

    def _cache(self, cle, famille, fonction):
        if not self.forcer:
            d, date = self.cache.lire(cle, AGE_CACHE[famille])
            if d is not None:
                self.log(f"   (cache du {date})")
                return d
        d = fonction()
        self.cache.ecrire(cle, d)
        return d

    def _urssaf(self, ds, **params):
        return self.c.get(f"{URSSAF}/{ds}/exports/json", params)

    # --- Urssaf ---
    def champs_communes(self):
        def f():
            m = self.c.get(f"{URSSAF}/{DS_COMMUNES}")
            return m.get("fields") or (m.get("dataset") or {}).get("fields", [])
        return self._cache("urssaf_champs", "urssaf", f)

    def detail_epci(self, sc, siren):
        cols = ([sc[r] for r in ("code_commune", "commune") if sc.get(r)] + list(sc["niveaux"].values())
                + list(sc["eff"].values()) + list(sc["etab"].values()))
        return self._cache(f"urssaf_detail_{siren}", "urssaf",
                           lambda: self._urssaf(DS_COMMUNES, select=",".join(cols),
                                                where=f'{sc["code_epci"]}="{siren}"'))

    def detail_departements(self, sc, deps):
        """Détail commune x activité de tous les établissements des départements donnés (la région) : sert à la
        fois à l'EPCI étudié (outil Emploi) et aux comparaisons entre EPCI de la région (portrait économique).
        Une seule requête remplace l'ancien téléchargement CSV régional et l'ancien détail de l'EPCI."""
        cols = ([sc[r] for r in ("code_commune", "commune", "code_epci", "code_dep") if sc.get(r)]
                + list(sc["niveaux"].values()) + list(sc["eff"].values()) + list(sc["etab"].values()))
        liste = ",".join(f'"{d}"' for d in deps)
        return self._cache(f"urssaf_region_{'-'.join(deps)}", "urssaf",
                           lambda: self._urssaf(DS_COMMUNES, select=",".join(cols),
                                                where=f'{sc["code_dep"]} in ({liste})'))

    def references(self, sc):
        grp = ([sc[r] for r in ("code_reg", "reg", "code_dep", "dep") if sc.get(r)]
               + [f for n, f in sc["niveaux"].items() if n != "APE"])
        return self._cache("urssaf_references", "urssaf",
                           lambda: self._urssaf(DS_COMMUNES, select=",".join(grp + _sommes(sc)),
                                                group_by=",".join(grp)))

    def totaux_epci(self, sc):
        grp = [sc[r] for r in ("code_epci", "epci", "code_dep", "code_reg") if sc.get(r)]
        return self._cache("urssaf_totaux_epci", "urssaf",
                           lambda: self._urssaf(DS_COMMUNES, select=",".join(grp + _sommes(sc)),
                                                group_by=",".join(grp)))

    def communes_par_epci(self, sc):
        grp = f'{sc["code_epci"]},{sc["code_commune"]}'
        rows = self._cache("urssaf_communes_epci", "urssaf",
                           lambda: self._urssaf(DS_COMMUNES, select=grp, group_by=grp))
        return {_code(r.get(sc["code_commune"]), 5): _code(r.get(sc["code_epci"]), 9) for r in rows}

    def masse_salariale(self):
        rows = self._cache("urssaf_masse_salariale", "masse", lambda: self._urssaf(
            DS_EPCI_MS, select="code_epci,epci,annee,nombre_d_etablissements,effectifs_salaries_moyens,masse_salariale"))
        out = []
        for r in rows:
            a = str(r.get("annee") or "")[:4]
            if a.isdigit():
                out.append({"code_epci": _code(r.get("code_epci"), 9), "annee": int(a),
                            "etab": _num(r.get("nombre_d_etablissements")),
                            "eff_moy": _num(r.get("effectifs_salaries_moyens")),
                            "masse": _num(r.get("masse_salariale"))})
        return out

    # --- OFGL ---
    def population(self, annee):
        def f():
            rows = self.c.get(f"{OFGL}/{DS_OFGL_GFP}/exports/json", {
                "select": "siren,exer,ptot",
                "where": f'agregat="Frais de personnel" and year(exer)>={annee - 3} and year(exer)<={annee}'})
            meilleur = {}
            for r in rows:
                s, a = str(r.get("siren")), int(str(r.get("exer"))[:4])
                if s not in meilleur or a > meilleur[s][1]:
                    meilleur[s] = (_num(r.get("ptot")), a)
            return meilleur
        return {k: tuple(v) for k, v in self._cache("ofgl_population", "ofgl", f).items()}

    # --- geo.api.gouv.fr ---
    def contours(self, siren):
        return self._cache(f"geo2_{siren}", "geo", lambda: self.c.get(
            f"{GEO}/epcis/{siren}/communes",
            {"fields": "code,nom,population,codesPostaux", "format": "geojson", "geometry": "contour"}))

    # --- Insee Melodi : capacités touristiques ---
    def tourisme(self):
        return self._cache("tourisme_epci", "tourisme", self._tourisme)

    def _tourisme(self):
        r = self.c.get(URL_TOURISME, brut=True, timeout=300)
        contenu = r.content
        if contenu[:2] == b"PK":
            with zipfile.ZipFile(io.BytesIO(contenu)) as z:
                noms = [n for n in z.namelist() if n.lower().endswith(".csv")]
                noms.sort(key=lambda n: ("data" not in n.lower(), -z.getinfo(n).file_size))
                self.log(f"   archive Insee : {z.namelist()} -> lecture de {noms[0]}")
                contenu = z.read(noms[0])
        texte = contenu.decode("utf-8-sig", errors="replace")
        premiere = texte.split("\n", 1)[0]
        sep = ";" if premiere.count(";") >= premiere.count(",") else ","
        lecteur = csv.DictReader(io.StringIO(texte), delimiter=sep)
        cols = lecteur.fieldnames or []
        c_val = next((c for c in cols if "OBS_VALUE" in c.upper()), None)
        c_objet = next((c for c in cols if c.upper() == "GEO_OBJECT"), None)
        if not c_val or "GEO" not in cols:
            raise RuntimeError(f"colonnes inattendues dans le fichier tourisme : {cols}")
        # (epci, mesure, activité) -> {(rang, durée): valeur}
        brut = {}
        for ligne in lecteur:
            geo = ligne["GEO"]
            if c_objet:
                if ligne.get(c_objet) != "EPCI":
                    continue
                code = geo
            else:
                if "-EPCI-" not in geo:
                    continue
                code = geo.rsplit("-", 1)[-1]
            cle = (code, ligne.get("TOUR_MEASURE"), ligne.get("ACTIVITY"))
            brut.setdefault(cle, {})[(ligne.get("UNIT_LOC_RANKING", "_T"), ligne.get("L_STAY", "_T"))] = \
                _num(ligne.get(c_val)) or 0.0
        return calculer_lits(brut)

    # --- SIRENE, Observatoire des territoires, BMO ---
    def employeurs(self, siren, codes_communes):
        from . import sirene
        cle = sirene.lire_cle()
        if not cle:
            raise RuntimeError("fichier cle_sirene.txt absent à côté de l'application")
        return self._cache(f"sirene2_{siren}", "sirene",
                           lambda: sirene.telecharger(self.c, cle, codes_communes, self.log))

    def sirene_demographie(self, siren, codes_communes, annees):
        from . import sirene
        cle = sirene.lire_cle()
        if not cle:
            raise RuntimeError("fichier cle_sirene.txt absent à côté de l'application")
        return self._cache(f"sirene_demo_{siren}_{annees[0]}_{annees[-1]}", "sirene",
                           lambda: sirene.creations_fermetures(self.c, cle, codes_communes, annees, self.log))

    # --- Insee Melodi : logements, Flores, créations d'entreprises ---
    def logements(self, siren):
        from . import melodi
        return self._cache(f"logements_{siren}", "logement", lambda: melodi.logements_epci(self.c, siren))

    def residences_secondaires(self, codes_epci):
        from . import melodi
        return self._cache("rs_epci", "logement",
                           lambda: melodi.residences_secondaires_toutes(self.c, codes_epci, self.log))

    def flores(self, siren, dep):
        from . import melodi
        out = {"epci": self._cache(f"flores_{siren}", "flores", lambda: melodi.flores(self.c, f"EPCI-{siren}"))}
        try:
            out["dep"] = self._cache(f"flores_dep_{dep}", "flores", lambda: melodi.flores(self.c, f"DEP-{dep}"))
        except Exception as e:
            self.log(f"      Flores du département indisponible ({str(e)[:80]})")
        return out

    def creations(self, siren, dep):
        from . import melodi
        out = {"epci": self._cache(f"side_crea_{siren}", "side", lambda: melodi.creations(self.c, f"EPCI-{siren}"))}
        for cle, f in (("stock_epci", lambda: melodi.stocks(self.c, f"EPCI-{siren}")),
                       ("dep", lambda: melodi.creations(self.c, f"DEP-{dep}", "DS_SIDE_CREA_DEP_REG_NAT")),
                       ("stock_dep", lambda: melodi.stocks(self.c, f"DEP-{dep}", "DS_SIDE_STOCKS_A21"))):
            try:
                out[cle] = self._cache(f"side_{cle}_{siren if 'epci' in cle else dep}", "side", f)
            except Exception as e:
                self.log(f"      {cle.replace('_', ' ')} indisponible ({str(e)[:80]})")
        return out

    # --- Insee : déplacements domicile-travail ---
    def mobilites(self, siren, codes_communes):
        from . import mobilites
        def f():
            m = mobilites.telecharger(self.c, codes_communes, self.log)
            m["centres"] = mobilites.centres(self.c, m["flux"], codes_communes, self.log)
            return m
        return self._cache(f"mobilites_{siren}", "mobilites", f)

    # --- BODACC ---
    def bodacc(self, dep, annees):
        from . import bodacc
        return self._cache(f"bodacc_{dep}_{annees[0]}_{annees[-1]}", "bodacc",
                           lambda: bodacc.telecharger(self.c, dep, annees, self.log))

    def anct(self):
        from . import anct
        # clé renommée en v0.5.1 : l'ancienne a pu garder un résultat vide (service en panne)
        return self._cache("anct2_indicateurs", "anct", lambda: anct.telecharger(self.c, self.log))

    def bmo(self):
        from . import bmo
        return self._cache("bmo", "bmo", lambda: bmo.telecharger(self.c, self.log))

    # --- France Travail (API, identifiants dans identifiants_francetravail.txt) ---
    def france_travail(self, siren, nom, dep, reg):
        from . import francetravail
        return self._cache(f"ft2_{siren}", "ft", lambda: francetravail.collecter(
            self.c, siren, nom, dep, reg, None, None, self.log))

    def ft_tensions(self, bassin, dep, metiers):
        from . import francetravail
        return self._cache(f"ft_tensions_{bassin or dep}", "ft", lambda: francetravail.tensions_seules(
            self.c, metiers, bassin, dep, self.log))

    # --- data.gouv.fr : communes littorales ---
    def littoral(self):
        return set(self._cache("littoral", "littoral", self._littoral))

    def _littoral(self):
        for slug in JEUX_LITTORAL:
            try:
                js = self.c.get(f"{DATAGOUV}/datasets/{slug}/", essais=1)
            except RuntimeError as e:
                self.log(f"   jeu {slug} indisponible ({e})")
                continue
            ressources = sorted(js.get("resources", []), key=lambda r: str(r.get("last_modified", "")), reverse=True)
            for res in ressources:
                fmt = str(res.get("format", "")).lower()
                if fmt in ("xlsx", "csv", "xls"):
                    try:
                        codes = lire_liste_communes(self.c.get(res["url"], brut=True).content, fmt)
                        if len(codes) > 500:
                            self.log(f"   {len(codes)} communes littorales ({res.get('title')})")
                            return sorted(codes)
                    except Exception as e:
                        self.log(f"   lecture impossible de {res.get('title')} ({e})")
        self.log("   liste de secours (COG 2020)")
        codes = lire_liste_communes(self.c.get(URL_LITTORAL_SECOURS, brut=True).content, "xlsx")
        return sorted(codes)


RE_COMMUNE = re.compile(r"^(\d{5}|2[AB]\d{3})$")


def lire_liste_communes(contenu, fmt):
    """Extrait les codes INSEE d'un tableau (xlsx, xls ou csv) : colonne dont l'en-tête
    évoque un code commune, sinon colonne contenant le plus de codes valides."""
    lignes = []
    if fmt == "xlsx":
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(contenu), read_only=True, data_only=True)
        for ws in wb.worksheets:
            lignes += [list(r) for r in ws.iter_rows(values_only=True)]
    elif fmt == "xls":
        import xlrd  # facultatif : seulement si le fichier publié est au vieux format Excel
        wb = xlrd.open_workbook(file_contents=contenu)
        for ws in wb.sheets():
            lignes += [ws.row_values(i) for i in range(ws.nrows)]
    else:
        texte = contenu.decode("utf-8-sig", errors="replace")
        sep = ";" if texte[:2000].count(";") > texte[:2000].count(",") else ","
        lignes = list(csv.reader(io.StringIO(texte), delimiter=sep))

    def code(v):
        if isinstance(v, float) and v.is_integer():
            v = int(v)
        s = str(v or "").strip()
        if s.isdigit() and len(s) == 4:
            s = s.zfill(5)
        return s if RE_COMMUNE.match(s) else None

    entetes = [(i, j) for i, l in enumerate(lignes[:30]) for j, v in enumerate(l)
               if any(m in normaliser(v) for m in ("insee", "codgeo", "code_com", "code commune", "depcom", "com"))
               and not code(v)]
    candidates = {}
    for i, j in entetes:
        vals = {code(l[j]) for l in lignes[i + 1:] if j < len(l)}
        vals.discard(None)
        candidates[(i, j)] = vals
    if not candidates or max(len(v) for v in candidates.values()) < 100:
        largeur = max((len(l) for l in lignes), default=0)
        for j in range(largeur):
            vals = {code(l[j]) for l in lignes if j < len(l)}
            vals.discard(None)
            candidates[("col", j)] = vals
    return max(candidates.values(), key=len) if candidates else set()


def calculer_lits(brut):
    """Lits touristiques marchands par EPCI, selon la convention usuelle de l'Insee :
    1 chambre d'hôtel = 2 lits, 1 emplacement de camping = 3 lits,
    autres hébergements collectifs : lits déclarés.
    Codes Melodi : ACTIVITY I551 hôtels, I552 autres hébergements collectifs, I553 campings ;
    TOUR_MEASURE PLACE = chambres ou emplacements, BEDPLACE = lits, UNIT_LOC = établissements."""
    def total(cases):
        if ("_T", "_T") in cases:
            return cases[("_T", "_T")]
        par_rang = {}
        for (rang, duree), v in cases.items():
            par_rang.setdefault(rang, {})[duree] = v
        s = 0.0
        for rang, d in par_rang.items():
            if rang == "_T" and len(par_rang) > 1:
                continue
            s += d.get("_T", sum(v for k, v in d.items() if k != "_T"))
        return s

    out = {}
    for (code, mesure, activite), cases in brut.items():
        e = out.setdefault(code, {"chambres_hotel": 0.0, "emplacements_camping": 0.0, "lits_autres": 0.0,
                                  "etab_hotel": 0.0, "etab_camping": 0.0, "etab_autres": 0.0})
        v = total(cases)
        if activite == "I551" and mesure == "PLACE":
            e["chambres_hotel"] = v
        elif activite == "I553" and mesure == "PLACE":
            e["emplacements_camping"] = v
        elif activite == "I552" and mesure == "BEDPLACE":
            e["lits_autres"] = v
        elif mesure == "UNIT_LOC" and activite in ("I551", "I552", "I553"):
            e[{"I551": "etab_hotel", "I552": "etab_autres", "I553": "etab_camping"}[activite]] = v
    for e in out.values():
        e["lits"] = 2 * e["chambres_hotel"] + 3 * e["emplacements_camping"] + e["lits_autres"]
    return out


# ---------------------------------------------------------------------------
# Test rapide des connexions
# ---------------------------------------------------------------------------
TESTS = [
    ("Open Urssaf", f"{URSSAF}/{DS_COMMUNES}/records", {"limit": 1}),
    ("Open Urssaf (masse salariale)", f"{URSSAF}/{DS_EPCI_MS}/records", {"limit": 1}),
    ("OFGL", f"{OFGL}/{DS_OFGL_GFP}/records", {"limit": 1}),
    ("geo.api.gouv.fr", f"{GEO}/epcis/200065563", None),
    ("Insee Melodi", f"{MELODI}/catalog/DS_TOUR_CAP", None),
    ("data.gouv.fr", f"{DATAGOUV}/datasets/{JEUX_LITTORAL[0]}/", None),
    ("Observatoire des territoires (téléchargement d'un indicateur)",
     "https://www.observatoire-des-territoires.gouv.fr/outils/cartographie-interactive/api/v1/functions/"
     "GC_API_download.php",
     {"lang": "fr", "type": "stat", "dataset": "indic_sex_rp", "indic": "tx_chom1564", "nivgeo": "epci2025",
      "filter": "last", "format": "csv"}),
    ("Insee Melodi (données par territoire)", f"{MELODI}/data/DS_FLORES_A38",
     {"GEO": "EPCI-200065563", "maxResult": 1}),
    ("BODACC", "https://bodacc-datadila.opendatasoft.com/api/explore/v2.1/catalog/datasets/annonces-commerciales",
     None),
    ("Insee (mobilités domicile-travail)", "https://www.insee.fr/fr/statistiques/8582949", None),
]


def tester_france_travail(client, log):
    from . import francetravail
    try:
        ft = francetravail.ClientFT(client, log)
        ft._jeton()
        log("   OK  France Travail (jeton d'accès obtenu)")
    except Exception as e:
        log(f"   ECHEC  France Travail : {e}")


def tester_connexions(client, log):
    tester_france_travail(client, log)
    for nom, url, params in TESTS:
        try:
            # réponse brute : certaines adresses testées renvoient du HTML ou du XML, pas du JSON
            client.get(url, params, timeout=30, essais=1, brut=True,
                       entetes={"User-Agent": "Mozilla/5.0 ObservatoireEmploiNCPA"})
            log(f"   OK  {nom}")
        except Exception as e:
            log(f"   ECHEC  {nom} : {e}")

"""Fonds de carte communs aux quatre cartes HTML.

- « Plan » : Plan IGN v2 (Géoplateforme, tuiles raster, sans clé), choisi par
  l'utilisateur à la place du fond vectoriel OpenFreeMap, qui ne s'affichait
  pas sur son poste (WebGL ou proxy) ;
- « Photo » : orthophotographies IGN.
Le sélecteur est posé sur la carte (en haut à droite), donc toujours visible,
même quand le panneau latéral est long. La fonction surChangement(estPhoto)
permet à chaque carte d'adapter ses contours : limites communales en blanc
fin sur la photo, plus lisibles qu'un trait sombre.
"""

FONDS_CSS = """
.fonds-ctrl{display:flex;background:#fff;border-radius:6px;box-shadow:0 1px 5px rgba(0,0,0,.35);overflow:hidden;
  font:600 12.5px Calibri,"Segoe UI",sans-serif}
.fonds-ctrl button{border:none;background:#fff;color:#1F2A2E;padding:6px 11px;cursor:pointer;margin:0;border-radius:0}
.fonds-ctrl button+button{border-left:1px solid #DCDDD3}
.fonds-ctrl button.actif{background:#B91E27;color:#fff}
.fonds-ctrl button:focus-visible{outline:2px solid #1F2A2E;outline-offset:-2px}
"""

FONDS_JS = r"""
function installerFonds(map, surChangement) {
  const wmts = (couche, format) => "https://data.geopf.fr/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=" + couche
    + "&STYLE=normal&FORMAT=" + format + "&TILEMATRIXSET=PM&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}";
  const attribution = '© <a href="https://www.ign.fr/" target="_blank" rel="noopener">IGN</a> / Géoplateforme';
  const plan = L.tileLayer(wmts("GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2", "image/png"),
    {maxZoom:20, maxNativeZoom:19, attribution});
  const photo = L.tileLayer(wmts("ORTHOIMAGERY.ORTHOPHOTOS", "image/jpeg"),
    {maxZoom:20, maxNativeZoom:19, attribution});
  let estPhoto = false;
  plan.addTo(map);
  const boutons = {};
  function choisir(versPhoto) {
    if (versPhoto === estPhoto) return;
    estPhoto = versPhoto;
    map.removeLayer(versPhoto ? plan : photo);
    (versPhoto ? photo : plan).addTo(map).bringToBack();
    boutons.plan.classList.toggle("actif", !versPhoto);
    boutons.photo.classList.toggle("actif", versPhoto);
    boutons.plan.setAttribute("aria-pressed", String(!versPhoto));
    boutons.photo.setAttribute("aria-pressed", String(versPhoto));
    if (surChangement) surChangement(versPhoto);
  }
  const Controle = L.Control.extend({options:{position:"topright"}, onAdd() {
    const div = L.DomUtil.create("div", "fonds-ctrl");
    div.setAttribute("role", "group"); div.setAttribute("aria-label", "Fond de carte");
    boutons.plan = L.DomUtil.create("button", "actif", div); boutons.plan.type = "button";
    boutons.plan.textContent = "Plan IGN"; boutons.plan.setAttribute("aria-pressed", "true");
    boutons.photo = L.DomUtil.create("button", "", div); boutons.photo.type = "button";
    boutons.photo.textContent = "Photo aérienne"; boutons.photo.setAttribute("aria-pressed", "false");
    boutons.plan.onclick = () => choisir(false); boutons.photo.onclick = () => choisir(true);
    L.DomEvent.disableClickPropagation(div);
    return div;
  }});
  new Controle().addTo(map);
  return {photo: () => estPhoto};
}
// Style des limites communales selon le fond : trait sombre pointillé sur le plan, blanc fin sur la photo.
function styleLimite(estPhoto) {
  return estPhoto ? {color:"#FFFFFF", weight:1.6, opacity:.95, fill:false, dashArray:null}
                  : {color:"#3F4448", weight:1.3, opacity:.9, fill:false, dashArray:"5 3"};
}
"""


def injecter(html, lire):
    """Remplace les marqueurs /*FONDS_CSS*/ et /*FONDS_JS*/ ; lire(chemin) renvoie le texte d'une ressource."""
    return html.replace("/*FONDS_CSS*/", FONDS_CSS).replace("/*FONDS_JS*/", FONDS_JS)

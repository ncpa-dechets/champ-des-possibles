"""Paramètres de l'outil, stockés dans config.xlsx (modifiable sans toucher au code).

Si config.xlsx n'existe pas, il est recréé avec les valeurs par défaut ci-dessous.
Pour revenir aux réglages d'origine : supprimer config.xlsx et relancer.
"""
import shutil
from datetime import datetime

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .utils import RACINE, log

FICHIER = RACINE / "config.xlsx"

# ------------------------------------------------------------------ territoire
TERRITOIRE = [
    ("code_epci", "200065563", "SIREN de l'EPCI étudié"),
    ("nom_court", "NCPA", "Nom affiché dans les graphiques et le rapport"),
    ("nom_long", "Normandie Cabourg Pays d'Auge", "Nom complet"),
    ("departement", "14", "Département de comparaison (tous ses EPCI sont comparés)"),
    ("nom_departement", "le Calvados", "Nom du département AVEC son article (le Calvados, la Manche, l'Orne…) : sert à accorder les phrases"),
    ("region", "28", "Code région (Normandie = 28)"),
    ("nom_region", "la Normandie", "Nom de la région AVEC son article"),
    ("departements_region", "14,27,50,61,76", "Départements de la région, séparés par des virgules"),
    ("proxy", "", "Proxy internet si le réseau de la collectivité l'impose (ex. http://proxy:8080). Vide sinon"),
    ("duree_cache_jours", "90", "Au-delà, les données sont retéléchargées (sauf si --hors-ligne)"),
]

# ------------------------------------------------------------------ indicateurs INSEE
# Repérage d'un indicateur dans la base du dossier complet :
#   tableau    : identifiant du tableau (ID_TAB), motif d'expression régulière, ex. ^EMP_T5$
#   code_insee : code exact de la mesure (TAB_MEASURE) — REPÉRAGE PRIORITAIRE, insensible
#                aux changements de libellé. Colonne B du catalogue sorties/catalogue_INSEE_*.xlsx
#   mesure / exclure : motifs sur le libellé, utilisés seulement si code_insee est vide ou introuvable
#   unite      : "nombre" ou "pct"
# Codes vérifiés sur la base du dossier complet INSEE (catalogue NCPA, octobre 2026).
INDICATEURS = [
    # code, libellé, thème, tableau, code_insee, mesure, exclure, unité
    ("pop", "Population", "Démographie", r"^POP_T1$", "POP", r"^population$", "", "nombre"),
    ("emplois_lt", "Emplois au lieu de travail", "Emploi", r"^EMP_T5$", "NBEMP_AGE_Y_GE15", r"^nombre d.emplois", "", "nombre"),
    ("actifs_occ", "Actifs occupés résidents (15 ans ou plus)", "Emploi", r"^EMP_T5$", "POP_EMPSTA_ENQ_1_AGE_Y_GE15", r"actif occupe", "", "nombre"),
    ("actifs_1564", "Actifs de 15 à 64 ans", "Emploi", r"^EMP_T4$", "POP_EMPSTA_ENQ_1T2_AGE_Y15T64", r"actif \* de 15 a 64", "", "nombre"),
    ("chomeurs_1564", "Chômeurs de 15 à 64 ans", "Emploi", r"^EMP_T4$", "POP_EMPSTA_ENQ_2_AGE_Y15T64", r"chomeur \* de 15 a 64", "", "nombre"),
    ("emp_total_t8", "Emplois (total, par secteur)", "Emploi", r"^EMP_T8$", "NBEMP", r"^nombre d.emplois$", "", "nombre"),
    ("emp_agri", "Emplois – agriculture", "Emploi", r"^EMP_T8$", "NBEMP_EMP_ACTIVITY_AZ", r"^agriculture", "femme|salarie", "nombre"),
    ("emp_indus", "Emplois – industrie", "Emploi", r"^EMP_T8$", "NBEMP_EMP_ACTIVITY_BE", r"^industrie", "femme|salarie", "nombre"),
    ("emp_constr", "Emplois – construction", "Emploi", r"^EMP_T8$", "NBEMP_EMP_ACTIVITY_FZ", r"^construction", "femme|salarie", "nombre"),
    ("emp_comm", "Emplois – services principalement marchands", "Emploi", r"^EMP_T8$", "NBEMP_EMP_ACTIVITY_GU", r"services principalement marchands", "femme|salarie", "nombre"),
    ("emp_admin", "Emplois – administration, enseignement, santé, social", "Emploi", r"^EMP_T8$", "NBEMP_EMP_ACTIVITY_OQ", r"^administration", "femme|salarie", "nombre"),
    ("eff_etab", "Salariés des établissements employeurs (hors particuliers employeurs)", "Sphères", r"^RES_T3$", "EMPL3112_LEGAL_FORM_WITH_PUBLIC_1T9X7", r"^effectifs .*ensemble hors particuliers employeurs$", "", "nombre"),
    ("eff_pres", "Salariés des établissements de la sphère présentielle", "Sphères", r"^RES_T3$", "EMPL3112_LEGAL_FORM_WITH_PUBLIC_1T9X7_ECONOMIC_SPHERE_PRESENTIAL", r"^effectifs .*ensemble hors particuliers employeurs \* .*presentielle", "", "nombre"),
    ("log_total", "Logements (total)", "Logement", r"^LOG_T1$", "DWELLINGS", r"^logements$", "", "nombre"),
    ("log_rs", "Résidences secondaires et logements occasionnels", "Logement", r"^LOG_T1$", "DWELLINGS_OCS_DW_SEC_DW_OCC", r"residences secondaires", "", "nombre"),
    ("pers_menfisc", "Personnes dans les ménages fiscaux (Filosofi)", "Revenus", r"^REV_T", "", r"personnes dans les menages fiscaux", "", "nombre"),
    ("niv_vie_med", "Niveau de vie médian (€)", "Revenus", r"^REV_T1$", "MED_SL", r"niveau de vie median", "", "nombre"),
    ("taux_pauvrete", "Taux de pauvreté (%)", "Revenus", r"^REV_T1$", "PR_MD60", r"^taux de pauvrete", "", "pct"),
    ("part_activite", "Part des revenus d'activité", "Revenus", r"^REV_T2$", "S_EI_DI", r"revenus d.activite", "", "pct"),
    ("part_pensions", "Part des pensions, retraites et rentes", "Revenus", r"^REV_T2$", "S_RET_PEN_DI", r"pensions", "", "pct"),
    ("part_patrimoine", "Part des revenus du patrimoine", "Revenus", r"^REV_T2$", "S_INC_ASS_DI", r"patrimoine", "", "pct"),
    ("part_prestations", "Part des prestations sociales", "Revenus", r"^REV_T2$", "S_SOC_BEN_DI", r"ensemble des prestations sociales", "", "pct"),
    ("part_impots", "Part des impôts", "Revenus", r"^REV_T2$", "S_DIR_TAX_DI", r"impots directs", "", "pct"),
    ("hotels_places", "Hôtels – places", "Tourisme", r"^TOU_T1$", "PLACE_ACTIVITY_I551", r"^nombre de places", "etoile|non classe", "nombre"),
    ("camping_places", "Campings – places", "Tourisme", r"^TOU_T2$", "PLACE_ACTIVITY_I553", r"^nombre de places", "etoile|non classe", "nombre"),
    ("autres_lits", "Autres hébergements collectifs – place-lits", "Tourisme", r"^TOU_T3$", "BEDPLACE_ACTIVITY_I552", r"^nombre de place-lits .* hebergement touristique et autre", "", "nombre"),
]

# Indicateurs CALCULÉS à partir des précédents (absents tels quels de la base) :
#   code : (libellé, numérateur, dénominateur, multiplicateur)
CALCULES = {
    "ice": ("Indicateur de concentration d'emploi (emplois pour 100 actifs occupés)", "emplois_lt", "actifs_occ", 100),
    "chomage": ("Taux de chômage des 15-64 ans, au sens du recensement (%)", "chomeurs_1564", "actifs_1564", 100),
    "part_pres_off": ("Part des salariés dans la sphère présentielle, source INSEE (%)", "eff_pres", "eff_etab", 100),
}

# ------------------------------------------------------------------ sphères (approximation)
# Classement d'un code APE (sans point, ex. 4711F) dans la sphère présentielle (P) ou
# productive (N). Règle du préfixe le plus long : "1071" l'emporte sur "10".
# APPROXIMATION au niveau division NAF avec quelques exceptions connues : la série
# officielle INSEE (Observatoire des territoires) reste la référence.
SPHERES = [
    ("01", "N", "Agriculture"), ("02", "N", "Sylviculture"), ("03", "N", "Pêche"),
    ("05", "N", "Industries extractives"), ("06", "N", ""), ("07", "N", ""), ("08", "N", ""), ("09", "N", ""),
    ("1", "N", "Industrie manufacturière (10 à 19)"), ("2", "N", "Industrie manufacturière (20 à 29)"),
    ("30", "N", ""), ("31", "N", ""), ("32", "N", ""), ("33", "N", "Réparation/installation de machines"),
    ("1071", "P", "Boulangerie-pâtisserie (artisanat de proximité)"),
    ("35", "N", "Énergie (production)"),
    ("36", "P", "Eau"), ("37", "P", "Assainissement"), ("38", "P", "Déchets"), ("39", "P", "Dépollution"),
    ("41", "P", "Construction de bâtiments"), ("42", "P", "Génie civil"), ("43", "P", "Travaux spécialisés"),
    ("45", "P", "Commerce et réparation automobile"), ("46", "N", "Commerce de gros"), ("47", "P", "Commerce de détail"),
    ("49", "N", "Transports terrestres (fret)"), ("493", "P", "Transport de voyageurs (taxis, cars…)"),
    ("50", "N", ""), ("51", "N", ""), ("52", "N", "Entreposage"), ("53", "P", "Activités de poste et de courrier"),
    ("55", "P", "Hébergement"), ("56", "P", "Restauration"),
    ("58", "N", ""), ("59", "N", ""), ("5914", "P", "Cinémas"), ("60", "N", ""), ("61", "N", ""), ("62", "N", ""), ("63", "N", ""),
    ("64", "P", "Banques (agences de détail)"), ("65", "P", "Assurance"), ("66", "P", "Auxiliaires financiers"),
    ("68", "P", "Activités immobilières"),
    ("69", "N", ""), ("70", "N", ""), ("71", "N", ""), ("72", "N", ""), ("73", "N", ""), ("74", "N", ""), ("75", "P", "Vétérinaires"),
    ("77", "N", "Location (entreprises)"), ("772", "P", "Location de biens personnels"),
    ("78", "N", "Emploi, intérim"), ("79", "P", "Agences de voyage"), ("80", "N", "Sécurité"),
    ("81", "N", "Services aux bâtiments"), ("813", "P", "Aménagement paysager"), ("82", "N", ""),
    ("84", "P", "Administration publique"), ("85", "P", "Enseignement"),
    ("86", "P", "Santé"), ("87", "P", "Hébergement médico-social"), ("88", "P", "Action sociale"),
    ("90", "P", ""), ("91", "P", ""), ("92", "P", ""), ("93", "P", "Sport, loisirs"),
    ("94", "P", "Associations"), ("95", "P", "Réparation de biens personnels"), ("96", "P", "Services à la personne"),
    ("97", "P", ""), ("98", "P", ""), ("99", "P", ""),
]

# ------------------------------------------------------------------ hypothèses base économique
# Valeurs INDICATIVES à valider ou remplacer par des sources locales
# (Calvados Attractivité, enquêtes clientèles, taxe de séjour, Flux Vision…).
HYPOTHESES = [
    ("coef_moyenne_mediane", 1.10, 1.15, 1.20, "ratio",
     "Revenu moyen / revenu médian : Filosofi ne publie qu'une médiane, la masse de revenus est estimée par population × médiane × ce coefficient"),
    ("personnes_par_uc", 1.45, 1.50, 1.55, "personnes/UC",
     "Nombre moyen de personnes par unité de consommation (convertit le niveau de vie par UC en revenu par personne)"),
    ("part_actifs_hors_epci", 0.50, 0.54, 0.58, "part",
     "Part des actifs occupés résidents travaillant hors de l'EPCI. Valeur centrale NCPA : AURH, RP 2019 (≈ 6 470 sur 11 940). Remplacée automatiquement si le fichier des navettes INSEE est fourni"),
    ("nuits_occupees_par_rs", 40, 60, 90, "nuits/an", "Nuits d'occupation d'une résidence secondaire par an — HYPOTHÈSE à documenter"),
    ("personnes_par_sejour_rs", 2.0, 2.5, 3.0, "personnes", "Nombre moyen d'occupants d'une résidence secondaire — HYPOTHÈSE"),
    ("depense_jour_rs", 20, 30, 40, "€/pers/jour", "Dépense locale par personne et par jour des résidents secondaires — HYPOTHÈSE"),
    ("lits_par_place_hotel", 2, 2, 2, "lits/place",
     "Conversion des places d'hôtel INSEE en lits (convention INSEE : 2 lits par chambre). Mettre 1 si la base compte déjà des lits"),
    ("lits_par_place_camping", 3, 3, 3, "lits/place",
     "Conversion des places de camping INSEE en lits (convention INSEE : 3 lits par emplacement). Mettre 1 si la base compte déjà des lits"),
    ("nuitees_par_lit_marchand", 60, 90, 120, "nuitées/lit/an", "Fréquentation moyenne d'un lit touristique marchand — HYPOTHÈSE (à caler sur la taxe de séjour)"),
    ("depense_par_nuitee_marchande", 40, 60, 80, "€/nuitée", "Dépense locale d'un touriste en hébergement marchand, hébergement compris — HYPOTHÈSE"),
]


VERSION = 3
ENTETES = {
    "Territoire": (["parametre", "valeur", "commentaire"], [24, 30, 90], (2,)),
    "Indicateurs": (["code", "libelle", "theme", "tableau", "code_insee", "mesure", "exclure", "unite"],
                    [16, 45, 12, 14, 42, 36, 22, 8], (4, 5, 6, 7, 8)),
    "Spheres_NAF": (["prefixe_ape", "sphere", "commentaire"], [14, 8, 50], (2,)),
    "Hypotheses": (["parametre", "bas", "central", "haut", "unite", "commentaire"], [30, 9, 9, 9, 15, 95], (2, 3, 4)),
}
LISEZMOI = [
    "Paramètres de l'outil d'analyse économique territoriale",
    "",
    "Texte en BLEU = valeurs modifiables (aussi depuis l'interface, onglet Paramètres).",
    "Territoire : EPCI étudié et territoires de comparaison.",
    "Indicateurs : repérage dans la base du dossier complet INSEE, par code exact (colonne code_insee)",
    "   ou à défaut par motif sur le libellé. Codes disponibles : sorties/catalogue_INSEE_<EPCI>.xlsx.",
    "   Indicateurs calculés par l'outil (non paramétrables ici) : concentration d'emploi, taux de chômage,",
    "   part présentielle INSEE.",
    "Spheres_NAF : classement approximatif des codes APE en sphère présentielle (P) / productive (N).",
    "Hypotheses : paramètres de l'estimation de la base économique (fourchette bas / central / haut).",
    "",
    "Pour revenir aux réglages d'origine : supprimer ce fichier et relancer l'outil.",
    f"Version du paramétrage : {VERSION}",
]


def _feuille(wb, titre, lignes, index=None):
    colonnes, largeurs, col_saisie = ENTETES[titre]
    ws = wb.create_sheet(titre, index)
    ws.append(colonnes)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF", name="Calibri")
        c.fill = PatternFill("solid", fgColor="B91E27")
    for l in lignes:
        ws.append(list(l))
    for i, w in enumerate(largeurs, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
            c.font = Font(name="Calibri", color="0000FF" if c.column in col_saisie else None)
    ws.freeze_panes = "A2"
    return ws


def _lisezmoi(wb):
    if "LISEZMOI" in wb.sheetnames:
        del wb["LISEZMOI"]
    ws = wb.create_sheet("LISEZMOI", 0)
    for l in LISEZMOI:
        ws.append([l])
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name="Calibri")
    ws["A1"].font = Font(bold=True, size=14, color="B91E27", name="Calibri")
    ws.column_dimensions["A"].width = 110


def creer_config_defaut():
    wb = Workbook()
    wb.remove(wb.active)
    _lisezmoi(wb)
    _feuille(wb, "Territoire", TERRITOIRE)
    _feuille(wb, "Indicateurs", INDICATEURS)
    _feuille(wb, "Spheres_NAF", SPHERES)
    _feuille(wb, "Hypotheses", HYPOTHESES)
    wb.save(FICHIER)
    log("Configuration", f"config.xlsx créé avec les réglages par défaut ({FICHIER})", "ok")


def migrer_config():
    """Met à niveau un config.xlsx d'une version antérieure, sans toucher aux réglages
    de l'utilisateur (territoire, indicateurs existants, sphères, valeurs des hypothèses) :
    - onglet Indicateurs remplacé s'il date d'avant les codes INSEE exacts (v1) ;
    - paramètres de territoire, indicateurs et hypothèses nouveaux ajoutés avec leur valeur par défaut.
    L'ancien fichier est sauvegardé à côté (config_sauvegarde_<date>.xlsx)."""
    wb = load_workbook(FICHIER)
    entetes = [c.value for c in wb["Indicateurs"][1]]
    hyp_existantes = {r[0].value for r in wb["Hypotheses"].iter_rows(min_row=2) if r[0].value}
    terr_existants = {r[0].value: r[1].value for r in wb["Territoire"].iter_rows(min_row=2) if r[0].value}
    ind_existants = {r[0].value for r in wb["Indicateurs"].iter_rows(min_row=2) if r[0].value}
    h_manquantes = [h for h in HYPOTHESES if h[0] not in hyp_existantes]
    t_manquants = [t for t in TERRITOIRE if t[0] not in terr_existants]
    i_manquants = [i for i in INDICATEURS if i[0] not in ind_existants] if "code_insee" in entetes else []
    if "code_insee" in entetes and not (h_manquantes or t_manquants or i_manquants):
        return
    sauvegarde = FICHIER.with_name(f"config_sauvegarde_{datetime.now():%Y-%m-%d_%Hh%M}.xlsx")
    shutil.copy2(FICHIER, sauvegarde)
    changements = []

    def ajouter(ws, ligne, cols_saisie):
        ws.append(list(ligne))
        for c in ws[ws.max_row]:
            c.alignment = Alignment(wrap_text=True, vertical="top")
            c.font = Font(name="Calibri", color="0000FF" if c.column in cols_saisie else None)

    if "code_insee" not in entetes:
        idx = wb.sheetnames.index("Indicateurs")
        del wb["Indicateurs"]
        _feuille(wb, "Indicateurs", INDICATEURS, idx)
        changements.append("onglet Indicateurs remplacé (repérage par code INSEE exact)")
    for i in i_manquants:
        ajouter(wb["Indicateurs"], i, ENTETES["Indicateurs"][2])
    if i_manquants:
        changements.append("indicateurs ajoutés : " + ", ".join(i[0] for i in i_manquants))
    for t in t_manquants:
        valeur = t[1]
        # nom avec article : déduit du code si le territoire n'est pas celui par défaut
        if t[0] == "nom_departement" and str(terr_existants.get("departement", "14")).strip() != "14":
            valeur = ""
        if t[0] == "nom_region" and str(terr_existants.get("region", "28")).strip() != "28":
            valeur = ""
        ajouter(wb["Territoire"], (t[0], valeur, t[2]), ENTETES["Territoire"][2])
    if t_manquants:
        changements.append("paramètres de territoire ajoutés : " + ", ".join(t[0] for t in t_manquants))
    for h in h_manquantes:
        ajouter(wb["Hypotheses"], h, ENTETES["Hypotheses"][2])
    if h_manquantes:
        changements.append("hypothèses ajoutées : " + ", ".join(h[0] for h in h_manquantes))
    _lisezmoi(wb)
    wb.save(FICHIER)
    log("Configuration", "config.xlsx mis à niveau — " + " ; ".join(changements)
        + f". Ancienne version : {sauvegarde.name}", "alerte")


def enregistrer_config(territoire=None, hypotheses=None):
    """Écrit des valeurs modifiées (depuis l'interface) dans config.xlsx, en place :
    territoire = {parametre: valeur} ; hypotheses = {parametre: {"bas":…, "central":…, "haut":…}}."""
    wb = load_workbook(FICHIER)
    if territoire:
        for r in wb["Territoire"].iter_rows(min_row=2):
            if r[0].value in territoire:
                r[1].value = territoire[r[0].value]
    if hypotheses:
        for r in wb["Hypotheses"].iter_rows(min_row=2):
            if r[0].value in hypotheses:
                for j, sc in enumerate(("bas", "central", "haut"), 1):
                    r[j].value = float(hypotheses[r[0].value][sc])
    wb.save(FICHIER)
    log("Configuration", "config.xlsx enregistré depuis l'interface", "ok")


def charger_config():
    if not FICHIER.exists():
        creer_config_defaut()
    else:
        try:
            migrer_config()
        except PermissionError:
            log("Configuration", "config.xlsx est ouvert dans Excel : mise à niveau reportée au prochain lancement",
                "alerte")
    x = pd.read_excel(FICHIER, sheet_name=None, dtype=str)
    terr = {r.parametre: (r.valeur if isinstance(r.valeur, str) else "")
            for r in x["Territoire"].itertuples()}
    cfg = {
        "code_epci": terr["code_epci"].strip(),
        "nom_court": terr.get("nom_court", "EPCI"),
        "nom_long": terr.get("nom_long", ""),
        "departement": terr["departement"].strip(),
        "region": terr["region"].strip(),
        "nom_departement": terr.get("nom_departement", "").strip(),
        "nom_region": terr.get("nom_region", "").strip(),
        "deps_region": [d.strip() for d in terr["departements_region"].split(",") if d.strip()],
        "proxy": terr.get("proxy", "").strip() or None,
        "duree_cache": float(terr.get("duree_cache_jours", "90") or 90),
    }
    ind = x["Indicateurs"].fillna("")
    cfg["indicateurs"] = [r for r in ind.to_dict("records") if str(r.get("code", "")).strip()]
    sph = x["Spheres_NAF"].fillna("")
    cfg["spheres"] = {str(r.prefixe_ape).strip(): str(r.sphere).strip().upper()
                      for r in sph.itertuples() if str(r.prefixe_ape).strip()}
    hyp = pd.read_excel(FICHIER, sheet_name="Hypotheses")
    cfg["hypotheses"] = {r.parametre: {"bas": float(r.bas), "central": float(r.central),
                                       "haut": float(r.haut), "unite": r.unite,
                                       "commentaire": r.commentaire}
                         for r in hyp.itertuples()}
    return cfg

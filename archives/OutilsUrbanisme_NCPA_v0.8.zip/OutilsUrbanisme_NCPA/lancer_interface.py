"""Lance l'interface Streamlit des Outils Urbanisme dans le navigateur.

- installe si besoin les bibliothèques manquantes dans le dossier de
  l'utilisateur (pip --user : aucun droit administrateur nécessaire) ;
- évite la question « adresse e-mail » de Streamlit au premier lancement
  (fichier ~/.streamlit/credentials.toml créé vide, mode sans invite) ;
- ouvre le navigateur une fois le serveur prêt.
"""
import importlib.util
import os
import subprocess
import sys
import time
import urllib.request
import webbrowser

ICI = os.path.dirname(os.path.abspath(__file__))
PORT = 8512
MODULES = {"streamlit": "streamlit>=1.40", "requests": "requests", "openpyxl": "openpyxl", "shapely": "shapely",
           "pandas": "pandas"}

manquants = [paquet for nom, paquet in MODULES.items() if importlib.util.find_spec(nom) is None]
if manquants:
    print("Installation des bibliothèques manquantes : " + ", ".join(manquants))
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--user", "--quiet", *manquants])

# Streamlit demande une adresse e-mail au tout premier lancement, sauf si ce fichier existe.
dossier = os.path.join(os.path.expanduser("~"), ".streamlit")
identifiants = os.path.join(dossier, "credentials.toml")
if not os.path.exists(identifiants):
    os.makedirs(dossier, exist_ok=True)
    with open(identifiants, "w", encoding="utf-8") as f:
        f.write('[general]\nemail = ""\n')

adresse = f"http://localhost:{PORT}"
try:                                   # déjà lancé dans une autre fenêtre : on ouvre simplement la page
    urllib.request.urlopen(adresse, timeout=1)
    webbrowser.open(adresse)
    sys.exit(0)
except Exception:
    pass

print("Démarrage de l'interface (fermez cette fenêtre pour arrêter l'outil)...")
os.chdir(ICI)
serveur = subprocess.Popen([sys.executable, "-m", "streamlit", "run", os.path.join(ICI, "interface_streamlit.py"),
                            "--server.port", str(PORT), "--server.headless", "true",
                            "--browser.gatherUsageStats", "false"])
for _ in range(60):                    # attendre que le serveur réponde, puis ouvrir le navigateur
    time.sleep(0.5)
    try:
        urllib.request.urlopen(adresse, timeout=1)
        webbrowser.open(adresse)
        print(f"Interface ouverte : {adresse}")
        break
    except Exception:
        if serveur.poll() is not None:
            break
serveur.wait()

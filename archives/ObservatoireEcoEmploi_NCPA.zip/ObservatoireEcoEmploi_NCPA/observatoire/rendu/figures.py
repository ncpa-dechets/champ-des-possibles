# -*- coding: utf-8 -*-
"""Graphiques interactifs (Plotly), dessinés à partir de la description « graph » de chaque bloc.

Les mêmes figures servent dans l'interface et dans le rapport HTML. La barre d'outils Plotly est réduite à une
seule icône (appareil photo, visible au survol) qui enregistre le graphique en PNG : c'est l'« export image
discret » demandé. Le titre et la source sont inscrits dans la figure, pour que l'image se suffise à elle-même.
"""
import plotly.graph_objects as go
from plotly.subplots import make_subplots

ROUGE, VERT, GRIS, GRIS_F, NOIR, NAVY = "#B91E27", "#B1B993", "#C8CBCF", "#5B6770", "#222222", "#1F3A5F"
PALETTE = [GRIS_F, "#7D8A5B", "#D98C8F", "#9DA7B0", NAVY, "#E0A030", "#3B3B3B", VERT]
COULEURS = {"cible": ROUGE, "neutre": GRIS, "positif": "#3A7D2C", "negatif": ROUGE, "navy": NAVY, "accent": "#D98C8F"}
POLICE = "Calibri, Carlito, 'Segoe UI', system-ui, sans-serif"


def config(nom="graphique"):
    """Barre d'outils réduite à l'export PNG (icône au survol)."""
    return {"displaylogo": False, "displayModeBar": "hover", "modeBarButtons": [["toImage"]], "responsive": True,
            "toImageButtonOptions": {"format": "png", "filename": nom[:60], "scale": 2}}


def _fmt(fmt):
    """-> (format d3 des axes, suffixe, format du survol)."""
    return {
        "nombre": (",.0f", "", ",.0f"), "nombre1": (",.1f", "", ",.1f"), "nombre2": (",.2f", "", ",.2f"),
        "nombre_s": ("+,.0f", "", "+,.0f"), "frac": (".0%", "", ".1%"), "frac_s": ("+.0%", "", "+.1%"),
        "pct": (",.0f", " %", ",.1f"), "eur": (",.0f", " €", ",.0f"),
    }.get(fmt, (",.1f", "", ",.1f"))


def _deviner_fmt(g):
    if g.get("fmt"):
        return g["fmt"]
    lab = (g.get("ylabel") or "") + (g.get("xlabel") or "")
    if "%" in lab:
        return "pct"
    return "nombre1" if g.get("dec", 0) else "nombre"


def _nan(v):
    return None if v is None or (isinstance(v, float) and v != v) else v


def _base(fig, titre, source, hauteur, legende=True):
    """Titre et source en haut (l'image exportée se suffit), légende sous le graphique."""
    texte = f"<b>{titre}</b>" if titre else ""
    if source:
        texte += f"<br><span style='font-size:11px;color:#777'>Source : {source}</span>"
    haut = (58 if source else 38) if texte else 16
    fig.update_layout(
        title={"text": texte or None, "x": 0, "xanchor": "left", "y": 1, "yanchor": "top", "yref": "container", "pad": {"t": 16},
               "font": {"size": 15}},
        font={"family": POLICE, "size": 12.5, "color": NOIR}, separators=", ", height=hauteur + haut,
        paper_bgcolor="white", plot_bgcolor="white", margin={"l": 10, "r": 30, "t": haut + 14, "b": 30},
        legend={"orientation": "h", "y": -0.1, "yanchor": "top", "x": 0, "font": {"size": 11.5}} if legende else {},
        hoverlabel={"font": {"family": POLICE}}, showlegend=legende)
    fig.update_xaxes(gridcolor="#EEEEEE", zerolinecolor="#BBBBBB", automargin=True)
    fig.update_yaxes(gridcolor="#EEEEEE", zerolinecolor="#BBBBBB", automargin=True)
    return fig


def _hauteur_barres(n):
    return max(300, min(1600, 24 * n + 140))


def figure(g, titre="", source=""):
    """Figure Plotly pour une description de graphique (hors « variantes »)."""
    k = g["kind"]
    f = globals().get(f"_k_{k}")
    if f is None:
        raise ValueError(f"type de graphique inconnu : {k}")
    return f(g, titre, source)


# ---------------------------------------------------------------------------------------------- types
def _k_lines(g, titre, source):
    fmt = _deviner_fmt(g)
    ax, suf, hov = _fmt(fmt)
    fig = go.Figure()
    x = [str(v) for v in g["x"]]
    autres = iter(PALETTE)
    for nom, v in g["series"].items():
        if v is None:
            continue
        cible = nom == g.get("cible")
        fig.add_trace(go.Scatter(
            x=x, y=[_nan(a) for a in v], name=nom, mode="lines+markers" if len(x) <= 25 else "lines",
            line={"color": ROUGE if cible else next(autres, GRIS_F), "width": 3 if cible else 2,
                  "dash": "dash" if str(nom).startswith("Médiane") else "solid"},
            marker={"size": 6 if cible else 4}, hovertemplate=f"%{{x}} : %{{y:{hov}}}{suf}<extra>{nom}</extra>"))
    if g.get("ligne_ref") is not None:
        fig.add_hline(y=g["ligne_ref"], line={"color": "#999", "width": 1})
    if g.get("bandes_t3"):
        for i, p in enumerate(x):
            if p.endswith("T3"):
                fig.add_vrect(x0=i - .5, x1=i + .5, fillcolor="#DDDDDD", opacity=.35, line_width=0, layer="below")
    fig.update_yaxes(tickformat=ax, ticksuffix=suf, title=g.get("ylabel"))
    fig.update_xaxes(type="category", tickangle=-45 if len(x) > 12 else 0, nticks=min(len(x), 24))
    return _base(fig, titre, source, 420)


def _k_area(g, titre, source):
    fig = go.Figure()
    x = [str(v) for v in g["x"]]
    pal = [ROUGE, VERT] + PALETTE
    for i, (nom, v) in enumerate(g["series"].items()):
        fig.add_trace(go.Scatter(x=x, y=v, name=str(nom), stackgroup="un", mode="lines",
                                 line={"width": .5, "color": pal[i % len(pal)]},
                                 hovertemplate=f"%{{x}} : %{{y:,.0f}}<extra>{nom}</extra>"))
    fig.update_yaxes(tickformat=",.0f", title=g.get("ylabel"))
    fig.update_xaxes(type="category")
    return _base(fig, titre, source, 420)


def _k_barh_compare(g, titre, source):
    fmt = _deviner_fmt(g)
    ax, suf, hov = _fmt(fmt)
    n = len(g["labels"])
    cols = [ROUGE if c else GRIS for c in g["cible"]]
    fig = go.Figure(go.Bar(y=g["labels"], x=[_nan(v) for v in g["values"]], orientation="h", marker_color=cols,
                           hovertemplate=f"%{{y}} : %{{x:{hov}}}{suf}<extra></extra>"))
    if n <= 60:
        fig.update_traces(texttemplate=f"%{{x:{hov}}}{suf}", textposition="outside", textfont={"size": 10.5})
    for i, (lib, v) in enumerate((g.get("refs") or {}).items()):
        if _nan(v) is not None:
            fig.add_vline(x=v, line={"color": GRIS_F, "dash": "dash" if i == 0 else "dot", "width": 1.2},
                          annotation_text=f"{lib}", annotation_position="top", annotation_font_size=10.5)
    fig.update_xaxes(tickformat=ax, ticksuffix=suf, title=g.get("xlabel"))
    fig.update_yaxes(type="category", showticklabels=n <= 80, tickfont={"size": 10.5 if n < 40 else 8.5})
    return _base(fig, titre, source, _hauteur_barres(n), legende=False)


def _k_barh_simple(g, titre, source):
    fmt = _deviner_fmt(g)
    ax, suf, hov = _fmt(fmt)
    n = len(g["labels"])
    if g.get("intensite"):
        marker = {"color": g["intensite"], "colorscale": [[0, "#F2D6CF"], [1, "#8C1C22"]], "cmin": 0, "cmax": 1,
                  "colorbar": {"title": "Part<br>difficiles", "tickformat": ".0%", "len": .6}}
    elif g.get("couleurs"):
        marker = {"color": [COULEURS.get(c, c) for c in g["couleurs"]]}
    else:
        marker = {"color": ROUGE}
    textes = g.get("textes")
    fig = go.Figure(go.Bar(y=g["labels"], x=[_nan(v) for v in g["values"]], orientation="h", marker=marker,
                           customdata=textes or [""] * n,
                           hovertemplate=f"%{{y}} : %{{x:{hov}}}{suf}" + (" · %{customdata}" if textes else "") +
                           "<extra></extra>"))
    if textes:
        fig.update_traces(text=textes, textposition="outside", textfont={"size": 10})
    elif n <= 50:
        fig.update_traces(texttemplate=f"%{{x:{hov}}}{suf}", textposition="outside", textfont={"size": 10})
    if g.get("ligne_v") is not None:
        fig.add_vline(x=g["ligne_v"], line={"color": NOIR, "width": 1, "dash": "dash" if g["ligne_v"] else "solid"})
    fig.update_xaxes(tickformat=ax, ticksuffix=suf, title=g.get("xlabel"))
    fig.update_yaxes(type="category", tickfont={"size": 10.5 if n < 40 else 8.5})
    fig.update_layout(uniformtext_minsize=8)
    return _base(fig, titre, source, _hauteur_barres(n), legende=False)


def _k_barh_groupes(g, titre, source):
    ax, suf, hov = _fmt(_deviner_fmt(g))
    n = len(g["labels"])
    fig = go.Figure()
    for i, (nom, v) in enumerate(g["series"].items()):
        fig.add_trace(go.Bar(y=g["labels"], x=[_nan(a) for a in v], name=nom, orientation="h",
                             marker_color=[ROUGE, GRIS_F, VERT][i % 3],
                             hovertemplate=f"%{{y}} : %{{x:{hov}}}{suf}<extra>{nom}</extra>"))
    fig.update_layout(barmode="group", bargap=.25)
    fig.update_xaxes(tickformat=ax, ticksuffix=suf)
    fig.update_yaxes(type="category", tickfont={"size": 10.5})
    return _base(fig, titre, source, _hauteur_barres(n * 1.6))


def _k_barh_stack(g, titre, source):
    ax, suf, hov = _fmt(_deviner_fmt(g))
    fig = go.Figure()
    for i, (nom, v) in enumerate(g["series"].items()):
        fig.add_trace(go.Bar(y=g["labels"], x=v, name=nom, orientation="h", marker_color=["#E0A030", GRIS][i % 2],
                             hovertemplate=f"%{{y}} : %{{x:{hov}}}{suf}<extra>{nom}</extra>"))
    fig.update_layout(barmode="stack")
    fig.update_xaxes(tickformat=ax)
    fig.update_yaxes(type="category", tickfont={"size": 10.5})
    return _base(fig, titre, source, _hauteur_barres(len(g["labels"])))


def _k_stack100(g, titre, source):
    fig = go.Figure()
    pal = [ROUGE, VERT, GRIS_F, "#D98C8F", "#7D8A5B", "#9DA7B0"]
    for i, (nom, v) in enumerate(g["series"].items()):
        fig.add_trace(go.Bar(y=g["labels"], x=[_nan(a) for a in v], name=nom, orientation="h",
                             marker_color=pal[i % len(pal)], texttemplate="%{x:.0f}", textposition="inside",
                             hovertemplate=f"%{{y}} : %{{x:.1f}} %<extra>{nom}</extra>"))
    fig.update_layout(barmode="stack")
    fig.update_xaxes(range=[0, 100], ticksuffix=" %", title="% des emplois")
    fig.update_yaxes(autorange="reversed", type="category")
    return _base(fig, titre, source, 340)


def _k_bars_group(g, titre, source):
    ax, suf, hov = _fmt(_deviner_fmt(g))
    fig = go.Figure()
    cats = list(g["series"])
    autres = iter(PALETTE)
    for j, lab in enumerate(g["labels"]):
        vals = [_nan(g["series"][c][j]) for c in cats]
        fig.add_trace(go.Bar(x=cats, y=vals, name=lab, marker_color=ROUGE if lab == g.get("cible") else next(autres, GRIS),
                             texttemplate=f"%{{y:{hov}}}", textposition="outside", textfont={"size": 10},
                             hovertemplate=f"%{{x}} : %{{y:{hov}}}{suf}<extra>{lab}</extra>"))
    fig.update_layout(barmode="group")
    fig.update_yaxes(tickformat=ax, ticksuffix=suf, title=g.get("ylabel"))
    return _base(fig, titre, source, 420)


def _k_bars(g, titre, source):
    ax, suf, hov = _fmt(_deviner_fmt(g))
    cols = [COULEURS.get(c, c) for c in g.get("couleurs") or [ROUGE] * len(g["labels"])]
    fig = go.Figure(go.Bar(x=g["labels"], y=g["values"], marker_color=cols, texttemplate=f"%{{y:{hov}}}",
                           textposition="outside", hovertemplate=f"%{{x}} : %{{y:{hov}}}{suf}<extra></extra>"))
    fig.add_hline(y=0, line={"color": NOIR, "width": 1})
    fig.update_yaxes(tickformat=ax, ticksuffix=suf, title=g.get("ylabel"))
    return _base(fig, titre, source, 400, legende=False)


def _k_bars_line(g, titre, source):
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    x = [str(v) for v in g["x"]]
    for i, (nom, v) in enumerate(g["barres"].items()):
        fig.add_trace(go.Bar(x=x, y=v, name=nom, marker_color=["#3A7D2C", GRIS][i % 2],
                             customdata=[abs(a) if a is not None else None for a in v],
                             hovertemplate=f"%{{x}} : %{{customdata:,.0f}}<extra>{nom}</extra>"), secondary_y=False)
    for nom, v in (g.get("ligne") or {}).items():
        if any(a is not None for a in v):
            fig.add_trace(go.Scatter(x=x, y=v, name=nom, mode="lines+markers", line={"color": ROUGE, "width": 3},
                                     hovertemplate=f"%{{x}} : %{{y:,.0f}}<extra>{nom}</extra>"), secondary_y=True)
    fig.update_layout(barmode="relative")
    fig.update_yaxes(tickformat=",.0f", secondary_y=False)
    fig.update_yaxes(rangemode="tozero", secondary_y=True, showgrid=False)
    fig.update_xaxes(type="category")
    return _base(fig, titre, source, 430)


def _k_emploi_actifs(g, titre, source):
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    x = [str(v) for v in g["x"]]
    fig.add_trace(go.Bar(x=x, y=g["emplois"], name="Emplois au lieu de travail", marker_color=ROUGE,
                         hovertemplate="%{x} : %{y:,.0f}<extra>Emplois</extra>"), secondary_y=False)
    fig.add_trace(go.Bar(x=x, y=g["actifs"], name="Actifs occupés résidents", marker_color=VERT,
                         hovertemplate="%{x} : %{y:,.0f}<extra>Actifs occupés</extra>"), secondary_y=False)
    fig.add_trace(go.Scatter(x=x, y=g["ice"], name="Concentration d'emploi (axe droit)", mode="lines+markers+text",
                             line={"color": NOIR}, texttemplate="%{y:.1f}", textposition="top center",
                             hovertemplate="%{x} : %{y:.1f}<extra>Concentration d'emploi</extra>"), secondary_y=True)
    vals = [v for v in g["ice"] if v == v]
    if vals:
        fig.update_yaxes(range=[min(vals) * .8, max(vals) * 1.15], secondary_y=True, showgrid=False)
    fig.update_layout(barmode="group")
    fig.update_yaxes(tickformat=",.0f", secondary_y=False)
    return _base(fig, titre, source, 420)


def _k_base_eco(g, titre, source):
    labs = [l.replace(" : ", "<br>") for l in g["labels"]]
    cols = [ROUGE if l.startswith("Productive") else GRIS_F if l.startswith("Publique")
            else VERT if l.startswith("Résidentielle") else "#9DA7B0" for l in g["labels"]]
    lo = [min(t) for t in zip(g["bas"], g["central"], g["haut"])]
    hi = [max(t) for t in zip(g["bas"], g["central"], g["haut"])]
    fig = go.Figure(go.Bar(
        y=labs, x=g["central"], orientation="h", marker_color=cols,
        error_x={"type": "data", "symmetric": False, "array": [h - c for c, h in zip(g["central"], hi)],
                 "arrayminus": [c - b for c, b in zip(g["central"], lo)], "color": NOIR, "thickness": 1},
        customdata=list(zip(lo, hi)),
        hovertemplate="%{y}<br>central : %{x:,.1f} M€<br>fourchette : %{customdata[0]:,.1f} à %{customdata[1]:,.1f} M€"
                      "<extra></extra>"))
    fig.update_yaxes(autorange="reversed", tickfont={"size": 10.5})
    fig.update_xaxes(title="Millions d'euros par an (scénario central, fourchette bas-haut)", tickformat=",.0f")
    return _base(fig, titre, source, 470, legende=False)


def _k_saison(g, titre, source):
    pan = g["panneaux"][:4]
    lignes = 2 if len(pan) > 2 else 1
    fig = make_subplots(rows=lignes, cols=2 if len(pan) > 1 else 1, subplot_titles=[p["titre"] for p in pan],
                        vertical_spacing=.18, horizontal_spacing=.08)
    vus = set()
    for i, p in enumerate(pan):
        rr, cc = i // 2 + 1, i % 2 + 1
        for j, (terr, vals) in enumerate(p["territoires"].items()):
            base = terr.split(" (amplitude")[0]
            coul = ROUGE if base == str(p.get("cible", ""))[:len(base)] or j == 0 else [GRIS_F, VERT, NAVY][j % 3]
            fig.add_trace(go.Bar(x=["T1", "T2", "T3", "T4"], y=vals, name=base, marker_color=coul,
                                 legendgroup=base, showlegend=base not in vus, text=[terr.split("(")[-1].rstrip(")")] * 4,
                                 hovertemplate="%{x} : %{y:+.1%}<extra>" + terr + "</extra>"), row=rr, col=cc)
            vus.add(base)
    fig.update_layout(barmode="group")
    fig.update_traces(texttemplate=None)
    fig.update_yaxes(tickformat="+.0%")
    fig.update_annotations(font_size=11.5)
    return _base(fig, titre, source, 640 if lignes == 2 else 380)

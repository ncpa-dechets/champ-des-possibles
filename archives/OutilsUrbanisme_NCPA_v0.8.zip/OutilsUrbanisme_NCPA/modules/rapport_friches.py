"""Rapport HTML autonome du thème « Friches » (Chart.js embarqué, charte NCPA).
Élément central : la répartition des surfaces en friche selon leur statut,
les friches sans projet formant le gisement à examiner pour le ZAN."""
import json
from collections import Counter

from . import friches as F
from .chemins import chemin_ressource


def generer(chemin, resultat, communes, params):
    noms = {c["code"]: c["nom"] for c in communes}
    sites = resultat["sites"]
    total = next((l for l in resultat["lignes"] if l["niveau"] in ("EPCI", "Sélection")), None) \
        or (resultat["lignes"][0] if resultat["lignes"] else {})
    types = Counter((s["type"] or "non renseigné") for s in sites)
    pollution = Counter((s["attr"].get("sol_pollution_existe") or "non renseigné") for s in sites)
    donnees = {
        "nom": total.get("nom", params.get("titre", "")),
        "statuts": F.STATUTS,
        "total": {k: v for k, v in total.items() if isinstance(v, (int, float))},
        "communes": [l for l in resultat["lignes"] if l["niveau"] == "Commune" and l["n"]],
        "comparaison": [l for l in resultat["lignes"] if l["niveau"] != "Commune"],
        "types": types.most_common(12), "pollution": pollution.most_common(8),
        "sites": sorted([{"commune": noms.get(s["commune"], s["commune"]), "nom": s["nom"],
                          "statut": F.LIB_STATUT.get(s["statut"], "Autre"), "type": s["type"],
                          "surface": round(s["surface_m2"] / 10000, 2) if s["surface_m2"] else None,
                          "occupation": s["attr"].get("site_occupation", "")} for s in sites],
                        key=lambda x: -(x["surface"] or 0)),
        "version": resultat["meta"].get("maj"),
    }
    with open(chemin_ressource("donnees/chart.umd.min.js"), encoding="utf-8") as f:
        chartjs = f.read()
    html = (GABARIT.replace("/*CHARTJS*/", chartjs)
            .replace("__TITRE__", params.get("titre", "NCPA"))
            .replace("__DATE__", params.get("date", ""))
            .replace("__COMMUNES__", params.get("communes", ""))
            .replace("__DONNEES__", json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")))
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(html)


GABARIT = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Friches · __TITRE__</title>
<style>
:root{--rouge:#B91E27;--vert:#B1B993;--encre:#1F2A2E;--doux:#5E6A6E;--brume:#F3F4EF;--trait:#DCDDD3}
*{box-sizing:border-box}
body{margin:0;font-family:Calibri,"Segoe UI",system-ui,sans-serif;color:var(--encre);background:#fff;line-height:1.45}
header{border-left:8px solid var(--rouge);padding:22px 32px 18px;border-bottom:1px solid var(--trait)}
.eyebrow{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--rouge);font-weight:700}
h1{font-size:30px;margin:4px 0 2px;font-weight:700}
.sous{color:var(--doux);font-size:15px}
main{max-width:1080px;margin:0 auto;padding:8px 32px 48px}
h2{font-size:21px;margin:40px 0 4px}
.chapo{color:var(--doux);margin:0 0 14px;max-width:72ch}
.gisement{margin-top:28px;padding:24px 28px;background:var(--brume);border-radius:6px}
.phrase{font-size:24px;max-width:38ch;margin:0 0 22px;line-height:1.3}
.phrase b{color:var(--rouge)}
.bande{display:flex;height:34px;border-radius:4px;overflow:hidden;border:1px solid var(--trait);background:#fff}
.bande span{height:100%}
.legende{display:flex;flex-wrap:wrap;gap:18px;margin-top:10px;font-size:14px}
.legende i{display:inline-block;width:12px;height:12px;border-radius:2px;margin-right:6px;vertical-align:-1px}
.avert{margin-top:16px;font-size:14px;color:var(--doux);max-width:80ch}
.cadre{position:relative;height:320px}
.cadre.grand{height:auto}
.duo{display:grid;grid-template-columns:1fr 1fr;gap:28px}
table{border-collapse:collapse;width:100%;font-size:14px;margin-top:8px}
th{background:var(--encre);color:#fff;padding:7px 8px;text-align:left;font-weight:700}
td{padding:5px 8px;border-bottom:1px solid var(--trait)}
td.n,th.n{text-align:right}
tr.comp td{background:var(--brume);font-weight:700}
.tableau{overflow-x:auto}
.methode{font-size:14px;color:var(--doux);max-width:80ch}
.methode li{margin-bottom:6px}
footer{margin-top:40px;font-size:13px;color:var(--doux);border-top:1px solid var(--trait);padding-top:10px}
@media print{.gisement,.cadre{break-inside:avoid}h2{break-after:avoid}}
@media (max-width:760px){main,header{padding-left:16px;padding-right:16px}.phrase{font-size:19px}h1{font-size:24px}.duo{grid-template-columns:1fr}}
</style>
</head>
<body>
<header>
  <div class="eyebrow">NCPA · Observatoire foncier</div>
  <h1>Friches recensées</h1>
  <div class="sous" id="sous"></div>
</header>
<main>
  <section class="gisement">
    <p class="phrase" id="phrase"></p>
    <div class="bande" id="bande" role="img"></div>
    <div class="legende" id="legende"></div>
    <p class="avert">L'inventaire national n'est pas exhaustif : il dépend des sources nationales et des observatoires locaux transmis au Cerema. Une commune sans site recensé n'est pas forcément une commune sans friche.</p>
  </section>

  <section id="blocCommunes">
    <h2>Commune par commune</h2>
    <p class="chapo">Surface des sites recensés, par statut. Seules les communes ayant au moins un site apparaissent.</p>
    <div class="cadre grand" id="cadreCommunes"><canvas id="gCommunes"></canvas></div>
  </section>

  <div class="duo">
    <section><h2>Types de friches</h2><p class="chapo">Nombre de sites.</p><div class="cadre"><canvas id="gTypes"></canvas></div></section>
    <section><h2>Pollution des sols</h2><p class="chapo">Nombre de sites, selon l'information disponible.</p><div class="cadre"><canvas id="gPollution"></canvas></div></section>
  </div>

  <section id="blocComp">
    <h2>Comparaison</h2>
    <p class="chapo">Sites recensés et surfaces. À lire avec prudence : les écarts reflètent aussi la présence ou non d'un observatoire local des friches.</p>
    <div class="tableau"><table id="tComp"></table></div>
  </section>

  <h2>Liste des sites</h2>
  <div class="tableau"><table id="tSites"></table></div>

  <h2>Méthode et précautions</h2>
  <ul class="methode">
    <li>Source : Cerema, inventaire national des friches Cartofriches, version du <span id="version"></span> (data.gouv.fr, standard CNIG Friches).</li>
    <li>Statuts : sans projet, avec projet, potentielle (friche supposée, à confirmer sur le terrain), reconvertie ; les autres valeurs sont regroupées en « autre ou inconnu ».</li>
    <li>Surface : celle de l'unité foncière déclarée dans l'inventaire ; à défaut, calculée à partir du contour du site.</li>
    <li>Lien avec le ZAN : reconvertir une friche permet de construire sans consommer d'espaces naturels, agricoles ou forestiers.</li>
  </ul>
  <footer>Rapport produit le __DATE__ par Outils Urbanisme · NCPA · Communes : __COMMUNES__</footer>
</main>
<script>/*CHARTJS*/</script>
<script>
const D = __DONNEES__, T = D.total;
const f = (v, d=1) => v==null || isNaN(v) ? "" : Number(v).toLocaleString("fr-FR",{maximumFractionDigits:d, minimumFractionDigits:d});
Chart.defaults.font.family = 'Calibri, "Segoe UI", system-ui, sans-serif'; Chart.defaults.font.size = 13; Chart.defaults.color = "#1F2A2E";
document.getElementById("sous").textContent = `${D.nom} · inventaire Cartofriches du ${D.version || "?"}`;
document.getElementById("version").textContent = D.version || "?";

// ---------- gisement
const sp = T["s_friche sans projet"] || 0, nsp = T["n_friche sans projet"] || 0;
document.getElementById("phrase").innerHTML = T.n ?
  `<b>${T.n} site${T.n>1?"s":""}</b> recensé${T.n>1?"s":""} sur ${f(T.surface)} ha, dont <b>${f(sp)} ha sans projet</b> (${nsp} site${nsp>1?"s":""}) : un gisement à examiner avant d'ouvrir de nouveaux terrains à l'urbanisation.` :
  "Aucun site recensé dans l'inventaire national sur les communes choisies.";
if (T.surface > 0) {
  document.getElementById("bande").innerHTML = D.statuts.map(([k,l,c]) => {
    const v = T["s_" + k] || 0; return v ? `<span style="width:${v / T.surface * 100}%;background:${c}" title="${l} : ${f(v)} ha"></span>` : ""; }).join("");
  document.getElementById("bande").setAttribute("aria-label", D.statuts.map(([k,l]) => `${l} ${f(T["s_"+k]||0)} ha`).join(", "));
  document.getElementById("legende").innerHTML = D.statuts.map(([k,l,c]) =>
    `<span><i style="background:${c}"></i>${l} : ${f(T["s_"+k]||0)} ha (${T["n_"+k]||0})</span>`).join("");
} else { document.getElementById("bande").style.display = "none"; }

// ---------- communes
const C = D.communes.slice().sort((a,b) => b.surface - a.surface);
if (C.length > 1) {
  document.getElementById("cadreCommunes").style.height = (C.length * 26 + 90) + "px";
  new Chart(document.getElementById("gCommunes"), {type:"bar",
    data:{labels:C.map(c => c.nom), datasets:D.statuts.map(([k,l,c]) => ({label:l, data:C.map(x => x["s_"+k] || 0), backgroundColor:c}))},
    options:{indexAxis:"y", maintainAspectRatio:false, plugins:{legend:{position:"top"},
      tooltip:{callbacks:{label:x => `${x.dataset.label} : ${f(x.raw,2)} ha`}}},
      scales:{x:{stacked:true, title:{display:true, text:"hectares"}}, y:{stacked:true, grid:{display:false}, ticks:{autoSkip:false}}}}});
} else { document.getElementById("blocCommunes").style.display = "none"; }

// ---------- types et pollution
const barres = (id, paires, couleur) => new Chart(document.getElementById(id), {type:"bar",
  data:{labels:paires.map(p => p[0]), datasets:[{data:paires.map(p => p[1]), backgroundColor:couleur}]},
  options:{indexAxis:"y", maintainAspectRatio:false, plugins:{legend:{display:false}},
    scales:{x:{ticks:{precision:0}}, y:{grid:{display:false}}}}});
barres("gTypes", D.types, "#4F6D7A"); barres("gPollution", D.pollution, "#B91E27");

// ---------- comparaison
if (D.comparaison.length) {
  document.getElementById("tComp").innerHTML = `<thead><tr><th>Territoire</th><th class="n">Sites recensés</th><th class="n">Surface (ha)</th><th class="n">Sites sans projet</th></tr></thead><tbody>` +
    D.comparaison.map(l => `<tr class="comp"><td>${l.nom}</td><td class="n">${l.n}</td><td class="n">${f(l.surface)}</td><td class="n">${l["n_friche sans projet"] ?? ""}</td></tr>`).join("") + "</tbody>";
} else { document.getElementById("blocComp").style.display = "none"; }

// ---------- liste
document.getElementById("tSites").innerHTML = `<thead><tr><th>Commune</th><th>Site</th><th>Statut</th><th>Type</th><th class="n">Surface (ha)</th><th>Occupation</th></tr></thead><tbody>` +
  D.sites.map(s => `<tr><td>${s.commune}</td><td>${s.nom||""}</td><td>${s.statut}</td><td>${s.type||""}</td><td class="n">${f(s.surface,2)}</td><td>${s.occupation||""}</td></tr>`).join("") + "</tbody>";
</script>
</body>
</html>
"""

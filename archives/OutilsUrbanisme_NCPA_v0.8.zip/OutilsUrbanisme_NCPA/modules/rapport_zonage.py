"""Rapport HTML autonome du thème « Zonage » (Chart.js embarqué, charte NCPA).

Élément central : la couverture du territoire par les documents
d'urbanisme, puis la répartition des surfaces entre zones urbaines, à
urbaniser, agricoles et naturelles. Les zones à urbaniser (AU) sont mises
en avant : ce sont les réserves foncières, à rapprocher de l'enveloppe ZAN.
"""
import json

from . import servitudes as S
from . import zonage as Z
from .carte_zonage import _date
from .chemins import chemin_ressource


def _matrice(bilan, communes, libelle):
    """{colonnes: [(code, libellé)], lignes: [{nom, cellules: {code: {nombre, ha, m}}}], totaux}."""
    codes = sorted({k for b in bilan.values() for k in b})
    if not codes:
        return None
    lignes, totaux = [], {k: {"nombre": 0, "ha": 0.0, "m": 0.0, "communes": 0} for k in codes}
    for l in communes:
        cell = bilan.get(l["code"], {})
        lignes.append({"nom": l["nom"], "cellules": cell})
        for k, v in cell.items():
            t = totaux[k]
            t["nombre"] += v["nombre"]
            t["ha"] += v["ha"]
            t["m"] += v["m"]
            t["communes"] += 1
    return {"colonnes": [libelle(k) for k in codes], "lignes": lignes, "totaux": totaux}


def generer(chemin, resultat, params):
    lignes = resultat["lignes"]
    communes = [l for l in lignes if l["niveau"] == "Commune"]
    total = next((l for l in lignes if l["niveau"] != "Commune"), communes[0] if communes else {})
    docs = []
    for l in communes:
        d = l["document"] or {}
        docs.append({"commune": l["nom"], "statut": l["statut"], "nom": d.get("nom") or "",
                     "partition": d.get("partition") or "", "approbation": _date(d.get("approbation")),
                     "etat": d.get("etat") or "", "maj": _date(d.get("maj"))})
    zones_detail = {}
    for code, fams in resultat["details"].items():
        for fam, libs in fams.items():
            for lib, ha in libs.items():
                cle = (fam, lib)
                zones_detail[cle] = zones_detail.get(cle, 0) + ha
    detail = sorted(({"famille": Z.LIB_FAMILLE[f], "libelle": lib, "ha": round(ha, 1)}
                     for (f, lib), ha in zones_detail.items()), key=lambda x: -x["ha"])
    donnees = {
        "nom": total.get("nom", ""), "familles": Z.FAMILLES,
        "total": {k: v for k, v in total.items() if isinstance(v, (int, float))},
        "communes": [{k: v for k, v in l.items() if k != "document"} for l in communes],
        "documents": docs, "detail": detail, "date": resultat["date"],
        "sup": _matrice(resultat.get("bilan_sup", {}), communes, lambda c: (c, S.libelle_sup(c))),
        "psc": _matrice(resultat.get("bilan_psc", {}), communes,
                        lambda t: (t, resultat.get("types_psc", {}).get(t, t))),
        "croisement": resultat.get("croisement"), "origines": resultat.get("origines", []),
        "points": [{k: p.get(k) for k in ("source", "nom", "commune_code", "famille_lib", "zone", "servitudes",
                                          "prescriptions", "logements", "a_venir", "statut", "surface_ha")}
                   for p in resultat.get("points", [])],
        "noms": {l["code"]: l["nom"] for l in communes},
        "familles_ordre": [l for _k, l, _c in Z.FAMILLES] + ["Hors zonage (RNU ou non couvert)"],
        "couleurs_familles": {l: c for _k, l, c in Z.FAMILLES} | {"Hors zonage (RNU ou non couvert)": "#BDBDB5"},
    }
    with open(chemin_ressource("donnees/chart.umd.min.js"), encoding="utf-8") as f:
        chartjs = f.read()
    html = (GABARIT.replace("/*CHARTJS*/", chartjs)
            .replace("__TITRE__", params.get("titre", "NCPA"))
            .replace("__DATE__", params.get("date", ""))
            .replace("__COMMUNES__", params.get("communes", ""))
            .replace("__DONNEES__", json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")))
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(html)


GABARIT = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Zonage · __TITRE__</title>
<style>
:root{--rouge:#B91E27;--vert:#B1B993;--encre:#1F2A2E;--doux:#5E6A6E;--brume:#F3F4EF;--trait:#DCDDD3}
*{box-sizing:border-box}
body{margin:0;font-family:Calibri,"Segoe UI",system-ui,sans-serif;color:var(--encre);background:#fff;line-height:1.45}
header{border-left:8px solid var(--rouge);padding:22px 32px 18px;border-bottom:1px solid var(--trait)}
.eyebrow{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--rouge);font-weight:700}
h1{font-size:30px;margin:4px 0 2px;font-weight:700}
.sous{color:var(--doux);font-size:15px}
main{max-width:1080px;margin:0 auto;padding:8px 32px 48px}
h2{font-size:21px;margin:40px 0 4px}
.chapo{color:var(--doux);margin:0 0 14px;max-width:72ch}
.couverture{margin-top:28px;padding:24px 28px;background:var(--brume);border-radius:6px}
.phrase{font-size:23px;max-width:40ch;margin:0 0 20px;line-height:1.3}
.phrase b{color:var(--rouge)}
.bande{display:flex;height:34px;border-radius:4px;overflow:hidden;border:1px solid var(--trait);background:#fff}
.bande span{height:100%}
.legende{display:flex;flex-wrap:wrap;gap:16px;margin-top:10px;font-size:14px}
.legende i{display:inline-block;width:12px;height:12px;border-radius:2px;margin-right:6px;vertical-align:-1px;border:1px solid rgba(0,0,0,.2)}
.cadre{position:relative;height:320px}
.cadre.grand{height:auto}
details table{margin-top:8px}
table{border-collapse:collapse;width:100%;font-size:14px;margin-top:8px}
th{background:var(--encre);color:#fff;padding:7px 8px;text-align:left;font-weight:700}
td{padding:5px 8px;border-bottom:1px solid var(--trait)}
td.n,th.n{text-align:right}
.tableau{overflow-x:auto}
.methode{font-size:14px;color:var(--doux);max-width:80ch}
.methode li{margin-bottom:6px}
footer{margin-top:40px;font-size:13px;color:var(--doux);border-top:1px solid var(--trait);padding-top:10px}
@media print{.couverture,.cadre{break-inside:avoid}h2{break-after:avoid}}
@media (max-width:700px){main,header{padding-left:16px;padding-right:16px}.phrase{font-size:19px}h1{font-size:24px}}
</style>
</head>
<body>
<header>
  <div class="eyebrow">NCPA · Observatoire foncier</div>
  <h1>Zonage, servitudes et prescriptions</h1>
  <div class="sous" id="sous"></div>
</header>
<main>
  <section class="couverture">
    <p class="phrase" id="phrase"></p>
    <div class="bande" id="bande" role="img"></div>
    <div class="legende" id="legende"></div>
  </section>

  <section id="blocProfils">
    <h2>Profil de chaque commune</h2>
    <p class="chapo">Part de chaque type de zone dans la surface zonée de la commune. Les communes au règlement national d'urbanisme (RNU) ou sans document en ligne n'ont pas de zonage.</p>
    <div class="cadre grand" id="cadreProfils"><canvas id="gProfils"></canvas></div>
  </section>

  <section id="blocAU">
    <h2>Zones à urbaniser</h2>
    <p class="chapo">Surfaces en zone AU par commune : ouvertes à l'urbanisation (AUc) ou fermées, à ouvrir par une évolution du document (AUs). Ce sont les réserves foncières du document, à rapprocher de l'enveloppe de consommation d'espaces fixée par la loi Climat et résilience.</p>
    <div class="cadre grand" id="cadreAU"><canvas id="gAU"></canvas></div>
  </section>

  <section id="blocSup">
    <h2>Servitudes d'utilité publique</h2>
    <p class="chapo">Servitudes publiées sur le Géoportail de l'Urbanisme, découpées par commune : surface couverte (ha), longueur (m) pour les servitudes linéaires (lignes électriques, canalisations…), ou nombre d'objets ponctuels. Une case vide signifie qu'aucune servitude de cette catégorie n'est publiée sur la commune, pas forcément qu'il n'en existe aucune.</p>
    <div class="tableau"><table id="tSupTot"></table></div>
    <details style="margin-top:12px"><summary style="cursor:pointer;font-weight:700">Détail commune par commune</summary><div class="tableau"><table id="tSup"></table></div></details>
  </section>

  <section id="blocPsc">
    <h2>Prescriptions des documents d'urbanisme</h2>
    <p class="chapo">Espaces boisés classés, emplacements réservés, éléments de paysage ou de patrimoine protégés et autres prescriptions graphiques des PLU et PLUi.</p>
    <div class="tableau"><table id="tPscTot"></table></div>
    <details style="margin-top:12px"><summary style="cursor:pointer;font-weight:700">Détail commune par commune</summary><div class="tableau"><table id="tPsc"></table></div></details>
  </section>

  <section id="blocCroise">
    <h2>Permis et friches selon le zonage</h2>
    <p class="chapo" id="chapoCroise"></p>
    <div class="cadre" id="cadreCroise"><canvas id="gCroise"></canvas></div>
    <div class="tableau"><table id="tCroise"></table></div>
    <h3 style="margin-top:22px;font-size:17px">Permis et friches concernés par une servitude</h3>
    <div class="tableau"><table id="tCroiseSup"></table></div>
  </section>

  <h2>Documents d'urbanisme</h2>
  <p class="chapo">Document applicable à chaque commune, tel que publié sur le Géoportail de l'Urbanisme.</p>
  <div class="tableau"><table id="tDocs"></table></div>

  <h2>Les zones les plus étendues</h2>
  <p class="chapo">Surface totale par libellé de zone, sur les communes choisies (25 premiers).</p>
  <div class="tableau"><table id="tDetail"></table></div>

  <h2>Méthode et précautions</h2>
  <ul class="methode">
    <li>Source : Géoportail de l'Urbanisme, via l'API Carto de l'IGN (couches document, zone-urba et secteur-cc), données du <span id="date"></span>.</li>
    <li>Pour chaque commune, le document retenu est celui qui couvre un point situé à l'intérieur de la commune. Les zones sont découpées selon les limites communales (geo.api.gouv.fr) et mesurées en Lambert-93.</li>
    <li>Une commune nouvelle couverte par plusieurs documents n'est rattachée qu'à l'un d'eux. De petits écarts entre la surface zonée et la surface communale viennent des différences de tracé entre limites communales et documents d'urbanisme.</li>
    <li>Servitudes : couches assiette-sup du Géoportail, interrogées commune par commune puis découpées selon la limite communale. Leur publication dépend des gestionnaires (État, ABF, ARS, gestionnaires de réseaux) : la liste peut être incomplète.</li>
    <li>Prescriptions : couches prescription-surf, -lin et -pct de chaque document. Libellés des types d'après le standard CNIG ; à défaut, libellé le plus fréquent dans le document.</li>
    <li>Croisement : chaque permis est placé au centre de sa parcelle cadastrale, chaque friche au centre de son site ; la zone retenue est celle qui contient ce point.</li>
    <li>Seul le document en vigueur, consultable sur le Géoportail de l'Urbanisme ou en mairie, fait foi.</li>
  </ul>
  <footer>Rapport produit le __DATE__ par Outils Urbanisme · NCPA · Communes : __COMMUNES__</footer>
</main>
<script>/*CHARTJS*/</script>
<script>
const D = __DONNEES__, T = D.total;
const f = (v, d=0) => v==null || isNaN(v) ? "" : Number(v).toLocaleString("fr-FR",{maximumFractionDigits:d, minimumFractionDigits:d});
Chart.defaults.font.family = 'Calibri, "Segoe UI", system-ui, sans-serif'; Chart.defaults.font.size = 13; Chart.defaults.color = "#1F2A2E";
document.getElementById("sous").textContent = `${D.nom} · Géoportail de l'Urbanisme, données du ${D.date}`;
document.getElementById("date").textContent = D.date;

// ---------- couverture
const parStatut = {}; D.communes.forEach(c => parStatut[c.statut] = (parStatut[c.statut] || 0) + 1);
const libStatut = {"PLUi":"PLU intercommunal", "PLU":"PLU communal", "POS":"POS", "CC":"carte communale", "PSMV":"PSMV", "RNU":"règlement national (RNU)"};
const morceaux = Object.entries(parStatut).sort((a,b) => b[1]-a[1]).map(([s,n]) => `${n} ${libStatut[s] ? "sous " + libStatut[s] : "sans document en ligne"}`);
const AU = (T.AUc||0) + (T.AUs||0);
document.getElementById("phrase").innerHTML = `${D.communes.length} commune${D.communes.length>1?"s":""} : ${morceaux.join(", ")}. `
  + (T.zone ? `Sur ${f(T.zone)} ha zonés, <b>${f(AU)} ha</b> sont en zone à urbaniser, dont <b>${f(T.AUc||0)} ha</b> déjà ouverts.` : "");
if (T.zone) {
  document.getElementById("bande").innerHTML = D.familles.map(([k,l,c]) => T[k] ? `<span style="width:${T[k]/T.zone*100}%;background:${c}" title="${l} : ${f(T[k])} ha"></span>` : "").join("");
  document.getElementById("bande").setAttribute("aria-label", D.familles.filter(([k]) => T[k]).map(([k,l]) => `${l} ${f(T[k])} ha`).join(", "));
  document.getElementById("legende").innerHTML = D.familles.filter(([k]) => T[k]).map(([k,l,c]) =>
    `<span><i style="background:${c}"></i>${l} : ${f(T[k])} ha (${f(T[k]/T.zone*100,1)} %)</span>`).join("");
} else { document.getElementById("bande").style.display = "none"; }

// ---------- profils (100 %)
const zonees = D.communes.filter(c => c.zone > 0).sort((a,b) => ((b.U||0)/b.zone) - ((a.U||0)/a.zone));
const fams = D.familles.filter(([k]) => zonees.some(c => c[k] > 0));
if (zonees.length) {
  document.getElementById("cadreProfils").style.height = (zonees.length * 24 + 90) + "px";
  new Chart(document.getElementById("gProfils"), {type:"bar",
    data:{labels:zonees.map(c => c.nom), datasets:fams.map(([k,l,c]) => ({label:l, data:zonees.map(x => (x[k]||0) / x.zone * 100), backgroundColor:c}))},
    options:{indexAxis:"y", maintainAspectRatio:false, plugins:{legend:{position:"top"},
      tooltip:{callbacks:{label:x => `${x.dataset.label} : ${f(x.raw,1)} %`}}},
      scales:{x:{stacked:true, max:100, ticks:{callback:v => v + " %"}}, y:{stacked:true, grid:{display:false}, ticks:{autoSkip:false}}}}});
} else { document.getElementById("blocProfils").style.display = "none"; }

// ---------- AU
const au = D.communes.filter(c => (c.AUc||0) + (c.AUs||0) > 0).sort((a,b) => ((b.AUc||0)+(b.AUs||0)) - ((a.AUc||0)+(a.AUs||0)));
if (au.length) {
  document.getElementById("cadreAU").style.height = (au.length * 24 + 90) + "px";
  new Chart(document.getElementById("gAU"), {type:"bar",
    data:{labels:au.map(c => c.nom), datasets:[
      {label:"AUc (ouverte)", data:au.map(c => c.AUc||0), backgroundColor:"#F08C3C"},
      {label:"AUs (fermée)", data:au.map(c => c.AUs||0), backgroundColor:"#F5BE82"}]},
    options:{indexAxis:"y", maintainAspectRatio:false, plugins:{legend:{position:"top"},
      tooltip:{callbacks:{label:x => `${x.dataset.label} : ${f(x.raw,1)} ha`}}},
      scales:{x:{stacked:true, title:{display:true, text:"hectares"}}, y:{stacked:true, grid:{display:false}, ticks:{autoSkip:false}}}}});
} else { document.getElementById("blocAU").style.display = "none"; }

// ---------- tableaux
document.getElementById("tDocs").innerHTML = `<thead><tr><th>Commune</th><th>Type</th><th>Document</th><th>Approuvé le</th><th>État</th><th>Mise à jour (Géoportail)</th></tr></thead><tbody>` +
  D.documents.map(d => `<tr><td>${d.commune}</td><td>${d.statut}</td><td>${d.nom}</td><td>${d.approbation}</td><td>${d.etat}</td><td>${d.maj}</td></tr>`).join("") + "</tbody>";
// ---------- servitudes et prescriptions
function cellule(v) {
  if (!v) return "";
  if (v.ha > 0) return f(v.ha, 1) + " ha";
  if (v.m > 0) return f(v.m) + " m";
  return v.nombre + " objet" + (v.nombre > 1 ? "s" : "");
}
function matrice(M, idTot, idDet, bloc) {
  if (!M) { document.getElementById(bloc).style.display = "none"; return; }
  const codes = M.colonnes.map(c => c[0]);
  document.getElementById(idTot).innerHTML = `<thead><tr><th>Catégorie</th><th class="n">Communes concernées</th><th class="n">Objets</th><th class="n">Emprise</th></tr></thead><tbody>` +
    M.colonnes.map(([k, l]) => { const t = M.totaux[k]; return `<tr><td>${k.length <= 5 && /^[A-Z][A-Z0-9]*$/.test(k) ? k + " · " : ""}${l}</td><td class="n">${t.communes}</td><td class="n">${t.nombre}</td><td class="n">${cellule(t)}</td></tr>`; }).join("") + "</tbody>";
  document.getElementById(idDet).innerHTML = `<thead><tr><th>Commune</th>${M.colonnes.map(([k, l]) => `<th class="n" title="${l}">${/^[A-Z][A-Z0-9]*$/.test(k) && k.length <= 5 ? k : l}</th>`).join("")}</tr></thead><tbody>` +
    M.lignes.map(l => `<tr><td>${l.nom}</td>${codes.map(k => `<td class="n">${cellule(l.cellules[k])}</td>`).join("")}</tr>`).join("") + "</tbody>";
}
matrice(D.sup, "tSupTot", "tSup", "blocSup");
matrice(D.psc, "tPscTot", "tPsc", "blocPsc");

// ---------- croisement
if (D.croisement && D.points.length) {
  const X = D.croisement.par_zone;
  const lg = X.filter(x => x.source_code === "logements"), fr = X.filter(x => x.source_code === "friche");
  const totL = lg.reduce((a, x) => a + x.logements, 0);
  const horsU = lg.filter(x => !x.famille.startsWith("Urbaine")).reduce((a, x) => a + x.logements, 0);
  document.getElementById("chapoCroise").textContent = `Zone dans laquelle se trouve chaque permis ou friche (point placé au centre de la parcelle ou du site). Sources : ${D.origines.join(", ")}.`
    + (totL ? ` ${f(horsU)} des ${f(totL)} logements autorisés (${f(horsU / totL * 100)} %) se situent hors des zones urbaines.` : "");
  const sources = [...new Set(X.map(x => x.source))];
  const fams = D.familles_ordre.filter(fa => X.some(x => x.famille === fa));
  new Chart(document.getElementById("gCroise"), {type:"bar",
    data:{labels:sources, datasets:fams.map(fa => ({label:fa, backgroundColor:D.couleurs_familles[fa] || "#999",
      data:sources.map(s => { const x = X.find(y => y.source === s && y.famille === fa); return x ? x.nombre : 0; })}))},
    options:{indexAxis:"y", maintainAspectRatio:false, plugins:{legend:{position:"bottom"}},
      scales:{x:{stacked:true, title:{display:true, text:"nombre d'autorisations ou de sites"}}, y:{stacked:true, grid:{display:false}}}}});
  document.getElementById("tCroise").innerHTML = `<thead><tr><th>Type</th><th>Zone</th><th class="n">Nombre</th><th class="n">Logements</th><th class="n">dont à venir</th><th class="n">Surface de friches (ha)</th><th class="n">Friches sans projet</th></tr></thead><tbody>` +
    X.map(x => `<tr><td>${x.source}</td><td>${x.famille}</td><td class="n">${x.nombre}</td><td class="n">${x.source_code === "logements" && x.logements ? f(x.logements) : ""}</td><td class="n">${x.source_code === "logements" && x.a_venir ? f(x.a_venir) : ""}</td><td class="n">${x.surface_ha ? f(x.surface_ha, 1) : ""}</td><td class="n">${x.source_code === "friche" ? x.sans_projet : ""}</td></tr>`).join("") + "</tbody>";
  const S = D.croisement.par_servitude;
  document.getElementById("tCroiseSup").innerHTML = S.length ? `<thead><tr><th>Type</th><th>Servitude</th><th class="n">Nombre</th></tr></thead><tbody>` +
    S.map(x => `<tr><td>${x.source}</td><td>${x.categorie}</td><td class="n">${x.nombre}</td></tr>`).join("") + "</tbody>" : "<tbody><tr><td>Aucun permis ni friche dans l'emprise d'une servitude publiée.</td></tr></tbody>";
} else { document.getElementById("blocCroise").style.display = "none"; }

document.getElementById("tDetail").innerHTML = `<thead><tr><th>Zone</th><th>Type</th><th class="n">Surface (ha)</th></tr></thead><tbody>` +
  D.detail.slice(0, 25).map(z => `<tr><td>${z.libelle}</td><td>${z.famille}</td><td class="n">${f(z.ha,1)}</td></tr>`).join("") + "</tbody>";
</script>
</body>
</html>
"""

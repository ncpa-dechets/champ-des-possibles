# -*- coding: utf-8 -*-
"""Insee Melodi, interrogation par territoire (API « data ») ou fichier national (API « file »).

Vérifié par les sondes 5 et 5b du 20/10/2026 :
  - adresse https://api.insee.fr/melodi/data/<jeu>?GEO=EPCI-200065563 (ou COM-14117) : sans clé, réponse
    {"observations": [{"dimensions": {...}, "measures": {"OBS_VALUE_NIVEAU": {"value": x}}, "attributes": {...}}]} ;
  - DS_RP_LOGEMENT_PRINC : dimension OCS (DW_MAIN, DW_SEC_DW_OCC = résidences secondaires et logements
    occasionnels, DW_VAC, _T), RP_MEASURE = DWELLINGS, recensements 2012, 2017 et 2023 ;
  - DS_FLORES_A38 : 2024, FLORES_MEASURE EMPL3112 (postes salariés fin d'année) et UNIT_LOC (établissements),
    NUMBER_EMPL (tranches, _T), ACTIVITY en 38 postes, une seule forme juridique (1T9X7 = toutes) ;
  - DS_SIDE_CREA_COM : créations 2012-2025, SIDE_MEASURE BURE (entreprises) et UNIT_LOC_BURE (établissements),
    ACTIVITY en 10 postes, LEGAL_FORM (10, 54, 57, OTH_SIDE, _T) ;
  - DS_SIDE_STOCKS_COM : stocks 2014-2024, SIDE_MEASURE LEGAL_UNIT (entreprises) et UNIT_LOC.
Non vérifié : le code géographique d'un département (DEP-14 supposé, sur le modèle de EPCI-...), l'interrogation
de plusieurs territoires en un appel, et le contenu exact du fichier national du recensement (repli seulement)."""
import csv
import io
import os
import re
import tempfile
import zipfile

MELODI = "https://api.insee.fr/melodi"
DS_LOGEMENT = "DS_RP_LOGEMENT_PRINC"
FICHIER_LOGEMENT = "DS_RP_LOGEMENT_PRINC_2023_CSV_FR"
RS = "DW_SEC_DW_OCC"
NON_DIMENSIONS = {"GEO", "TIME_PERIOD", "FREQ", "valeur", "statut", "GEO_OBJECT"}

A38 = {
    "AZ": "Agriculture, sylviculture et pêche", "BZ": "Industries extractives",
    "CA": "Industries alimentaires, boissons, tabac", "CB": "Textile, habillement, cuir et chaussure",
    "CC": "Bois, papier et imprimerie", "CD": "Cokéfaction et raffinage", "CE": "Industrie chimique",
    "CF": "Industrie pharmaceutique", "CG": "Caoutchouc, plastique, minéraux non métalliques",
    "CH": "Métallurgie et produits métalliques", "CI": "Produits informatiques, électroniques et optiques",
    "CJ": "Équipements électriques", "CK": "Machines et équipements n.c.a.", "CL": "Matériels de transport",
    "CM": "Autres industries manufacturières, réparation et installation",
    "DZ": "Électricité, gaz, vapeur et air conditionné", "EZ": "Eau, assainissement, déchets et dépollution",
    "FZ": "Construction", "GZ": "Commerce, réparation d'automobiles et de motocycles",
    "HZ": "Transports et entreposage", "IZ": "Hébergement et restauration", "JA": "Édition, audiovisuel et diffusion",
    "JB": "Télécommunications", "JC": "Activités informatiques et services d'information",
    "KZ": "Activités financières et d'assurance", "LZ": "Activités immobilières",
    "MA": "Activités juridiques, comptables, de gestion, d'architecture et d'ingénierie",
    "MB": "Recherche-développement scientifique", "MC": "Autres activités spécialisées, scientifiques et techniques",
    "NZ": "Services administratifs et de soutien", "OZ": "Administration publique", "PZ": "Enseignement",
    "QA": "Activités pour la santé humaine", "QB": "Hébergement médico-social, action sociale sans hébergement",
    "RZ": "Arts, spectacles et activités récréatives", "SZ": "Autres activités de services",
    "TZ": "Activités des ménages en tant qu'employeurs", "UZ": "Activités extra-territoriales",
}
# Secteurs en grande partie hors du champ Urssaf (employeurs publics, MSA, particuliers employeurs)
HORS_CHAMP = {"AZ": "agriculture (MSA)", "OZ": "administration publique", "PZ": "enseignement",
              "QA": "santé", "QB": "action sociale", "TZ": "particuliers employeurs"}
A10 = {"BE": "Industrie", "FZ": "Construction", "GI": "Commerce, transports, hébergement et restauration",
       "JZ": "Information et communication", "KZ": "Finance et assurance", "LZ": "Immobilier",
       "MN": "Services spécialisés, administratifs et de soutien",
       "OQ": "Administration publique, enseignement, santé, action sociale", "RU": "Autres services"}
FORMES = {"10": "Entrepreneurs individuels", "54": "SARL", "57": "SAS", "OTH_SIDE": "Autres formes"}


# ---------------------------------------------------------------------------- API « data »
def _aplatir(o):
    d = dict(o.get("dimensions") or {})
    m = o.get("measures") or {}
    v = next(iter(m.values()), {}) if m else {}
    d["valeur"] = v.get("value") if isinstance(v, dict) else v
    d["statut"] = (o.get("attributes") or {}).get("OBS_STATUS")
    return d


def donnees(client, ident, geo, params=None, max_pages=60):
    """Observations d'un jeu pour un ou plusieurs territoires (liste -> paramètre GEO répété), aplaties en
    dictionnaires {dimension: modalité, ..., 'valeur': x}. Suit la pagination si l'API en propose une."""
    p = {"GEO": geo, "maxResult": 10000}
    p.update(params or {})
    js = client.get(f"{MELODI}/data/{ident}", p, timeout=180)
    obs = list(js.get("observations") or [])
    pages = 0
    while isinstance(js.get("paging"), dict) and js["paging"].get("next") and pages < max_pages:
        js = client.get(js["paging"]["next"], None, timeout=180)
        obs += js.get("observations") or []
        pages += 1
    return [_aplatir(o) for o in obs]


def code_geo(g):
    return str(g or "").rsplit("-", 1)[-1]


def totaux(lignes, garder=()):
    """Lignes « tout compris » : chaque dimension non gardée vaut _T, sauf celles qui n'ont qu'une modalité dans
    la réponse (ex. LEGAL_FORM_WITH_PUBLIC = 1T9X7 pour Flores)."""
    if not lignes:
        return []
    modalites = {}
    for l in lignes:
        for k, v in l.items():
            if k not in NON_DIMENSIONS:
                modalites.setdefault(k, set()).add(v)
    a_tester = [k for k, v in modalites.items() if k not in garder and len(v) > 1]
    return [l for l in lignes if all(l.get(k) == "_T" for k in a_tester)]


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------- logement, résidences secondaires
def logements_epci(client, siren):
    """Parc de logements de l'EPCI : {année: {'total', 'rs', 'principales', 'vacants'}}."""
    lignes = [l for l in donnees(client, DS_LOGEMENT, f"EPCI-{siren}") if l.get("RP_MEASURE") == "DWELLINGS"]
    out = {}
    noms = {"_T": "total", RS: "rs", "DW_MAIN": "principales", "DW_VAC": "vacants"}
    for l in totaux(lignes, garder=("OCS", "RP_MEASURE")):
        if l.get("OCS") in noms and l["valeur"] is not None:
            out.setdefault(str(l["TIME_PERIOD"]), {})[noms[l["OCS"]]] = _num(l["valeur"])
    return out


def residences_secondaires_toutes(client, codes_epci, log=print):
    """Nombre de résidences secondaires de tous les EPCI : {code EPCI: [nombre, année]}.
    1) plusieurs EPCI par appel si l'API l'accepte (avec filtres si elle les accepte) ; 2) sinon fichier national
    du recensement, lu en flux. Lève une erreur si aucune des deux voies n'aboutit."""
    # Urssaf range sous « ZZZZZZZZZ » les communes sans EPCI : code refusé par Melodi (premier lancement réel)
    codes = sorted(c for c in codes_epci if re.fullmatch(r"\d{9}", str(c)))
    filtres = {"OCS": RS, "RP_MEASURE": "DWELLINGS"}

    def lire(lot, avec_filtres):
        lignes = donnees(client, DS_LOGEMENT, [f"EPCI-{c}" for c in lot], filtres if avec_filtres else None)
        return [l for l in lignes if l.get("OCS") == RS and l.get("RP_MEASURE") == "DWELLINGS"], lignes

    essai = codes[:3]
    voie = None
    for avec_filtres in (True, False):
        try:
            rs, tout = lire(essai, avec_filtres)
        except Exception as e:
            log(f"      plusieurs EPCI par appel{' avec filtres' if avec_filtres else ''} : refusé ({str(e)[:80]})")
            continue
        geos = {code_geo(l.get("GEO")) for l in tout}
        if len(geos) >= 2:
            voie = avec_filtres
            filtrage = "accepté" if avec_filtres and len(rs) == len(tout) else "non utilisé"
            log(f"      plusieurs EPCI par appel : accepté (filtre sur les dimensions : {filtrage})")
            break
        log(f"      plusieurs EPCI par appel{' avec filtres' if avec_filtres else ''} : un seul EPCI renvoyé")
    out, ecartes = {}, []

    def lot_robuste(lot):
        """Un territoire inconnu fait refuser tout le lot : on le coupe en deux jusqu'à isoler le coupable."""
        try:
            return lire(lot, voie)[0]
        except Exception:
            if len(lot) == 1:
                ecartes.append(lot[0])
                return []
            m = len(lot) // 2
            return lot_robuste(lot[:m]) + lot_robuste(lot[m:])
    if voie is not None:
        lot = 60 if voie else 25
        for i in range(0, len(codes), lot):
            for l in totaux(lot_robuste(codes[i:i + lot]), garder=("OCS", "RP_MEASURE")):
                c, a, v = code_geo(l.get("GEO")), str(l.get("TIME_PERIOD")), _num(l.get("valeur"))
                if v is not None and (c not in out or a > out[c][1]):
                    out[c] = [v, a]
            if (i // lot) % 5 == 0:
                log(f"      {min(i + lot, len(codes))} / {len(codes)} EPCI")
        if ecartes:
            log(f"      EPCI inconnus de l'Insee, ignorés : {', '.join(ecartes[:10])}")
        if not out:
            raise RuntimeError("aucune résidence secondaire lue")
        return out
    log("      repli sur le fichier national du recensement (logements), lecture en flux : quelques minutes")
    return _rs_fichier_national(client, log)


def _rs_fichier_national(client, log, max_mo=2000):
    url = f"{MELODI}/file/{DS_LOGEMENT}/{FICHIER_LOGEMENT}"
    r = client.s.get(url, stream=True, timeout=600)
    if r.status_code != 200:
        raise RuntimeError(f"fichier national indisponible (HTTP {r.status_code})")
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".bin")
    try:
        lu, palier = 0, 100
        for bloc in r.iter_content(1 << 20):
            tmp.write(bloc)
            lu += len(bloc)
            if lu / 1e6 >= palier:
                log(f"      {lu / 1e6:.0f} Mo reçus")
                palier += 100
            if lu > max_mo * 1e6:
                raise RuntimeError(f"fichier national trop volumineux (plus de {max_mo} Mo)")
        tmp.close()
        with open(tmp.name, "rb") as f:
            zipe = f.read(2) == b"PK"
        if zipe:
            z = zipfile.ZipFile(tmp.name)
            nom = max((n for n in z.namelist() if n.lower().endswith(".csv")),
                      key=lambda n: ("data" in n.lower(), z.getinfo(n).file_size))
            flux = io.TextIOWrapper(z.open(nom), encoding="utf-8-sig", errors="replace")
        else:
            flux = open(tmp.name, encoding="utf-8-sig", errors="replace")
        with flux:
            entete = flux.readline()
            sep = ";" if entete.count(";") >= entete.count(",") else ","
            cols = [c.strip().strip('"') for c in entete.rstrip("\r\n").split(sep)]
            c_val = next((c for c in cols if "OBS_VALUE" in c.upper()), None)
            if not c_val or "GEO" not in cols or "OCS" not in cols:
                raise RuntimeError(f"colonnes inattendues : {cols}")
            autres = [c for c in cols if c not in NON_DIMENSIONS | {"OCS", "RP_MEASURE", c_val}
                      and not c.upper().startswith("OBS_")]
            out = {}
            for l in csv.DictReader(flux, fieldnames=cols, delimiter=sep):
                geo = l.get("GEO") or ""
                if l.get("GEO_OBJECT") not in (None, "", "EPCI") or (not l.get("GEO_OBJECT") and "EPCI" not in geo):
                    continue
                if l.get("OCS") != RS or l.get("RP_MEASURE") not in (None, "", "DWELLINGS"):
                    continue
                if any(l.get(c) not in ("_T", "", None) for c in autres):
                    continue
                v, a, c = _num(l.get(c_val)), str(l.get("TIME_PERIOD")), code_geo(geo)
                if v is not None and (c not in out or a > out[c][1]):
                    out[c] = [v, a]
        if len(out) < 100:
            raise RuntimeError(f"seulement {len(out)} EPCI lus dans le fichier national")
        return out
    finally:
        try:
            tmp.close()
            os.unlink(tmp.name)
        except OSError:
            pass


# ---------------------------------------------------------------------------- Flores
def flores(client, geo):
    """Postes salariés fin d'année et établissements par secteur (A38), tous employeurs.
    -> {'annee', 'secteurs': {code: {'postes', 'etab'}}, 'total': {...}}."""
    lignes = donnees(client, "DS_FLORES_A38", geo)
    out = {"annee": None, "secteurs": {}, "total": {}}
    for l in totaux(lignes, garder=("ACTIVITY", "FLORES_MEASURE")):
        mes = {"EMPL3112": "postes", "UNIT_LOC": "etab"}.get(l.get("FLORES_MEASURE"))
        v = _num(l.get("valeur"))
        if not mes or v is None:
            continue
        out["annee"] = max(out["annee"] or "", str(l.get("TIME_PERIOD")))
        cible = out["total"] if l.get("ACTIVITY") == "_T" else out["secteurs"].setdefault(l.get("ACTIVITY"), {})
        cible[mes] = v
    if not out["secteurs"]:
        raise RuntimeError(f"aucune donnée Flores pour {geo}")
    return out


# ---------------------------------------------------------------------------- créations et stocks d'entreprises
def creations(client, geo, jeu="DS_SIDE_CREA_COM"):
    """Créations par année : entreprises (total, par forme juridique, par secteur) et établissements."""
    lignes = donnees(client, jeu, geo)
    out = {"entreprises": {}, "etablissements": {}, "formes": {}, "secteurs": {}}
    for l in totaux(lignes, garder=("SIDE_MEASURE", "ACTIVITY", "LEGAL_FORM")):
        v, a = _num(l.get("valeur")), str(l.get("TIME_PERIOD"))
        if v is None:
            continue
        mes, act, forme = l.get("SIDE_MEASURE"), l.get("ACTIVITY", "_T"), l.get("LEGAL_FORM", "_T")
        if mes == "UNIT_LOC_BURE" and act == "_T" and forme == "_T":
            out["etablissements"][a] = v
        elif mes == "BURE":
            if act == "_T" and forme == "_T":
                out["entreprises"][a] = v
            elif act == "_T":
                out["formes"].setdefault(forme, {})[a] = v
            elif forme == "_T":
                out["secteurs"].setdefault(act, {})[a] = v
    if not out["entreprises"]:
        raise RuntimeError(f"aucune création trouvée pour {geo} dans {jeu}")
    return out


def stocks(client, geo, jeu="DS_SIDE_STOCKS_COM"):
    """Stock d'entreprises (unités légales) et d'établissements au 31 décembre, par année."""
    lignes = donnees(client, jeu, geo)
    out = {"entreprises": {}, "etablissements": {}}
    for l in totaux(lignes, garder=("SIDE_MEASURE",)):
        v = _num(l.get("valeur"))
        cle = {"LEGAL_UNIT": "entreprises", "UNIT_LOC": "etablissements"}.get(l.get("SIDE_MEASURE"))
        if cle and v is not None:
            out[cle][str(l.get("TIME_PERIOD"))] = v
    return out

"""Exports Excel et GeoJSON du thème « Permis »."""
import json
from datetime import date

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from . import permis as P

NAVY = "1B3A5C"
ENTETE = Font(bold=True, color="FFFFFF")
FOND_ENTETE = PatternFill("solid", fgColor=NAVY)
FOND_TOTAL = PatternFill("solid", fgColor="E8EEF5")

COLONNES_SYNTHESE = [
    ("nom", "Territoire", 32, None), ("niveau", "Niveau", 11, None),
    ("lgt_nb_permis", "Autorisations créant des logements", 15, "0"),
    ("lgt_aut", "Logements autorisés", 12, "0"), ("lgt_ind", "dont individuels", 12, "0"),
    ("lgt_col", "dont collectifs", 12, "0"), ("lgt_commences", "Logements commencés", 12, "0"),
    ("lgt_termines", "Logements terminés", 12, "0"),
    ("lgt_a_venir", "Logements à venir (chantier ou autorisation de moins de 3 ans)", 18, "0"),
    ("surf_hab", "Surface habitable créée (m²)", 14, "#,##0"),
    ("pa_nb", "Permis d'aménager", 11, "0"), ("pa_superficie", "Terrain aménagé (ha)", 12, "#,##0.0"),
    ("pa_lots", "Lots (si renseigné)", 11, "0"),
    ("pd_nb", "Permis de démolir", 11, "0"), ("pd_lgt_demolis", "Logements démolis (si renseigné)", 14, "0"),
]
COLONNES_LISTE = [
    ("theme", "Type", 20), ("type_dau", "Nature (PC, DP, PA, PD)", 10), ("num", "Numéro", 18),
    ("commune", "Code commune", 10), ("_nom", "Commune", 22), ("etat", "État", 11),
    ("date_aut", "Date d'autorisation", 12), ("date_doc", "Ouverture de chantier", 12),
    ("date_daact", "Achèvement", 12), ("demandeur", "Demandeur", 22), ("denomination", "Dénomination", 28),
    ("adresse", "Adresse du terrain", 34), ("parcelles_txt", "Parcelles", 20),
    ("superficie", "Terrain (m²)", 11), ("logements", "Logements créés", 10), ("lgt_ind", "Individuels", 10),
    ("lgt_col", "Collectifs", 10), ("surf_hab", "Surface habitable créée (m²)", 12),
    ("lgt_demolis", "Logements démolis", 10), ("lots", "Lots", 8), ("nature", "Nature du projet", 18),
    ("a_venir", "Logements à venir", 10), ("localisation", "Localisation", 14),
    ("lon", "Longitude", 11), ("lat", "Latitude", 11),
]


def _entete(ws, valeurs, largeurs):
    for j, v in enumerate(valeurs, start=1):
        c = ws.cell(row=1, column=j, value=v)
        c.font, c.fill = ENTETE, FOND_ENTETE
        c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(j)].width = largeurs[j - 1]
    ws.row_dimensions[1].height = 48
    ws.freeze_panes = "B2"


def _valeur_liste(p, cle, noms):
    if cle == "theme":
        return P.LIB_TYPE[p["theme"]]
    if cle == "_nom":
        return noms.get(p["commune"], "")
    if cle == "parcelles_txt":
        return ", ".join(f"{s} {n}" for s, n in p["parcelles"])
    if cle == "a_venir":
        return "oui" if P.en_attente(p) else ""
    return p.get(cle)


def exporter_excel(chemin, resultat, communes, params):
    noms = {c["code"]: c["nom"] for c in communes}
    wb = Workbook()
    ws = wb.active
    ws.title = "Synthèse"
    _entete(ws, [c[1] for c in COLONNES_SYNTHESE], [c[2] for c in COLONNES_SYNTHESE])
    for i, ligne in enumerate(resultat["synthese"]["lignes"], start=2):
        for j, (cle, _l, _w, fmt) in enumerate(COLONNES_SYNTHESE, start=1):
            v = ligne.get(cle)
            cell = ws.cell(row=i, column=j, value=round(v, 2) if isinstance(v, float) else v)
            if fmt:
                cell.number_format = fmt
            if ligne["niveau"] != "Commune":
                cell.fill, cell.font = FOND_TOTAL, Font(bold=True)

    ws = wb.create_sheet("Par année")
    _entete(ws, ["Année d'autorisation", "Logements individuels", "Logements collectifs",
                 "Autres logements (non ventilés)", "Logements autorisés", "dont commencés",
                 "Permis d'aménager", "Permis de démolir"], [12, 13, 13, 15, 13, 13, 12, 12])
    for i, (a, s) in enumerate(sorted(resultat["synthese"]["par_annee"].items()), start=2):
        lg = s["logements"]
        for j, v in enumerate([a, lg["ind"], lg["col"], lg["autre"], lg["ind"] + lg["col"] + lg["autre"],
                               lg["commences"], s["amenager"], s["demolir"]], start=1):
            ws.cell(row=i, column=j, value=v)

    for t in resultat["types"]:
        liste = [p for p in resultat["permis"] if p["theme"] == t]
        ws = wb.create_sheet(P.LIB_TYPE[t][:31].replace("'", " "))
        entetes_brutes = resultat["entetes"].get(t, [])
        _entete(ws, [c[1] for c in COLONNES_LISTE] + [f"[source] {h}" for h in entetes_brutes],
                [c[2] for c in COLONNES_LISTE] + [14] * len(entetes_brutes))
        for i, p in enumerate(sorted(liste, key=lambda p: (p["commune"], p["date_aut"])), start=2):
            for j, (cle, _l, _w) in enumerate(COLONNES_LISTE, start=1):
                v = _valeur_liste(p, cle, noms)
                if cle.startswith("date_") and v:
                    ws.cell(row=i, column=j, value=date.fromisoformat(v)).number_format = "dd/mm/yyyy"
                else:
                    ws.cell(row=i, column=j, value=v)
            for j, v in enumerate(p["brut"], start=len(COLONNES_LISTE) + 1):
                ws.cell(row=i, column=j, value=v)
        ws.auto_filter.ref = f"A1:{get_column_letter(len(COLONNES_LISTE) + len(entetes_brutes))}{len(liste) + 1}"

    ws = wb.create_sheet("Lisez-moi")
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 110
    lignes = [
        ("Source", "SDES, liste des permis de construire et autres autorisations d'urbanisme (base Sitadel), "
                   "API DiDo · Licence Ouverte"),
        ("Millésimes", ", ".join(f"{P.LIB_TYPE[t]} : {m}" for t, m in resultat["millesimes"].items())),
        ("Communes", params.get("communes", "")),
        ("Période", f"autorisations délivrées de {resultat['annees'][0]} à {resultat['annees'][-1]}"),
        ("Extraction", params.get("date", "")),
        ("", ""),
        ("Logements autorisés", "Somme des logements créés par les permis et déclarations préalables autorisés, "
                                "hors autorisations annulées."),
        ("Logements à venir", "Logements dont le chantier est ouvert mais pas achevé, ou dont l'autorisation date de "
                              "moins de 3 ans sans ouverture de chantier connue. Repère utile pour anticiper de "
                              "nouveaux foyers à desservir ; les déclarations d'achèvement arrivent souvent en retard."),
        ("Dernières années", "Incomplètes : des permis sont transmis avec retard par les services instructeurs."),
        ("Code commune", "Celui du dépôt : un permis déposé sous l'ancien code d'une commune fusionnée n'est pas "
                         "retrouvé."),
        ("Localisation", "Centre de la parcelle cadastrale (plan cadastral Etalab) ; moyenne des parcelles si "
                         "plusieurs. Sitadel ne donne que 3 parcelles au maximum par permis."),
        ("Colonnes [source]", "Toutes les colonnes d'origine du SDES sont conservées à droite de chaque liste."),
    ]
    for i, (a, b) in enumerate(lignes, start=1):
        ws.cell(row=i, column=1, value=a).font = Font(bold=True, color=NAVY)
        ws.cell(row=i, column=2, value=b).alignment = Alignment(wrap_text=True, vertical="top")
    wb.save(chemin)


def entites(resultat, communes):
    noms = {c["code"]: c["nom"] for c in communes}
    feats = []
    for p in resultat["permis"]:
        if p.get("lon") is None:
            continue
        props = {cle: _valeur_liste(p, cle, noms) for cle, _l, _w in COLONNES_LISTE if cle not in ("lon", "lat")}
        props["theme_code"] = p["theme"]
        props["annee"] = p["annee"]
        feats.append({"type": "Feature", "properties": props,
                      "geometry": {"type": "Point", "coordinates": [p["lon"], p["lat"]]}})
    return feats


def exporter_geojson(chemin, resultat, communes):
    feats = entites(resultat, communes)
    fc = {"type": "FeatureCollection", "name": "permis_ncpa",
          "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
          "metadata": {"source": "SDES, liste des autorisations d'urbanisme (Sitadel) ; localisation : cadastre Etalab"},
          "features": feats}
    with open(chemin, "w", encoding="utf-8") as f:
        json.dump(fc, f, ensure_ascii=False)
    return len(feats), len(resultat["permis"]) - len(feats)

@echo off
title Economie et emploi NCPA - interface
cd /d "%~dp0"
python lancer_interface.py
if errorlevel 1 pause

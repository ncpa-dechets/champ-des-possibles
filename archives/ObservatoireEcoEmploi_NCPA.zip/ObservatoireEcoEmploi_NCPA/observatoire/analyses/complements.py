# -*- coding: utf-8 -*-
"""Indicateurs ajoutés en v0.5, en Python pur (aucun téléchargement ici) :
saisonnalité (France Travail, enquête BMO), parc de logements et résidences secondaires, emploi tous employeurs
(Flores) comparé au champ Urssaf, déplacements domicile-travail, créations et disparitions d'entreprises."""
import re
import unicodedata

from ..collecte.melodi import A10, A38, FORMES, HORS_CHAMP

ANNEE_MIN_SAISON = 2021  # 2020 (confinements) fausse le profil saisonnier
SERIES_SAISON = [
    ("serie_a", "Demandeurs d'emploi sans activité (catégorie A)"),
    ("serie_embauches", "Embauches, toutes durées de contrat"),
    ("serie_embauches_long", "Embauches en contrat de plus d'un mois"),
    ("serie_embauches_court", "Embauches en contrat d'un mois ou moins"),
    ("serie_offres", "Offres d'emploi, toutes origines"),
    ("serie_offres_ft", "Offres déposées à France Travail"),
]
SEUIL_PETIT_FLUX = 200  # Insee : en dessous, un flux domicile-travail est un ordre de grandeur


def _n(v):
    return f"{v:,.0f}".replace(",", " ") if v is not None else "nd"


def _p(v, signe=False):
    if v is None:
        return "nd"
    return (f"{v * 100:+.1f} %" if signe else f"{v * 100:.1f} %").replace(".", ",")


def norm(s):
    return re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFD", str(s or "")).encode("ascii", "ignore")
                  .decode().lower())


def div(a, b):
    return a / b if a is not None and b not in (None, 0) else None


# =============================================================================== saisonnalité
def decouper_periode(code):
    """'2024T2' (ou '2024-T2', '2024Q2') -> (2024, 2)."""
    s = str(code or "")
    a = re.search(r"(19|20)\d{2}", s)
    t = re.search(r"[TQ]\s*([1-4])(?!\d)", s.upper())
    if a and t:
        return int(a.group(0)), int(t.group(1))
    m = re.search(r"(?:19|20)\d{2}\D?(0[1-9]|1[0-2])(?!\d)", s)
    if a and m:
        return int(a.group(0)), (int(m.group(1)) - 1) // 3 + 1
    return None


def profil(serie, annee_min=ANNEE_MIN_SAISON):
    """Profil saisonnier moyen : pour chaque année complète, valeur du trimestre / moyenne de l'année.
    -> ({1: 0.97, ...}, nombre d'années complètes) ou (None, 0)."""
    par_an = {}
    for code, v in (serie or {}).items():
        p = decouper_periode(code)
        if p and v is not None and p[0] >= annee_min:
            par_an.setdefault(p[0], {})[p[1]] = float(v)
    complets = [d for d in par_an.values() if len(d) == 4 and sum(d.values()) > 0]
    if not complets:
        return None, 0
    prof = {k: sum(d[k] / (sum(d.values()) / 4) for d in complets) / len(complets) for k in range(1, 5)}
    return prof, len(complets)


def _court(t):
    """Embauches d'un mois ou moins = toutes durées - plus d'un mois."""
    tt, lg = t.get("serie_embauches") or {}, t.get("serie_embauches_long") or {}
    return {k: tt[k] - lg[k] for k in tt if k in lg and tt[k] is not None and lg[k] is not None}


def saisonnalite(ft, bmo, ref_nom):
    terr = (ft or {}).get("territoires") or {}
    lignes = []
    for cle, lib in SERIES_SAISON:
        for t, d in terr.items():
            serie = _court(d) if cle == "serie_embauches_court" else d.get(cle)
            prof, nb = profil(serie)
            if not prof:
                continue
            pic = max(prof, key=prof.get)
            creux = min(prof, key=prof.get)
            lignes.append({"cle": cle, "serie": lib, "territoire": ref_nom if t == "EPCI" else t, "code_terr": t,
                           **{f"T{k}": prof[k] - 1 for k in range(1, 5)},
                           "amplitude": max(prof.values()) - min(prof.values()), "pic": f"T{pic}",
                           "creux": f"T{creux}", "annees": nb})
    e = terr.get("EPCI") or {}
    chrono = sorted(set(e.get("serie_embauches") or {}) | set(e.get("serie_a") or {}))
    brut = [{"periode": p, "embauches": (e.get("serie_embauches") or {}).get(p),
             "embauches_long": (e.get("serie_embauches_long") or {}).get(p),
             "embauches_court": _court(e).get(p), "demandeurs_a": (e.get("serie_a") or {}).get(p),
             "offres": (e.get("serie_offres") or {}).get(p)} for p in chrono]
    tot = (bmo or {}).get("totaux") or {}
    saison_bmo = sorted([m for m in (bmo or {}).get("metiers", []) if m.get("saisonniers")],
                        key=lambda m: -m["saisonniers"])[:15]
    return {"lignes": lignes, "brut": brut, "bmo_totaux": tot, "bmo_metiers": saison_bmo,
            "annee_min": ANNEE_MIN_SAISON}


def phrases_saison(s, ref_nom):
    out = []

    def lig(cle, terr):
        return next((l for l in s["lignes"] if l["cle"] == cle and l["code_terr"] == terr), None)
    a, af = lig("serie_a", "EPCI"), lig("serie_a", "France")
    if a and af:
        out.append(f"Le chômage suit fortement les saisons : au fil de l'année, le nombre de demandeurs d'emploi sans "
                   f"activité varie de {_p(a['amplitude'])} entre le trimestre le plus haut et le plus bas, contre "
                   f"{_p(af['amplitude'])} en France (moyenne {s['annee_min']}-{s['annee_min'] + a['annees'] - 1}, "
                   f"creux au {a['creux'].replace('T', '')}e trimestre).")
    e, ef = lig("serie_embauches_long", "EPCI"), lig("serie_embauches_long", "France")
    if e and ef:
        out.append(f"Les embauches de plus d'un mois culminent au {e['pic'].replace('T', '')}e trimestre "
                   f"({_p(e[e['pic']], True)} par rapport à la moyenne de l'année, contre "
                   f"{_p(ef[ef['pic']], True)} en France) ; au 2e trimestre, elles sont déjà à "
                   f"{_p(e['T2'], True)} (France : {_p(ef['T2'], True)}) : le territoire recrute dès le printemps.")
    b = s.get("bmo_totaux") or {}
    if b.get("Bassin") and b.get("France") and b["Bassin"].get("part_saisonniers") is not None:
        out.append(f"Dans l'enquête Besoins en main-d'œuvre, {_p(b['Bassin']['part_saisonniers'])} des projets de "
                   f"recrutement du bassin d'emploi sont saisonniers (France : {_p(b['France']['part_saisonniers'])}).")
    return out


# =============================================================================== logement et capacité d'accueil
def logement(logements):
    """Parc de logements de l'EPCI (recensements) et capacité en résidences secondaires."""
    if not logements:
        return None
    ans = sorted(logements)
    d, d0 = logements[ans[-1]], logements[ans[0]]
    return {"annees": [{"annee": a, **logements[a], "part_rs": div(logements[a].get("rs"), logements[a].get("total"))}
                       for a in ans],
            "annee": ans[-1], "rs": d.get("rs"), "total": d.get("total"), "part_rs": div(d.get("rs"), d.get("total")),
            "lits_rs": 5 * d["rs"] if d.get("rs") is not None else None, "annee_deb": ans[0],
            "evol_rs": div((d.get("rs") or 0) - (d0.get("rs") or 0), d0.get("rs")) if d0.get("rs") else None}


# =============================================================================== Flores : emploi tous employeurs
def code_a38(lib):
    """Code A38 d'un libellé Urssaf (« IZ Hébergement et restauration » ou libellé seul)."""
    s = str(lib or "").strip()
    m = re.match(r"^([A-Z]{2})\b", s)
    if m and m.group(1) in A38:
        return m.group(1)
    n = norm(s)[:22]
    for c, l in A38.items():
        if n and norm(l)[:22] == n:
            return c
    return None


def _urssaf_a38(lignes, annee):
    out = {}
    for l in lignes:
        c = code_a38(l.get("NA38"))
        v = (l.get("eff") or {}).get(annee)
        if c and v is not None:
            out[c] = out.get(c, 0) + v
    return out


def hors_champ(flores, brut, dep):
    """Compare Flores (tous employeurs) et Urssaf (privé, régime général) secteur par secteur, la même année."""
    fe = (flores or {}).get("epci")
    if not fe or not fe.get("secteurs"):
        return None
    annee = int(fe["annee"]) if fe.get("annee") else None
    ans = [a for a in brut["annees"] if a <= (annee or 9999)]
    a_u = ans[-1] if ans else brut["annees"][-1]
    if not any("NA38" in l for l in brut["detail"][:50]):
        return None
    u = _urssaf_a38(brut["detail"], a_u)
    secteurs = []
    for c, lib in A38.items():
        f = (fe["secteurs"].get(c) or {}).get("postes")
        if f is None and c not in u:
            continue
        secteurs.append({"code": c, "secteur": f"{c} {lib}", "flores": f, "urssaf": u.get(c),
                         "ecart": (f or 0) - (u.get(c) or 0), "hors_champ": HORS_CHAMP.get(c, "")})
    tf = (fe.get("total") or {}).get("postes") or sum(s["flores"] or 0 for s in secteurs)
    tu = sum(u.values())
    out = {"annee": annee, "annee_urssaf": a_u, "secteurs": sorted(secteurs, key=lambda s: -(s["flores"] or 0)),
           "total_flores": tf, "total_urssaf": tu, "part_hors": div(tf - tu, tf),
           "etab_flores": (fe.get("total") or {}).get("etab")}
    principaux = sorted([s for s in secteurs if s["hors_champ"] and s["ecart"] > 0], key=lambda s: -s["ecart"])
    out["principaux"] = principaux[:4]
    fd = (flores or {}).get("dep")
    if fd and fd.get("secteurs"):
        ud = _urssaf_a38([l for l in brut["refs"] if l.get("code_dep") == dep], a_u)
        tfd = (fd.get("total") or {}).get("postes") or sum((v.get("postes") or 0) for v in fd["secteurs"].values())
        out["dep"] = {"total_flores": tfd, "total_urssaf": sum(ud.values()), "part_hors": div(tfd - sum(ud.values()), tfd)}
    return out


def phrases_hors_champ(h, dep_nom):
    if not h or not h.get("total_flores"):
        return []
    if (h.get("part_hors") or 0) < 0:
        return [f"Flores compte {_n(h['total_flores'])} postes salariés fin {h['annee']}, moins que l'Urssaf "
                f"({_n(h['total_urssaf'])}) : les deux sources ne concordent pas, comparaison à vérifier."]
    txt = (f"Tous employeurs confondus (Flores, fin {h['annee']}), le territoire compte {_n(h['total_flores'])} postes "
           f"salariés, dont {_p(h['part_hors'])} échappent au champ Urssaf de cet outil")
    if h.get("dep"):
        txt += f" ({dep_nom} : {_p(h['dep']['part_hors'])})"
    if h.get("principaux"):
        txt += " : surtout " + ", ".join(f"{s['hors_champ']} ({_n(s['ecart'])})" for s in h["principaux"])
    return [txt + "."]


# =============================================================================== déplacements domicile-travail
def mobilites(mob, brut, codes_ref):
    if not mob or not mob.get("flux"):
        return None
    codes_ref = set(codes_ref)
    com_epci = brut.get("communes_epci") or {}
    noms_epci = {l.get("code_epci"): l.get("epci") for l in brut.get("epci", []) if l.get("code_epci")}
    centres = mob.get("centres") or {}
    noms = {}
    residents, emplois, internes, meme = {}, {}, 0, {}
    sortants, entrants = {}, {}
    for r, lr, t, lt, n in mob["flux"]:
        noms[r], noms[t] = lr, lt
        if r in codes_ref:
            residents[r] = residents.get(r, 0) + n
            if r == t:
                meme[r] = meme.get(r, 0) + n
        if t in codes_ref:
            emplois[t] = emplois.get(t, 0) + n
        if r in codes_ref and t in codes_ref:
            internes += n
        elif r in codes_ref:
            sortants[t] = sortants.get(t, 0) + n
        elif t in codes_ref:
            entrants[r] = entrants.get(r, 0) + n

    def par_epci(d):
        agg = {}
        for c, n in d.items():
            e = com_epci.get(c)
            lib = noms_epci.get(e) if e else None
            lib = lib or (f"Autres communes ({c[:2]})" if not c.startswith("97") else "Outre-mer")
            agg[lib] = agg.get(lib, 0) + n
        tot = sum(agg.values()) or 1
        return [{"territoire": k, "actifs": v, "part": v / tot} for k, v in sorted(agg.items(), key=lambda x: -x[1])]

    def top(d, k=25):
        tot = sum(d.values()) or 1
        return [{"code": c, "commune": noms.get(c, c), "actifs": n, "part": n / tot, "indicatif": n < SEUIL_PETIT_FLUX}
                for c, n in sorted(d.items(), key=lambda x: -x[1])[:k]]
    tot_res, tot_sort, tot_ent = sum(residents.values()), sum(sortants.values()), sum(entrants.values())
    communes = []
    for c in sorted(residents, key=lambda c: -residents[c]):
        sort_c = sum(n for r, _, t, _, n in mob["flux"] if r == c and t not in codes_ref)
        communes.append({"code": c, "commune": noms.get(c, c), "actifs": residents[c], "meme_commune": meme.get(c, 0),
                         "hors_epci": sort_c, "part_hors_epci": div(sort_c, residents[c]),
                         "emplois_lt": emplois.get(c, 0), "indice_concentration": div(emplois.get(c, 0), residents[c])})
    # liens pour la carte : une ligne par commune extérieure, depuis le centre de gravité de l'EPCI
    pts = [centres[c] for c in codes_ref if c in centres]
    if not pts:
        for f in (brut.get("geo") or {}).get("features", []):
            ring = _premier_anneau(f.get("geometry") or {})
            if ring:
                pts.append([sum(p[0] for p in ring) / len(ring), sum(p[1] for p in ring) / len(ring)])
    centre = [sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)] if pts else None
    ext = set(sortants) | set(entrants)
    liens = sorted([{"code": c, "commune": noms.get(c, c), "sortants": sortants.get(c, 0), "entrants": entrants.get(c, 0),
                     "lon": centres[c][0], "lat": centres[c][1]} for c in ext if c in centres],
                   key=lambda x: -(x["sortants"] + x["entrants"]))[:60]
    return {"annee": mob.get("annee"), "residents": tot_res, "internes": internes, "sortants": tot_sort,
            "entrants": tot_ent, "emplois_lt": internes + tot_ent, "part_sortants": div(tot_sort, tot_res),
            "part_entrants": div(tot_ent, internes + tot_ent),
            "indice_concentration": div(internes + tot_ent, tot_res),
            "dest_epci": par_epci(sortants), "orig_epci": par_epci(entrants),
            "dest_communes": top(sortants), "orig_communes": top(entrants),
            "part_petits_sortants": div(sum(n for n in sortants.values() if n < SEUIL_PETIT_FLUX), tot_sort),
            "part_petits_entrants": div(sum(n for n in entrants.values() if n < SEUIL_PETIT_FLUX), tot_ent),
            "communes": communes, "liens": liens, "centre": centre}


def _premier_anneau(g):
    if g.get("type") == "Polygon":
        return g["coordinates"][0]
    if g.get("type") == "MultiPolygon":
        return max((p[0] for p in g["coordinates"]), key=len)
    return None


def phrases_mobilites(m):
    if not m or not m.get("residents"):
        return []
    d = m["dest_epci"][0] if m.get("dest_epci") else None
    o = m["orig_epci"][0] if m.get("orig_epci") else None
    out = [f"Sur {_n(m['residents'])} actifs occupés habitant le territoire (recensement {m['annee']}), "
           f"{_p(m['part_sortants'])} travaillent ailleurs"
           + (f", d'abord dans {d['territoire']} ({_p(d['part'])} de ces sortants)" if d else "")
           + f" ; à l'inverse, {_n(m['entrants'])} actifs viennent y travailler de l'extérieur"
           + (f" (premier territoire d'origine : {o['territoire']})" if o else "") + "."]
    return out


# =============================================================================== créations et disparitions
def _taux(num, stock, annee):
    s = (stock or {}).get(str(int(annee) - 1))
    return div(num, s)


def demographie(crea, sirene_demo, ouvertures, employeurs_tous, geo, annee_courante):
    """Créations d'entreprises (Insee), créations et fermetures d'établissements (SIRENE), ouvertures de
    procédures collectives (BODACC) : tableau annuel pour l'EPCI et le département, liste des défaillances."""
    if not (crea or sirene_demo or ouvertures):
        return None
    crea = crea or {}
    ce, cd = crea.get("epci") or {}, crea.get("dep") or {}
    se, sd = (crea.get("stock_epci") or {}).get("entreprises"), (crea.get("stock_dep") or {}).get("entreprises")
    # rattachement des défaillances à l'EPCI : SIREN d'un employeur connu (même fermé) ou adresse dans l'EPCI
    par_siren = {}
    for d in employeurs_tous or []:
        if d.get("siren") and d["siren"] not in par_siren:
            par_siren[d["siren"]] = d
    cps, villes = set(), set()
    for f in (geo or {}).get("features", []):
        cps |= set(f["properties"].get("codesPostaux") or [])
        villes.add(norm(f["properties"].get("nom")))
    liste, def_ncpa, def_dep = [], {}, {}
    for o in ouvertures or []:
        a = o["annee"]
        def_dep[a] = def_dep.get(a, 0) + 1
        emp = par_siren.get(o.get("siren"))
        par_adresse = o.get("cp") in cps and norm(o.get("ville")) in villes
        if not (emp or par_adresse):
            continue
        def_ncpa[a] = def_ncpa.get(a, 0) + 1
        liste.append({**o, "secteur": (emp or {}).get("activite") or "", "tranche": (emp or {}).get("tranche_lib") or "",
                      "commune": (emp or {}).get("commune") or o.get("ville"),
                      "rattachement": "employeur connu" if emp else "adresse"})
    liste.sort(key=lambda x: x["date"], reverse=True)
    annees = sorted(set(ce.get("entreprises", {})) | set((sirene_demo or {})) | set(def_dep), key=int)
    tableau = []
    for a in annees:
        c = (ce.get("entreprises") or {}).get(a)
        ei = ((ce.get("formes") or {}).get("10") or {}).get(a)
        cdep = (cd.get("entreprises") or {}).get(a)
        sdm = (sirene_demo or {}).get(a) or {}
        dn, dd = (def_ncpa.get(a, 0), def_dep[a]) if a in def_dep else (None, None)
        tableau.append({"annee": a, "crea": c, "part_ei": div(ei, c), "stock": (se or {}).get(a),
                        "taux_crea": _taux(c, se, a), "crea_dep": cdep, "taux_crea_dep": _taux(cdep, sd, a),
                        "etab_crees": sdm.get("creations"), "etab_fermes": sdm.get("fermetures"),
                        "solde_etab": (sdm["creations"] - sdm["fermetures"]) if sdm else None,
                        "defaillances": dn, "defaillances_dep": dd,
                        "def_1000": div(dn * 1000 if dn is not None else None, (se or {}).get(str(int(a) - 1))),
                        "def_1000_dep": div(dd * 1000 if dd is not None else None, (sd or {}).get(str(int(a) - 1))),
                        "partiel": int(a) >= annee_courante})
    dern = max((a for v in (ce.get("secteurs") or {}).values() for a in v), key=int, default=None)
    secteurs = sorted([{"secteur": A10.get(k, k), "crea": v.get(dern)} for k, v in (ce.get("secteurs") or {}).items()
                       if v.get(dern)], key=lambda x: -x["crea"]) if dern else []
    formes = [{"forme": FORMES.get(k, k), "crea": v.get(dern)} for k, v in (ce.get("formes") or {}).items()
              if dern and v.get(dern)]
    return {"tableau": tableau, "defaillances": liste, "secteurs": secteurs, "formes": formes, "annee_secteurs": dern,
            "dep_dispo": bool(cd), "stock_dispo": bool(se)}


def phrases_demographie(d, dep_nom):
    if not d:
        return []
    t = [x for x in d["tableau"] if not x["partiel"]]
    out = []
    c = [x for x in t if x["crea"] is not None]
    if c:
        x, x0 = c[-1], c[0]
        txt = (f"{_n(x['crea'])} entreprises ont été créées en {x['annee']} (contre {_n(x0['crea'])} en {x0['annee']})"
               + (f", dont {_p(x['part_ei'])} d'entrepreneurs individuels" if x["part_ei"] is not None else ""))
        if x["taux_crea"] is not None:
            txt += f" ; taux de création {_p(x['taux_crea'])}"
            if x["taux_crea_dep"] is not None:
                txt += f" ({dep_nom} : {_p(x['taux_crea_dep'])})"
        out.append(txt + ".")
    f = [x for x in t if x["defaillances"] is not None]
    if f:
        x = f[-1]
        txt = f"{_n(x['defaillances'])} entreprises du territoire ont fait l'objet d'une procédure collective en {x['annee']}"
        if x["def_1000"] is not None and x["def_1000_dep"] is not None:
            v1, v2 = (f"{v:.1f}".replace(".", ",") for v in (x["def_1000"], x["def_1000_dep"]))
            txt += f", soit {v1} pour 1 000 entreprises ({dep_nom} : {v2})"
        out.append(txt + " (BODACC).")
    return out

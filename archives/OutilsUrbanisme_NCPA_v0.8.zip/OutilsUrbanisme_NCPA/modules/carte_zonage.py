"""Sorties cartographiques du thème « Zonage » : GeoJSON pour QGIS et carte
HTML autonome (Leaflet, charte NCPA, couleurs des zones inspirées du
standard CNIG). Les zones sont découpées par commune et simplifiées
(environ 2 m) pour garder un fichier léger."""
import json

from . import zonage as Z
from .export_geo import _lire
from .fonds_carte import FONDS_CSS, FONDS_JS


def _date(d):
    d = str(d or "")
    if len(d) == 8 and d.isdigit():
        return f"{d[6:8]}/{d[4:6]}/{d[:4]}"
    if len(d) >= 10 and d[4] == "-":
        return f"{d[8:10]}/{d[5:7]}/{d[:4]}"
    return d


def _fc(nom, features, resultat):
    return {"type": "FeatureCollection", "name": nom,
            "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
            "metadata": {"source": "Géoportail de l'Urbanisme (API Carto IGN), découpage par commune",
                         "extraction": resultat["date"]},
            "features": features}


def exporter_geojson(chemin, resultat):
    """Zones dans le fichier choisi ; servitudes, prescriptions et points croisés dans des fichiers voisins."""
    from . import croisement
    base = chemin[:-8] if chemin.lower().endswith(".geojson") else chemin
    fichiers = [(chemin, "zonage_ncpa", resultat["zones"]["features"])]
    if resultat.get("servitudes", {}).get("features"):
        fichiers.append((base + "_servitudes.geojson", "servitudes_ncpa", resultat["servitudes"]["features"]))
    if resultat.get("prescriptions", {}).get("features"):
        fichiers.append((base + "_prescriptions.geojson", "prescriptions_ncpa", resultat["prescriptions"]["features"]))
    if resultat.get("points"):
        fichiers.append((base + "_permis_friches.geojson", "permis_friches_zonage",
                         croisement.entites(resultat["points"])))
    sortie = []
    for ch, nom, feats in fichiers:
        with open(ch, "w", encoding="utf-8") as f:
            json.dump(_fc(nom, feats, resultat), f, ensure_ascii=False)
        sortie.append((ch, len(feats)))
    return sortie


def exporter_carte(chemin, resultat, contours, params):
    codes = {l["code"] for l in resultat["lignes"] if l["niveau"] == "Commune"}
    limites = {"type": "FeatureCollection", "features": []}
    for f in (contours or {}).get("features", []):
        code = str(f["properties"]["code"])
        if code in codes:
            d = resultat["documents"][code]
            doc = d["document"] or {}
            limites["features"].append({"type": "Feature", "geometry": f["geometry"], "properties": {
                "code": code, "nom": f["properties"].get("nom"), "statut": d["statut"],
                "document": doc.get("nom"), "approbation": _date(doc.get("approbation"))}})
    lignes = [{k: (round(v, 1) if isinstance(v, float) else v) for k, v in l.items() if k != "document"}
              for l in resultat["lignes"]]
    from .servitudes import COULEURS_PSC
    cats = sorted({f["properties"]["categorie"] for f in resultat.get("servitudes", {}).get("features", [])})
    palette = ["#1565C0", "#6A1B9A", "#00838F", "#AD1457", "#EF6C00", "#283593", "#4E342E", "#9E9D24",
               "#00695C", "#C62828", "#37474F", "#5D4037"]
    sup_cat = [(c, next((f["properties"]["categorie_lib"] for f in resultat["servitudes"]["features"]
                         if f["properties"]["categorie"] == c), c), palette[i % len(palette)])
               for i, c in enumerate(cats)]
    psc_types = [(t, lib, COULEURS_PSC.get(t, "#8D6E63")) for t, lib in sorted(resultat.get("types_psc", {}).items())]
    from .croisement import LIB_THEME
    sources = sorted({p["source"] for p in resultat.get("points", [])})
    donnees = {"zones": resultat["zones"], "limites": limites, "familles": Z.FAMILLES, "lignes": lignes,
               "date": resultat["date"],
               "servitudes": resultat.get("servitudes") or {"type": "FeatureCollection", "features": []},
               "prescriptions": resultat.get("prescriptions") or {"type": "FeatureCollection", "features": []},
               "sup_cat": sup_cat, "psc_types": psc_types,
               "points": resultat.get("points", []),
               "sources": [(src, LIB_THEME.get(src, src), {"logements": "#B91E27", "amenager": "#5E7A2E",
                                                           "demolir": "#3F4448", "friche": "#4F6D7A"}.get(src, "#777"))
                           for src in sources]}
    html = (GABARIT
            .replace("/*LEAFLET_CSS*/", _lire("donnees/leaflet.css"))
            .replace("/*FONDS_CSS*/", FONDS_CSS)
            .replace("/*LEAFLET_JS*/", _lire("donnees/leaflet.js"))
            .replace("/*FONDS_JS*/", FONDS_JS)
            .replace("__TITRE__", params.get("titre", "NCPA"))
            .replace("__DATE__", params.get("date", ""))
            .replace("__DONNEES__", json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")))
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(html)
    return len(resultat["zones"]["features"])


GABARIT = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Zonage · __TITRE__</title>
<style>/*LEAFLET_CSS*/</style>
<style>/*FONDS_CSS*/</style>
<style>
:root{--rouge:#B91E27;--vert:#B1B993;--encre:#1F2A2E;--doux:#5E6A6E;--brume:#F3F4EF;--trait:#DCDDD3;
      font-family:Calibri,"Segoe UI",system-ui,sans-serif;color:var(--encre)}
*{box-sizing:border-box}
html,body{margin:0;height:100%}
body{display:flex;flex-direction:column;height:100vh;background:#fff}
header{border-left:6px solid var(--rouge);border-bottom:1px solid var(--trait);padding:10px 18px 10px 16px}
.eyebrow{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--rouge);font-weight:700}
h1{font-size:21px;margin:2px 0 0;font-weight:700}
.sous{font-size:13px;color:var(--doux)}
#corps{flex:1 1 auto;display:flex;min-height:0}
#panneau{width:300px;flex:0 0 300px;border-right:1px solid var(--trait);padding:14px;overflow-y:auto;background:var(--brume)}
#droite{flex:1 1 auto;display:flex;flex-direction:column;min-width:0}
#map{position:relative;flex:1 1 auto;height:0}
label.titre{display:block;font-weight:700;font-size:13px;margin:12px 0 4px}
select{width:100%;padding:6px;border:1px solid var(--trait);border-radius:4px;font:inherit;background:#fff}
.familles label{display:grid;grid-template-columns:18px 16px 1fr auto;align-items:center;gap:6px;margin:3px 0;font-size:13.5px}
.familles .ha{color:var(--doux);font-size:12.5px}
.pastille{width:14px;height:14px;border-radius:2px;display:inline-block;border:1px solid rgba(0,0,0,.25)}
.fonds label{margin-right:12px;font-size:14px}
.stats{margin-top:14px;padding:10px;background:#fff;border:1px solid var(--trait);border-radius:4px;font-size:13px;line-height:1.55}
.note{font-size:12px;color:var(--doux);margin-top:12px;line-height:1.4}
button{font:inherit;padding:6px 10px;border:1px solid var(--rouge);background:#fff;color:var(--rouge);border-radius:4px;cursor:pointer;margin-top:12px}
button:hover,button:focus-visible{background:var(--rouge);color:#fff;outline:none}
#zoneTable{display:none;flex:0 0 38%;overflow:auto;border-top:2px solid var(--vert)}
table{border-collapse:collapse;width:100%;font-size:13px}
th{position:sticky;top:0;background:var(--encre);color:#fff;text-align:right;padding:6px 8px;cursor:pointer;white-space:nowrap}
th:nth-child(-n+2),td:nth-child(-n+2){text-align:left}
td{padding:4px 8px;border-bottom:1px solid var(--trait);text-align:right}
tr.actif td{background:#F6E3E4}
tr.comp td{background:var(--brume);font-weight:700}
tbody tr:hover td{background:#EEF0E6;cursor:pointer}
.leaflet-popup-content{font-family:Calibri,"Segoe UI",sans-serif;font-size:13px;min-width:240px}
.leaflet-popup-content h3{margin:0 0 6px;font-size:15px}
.leaflet-popup-content table td{border:none;padding:1px 4px;text-align:left;vertical-align:top}
.util{border:1px solid var(--trait);background:#fff;border-radius:6px;padding:7px 9px;margin-top:6px;font-size:12.5px}
.util .tete{display:flex;align-items:center;gap:6px;font-weight:700;font-size:13px}
.util .tete span.nom{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.util button{margin:0;padding:2px 7px;font-size:12px}
.util .resume{color:var(--doux);margin-top:3px;line-height:1.35}
.etiquette{background:transparent;border:none;box-shadow:none;font:700 12px Calibri,"Segoe UI",sans-serif;color:#555}
@media (max-width:840px){#corps{flex-direction:column}#panneau{width:auto;flex:0 0 auto;border-right:none;border-bottom:1px solid var(--trait)}#map{min-height:60vh}}
</style>
</head>
<body>
<header>
  <div class="eyebrow">NCPA · Observatoire foncier</div>
  <h1>Zonage, servitudes et prescriptions</h1>
  <div class="sous" id="sousTitre"></div>
</header>
<div id="corps">
  <aside id="panneau">
    <label class="titre" for="commune">Commune</label>
    <select id="commune"><option value="">Tout le territoire</option></select>
    <label class="titre">Zones (légende)</label>
    <div class="familles" id="familles"></div>
    <div id="blocSup" style="display:none">
      <label class="titre"><input type="checkbox" id="voirSup"> Servitudes d'utilité publique</label>
      <div class="familles" id="supCats"></div>
    </div>
    <div id="blocPsc" style="display:none">
      <label class="titre"><input type="checkbox" id="voirPsc"> Prescriptions</label>
      <div class="familles" id="pscTypes"></div>
    </div>
    <div id="blocPts" style="display:none">
      <label class="titre"><input type="checkbox" id="voirPts" checked> Permis et friches</label>
      <div class="familles" id="ptsSources"></div>
    </div>
    <div id="blocUtil">
      <label class="titre">Ajouter ma couche (GeoJSON)</label>
      <input type="file" id="fichierUtil" accept=".geojson,.json,application/geo+json" multiple hidden>
      <button type="button" id="btnUtil" style="margin-top:2px">Choisir un fichier GeoJSON…</button>
      <div id="listeUtil"></div>
      <p class="note" style="margin-top:6px">Points, lignes ou surfaces, en WGS84 ou en Lambert-93 (converti automatiquement). Cliquez un objet pour voir la zone du document d'urbanisme où il se trouve. Le fichier reste sur votre poste.</p>
    </div>
    <div class="stats" id="stats"></div>
    <button id="btnTable" type="button" aria-expanded="false">Afficher le tableau</button>
    <p class="note">Cliquez une zone pour son libellé, sa surface et le lien vers son règlement. Communes grisées : règlement national d'urbanisme (RNU) ou document non publié sur le Géoportail de l'Urbanisme.</p>
    <p class="note">Source : Géoportail de l'Urbanisme (API Carto, IGN), données du __DATE__ ; zones découpées par commune et simplifiées pour l'affichage. Seul le document en vigueur publié sur le Géoportail fait foi.</p>
  </aside>
  <div id="droite">
    <div id="map"></div>
    <div id="zoneTable"><table id="table"><thead></thead><tbody></tbody></table></div>
  </div>
</div>
<script>/*LEAFLET_JS*/</script>
<script>/*FONDS_JS*/</script>
<script>
const D = __DONNEES__;
const COUL = Object.fromEntries(D.familles.map(([k,l,c]) => [k,c]));
const LIB = Object.fromEntries(D.familles.map(([k,l]) => [k,l]));
const fmt = (v, d=0) => v==null ? "" : Number(v).toLocaleString("fr-FR",{maximumFractionDigits:d, minimumFractionDigits:d});
const dateFr = d => { d = String(d||""); return /^\d{8}$/.test(d) ? `${d.slice(6)}/${d.slice(4,6)}/${d.slice(0,4)}` : d; };
document.getElementById("sousTitre").textContent = `${D.limites.features.length} commune(s) · ${D.zones.features.length} zones · données du ${D.date}`;

const map = L.map("map", {zoomSnap:0.25, preferCanvas:true});
const fonds = installerFonds(map, estPhoto => surFond(estPhoto));

// communes : contour, et grisé si pas de zonage
function styleCommune(f) {
  const sans = ["RNU","Aucun document en ligne"].includes(f.properties.statut);
  const base = styleLimite(fonds.photo());
  return {...base, fill:sans, fillColor:"#BDBDB5", fillOpacity:sans?.45:0, dashArray:sans ? null : base.dashArray};
}
function surFond() { communes.setStyle(styleCommune); dessiner(); }
const communes = L.geoJSON(D.limites, {style:styleCommune, onEachFeature:(f, l) => {
  const p = f.properties;
  if (["RNU","Aucun document en ligne"].includes(p.statut)) {
    l.bindPopup(`<h3>${p.nom}</h3>${p.statut === "RNU" ? "Règlement national d'urbanisme : pas de zonage local." : "Aucun document d'urbanisme publié sur le Géoportail de l'Urbanisme."}`);
    l.bindTooltip(`${p.nom} · ${p.statut}`, {permanent:false});
  }
}}).addTo(map);

// zones
const famEl = document.getElementById("familles"), comEl = document.getElementById("commune");
D.limites.features.slice().sort((a,b) => a.properties.nom.localeCompare(b.properties.nom))
  .forEach(f => comEl.add(new Option(`${f.properties.nom} (${f.properties.statut})`, f.properties.code)));
const presentes = new Set(D.zones.features.map(f => f.properties.famille));
D.familles.filter(([k]) => presentes.has(k)).forEach(([k,l,c]) =>
  famEl.insertAdjacentHTML("beforeend", `<label><input type="checkbox" value="${k}" checked><span class="pastille" style="background:${c}"></span><span>${l}</span><span class="ha" id="ha_${k}"></span></label>`));
function popup(p) {
  const l = (t,v) => v==null || v==="" ? "" : `<tr><td>${t}</td><td><b>${v}</b></td></tr>`;
  return `<h3 style="color:${COUL[p.famille]}">${p.libelle || p.typezone}</h3><table>
    ${l("Libellé long", p.libelong)}${l("Type", `${p.typezone} · ${p.famille_lib}`)}${l("Commune", p.commune)}
    ${l("Surface dans la commune", fmt(p.surface_ha, 2) + " ha")}${l("Document", `${p.type_document} (${p.partition})`)}
    ${l("Approuvé le", dateFr(p.date_approbation))}
    ${p.reglement_url ? `<tr><td colspan="2"><a href="${p.reglement_url}" target="_blank" rel="noopener">Règlement de la zone (PDF)</a></td></tr>` : ""}</table>`;
}
let couche = null;
function filtre() {
  const fam = new Set([...famEl.querySelectorAll("input:checked")].map(i => i.value)), c = comEl.value;
  return f => fam.has(f.properties.famille) && (!c || f.properties.commune_code === c);
}
var dessiner = function () {
  if (couche) map.removeLayer(couche);
  couche = L.geoJSON({type:"FeatureCollection", features:D.zones.features.filter(filtre())}, {
    style:f => ({color: fonds.photo() ? "#FFFFFF" : "#555", weight:.5, fillColor:COUL[f.properties.famille],
                 fillOpacity: fonds.photo() ? .45 : .6}),
    onEachFeature:(f, l) => l.bindPopup(() => popup(f.properties))}).addTo(map);
  communes.bringToFront();
  stats();
};
function stats() {
  const c = comEl.value, v = D.zones.features.filter(f => !c || f.properties.commune_code === c);
  const tot = {}; v.forEach(f => tot[f.properties.famille] = (tot[f.properties.famille]||0) + f.properties.surface_ha);
  D.familles.forEach(([k]) => { const e = document.getElementById("ha_"+k); if (e) e.textContent = tot[k] ? fmt(tot[k]) + " ha" : "–"; });
  const somme = Object.values(tot).reduce((a,b) => a+b, 0);
  const lg = c ? D.lignes.find(x => x.code === c) : D.lignes.find(x => x.niveau !== "Commune") || D.lignes[0];
  const doc = c ? D.limites.features.find(f => f.properties.code === c).properties : null;
  document.getElementById("stats").innerHTML =
    (doc ? `<div><b>${doc.nom}</b> · ${doc.statut}${doc.document ? " : " + doc.document : ""}${doc.approbation ? ", approuvé le " + doc.approbation : ""}</div>` : "") +
    `<div>Surface zonée : <b>${fmt(somme)}</b> ha${lg && lg.surface_commune ? " sur " + fmt(lg.surface_commune) + " ha" : ""}</div>` +
    `<div>Zones à urbaniser : <b>${fmt((tot.AUc||0) + (tot.AUs||0))}</b> ha (dont ouvertes : ${fmt(tot.AUc||0)} ha)</div>`;
}
famEl.addEventListener("change", dessiner);
comEl.addEventListener("change", () => {
  dessiner();
  const c = comEl.value;
  if (c) communes.eachLayer(l => { if (l.feature.properties.code === c) map.fitBounds(l.getBounds(), {padding:[20,20]}); });
  else map.fitBounds(communes.getBounds(), {padding:[12,12]});
  tableau();
});

// tableau par commune
const COLS = [["nom","Commune"],["statut","Document"],["U","U (ha)"],["AUc","AUc (ha)"],["AUs","AUs (ha)"],["A","A (ha)"],["N","N (ha)"],["zone","Total zoné (ha)"]];
let tri = ["nom", 1];
function tableau() {
  const th = document.querySelector("#table thead"), tb = document.querySelector("#table tbody");
  th.innerHTML = "<tr>" + COLS.map(([k,l]) => `<th data-k="${k}" scope="col">${l}${tri[0]===k?(tri[1]>0?" ▲":" ▼"):""}</th>`).join("") + "</tr>";
  const com = D.lignes.filter(l => l.niveau === "Commune").sort((a,b) => {
    const x=a[tri[0]], y=b[tri[0]]; return (typeof x === "number" ? x-y : String(x).localeCompare(String(y)))*tri[1]; });
  const tot = D.lignes.filter(l => l.niveau !== "Commune");
  const ligne = (l, cls) => `<tr data-code="${l.code}" class="${cls}">` + COLS.map(([k]) => `<td>${typeof l[k] === "number" ? fmt(l[k]) : (l[k]||"")}</td>`).join("") + "</tr>";
  tb.innerHTML = com.map(l => ligne(l, l.code === comEl.value ? "actif" : "")).join("") + tot.map(l => ligne(l, "comp")).join("");
  th.querySelectorAll("th").forEach(h => h.onclick = () => { tri = [h.dataset.k, tri[0]===h.dataset.k ? -tri[1] : (h.dataset.k==="nom"||h.dataset.k==="statut"?1:-1)]; tableau(); });
  tb.querySelectorAll("tr[data-code]").forEach(r => r.onclick = () => {
    if (r.dataset.code === "TOTAL") return;
    comEl.value = r.dataset.code; comEl.dispatchEvent(new Event("change")); });
}
document.getElementById("btnTable").onclick = e => {
  const z = document.getElementById("zoneTable"), ouvert = z.style.display === "block";
  z.style.display = ouvert ? "none" : "block";
  e.target.textContent = ouvert ? "Afficher le tableau" : "Masquer le tableau";
  e.target.setAttribute("aria-expanded", String(!ouvert));
  setTimeout(() => map.invalidateSize(), 50);
};
// ---------- couches de l'étape 2 : servitudes, prescriptions, permis et friches
function listeCases(el, items, compte) {
  items.forEach(([k,l,c]) => el.insertAdjacentHTML("beforeend",
    `<label><input type="checkbox" value="${k}" checked><span class="pastille" style="background:${c}"></span><span>${l}</span><span class="ha">${compte(k)}</span></label>`));
}
const cochees = el => new Set([...el.querySelectorAll("input:checked")].map(i => i.value));
const COUL_SUP = Object.fromEntries(D.sup_cat.map(([k,l,c]) => [k,c]));
const COUL_PSC = Object.fromEntries(D.psc_types.map(([k,l,c]) => [k,c]));
const COUL_PT = Object.fromEntries(D.sources.map(([k,l,c]) => [k,c]));
const supEl = document.getElementById("supCats"), pscEl = document.getElementById("pscTypes"), ptsEl = document.getElementById("ptsSources");
if (D.sup_cat.length) { document.getElementById("blocSup").style.display = "block";
  listeCases(supEl, D.sup_cat.map(([k,l,c]) => [k, `${k} · ${l}`, c]), k => D.servitudes.features.filter(f => f.properties.categorie === k).length); }
if (D.psc_types.length) { document.getElementById("blocPsc").style.display = "block";
  listeCases(pscEl, D.psc_types, k => D.prescriptions.features.filter(f => f.properties.typepsc === k).length); }
if (D.sources.length) { document.getElementById("blocPts").style.display = "block";
  listeCases(ptsEl, D.sources, k => D.points.filter(p => p.source === k).length); }
const ligneP = (t,v) => v==null || v==="" ? "" : `<tr><td>${t}</td><td><b>${v}</b></td></tr>`;
let coucheSup = null, couchePsc = null, couchePts = null;
const dansCommune = p => !comEl.value || p.commune_code === comEl.value;
function geomStyle(c, f) {
  const t = f.geometry.type;
  return t.includes("Line") ? {color:c, weight:3, opacity:.9} : {color:c, weight:2, dashArray:"6 3", fillColor:c, fillOpacity:.15};
}
function dessinerEtape2() {
  [coucheSup, couchePsc, couchePts].forEach(c => { if (c) map.removeLayer(c); });
  if (D.sup_cat.length && document.getElementById("voirSup").checked) {
    const ok = cochees(supEl);
    coucheSup = L.geoJSON({type:"FeatureCollection", features:D.servitudes.features.filter(f => ok.has(f.properties.categorie) && dansCommune(f.properties))}, {
      style:f => geomStyle(COUL_SUP[f.properties.categorie], f),
      pointToLayer:(f, ll) => L.circleMarker(ll, {radius:5, color:"#fff", weight:1, fillColor:COUL_SUP[f.properties.categorie], fillOpacity:.95}),
      onEachFeature:(f, l) => l.bindPopup(() => { const p = f.properties; return `<h3 style="color:${COUL_SUP[p.categorie]}">${p.categorie} · ${p.categorie_lib}</h3><table>
        ${ligneP("Objet", p.nom)}${ligneP("Type d'assiette", p.type_assiette)}${ligneP("Commune", p.commune)}
        ${ligneP("Emprise dans la commune", p.unite === "ha" ? fmt(p.mesure, 2) + " ha" : p.unite === "m" ? fmt(p.mesure) + " m" : "")}
        ${ligneP("Jeu de données", p.gestionnaire)}</table>`; })}).addTo(map);
  }
  if (D.psc_types.length && document.getElementById("voirPsc").checked) {
    const ok = cochees(pscEl);
    couchePsc = L.geoJSON({type:"FeatureCollection", features:D.prescriptions.features.filter(f => ok.has(f.properties.typepsc) && dansCommune(f.properties))}, {
      style:f => { const c = COUL_PSC[f.properties.typepsc]; return f.geometry.type.includes("Line") ? {color:c, weight:3} : {color:c, weight:1.5, fillColor:c, fillOpacity:.35}; },
      pointToLayer:(f, ll) => L.circleMarker(ll, {radius:5, color:"#fff", weight:1, fillColor:COUL_PSC[f.properties.typepsc], fillOpacity:.95}),
      onEachFeature:(f, l) => l.bindPopup(() => { const p = f.properties; return `<h3 style="color:${COUL_PSC[p.typepsc]}">${p.type_lib}</h3><table>
        ${ligneP("Libellé", p.libelle)}${ligneP("Commune", p.commune)}
        ${ligneP("Emprise", p.unite === "ha" ? fmt(p.mesure, 2) + " ha" : p.unite === "m" ? fmt(p.mesure) + " m" : "")}
        ${p.reglement_url ? `<tr><td colspan="2"><a href="${p.reglement_url}" target="_blank" rel="noopener">Document associé</a></td></tr>` : ""}</table>`; })}).addTo(map);
  }
  if (D.sources.length && document.getElementById("voirPts").checked) {
    const ok = cochees(ptsEl);
    couchePts = L.layerGroup(D.points.filter(p => ok.has(p.source) && dansCommune(p)).map(p =>
      L.circleMarker([p.lat, p.lon], {radius:p.source === "friche" ? 7 : 5, color:"#fff", weight:1.5, fillColor:COUL_PT[p.source], fillOpacity:.95})
        .bindTooltip(p.nom || "")
        .bindPopup(`<h3 style="color:${COUL_PT[p.source]}">${D.sources.find(s => s[0] === p.source)[1]} · ${p.nom || ""}</h3><table>
          ${ligneP("Zone", p.zone ? `${p.zone} (${p.famille_lib})` : p.famille_lib)}${ligneP("Servitudes", p.servitudes)}
          ${ligneP("Prescriptions", p.prescriptions)}${ligneP("Date", p.date)}${ligneP("État", p.etat)}
          ${ligneP("Logements", p.logements ? fmt(p.logements) : "")}${ligneP("Logements à venir", p.a_venir)}
          ${ligneP("Surface", p.surface_ha ? fmt(p.surface_ha, 2) + " ha" : "")}
          ${p.reglement_url ? `<tr><td colspan="2"><a href="${p.reglement_url}" target="_blank" rel="noopener">Règlement de la zone (PDF)</a></td></tr>` : ""}</table>`)
    )).addTo(map);
  }
}
["voirSup","voirPsc","voirPts"].forEach(id => document.getElementById(id).addEventListener("change", dessinerEtape2));
[supEl, pscEl, ptsEl].forEach(el => el.addEventListener("change", dessinerEtape2));
comEl.addEventListener("change", dessinerEtape2);
// ---------- couches ajoutées par l'utilisateur (GeoJSON local)
const PAL_UTIL = ["#6A1B9A", "#0277BD", "#E65100", "#00838F", "#AD1457", "#1B5E20"];
const couchesUtil = [];
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function l93(x, y) {   // Lambert-93 -> WGS84 (formules IGN)
  const n = 0.7256077650532670, C = 11754255.426096, Xs = 700000, Ys = 12655612.049876, e = 0.0818191910428158, l0 = 3 * Math.PI / 180;
  const dx = x - Xs, dy = y - Ys, R = Math.hypot(dx, dy), g = Math.atan(dx / -dy), lat0 = -1 / n * Math.log(Math.abs(R / C));
  let phi = 2 * Math.atan(Math.exp(lat0)) - Math.PI / 2;
  for (let i = 0; i < 12; i++) { const s = e * Math.sin(phi); phi = 2 * Math.atan(Math.pow((1 + s) / (1 - s), e / 2) * Math.exp(lat0)) - Math.PI / 2; }
  return [(l0 + g / n) * 180 / Math.PI, phi * 180 / Math.PI];
}
let conversion = "";
function corriger(c) {
  if (Math.abs(c[0]) > 1000 && Math.abs(c[1]) > 1000) { conversion = "Lambert-93 converti"; return l93(c[0], c[1]); }
  if (c[0] >= 41 && c[0] <= 52 && c[1] >= -6 && c[1] <= 10) { conversion = "latitude et longitude inversées corrigées"; return [c[1], c[0]]; }
  return c;
}
function corrigerGeom(g) {
  if (!g) return g;
  if (g.type === "GeometryCollection") return {...g, geometries: g.geometries.map(corrigerGeom)};
  const t = a => typeof a[0] === "number" ? corriger(a) : a.map(t);
  return {...g, coordinates: t(g.coordinates)};
}
function boite(g) {
  let b = [Infinity, Infinity, -Infinity, -Infinity];
  const parc = a => { if (typeof a[0] === "number") b = [Math.min(b[0], a[0]), Math.min(b[1], a[1]), Math.max(b[2], a[0]), Math.max(b[3], a[1])]; else a.forEach(parc); };
  parc(g.coordinates); return b;
}
const boitesZones = D.zones.features.map(f => boite(f.geometry));
function dansAnneau(x, y, r) {
  let d = false;
  for (let i = 0, j = r.length - 1; i < r.length; j = i++) {
    const [xi, yi] = r[i], [xj, yj] = r[j];
    if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) d = !d;
  }
  return d;
}
const dansPoly = (x, y, p) => dansAnneau(x, y, p[0]) && !p.slice(1).some(t => dansAnneau(x, y, t));
function zoneDe(x, y) {
  for (let i = 0; i < D.zones.features.length; i++) {
    const b = boitesZones[i];
    if (x < b[0] || x > b[2] || y < b[1] || y > b[3]) continue;
    const g = D.zones.features[i].geometry;
    const polys = g.type === "Polygon" ? [g.coordinates] : g.type === "MultiPolygon" ? g.coordinates : [];
    if (polys.some(p => dansPoly(x, y, p))) return D.zones.features[i].properties;
  }
  return null;
}
function etiquette(p) {
  for (const k of ["nom", "name", "libelle", "label", "NOM", "Nom", "LIBELLE", "id", "ID"]) if (p && p[k] != null && p[k] !== "") return String(p[k]);
  const v = Object.values(p || {}).find(v => typeof v === "string" && v);
  return v || "";
}
function popupUtil(nomCouche, p, ll) {
  const z = ll ? zoneDe(ll.lng, ll.lat) : null;
  const attributs = Object.entries(p || {}).slice(0, 30)
    .map(([k, v]) => `<tr><td>${esc(k)}</td><td><b>${esc(String(v ?? "").slice(0, 150))}</b></td></tr>`).join("");
  return `<h3 style="color:#6A1B9A">${esc(etiquette(p) || nomCouche)}</h3><table>
    ${ligneP("Couche", esc(nomCouche))}
    ${z ? ligneP("Zone", esc(`${z.libelle || z.typezone} (${z.famille_lib})`)) + ligneP("Commune", esc(z.commune)) : ligneP("Zone", "hors des zones extraites (RNU, commune non choisie ou hors territoire)")}
    ${attributs}</table>
    ${z && z.reglement_url ? `<a href="${z.reglement_url}" target="_blank" rel="noopener">Règlement de la zone (PDF)</a>` : ""}`;
}
const listeUtil = document.getElementById("listeUtil");
function ajouterCouche(nom, donnees) {
  conversion = "";
  let feats = donnees.type === "FeatureCollection" ? donnees.features : donnees.type === "Feature" ? [donnees]
            : donnees.type ? [{type: "Feature", properties: {}, geometry: donnees}] : [];
  feats = feats.filter(f => f && f.geometry).map(f => ({...f, geometry: corrigerGeom(f.geometry)}));
  if (!feats.length) { alert(`${nom} : aucun objet avec une géométrie.`); return; }
  const c = PAL_UTIL[couchesUtil.length % PAL_UTIL.length];
  const couche = L.geoJSON({type: "FeatureCollection", features: feats}, {
    style: () => ({color: c, weight: 2.5, fillColor: c, fillOpacity: .25}),
    pointToLayer: (f, ll) => L.circleMarker(ll, {radius: 7, color: "#fff", weight: 2, fillColor: c, fillOpacity: .95}),
    onEachFeature: (f, l) => {
      const lib = etiquette(f.properties);
      if (lib) l.bindTooltip(esc(lib));
      l.bindPopup(() => popupUtil(nom, f.properties, l.getLatLng ? l.getLatLng() : l.getBounds().getCenter()));
    }}).addTo(map);
  // résumé : où tombent les points ?
  const parFamille = {};
  let nbPoints = 0;
  feats.forEach(f => {
    if (f.geometry.type !== "Point") return;
    nbPoints++;
    const z = zoneDe(f.geometry.coordinates[0], f.geometry.coordinates[1]);
    const k = z ? z.famille_lib : "Hors zones extraites";
    parFamille[k] = (parFamille[k] || 0) + 1;
  });
  const resume = nbPoints ? Object.entries(parFamille).sort((a, b) => b[1] - a[1]).map(([k, n]) => `${n} en ${k}`).join(" · ") : "";
  const div = document.createElement("div");
  div.className = "util";
  div.innerHTML = `<div class="tete"><span class="pastille" style="background:${c};border-radius:50%"></span><span class="nom" title="${esc(nom)}">${esc(nom)}</span>
    <button type="button" data-a="zoom">Zoom</button><button type="button" data-a="retirer">Retirer</button></div>
    <div class="resume">${feats.length} objet(s)${conversion ? " · " + conversion : ""}${resume ? "<br>" + esc(resume) : ""}</div>`;
  div.querySelector('[data-a="zoom"]').onclick = () => map.fitBounds(couche.getBounds(), {padding: [30, 30], maxZoom: 16});
  div.querySelector('[data-a="retirer"]').onclick = () => { map.removeLayer(couche); div.remove(); };
  listeUtil.appendChild(div);
  couchesUtil.push(couche);
  map.fitBounds(couche.getBounds(), {padding: [30, 30], maxZoom: 16});
}
document.getElementById("btnUtil").onclick = () => document.getElementById("fichierUtil").click();
document.getElementById("fichierUtil").addEventListener("change", e => {
  [...e.target.files].forEach(fichier => {
    const lecteur = new FileReader();
    lecteur.onload = () => {
      try { ajouterCouche(fichier.name.replace(/\.(geo)?json$/i, ""), JSON.parse(lecteur.result)); }
      catch (err) { alert(`${fichier.name} : fichier GeoJSON illisible (${err.message}).`); }
    };
    lecteur.readAsText(fichier);
  });
  e.target.value = "";
});

const dessinerZones = dessiner;
dessiner = function () { dessinerZones(); dessinerEtape2(); };

dessiner(); tableau();
map.fitBounds(communes.getBounds(), {padding:[12,12]});
setTimeout(() => map.invalidateSize(), 50);
</script>
</body>
</html>
"""

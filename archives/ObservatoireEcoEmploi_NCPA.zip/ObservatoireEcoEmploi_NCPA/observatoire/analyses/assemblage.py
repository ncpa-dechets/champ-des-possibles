# -*- coding: utf-8 -*-
"""Assemble les deux moteurs d'analyse repris des anciens outils (portrait économique en pandas, emploi en Python
pur) en un seul résultat : blocs rangés par thème du catalogue, chiffres clés, synthèse rédigée, cartes.

Doublons tranchés ici :
  - évolution de l'emploi salarié privé en base 100 : version Emploi (avec groupes d'EPCI), l'ancienne version du
    portrait (urssaf_indice) est abandonnée ;
  - emplois par commune : un seul bloc, graphique de l'outil Emploi (toutes les communes) et lecture « concentration »
    du portrait (avec le tableau des 10 premières activités) ;
  - navettes domicile-travail : blocs Emploi (destinations et origines), l'ancien bloc du portrait est abandonné ; ses
    flux, désormais téléchargés automatiquement, servent toujours au calcul de la base économique ;
  - résidences secondaires de l'EPCI : dossier complet Insee (l'appel Melodi propre à l'outil Emploi est supprimé) ;
  - indicateurs ANCT déjà présents dans le portrait (concentration d'emploi, sphère présentielle, chômage) : retirés
    du bloc ANCT quand le portrait est calculé.
"""
import re
import traceback

import pandas as pd

from .. import catalogue
from ..utils import fmt_nombre, log
from . import blocs_emploi as BE

ECO_THEMES = {"emploi_actifs": "recensement", "ice_compare": "recensement", "secteurs_rp": "recensement",
              "urssaf_secteurs": "secteurs", "spheres_evol": "spheres", "spheres_compare": "spheres",
              "spheres_officielles": "spheres", "spheres_insee": "spheres", "residences_secondaires": "base_eco",
              "revenus": "base_eco", "base_eco": "base_eco"}
ECO_ESSENTIELS = {"emploi_actifs", "spheres_insee", "base_eco", "residences_secondaires"}
THEMES_ECO = {"recensement", "spheres", "base_eco", "secteurs", "communes"}


def parametres(brut, params=None):
    """Paramètres de calcul (période, niveau, groupes) complétés par les valeurs par défaut."""
    p = dict(params or {})
    ans = (brut.get("urssaf") or {}).get("annees") or []
    a2 = p.get("a2") if p.get("a2") in ans else (ans[-1] if ans else None)
    a1 = p.get("a1") if p.get("a1") in ans and (a2 is None or p.get("a1") < a2) else \
        (ans[max(0, len(ans) - 11)] if ans else None)
    opt = brut.get("options") or {}
    p.update(a1=a1, a2=a2, niveau=p.get("niveau") or "NA38",
             grp_dep=p.get("grp_dep", True), grp_reg=p.get("grp_reg", True),
             grp_taille=p.get("grp_taille", opt.get("grp_taille", True)),
             critere=p.get("critere") or opt.get("critere") or "emplois", tolerance=p.get("tolerance") or 30,
             grp_france=p.get("grp_france", False), bassin=p.get("bassin") or opt.get("bassin"))
    return p


def _brut_emploi(brut, res_eco):
    """Données au format attendu par les calculs de l'ancien outil Emploi."""
    u = brut.get("urssaf") or {}
    be = {"siren": brut["siren"], "date": brut["date"], "annees": u.get("annees") or [], "detail": u.get("detail") or [],
          "refs": u.get("refs") or [], "epci": u.get("epci") or [], "communes_epci": u.get("communes_epci") or {},
          "geo": brut.get("fc_epci")}
    for k in ("masse", "pop", "tourisme", "littoral", "rs", "employeurs", "employeurs_tous", "sirene_demo", "anct",
              "bmo", "ft", "flores", "creations", "mobilites", "bodacc"):
        if brut.get(k) is not None:
            be[k] = brut[k]
    if res_eco is not None:  # parc de logements de l'EPCI : dossier complet (remplace l'appel Melodi)
        D = res_eco["D"]
        try:
            rs, tot = D.serie("log_rs", "EPCI", D.cible), D.serie("log_total", "EPCI", D.cible)
            be["logements"] = {str(a): {"rs": float(rs[a]), "total": float(tot[a])} for a in rs.index if a in tot.index}
        except Exception:
            pass
    return be


def _res_minimal(brut):
    return {"ref": brut["siren"], "ref_nom": brut["nom"], "dep": brut["dep"], "reg": brut["reg"],
            "dep_nom": brut["dep_nom"], "reg_nom": brut["reg_nom"], "groupes": {}, "synthese": [""], "journal": [],
            "geo": brut.get("fc_epci"), "a_deb": None, "a_fin": None}


def _navettes(brut, cfg):
    m = brut.get("mobilites")
    if m and m.get("flux"):
        return pd.DataFrame([{"origine": r, "destination": t, "flux": n} for r, _, t, _, n in m["flux"]])
    from ..collecte.manuels import charger_navettes
    return charger_navettes(cfg)


def _portrait(brut, themes, journal):
    if not (set(themes) & THEMES_ECO) or brut.get("com") is None:
        return None, None
    if brut.get("insee") is None and not brut.get("urssaf"):
        return None, None
    from ..collecte import urssaf
    from ..collecte.insee import extraire_indicateurs
    from ..collecte.manuels import charger_spheres_officielles
    from . import eco
    cfg = brut["cfg"]
    if brut.get("insee") is not None:
        tidy, rapport = extraire_indicateurs(brut["insee"], cfg["indicateurs"], cfg["code_epci"])
    else:
        tidy = pd.DataFrame(columns=["code", "niveau", "geo", "annee", "valeur", "libgeo"])
        rapport = pd.DataFrame()
    U = urssaf.vers_dataframe(brut["urssaf"]["region"]) if brut.get("urssaf") else None
    epcis = brut["epcis"]
    spheres_off = charger_spheres_officielles(set(epcis.code) | set(cfg["deps_region"]) | {cfg["region"]}) \
        if "spheres" in themes else None
    res = eco.analyser(tidy, U, brut["com"], epcis, cfg, _navettes(brut, cfg) if "base_eco" in themes else None,
                       spheres_off, brut.get("grille"), brut.get("ircom"))
    res["tidy"], res["rapport_indic"] = tidy, rapport
    return res, rapport


def assembler(brut, themes, params=None):
    themes = [t for t in catalogue.THEMES if t in set(themes)]
    p = parametres(brut, params)
    journal = []

    # ------------------------------------------------------------------ 1. portrait économique
    res_eco = None
    try:
        res_eco, _ = _portrait(brut, themes, journal)
    except Exception as e:
        journal.append(f"Portrait économique non calculé : {e}")
        log("Analyses", f"portrait économique non calculé : {e}\n{traceback.format_exc()[-800:]}", "erreur")
    blocs_eco = {b["id"]: b for b in (res_eco or {}).get("blocs", [])}

    # ------------------------------------------------------------------ 2. emploi
    from . import emploi as calculs
    be = _brut_emploi(brut, res_eco)
    r = None
    if brut.get("urssaf") and p["a1"] is not None:
        try:
            r = calculs.calculer(be, p)
        except Exception as e:
            journal.append(f"Calculs Urssaf impossibles : {e}")
            log("Analyses", f"calculs Urssaf impossibles : {e}", "erreur")
    if r is None:
        r = _res_minimal(brut)
    try:
        calculs.completer(r, be, p)
    except Exception as e:
        journal.append(f"Compléments (France Travail, BMO, mobilités…) partiels : {e}")
        log("Analyses", f"compléments partiels : {e}\n{traceback.format_exc()[-800:]}", "alerte")
    journal += r.get("journal", [])

    # ------------------------------------------------------------------ 3. blocs par thème
    blocs = []
    a_urssaf = "serie" in r
    for t in themes:
        lot = []
        try:
            if t in ("recensement", "spheres", "base_eco"):
                lot = [dict(b, essentiel=b["id"] in ECO_ESSENTIELS) for i, b in blocs_eco.items() if ECO_THEMES.get(i) == t]
                if t == "spheres" and "spheres_insee" not in blocs_eco:
                    lot = [dict(b, essentiel=b["id"] == "spheres_evol") for b in lot]
            elif t == "evolution" and a_urssaf:
                lot = BE.b_evolution(r)
            elif t == "secteurs":
                lot = ([blocs_eco["urssaf_secteurs"]] if "urssaf_secteurs" in blocs_eco else []) + \
                      (BE.b_secteurs(r) if a_urssaf else [])
            elif t == "communes":
                conc = blocs_eco.get("concentration")
                if a_urssaf:
                    lot = BE.b_communes(r, conc)
                elif conc:
                    lot = [conc]
            elif t == "salaires" and a_urssaf:
                lot = BE.b_salaires(r)
            elif t == "flores":
                lot = BE.b_flores(r)
            elif t == "ft":
                lot = BE.b_ft(r, brut.get("ft"))
            elif t == "saison":
                lot = BE.b_saison(r)
            elif t == "bmo":
                lot = BE.b_bmo(r)
            elif t == "tensions":
                lot = BE.b_tensions(r, brut.get("ft_tensions"))
            elif t == "employeurs":
                lot = BE.b_employeurs(r, brut.get("employeurs"))
            elif t == "lbb":
                lot = BE.b_lbb(r, brut.get("lbb"))
            elif t == "demographie":
                lot = BE.b_demographie(r)
            elif t == "mobilites":
                lot = BE.b_mobilites(r)
            elif t == "anct" and r.get("groupes"):
                lot = BE.b_anct(r, set(blocs_eco))
        except Exception as e:
            journal.append(f"Thème « {catalogue.THEMES[t][1]} » : erreur de calcul ({e})")
            log("Analyses", f"{t} : {e}\n{traceback.format_exc()[-800:]}", "erreur")
        for b in lot:
            b = dict(b, theme=t, famille=catalogue.THEMES[t][0])
            b.setdefault("essentiel", False)
            if b.get("table") is None:
                b["table"] = pd.DataFrame()
            blocs.append(b)
        if not lot:
            journal.append(f"Thème « {catalogue.THEMES[t][1]} » : aucune analyse (source indisponible ou non collectée).")

    # ------------------------------------------------------------------ 4. chiffres clés et synthèse
    cles = list((res_eco or {}).get("cles", []))
    noms_cles = {c["libelle"] for c in cles}

    def cle(lib, v, txt, sous=""):
        if lib not in noms_cles:
            cles.append({"libelle": lib, "valeur": v, "texte": txt, "sous": sous})
            noms_cles.add(lib)
    if a_urssaf:
        e = r["evol_terr"][r["ref_nom"]]
        fr = r["evol_terr"].get("France", {})
        cle("Salariés du privé", e["eff"], fmt_nombre(e["eff"]), f"au 31/12/{r['a_fin']} (Urssaf, hors agriculture)")
        cle("Évolution de l'emploi privé", e["evol"], BE._p(e["evol"], True),
            f"{r['a_deb']}-{r['a_fin']} (France : {BE._p(fr.get('evol'), True)})")
        if r["shift"].get("effet_local") is not None:
            cle("Effet local", r["shift"]["effet_local"], f"{r['shift']['effet_local']:+,.0f}".replace(",", "\u202f"),
                "emplois dus à la dynamique propre du territoire")
        if (r.get("ind_ref") or {}).get("salaire"):
            cle("Salaire brut moyen", r["ind_ref"]["salaire"], fmt_nombre(r["ind_ref"]["salaire"]) + " €",
                f"par salarié et par an ({r['annee_salaire']})")
    ft_e = (((brut.get("ft") or {}).get("territoires") or {}).get("EPCI") or {})
    if ft_e.get("de_abc"):
        cle("Demandeurs d'emploi A, B, C", ft_e["de_abc"], fmt_nombre(ft_e["de_abc"]),
            f"{ft_e.get('periode_de') or ''} (France Travail)")
    if ft_e.get("offres_12m"):
        cle("Offres d'emploi sur 12 mois", ft_e["offres_12m"], fmt_nombre(ft_e["offres_12m"]),
            f"{fmt_nombre(ft_e.get('offres_pour_100_de'))} pour 100 demandeurs")
    if brut.get("employeurs"):
        cle("Employeurs actifs", len(brut["employeurs"]), fmt_nombre(len(brut["employeurs"])),
            "établissements employeurs (SIRENE)")
    items = (brut.get("lbb") or {}).get("items") or []
    if items:
        n = len({i["siret"] or i["nom"] for i in items})
        cle("Entreprises susceptibles d'embaucher", n, fmt_nombre(n), "La Bonne Boite, métiers recherchés")

    synthese = []
    for i in ("emploi_actifs", "spheres_insee", "residences_secondaires", "base_eco"):
        b = blocs_eco.get(i)
        if b and any(x["id"] == i for x in blocs):
            synthese.append(re.split(r"(?<=\.)\s", b["lecture"], maxsplit=1)[0])
    synthese += [s for s in r.get("synthese", []) if s and (a_urssaf or not s.startswith("Emploi salarié privé mesuré"))]

    # ------------------------------------------------------------------ 5. cartes
    from ..rendu import cartes
    donnees_cartes = {}
    try:
        donnees_cartes["communes"] = cartes.donnees_choroplethe(res_eco, r if a_urssaf else None, brut)
    except Exception as e:
        log("Analyses", f"carte des communes non préparée : {e}", "alerte")
    if "employeurs" in themes or "lbb" in themes:
        donnees_cartes["entreprises"] = cartes.donnees_entreprises(
            brut.get("employeurs") if "employeurs" in themes else None,
            items if "lbb" in themes else None, brut)
    if "mobilites" in themes and r.get("mobilites"):
        donnees_cartes["flux"] = cartes.donnees_flux(r["mobilites"], brut)

    return {
        "nom": brut["cfg"]["nom_court"], "nom_long": brut["nom"], "siren": brut["siren"], "date": brut["date"],
        "themes": themes, "params": p, "blocs": blocs, "cles": cles, "synthese": synthese, "journal": journal,
        "groupes": list(r.get("groupes") or {}), "bassins": r.get("bmo_bassins") or {},
        "annees": (brut.get("urssaf") or {}).get("annees") or [], "niveaux_dispo": ["Grand secteur", "NA17", "NA38", "NA88"],
        "employeurs": brut.get("employeurs") or [], "lbb": items, "lbb_info": {k: v for k, v in (brut.get("lbb") or {}).items()
                                                                                if k != "items"},
        "cartes": donnees_cartes, "base_eco": (res_eco or {}).get("base_eco"),
        "rapport_indic": (res_eco or {}).get("rapport_indic"), "dep_nom": brut["dep_nom"],
        "journal_collecte": brut.get("journal_collecte") or [],
    }

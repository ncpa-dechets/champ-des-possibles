# -*- coding: utf-8 -*-
"""Faux réseau pour les tests hors ligne de l'outil fusionné.

Branche toutes les requêtes de SessionSuivie (donc de tous les modules, éco comme emploi) sur :
  - le faux serveur de l'ancien outil Emploi (structures relevées par les sondes réelles) ;
  - une géographie régionale cohérente (communes NCPA du faux serveur + autres EPCI de Normandie) ;
  - un dossier complet Insee fictif (structure du générateur de démonstration de l'ancien portrait) ;
  - une réponse La Bonne Boite plausible (structure supposée, non vérifiée).
Usage : faux_reseau.installer() avant moteur.collecter(...). Données FICTIVES.
"""
import io
import json
import math

import numpy as np
import pandas as pd

import faux_serveur as FS
from observatoire import reseau
from observatoire.utils import SUIVI

RNG = np.random.default_rng(3)
REGION = ["14", "27", "50", "61", "76"]


# ------------------------------------------------------------------------------------------- géographie
def _geographie():
    feats, detail, com_epci = [], [], dict(FS.COMMUNE_EPCI)
    for k, (c, n, cps) in enumerate(FS.COMMUNES):
        x0, y0 = -0.35 + (k % 7) * .05, 49.10 + (k // 7) * .035
        feats.append(({"code": c, "nom": n, "codeEpci": FS.SIREN, "codeDepartement": "14", "population": 1000 + 100 * k,
                       "codesPostaux": cps}, (x0, y0, .05, .035)))
    compteur = {d: 600 for d in REGION}
    autres = [e for e in FS.AUTRES_EPCI if e[2] in REGION and e[0] != "ZZZZZZZZZ"][:70]
    for j, (e, nom, d) in enumerate(autres):
        for i in range(3):
            code = f"{d}{compteur[d]:03d}"
            compteur[d] += 1
            com_epci[code] = e
            x0, y0 = -1.6 + (j % 10) * .3 + i * .09, 48.6 + (j // 10) * .17
            feats.append(({"code": code, "nom": f"{nom} c{i}", "codeEpci": e, "codeDepartement": d,
                           "population": int(RNG.integers(400, 9000)), "codesPostaux": [f"{d}000"]}, (x0, y0, .08, .1)))
    fc = {}
    for p, (x, y, w, h) in feats:
        fc.setdefault(p["codeDepartement"], []).append(
            {"type": "Feature", "properties": p,
             "geometry": {"type": "Polygon", "coordinates": [[[x, y], [x + w, y], [x + w, y + h], [x, y + h], [x, y]]]}})
    # détail Urssaf régional : NCPA (faux serveur) + 4 activités par commune des autres EPCI
    for r in FS.detail_ncpa():
        detail.append({**r, "code_epci": FS.SIREN, "code_departement": "14"})
    for d, fs in fc.items():
        for f in fs:
            p = f["properties"]
            if p["codeEpci"] == FS.SIREN:
                continue
            for code, lib, gs in FS.SECTEURS[:4]:
                base = int(RNG.integers(5, 120))
                r = {"code_commune": p["code"], "intitule_commune": p["nom"], "code_epci": p["codeEpci"],
                     "code_departement": d, "grand_secteur_d_activite": gs, "secteur_na17j": lib,
                     "secteur_na38i": lib, "secteur_na88i": lib, "ape": FS.APE[code][0]}
                for a in FS.ANNEES:
                    r[f"effectifs_salaries_{a}"] = FS._eff(base, a)
                    r[f"nombre_d_etablissements_{a}"] = max(1, base // 6)
                detail.append(r)
    return fc, detail, com_epci


FC, DETAIL, COM_EPCI = _geographie()
NOMS_EPCI = {e: n for e, n, _ in FS.TOUS_EPCI}


# ------------------------------------------------------------------------------------------- dossier Insee
def dossier_insee():
    lignes = []
    epci_pop = {}
    for fs in FC.values():
        for f in fs:
            p = f["properties"]
            epci_pop[p["codeEpci"]] = epci_pop.get(p["codeEpci"], 0) + p["population"]
    geos = [("EPCI", e, NOMS_EPCI.get(e, e), pop, e == FS.SIREN) for e, pop in epci_pop.items()]
    geos += [("DEP", d, f"Département {d}", 600000.0, False) for d in REGION]
    geos += [("REG", "28", "Normandie", 3300000.0, False)]
    geos += [("COM", f["properties"]["code"], f["properties"]["nom"], f["properties"]["population"], False)
             for fs in FC.values() for f in fs]
    ans = {"2012": .95, "2017": .98, "2023": 1.0}

    def m(obj, g, lab, tab, mes, meslab, vals, unit=""):
        for an, v in vals.items():
            lignes.append((obj, g, lab, an, tab, tab, mes, meslab, v, 0, unit))
    for obj, g, lab, pop, cible in geos:
        if cible:
            pop = 31981.0
        ice = 73.0 if cible else RNG.uniform(55, 120)
        actifs = pop * .4
        emplois = actifs * ice / 100
        rs = .54 if cible else RNG.uniform(.1, .6)
        m(obj, g, lab, "POP_T1", "POP", "Population", {a: pop * f for a, f in ans.items()})
        m(obj, g, lab, "EMP_T5", "NBEMP_AGE_Y_GE15", "Nombre d’emplois – 15 ans ou plus",
          {a: emplois * f for a, f in ans.items()})
        m(obj, g, lab, "EMP_T5", "POP_EMPSTA_ENQ_1_AGE_Y_GE15", "Population – Actif occupé * 15 ans ou plus",
          {a: actifs * f for a, f in ans.items()})
        m(obj, g, lab, "EMP_T4", "POP_EMPSTA_ENQ_1T2_AGE_Y15T64", "Population – Actif * De 15 à 64 ans",
          {a: actifs * 1.1 * f for a, f in ans.items()})
        m(obj, g, lab, "EMP_T4", "POP_EMPSTA_ENQ_2_AGE_Y15T64", "Population – Chômeur * De 15 à 64 ans",
          {a: actifs * 1.1 * f * .1 for a, f in ans.items()})
        parts = [.03, .13, .08, .48, .28]
        m(obj, g, lab, "EMP_T8", "NBEMP", "Nombre d’emplois", {a: emplois * f for a, f in ans.items()})
        for (mes, meslab), part in zip([("AZ", "Agriculture"), ("BE", "Industrie"), ("FZ", "Construction"),
                                        ("GU", "Services principalement marchands"), ("OQ", "Administration publique")],
                                       parts):
            m(obj, g, lab, "EMP_T8", f"NBEMP_EMP_ACTIVITY_{mes}", f"Nombre d’emplois – {meslab}",
              {a: emplois * part * f for a, f in ans.items()})
        eff, pres = emplois * .85, (.695 if cible else RNG.uniform(.5, .8))
        m(obj, g, lab, "RES_T3", "EMPL3112_LEGAL_FORM_WITH_PUBLIC_1T9X7", "Effectifs – Ensemble hors particuliers employeurs", {"2024": eff})
        m(obj, g, lab, "RES_T3", "EMPL3112_LEGAL_FORM_WITH_PUBLIC_1T9X7_ECONOMIC_SPHERE_PRESENTIAL",
          "Effectifs – Ensemble hors particuliers employeurs * sphère présentielle", {"2024": eff * pres})
        logts = pop / 2.1 / (1 - rs)
        m(obj, g, lab, "LOG_T1", "DWELLINGS", "Logements", {a: logts * f for a, f in ans.items()})
        m(obj, g, lab, "LOG_T1", "DWELLINGS_OCS_DW_SEC_DW_OCC", "Logements – Résidences secondaires",
          {a: logts * rs * f for a, f in ans.items()})
        m(obj, g, lab, "REV_T1", "NB_PERS_HH_FISC", "Nombre de personnes dans les ménages fiscaux", {"2023": pop * .97})
        m(obj, g, lab, "REV_T1", "MED_SL", "Niveau de vie médian (en euros)", {"2023": RNG.uniform(21500, 27500)})
        m(obj, g, lab, "REV_T1", "PR_MD60", "Taux de pauvreté", {"2023": RNG.uniform(8, 17)})
        if obj in ("DEP", "REG") or (obj == "EPCI" and not cible):
            pens = RNG.uniform(27, 38)
            for mes, v in (("S_EI_DI", 100 - pens - 9), ("S_RET_PEN_DI", pens), ("S_INC_ASS_DI", 12.0),
                           ("S_SOC_BEN_DI", 5.0), ("S_DIR_TAX_DI", -17.0)):
                m(obj, g, lab, "REV_T2", mes, mes, {"2023": v}, "PT")
        for tab, mes, v in (("TOU_T1", "PLACE_ACTIVITY_I551", 721.0), ("TOU_T2", "PLACE_ACTIVITY_I553", 2671.0),
                            ("TOU_T3", "BEDPLACE_ACTIVITY_I552", 3270.0)):
            m(obj, g, lab, tab, mes, mes, {"2026": v if cible else v * RNG.uniform(.05, 1.2)})
    df = pd.DataFrame(lignes, columns=["GEO_OBJECT", "GEO", "GEO_LABEL", "TIME_PERIOD", "ID_TAB", "ID_TAB_LABEL",
                                       "TAB_MEASURE", "TAB_MEASURE_LABEL", "OBS_VALUE", "UNIT_MULT", "UNIT_MEASURE"])
    b = io.BytesIO()
    df.to_parquet(b)
    return b.getvalue()


PARQUET = None


# ------------------------------------------------------------------------------------------- La Bonne Boite
def labonneboite(p):
    rome = p.get("rome") or p.get("rome[]")
    if int(p.get("page", 1)) > 1:
        return {"hits": 6, "items": []}
    items = []
    for i in range(6):
        k = (hash(rome) + i) % 38
        c = FS.COMMUNES[k][0] if i < 5 else "14366"  # la dernière hors EPCI
        x0, y0 = -0.35 + (k % 7) * .05 + .02, 49.10 + (k // 7) * .035 + .015
        items.append({"siret": f"9{abs(hash(rome)) % 10 ** 7:07d}{i:05d}"[:14], "company_name": f"SOCIETE {rome}-{i}",
                      "naf": "5610A", "naf_label": "Restauration traditionnelle", "headcount_text": "10 à 19 salariés",
                      "city": FS.COMMUNES[k][1], "citycode": c, "postcode": "14390",
                      "location": {"lat": y0, "lon": x0} if i != 2 else None,
                      "hiring_potential": 35 + 12 * i, "is_high_potential": i >= 4})
    return {"hits": len(items), "resolved_params": {"rome": [rome]}, "items": items}


# ------------------------------------------------------------------------------------------- réponses
class Rep(FS.Rep):
    def raise_for_status(self):
        if self.status_code >= 400:
            import requests
            raise requests.HTTPError(f"HTTP {self.status_code}")

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def iter_content(self, chunk_size=1 << 20):
        for i in range(0, len(self.content), chunk_size):
            yield self.content[i:i + chunk_size]


def _rep(r):
    out = Rep(contenu=r.content, statut=r.status_code, texte=r.text, entetes=r.headers)
    out._data = r._data
    return out


FAUX = FS.FauxClient()


def repondre(method, url, params=None, data=None, json_=None):
    global PARQUET
    p = params or {}
    if "access_token" in url:
        scope = (data or {}).get("scope", "")
        return Rep({"access_token": "jeton", "expires_in": 1499, "scope": scope})
    if "labonneboite" in url:
        return Rep(labonneboite(p))
    if "api.francetravail.io" in url:
        if "referentiel/rechercherActivitesRomeFap" in url:
            return Rep({"romeFapList": [{"codeFap": "S1X20", "codeRome": "G1602", "libelleRome": "Personnel de cuisine"},
                                        {"codeFap": "S1X40", "codeRome": "G1803", "libelleRome": "Service en restauration"}]})
        if url.endswith("stat-perspective-employeur"):  # structure supposée (non sondée)
            r = json_.get("codeActivite", "")
            return Rep({"listeValeursParPeriode": [
                {"codePeriode": "2025", "codeNomenclature": c, "libNomenclature": lib, "libActivite": f"Métier {r}",
                 "valeurPrincipaleNombre": v} for c, lib, v in
                (("TENSION", "Indicateur de tension", 3 + len(r) % 3), ("INTENS", "Intensité d'embauche", 4),
                 ("MANQ", "Manque de main-d'œuvre", 2))]})
        if json_ and json_.get("codeTypeTerritoire") == "BASBMO":  # le faux serveur ne connaît pas les bassins
            json_ = dict(json_, codeTypeTerritoire="DEP", codeTerritoire="14")
        return _rep(FAUX.s.request(method, url, json=json_))
    if "geo.api.gouv.fr/departements/" in url:
        d = url.split("/departements/")[1].split("/")[0]
        return Rep({"type": "FeatureCollection", "features": FC.get(d, [])})
    if url.rstrip("/").endswith("geo.api.gouv.fr/epcis"):
        return Rep([{"code": e, "nom": n} for e, n, _ in FS.TOUS_EPCI])
    if "dossier_complet.parquet" in url:
        PARQUET = PARQUET or dossier_insee()
        return Rep(contenu=PARQUET, entetes={"content-length": str(len(PARQUET))})
    if "open.urssaf.fr" in url and "where" in p and " in (" in p["where"]:
        return Rep(DETAIL)
    if "open.urssaf.fr" in url and p.get("group_by") == "code_epci,code_commune":
        return Rep([{"code_epci": e, "code_commune": c} for c, e in COM_EPCI.items()])
    if "sphere_NAF" in url or "data.gouv.fr/api/1/datasets/l-impot" in url:
        return Rep(statut=404, texte="absent du faux serveur")
    if "geo.api.gouv.fr/communes" in url:
        r = FAUX.repondre(url, p)
        d = p.get("codeDepartement")
        extra = [{"code": f["properties"]["code"], "centre": {"coordinates": f["geometry"]["coordinates"][0][0]}}
                 for f in FC.get(d, []) if f["properties"]["codeEpci"] != FS.SIREN]
        return Rep(r.json() + extra)
    try:
        return _rep(FAUX.repondre(url, p))
    except RuntimeError:
        return Rep(statut=404, texte="adresse non simulée")


def installer():
    reseau.DELAIS.clear()  # pas d'attente entre appels pendant les tests
    def request(self, method, url, *args, **kwargs):
        if self.hors_ligne:
            import requests
            raise requests.ConnectionError("mode hors ligne")
        import os
        import time
        time.sleep(float(os.environ.get("OBS_FAUX_DELAI", "0")))  # pour observer la progression à l'écran
        r = repondre(method.upper(), url, kwargs.get("params"), kwargs.get("data"), kwargs.get("json"))
        SUIVI.appel(0 if kwargs.get("stream") else len(r.content or b""))
        return r
    reseau.SessionSuivie.request = request

"""Grille officielle de l'INSEE : chaque sous-classe de la NAF rév. 2 (732 codes, ex. 4711F)
est rattachée à la sphère présentielle ou productive. Elle remplace la table approximative
par préfixe (onglet Spheres_NAF de config.xlsx), qui ne sert plus que de solution de repli
pour les codes absents de la grille.

Source : https://www.insee.fr/fr/statistiques/1893206 (« Grille pour la définition des sphères »)
"""
import re

import pandas as pd

from ..utils import CACHE, MANUELS, log, norm, telecharger

ETAPE = "Sphères (grille INSEE)"
URL = "https://www.insee.fr/fr/statistiques/fichier/1893206/sphere_NAF_rev2.xls"
FICHIER = CACHE / "sphere_NAF_rev2.xls"
MOTIF_MANUEL = r"(grille.*spher|spher.*naf)"     # nom d'un fichier déposé à la main
RE_CODE = re.compile(r"^\d{2}\.?\d{2}[A-Z]$")


def _sphere(valeur):
    """Libellé de sphère -> P (présentielle) / N (productive) / None."""
    v = norm(valeur)
    if not v or v == "nan":
        return None
    if v in ("np", "n", "prod") or "productiv" in v or "non pres" in v or "non-pres" in v:
        return "N"
    if v in ("p", "pres") or "presentiel" in v:
        return "P"
    return None


def _code(valeur):
    c = str(valeur).strip().upper().replace(" ", "")
    return c.replace(".", "") if RE_CODE.match(c) else None


def lire_grille(f):
    """Lecture tolérante : on cherche, dans chaque onglet, la colonne des codes NAF
    (format 47.11F ou 4711F) et la colonne indiquant la sphère. Si l'onglet n'a pas de
    colonne de sphère mais que son nom en indique une, tous ses codes y sont rattachés."""
    if f.suffix.lower() == ".csv":
        feuilles = {"csv": pd.read_csv(f, sep=None, engine="python", dtype=str, header=None, encoding="utf-8-sig")}
    else:
        feuilles = pd.read_excel(f, sheet_name=None, dtype=str, header=None)
    grille = {}
    for nom_f, d in feuilles.items():
        d = d.dropna(how="all")
        if d.empty:
            continue
        taux = {c: d[c].map(_code).notna().mean() for c in d.columns}
        c_code = max(taux, key=taux.get)
        if taux[c_code] < 0.3:
            continue
        lignes = d[d[c_code].map(_code).notna()]
        c_sph = None
        for c in d.columns:
            if c == c_code:
                continue
            s = lignes[c].map(_sphere)
            if s.notna().mean() > 0.8:
                c_sph = c
                break
        if c_sph is not None:
            for code, sph in zip(lignes[c_code].map(_code), lignes[c_sph].map(_sphere)):
                if sph:
                    grille[code] = sph
        elif _sphere(nom_f):
            for code in lignes[c_code].map(_code):
                grille[code] = _sphere(nom_f)
    return grille


def charger_grille(session, hors_ligne=False, forcer=False):
    """Renvoie {code APE sans point: 'P'|'N'} ou None (repli sur la table par préfixe)."""
    manuels = [f for f in MANUELS.iterdir() if f.is_file() and re.search(MOTIF_MANUEL, norm(f.name))
               and f.suffix.lower() in (".xls", ".xlsx", ".csv")]
    if manuels:
        src = manuels[0]
    else:
        if not hors_ligne and (forcer or not FICHIER.exists()):
            try:
                telecharger(URL, FICHIER, session, ETAPE, timeout=120)
            except Exception as e:
                log(ETAPE, f"téléchargement impossible ({str(e)[:120]}) — table approximative de config.xlsx utilisée. "
                           "Pour y remédier : déposer sphere_NAF_rev2.xls (page INSEE 1893206) dans donnees_manuelles/",
                    "alerte")
        src = FICHIER if FICHIER.exists() else None
    if src is None:
        if hors_ligne:
            log(ETAPE, "grille absente du cache — table approximative de config.xlsx utilisée", "alerte")
        return None
    try:
        grille = lire_grille(src)
    except ImportError:
        log(ETAPE, "lecture des fichiers .xls impossible (bibliothèque xlrd manquante : relancer "
                   "lancer_interface.bat pour l'installer) — table approximative utilisée", "alerte")
        return None
    except Exception as e:
        log(ETAPE, f"lecture impossible de {src.name} ({e}) — table approximative utilisée", "alerte")
        return None
    if len(grille) < 300:  # la NAF compte 732 sous-classes : en dessous, la lecture a échoué
        log(ETAPE, f"{src.name} : seulement {len(grille)} codes reconnus (structure du fichier modifiée ?) — "
                   "table approximative utilisée", "alerte")
        return None
    n_p = sum(v == "P" for v in grille.values())
    log(ETAPE, f"{src.name} : {len(grille)} codes NAF ({n_p} présentiels, {len(grille) - n_p} productifs)", "ok")
    return grille

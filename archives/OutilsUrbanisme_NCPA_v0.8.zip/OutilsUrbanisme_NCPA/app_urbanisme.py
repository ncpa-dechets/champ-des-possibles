"""Outils Urbanisme · NCPA : un onglet par thème, chacun indépendant.

Thèmes disponibles : consommation d'espaces naturels, agricoles et
forestiers (v0.1) ; permis détaillés (v0.2) ; friches (v0.3) ; zonage (v0.4 et v0.5) :
documents, zones, servitudes, prescriptions, croisement avec les permis et
les friches.

Mêmes principes que les outils SIRENE et Habitat :
- couleurs en couples (clair, sombre) dans le dictionnaire C, jamais en dur ;
- tout appel réseau dans un thread ; le thread dépose ses messages dans une
  queue relue toutes les 100 ms (ne jamais toucher un widget depuis un thread) ;
- barre d'onglets maison (boutons rectangulaires) ;
- aucun tiret cadratin dans les textes de l'interface.
"""
import os
import queue
import shutil
import threading
import unicodedata
import webbrowser
from datetime import datetime
from tkinter import filedialog, messagebox, ttk

import customtkinter as ctk

from modules import (carte_friches, carte_permis, conso_enaf, export_excel, export_friches, export_geo,
                     export_permis, friches, permis, rapport_friches, rapport_html, rapport_permis, reseau,
                     test_connexions)
from modules import carte_zonage, croisement, rapport_zonage, zonage, zonage_complet
from modules import territoire as T
from modules.chemins import dossier_application

APPLICATION = {
    "nom": "Outils Urbanisme · NCPA",
    "version": "0.8",
    "auteur": "Yves Marti, Service Maîtrise des déchets",
    "contact": "y.marti@ncpa.fr",
    "description": "Exploration, thème par thème, des données d'urbanisme et de foncier "
                   "sur les communes de la NCPA, le Calvados et la Normandie.",
}

# Chaque couleur = (mode clair, mode sombre)
C = {
    "fond": ("#f3f5f8", "#1a1f26"),
    "panneau": ("#ffffff", "#232a33"),
    "bordure": ("#d5dce4", "#3a4452"),
    "texte": ("#1f2a37", "#e6ebf0"),
    "texte_doux": ("#5b6878", "#9aa7b5"),
    "navy": ("#1b3a5c", "#1b3a5c"),
    "vert": ("#2a7d3b", "#3a9a4d"),
    "orange": ("#d4782e", "#e08a42"),
    "onglet_inactif": ("#2c5078", "#2c5078"),
    "ligne_comparaison": ("#e8eef5", "#2d3845"),
    "selection": ("#cfe0f3", "#35506e"),
    "onglet_actif_texte": ("#1b3a5c", "#e6ebf0"),
    "titre": ("#1b3a5c", "#8fb4dd"),
}
POLICE = "Segoe UI"


def couleur(nom):
    """Couleur du mode courant (pour ttk qui ne gère pas les couples)."""
    clair, sombre = C[nom]
    return sombre if ctk.get_appearance_mode() == "Dark" else clair


def normaliser(texte):
    texte = unicodedata.normalize("NFD", str(texte or ""))
    return "".join(c for c in texte if unicodedata.category(c) != "Mn").lower()


def _milliers(n):
    return f"{n:,.0f}".replace(",", " ")


def _nombre(v, decimales=1, signe=False):
    if v is None:
        return ""
    texte = f"{v:+,.{decimales}f}" if signe else f"{v:,.{decimales}f}"
    return texte.replace(",", " ").replace(".", ",")


# =====================================================================
class BarreOnglets(ctk.CTkFrame):
    """Barre d'onglets maison : boutons rectangulaires alignés à gauche."""

    def __init__(self, maitre, conteneur, **kw):
        super().__init__(maitre, fg_color=C["navy"], corner_radius=0, height=42, **kw)
        self.conteneur = conteneur
        self.boutons, self.pages = {}, {}

    def ajouter(self, nom, page, largeur=170):
        bouton = ctk.CTkButton(self, text=nom, corner_radius=0, height=42, width=largeur,
                               fg_color=C["onglet_inactif"], hover_color=C["orange"],
                               text_color="#ffffff", font=ctk.CTkFont(POLICE, 14, "bold"),
                               command=lambda n=nom: self.afficher(n))
        bouton.pack(side="left", padx=(0, 1))
        page.grid(row=0, column=0, sticky="nsew", in_=self.conteneur)
        self.boutons[nom], self.pages[nom] = bouton, page

    def afficher(self, nom):
        for n, b in self.boutons.items():
            actif = n == nom
            b.configure(fg_color=C["fond"] if actif else C["onglet_inactif"],
                        text_color=C["onglet_actif_texte"] if actif else "#ffffff")
        self.pages[nom].tkraise()


# =====================================================================
class PanneauCommunes(ctk.CTkFrame):
    """Liste de communes à cocher. Chaque thème a la sienne (thèmes indépendants)."""

    def __init__(self, maitre):
        super().__init__(maitre, fg_color=C["panneau"], border_color=C["bordure"], border_width=1)
        self.cases = {}
        self.rowconfigure(3, weight=1)
        ctk.CTkLabel(self, text="Communes", font=ctk.CTkFont(POLICE, 16, "bold"),
                     text_color=C["titre"]).grid(row=0, column=0, sticky="w", padx=14, pady=(12, 2))
        self.lib_compte = ctk.CTkLabel(self, text="", text_color=C["texte_doux"])
        self.lib_compte.grid(row=0, column=1, sticky="e", padx=14)
        boutons = ctk.CTkFrame(self, fg_color="transparent")
        boutons.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10)
        ctk.CTkButton(boutons, text="Tout cocher", width=110, fg_color=C["navy"],
                      command=lambda: self._cocher_tout(True)).pack(side="left", padx=4, pady=4)
        ctk.CTkButton(boutons, text="Tout décocher", width=110, fg_color=C["onglet_inactif"],
                      command=lambda: self._cocher_tout(False)).pack(side="left", padx=4, pady=4)
        self.filtre = ctk.CTkEntry(self, placeholder_text="Filtrer par nom...")
        self.filtre.grid(row=2, column=0, columnspan=2, sticky="ew", padx=14, pady=6)
        self.filtre.bind("<KeyRelease>", lambda _e: self._filtrer())
        self.liste = ctk.CTkScrollableFrame(self, width=270, fg_color="transparent")
        self.liste.grid(row=3, column=0, columnspan=2, sticky="nsew", padx=6, pady=(0, 10))

    def remplir(self, communes):
        for w in self.liste.winfo_children():
            w.destroy()
        self.cases = {}
        for c in communes:
            var = ctk.BooleanVar(value=True)
            case = ctk.CTkCheckBox(self.liste, text=f"{c['nom']}  ({_milliers(c['population'])} hab.)",
                                   variable=var, command=self._maj_compte, font=ctk.CTkFont(POLICE, 13),
                                   fg_color=C["vert"], hover_color=C["vert"])
            case.pack(anchor="w", padx=6, pady=2)
            self.cases[c["code"]] = (var, case, c["nom"])
        self._maj_compte()

    def _filtrer(self):
        motif = normaliser(self.filtre.get())
        for _v, case, _n in self.cases.values():
            case.pack_forget()
        for _v, case, nom in self.cases.values():
            if motif in normaliser(nom):
                case.pack(anchor="w", padx=6, pady=2)

    def _cocher_tout(self, etat):
        for var, case, _n in self.cases.values():
            if case.winfo_ismapped() or not self.filtre.get():
                var.set(etat)
        self._maj_compte()

    def _maj_compte(self):
        self.lib_compte.configure(text=f"{len(self.codes_coches())} / {len(self.cases)} cochée(s)")

    def codes_coches(self):
        return [code for code, (var, _c, _n) in self.cases.items() if var.get()]


def cadre_titre(parent, titre, rang):
    cadre = ctk.CTkFrame(parent, fg_color=C["panneau"], border_color=C["bordure"], border_width=1)
    cadre.grid(row=rang, column=0, sticky="ew", pady=(0, 10))
    ctk.CTkLabel(cadre, text=titre, font=ctk.CTkFont(POLICE, 15, "bold"),
                 text_color=C["titre"]).pack(anchor="w", padx=14, pady=(10, 4))
    return cadre


# =====================================================================
class OngletTheme(ctk.CTkFrame):
    """Socle commun à chaque thème : communes, source, options, lancement,
    résultats avec boutons d'export, journal. Chaque thème est autonome."""

    COLONNES = []                 # (clé, titre, largeur, ancrage)
    TITRE_SOURCE = ""
    EXPORTS = []                  # (texte, nom de méthode, teinte), de droite à gauche

    def __init__(self, maitre, app):
        super().__init__(maitre, fg_color=C["fond"], corner_radius=0)
        self.app = app
        self.resultat, self.params = None, {}
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self.communes = PanneauCommunes(self)
        self.communes.grid(row=0, column=0, sticky="nsw", padx=(16, 8), pady=16)

        droite = ctk.CTkFrame(self, fg_color="transparent")
        droite.grid(row=0, column=1, sticky="nsew", padx=(8, 16), pady=16)
        droite.columnconfigure(0, weight=1)
        droite.rowconfigure(3, weight=3)
        droite.rowconfigure(4, weight=2)

        src = cadre_titre(droite, self.TITRE_SOURCE, 0)
        self.lib_source = ctk.CTkLabel(src, text="", text_color=C["texte_doux"], anchor="w", justify="left",
                                       font=ctk.CTkFont(POLICE, 12), wraplength=900)
        self.lib_source.pack(fill="x", padx=14)
        ligne = ctk.CTkFrame(src, fg_color="transparent")
        ligne.pack(fill="x", padx=14, pady=(6, 10))
        for texte, commande in self.boutons_source() + [("Journal technique", app.ouvrir_journal_technique)]:
            ctk.CTkButton(ligne, text=texte, height=30, fg_color=C["onglet_inactif"],
                          command=commande).pack(side="left", padx=(0, 6))
        self.v_detail = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(ligne, text="Afficher chaque appel dans le journal", variable=self.v_detail,
                        command=lambda: app.basculer_detail(self), font=ctk.CTkFont(POLICE, 12),
                        fg_color=C["vert"], hover_color=C["vert"]).pack(side="left", padx=12)

        opt = ctk.CTkFrame(droite, fg_color="transparent")
        opt.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        self.construire_options(opt)

        act = ctk.CTkFrame(droite, fg_color="transparent")
        act.grid(row=2, column=0, sticky="ew", pady=(0, 8))
        self.b_lancer = ctk.CTkButton(act, text="Lancer l'extraction", height=38, width=190,
                                      fg_color=C["vert"], hover_color=C["navy"],
                                      font=ctk.CTkFont(POLICE, 14, "bold"), command=self.lancer)
        self.b_lancer.pack(side="left")
        self.b_annuler = ctk.CTkButton(act, text="Annuler", height=38, width=110, state="disabled",
                                       fg_color=C["orange"], command=app.annuler)
        self.b_annuler.pack(side="left", padx=8)
        self.barre = ctk.CTkProgressBar(act, progress_color=C["vert"], mode="determinate")
        self.barre.set(0)
        self.barre.pack(side="left", fill="x", expand=True, padx=(16, 0))

        res = ctk.CTkFrame(droite, fg_color=C["panneau"], border_color=C["bordure"], border_width=1)
        res.grid(row=3, column=0, sticky="nsew", pady=(0, 8))
        res.columnconfigure(0, weight=1)
        res.rowconfigure(1, weight=1)
        haut = ctk.CTkFrame(res, fg_color="transparent")
        haut.grid(row=0, column=0, columnspan=2, sticky="ew", padx=10, pady=(8, 4))
        ctk.CTkLabel(haut, text="Résultats", font=ctk.CTkFont(POLICE, 15, "bold"),
                     text_color=C["titre"]).pack(side="left", padx=4)
        self.boutons_export = []
        for texte, methode, teinte in self.EXPORTS:
            b = ctk.CTkButton(haut, text=texte, width=120, height=30, fg_color=C[teinte],
                              state="disabled", command=getattr(self, methode))
            b.pack(side="right", padx=(6, 0))
            self.boutons_export.append(b)
        self.tableau = ttk.Treeview(res, show="headings", style="Urba.Treeview",
                                    columns=[c[0] for c in self.COLONNES])
        for cle, titre, largeur, ancre in self.COLONNES:
            self.tableau.heading(cle, text=titre)
            self.tableau.column(cle, width=largeur, anchor=ancre, stretch=False)
        dv = ttk.Scrollbar(res, orient="vertical", command=self.tableau.yview)
        dh = ttk.Scrollbar(res, orient="horizontal", command=self.tableau.xview)
        self.tableau.configure(yscrollcommand=dv.set, xscrollcommand=dh.set)
        self.tableau.grid(row=1, column=0, sticky="nsew", padx=(6, 0))
        dv.grid(row=1, column=1, sticky="ns")
        dh.grid(row=2, column=0, sticky="ew", padx=6, pady=(0, 6))
        self.info = ctk.CTkLabel(res, text="", text_color=C["texte_doux"], font=ctk.CTkFont(POLICE, 12),
                                 anchor="w", justify="left", wraplength=880)
        self.info.grid(row=3, column=0, columnspan=2, sticky="ew", padx=12, pady=(0, 6))

        self.journal = ctk.CTkTextbox(droite, font=ctk.CTkFont("Consolas", 12), height=150,
                                      fg_color=C["panneau"], border_color=C["bordure"], border_width=1)
        self.journal.grid(row=4, column=0, sticky="nsew")
        self.journal.configure(state="disabled")

    # à définir par chaque thème
    def boutons_source(self):
        return []

    def construire_options(self, cadre):
        pass

    def lancer(self):
        pass

    def maj_source(self):
        pass

    # communs
    def ecrire(self, texte):
        self.journal.configure(state="normal")
        self.journal.insert("end", texte + "\n")
        self.journal.see("end")
        self.journal.configure(state="disabled")

    def en_cours(self, actif):
        self.b_lancer.configure(state="disabled" if actif else "normal")
        self.b_annuler.configure(state="normal" if actif else "disabled")
        if actif:
            self.barre.configure(mode="indeterminate")
            self.barre.start()
        else:
            self.barre.stop()
            self.barre.configure(mode="determinate")
            self.barre.set(0)

    def progression(self, valeur, texte):
        """La barre passe de l'animation en boucle à une jauge dès que le moteur donne un avancement."""
        if self.barre.cget("mode") != "determinate":
            self.barre.stop()
            self.barre.configure(mode="determinate")
        self.barre.set(valeur)

    def remplir_tableau(self, lignes):
        """lignes : [(valeurs, est_une_ligne_de_comparaison)]."""
        self.tableau.delete(*self.tableau.get_children())
        for valeurs, comparaison in lignes:
            self.tableau.insert("", "end", values=valeurs, tags=("comparaison",) if comparaison else ())
        self.appliquer_couleurs()
        for b in self.boutons_export:
            b.configure(state="normal")

    def appliquer_couleurs(self):
        self.tableau.tag_configure("comparaison", background=couleur("ligne_comparaison"),
                                   font=(POLICE, 10, "bold"))

    def params_communs(self, codes):
        noms = [c["nom"] for c in self.app.communes if c["code"] in codes]
        return {"communes": "toutes" if len(codes) == len(self.app.communes) else ", ".join(noms),
                "titre": self.app.nom_epci if len(codes) == len(self.app.communes)
                else (noms[0] if len(noms) == 1 else f"{len(noms)} communes"),
                "date": datetime.now().strftime("%d/%m/%Y à %H:%M")}

    def enregistrer(self, prefixe, extension, libelle, action, ouvrir_apres=False):
        chemin = self.app.chemin_sortie(prefixe, extension, libelle)
        if not chemin:
            return
        try:
            message = action(chemin)
            if message:
                self.ecrire(message)
            if ouvrir_apres:
                ouvrir(chemin)
            elif extension == ".xlsx" and messagebox.askyesno("Export Excel", "Fichier enregistré. L'ouvrir maintenant ?"):
                ouvrir(chemin)
        except PermissionError:
            messagebox.showerror("Export", "Le fichier est peut-être ouvert dans un autre logiciel : fermez-le et recommencez.")
        except Exception as exc:
            messagebox.showerror("Export", f"Échec de l'export : {exc}")


# =====================================================================
class OngletConso(OngletTheme):
    """Thème 1 : consommation d'espaces naturels, agricoles et forestiers."""

    TITRE_SOURCE = "Source : Cerema, consommation d'espaces NAF (Fichiers fonciers)"
    COLONNES = [("nom", "Territoire", 250, "w"), ("niveau", "Niveau", 105, "w"),
                ("ref_ha", "2011-2021 (ha)", 120, "e"), ("ref_rythme", "Rythme réf. (ha/an)", 150, "e"),
                ("rec_ha", "Depuis 2021 (ha)", 135, "e"), ("rec_rythme", "Rythme récent (ha/an)", 165, "e"),
                ("evolution", "Évolution (%)", 115, "e"), ("part_enveloppe", "Enveloppe consommée (%)", 185, "e"),
                ("part_surface", "Part de la surface (%)", 170, "e")]
    EXPORTS = [("Rapport HTML", "rapport", "orange"), ("Carte HTML", "carte", "orange"),
               ("GeoJSON (QGIS)", "geojson", "navy"), ("Excel", "excel", "vert")]

    def boutons_source(self):
        return [("Tester la source", self.tester), ("Chercher une mise à jour", self.maj),
                ("Utiliser un fichier CSV local", self.fichier_local)]

    def construire_options(self, cadre):
        self.v_comparer = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(cadre, text="Comparer avec la NCPA, le Calvados et la Normandie", variable=self.v_comparer,
                        font=ctk.CTkFont(POLICE, 13), fg_color=C["vert"], hover_color=C["vert"]).pack(side="left")

    def maj_source(self):
        meta = conso_enaf.source_en_cache()
        if meta:
            texte = (f"Fichier prêt : millésime {meta['millesime']} · "
                     + ("fichier local" if meta.get("origine") == "local" else "data.gouv.fr")
                     + f" · récupéré le {meta.get('date', '?')}")
        else:
            texte = ("Aucun fichier en cache : le fichier national (environ 30 Mo) sera téléchargé "
                     "à la première extraction, puis conservé 90 jours.")
        self.lib_source.configure(text=texte)

    def _url(self):
        return self.app.o_parametres.url_api.get().strip() or conso_enaf.URL_API

    def tester(self):
        if not self.app.demarrer(self):
            return
        url = self._url()
        self.app.executer(self, lambda log: test_connexions.tester(url, journal=log))

    def maj(self):
        if not self.app.demarrer(self):
            return
        url = self._url()
        self.ecrire("\nRecherche d'un millésime plus récent sur data.gouv.fr...")
        self.app.executer(self, lambda log: conso_enaf.preparer_fichier(True, url, self.app.stop_event, log))

    def fichier_local(self):
        chemin = filedialog.askopenfilename(
            title="Fichier CSV communal de consommation d'espaces (Cerema)",
            filetypes=[("Fichier CSV", "*.csv"), ("Tous les fichiers", "*.*")])
        if not chemin:
            return
        meta = conso_enaf.utiliser_fichier_local(chemin)
        self.maj_source()
        self.ecrire(f"Fichier local retenu : {chemin} (millésime lu dans le nom : {meta['millesime']}). "
                    "« Chercher une mise à jour » revient au fichier de data.gouv.fr.")

    def lancer(self):
        codes = self.communes.codes_coches()
        if not codes:
            messagebox.showwarning("Communes", "Cochez au moins une commune.")
            return
        if not self.app.demarrer(self):
            return
        self.params = self.params_communs(codes)
        comparer, url = self.v_comparer.get(), self._url()
        communes, nom = list(self.app.communes), self.app.nom_epci
        self.ecrire(f"\nConsommation d'espaces · {len(codes)} commune(s)")
        self.app.executer(self, lambda log: conso_enaf.extraire(
            communes, codes, nom, comparer, url_api=url, stop_event=self.app.stop_event, journal=log),
            fin=self.afficher)

    def afficher(self, resultat):
        self.resultat = resultat
        lignes = []
        for t in resultat["territoires"]:
            s = t["synthese"]
            lignes.append(([t["nom"], t["niveau"], _nombre(s["ref_ha"]), _nombre(s["ref_rythme"], 2),
                            _nombre(s["rec_ha"]), _nombre(s["rec_rythme"], 2), _nombre(s["evolution"], 0, True),
                            _nombre(s["part_enveloppe"], 0), _nombre(s["part_surface"], 2)],
                           t["niveau"] != "Commune"))
        self.remplir_tableau(lignes)
        a = resultat["annees"]
        rec = next((t["synthese"]["rec_annees"] for t in resultat["territoires"]), "")
        self.info.configure(text=f"Millésime {resultat['meta']['millesime']} · flux annuels {a[0]} à {a[-1] + 1} · "
                                 f"« depuis 2021 » = {rec}, dernière année provisoire · enveloppe indicative = "
                                 "50 % de 2011-2021 (repère national, l'enveloppe applicable relève du SRADDET et du SCoT)")
        self.ecrire(f"Terminé · {len(resultat['territoires'])} territoire(s). Choisissez une sortie au-dessus du tableau.")

    def excel(self):
        self.enregistrer("Conso_espaces_NCPA", ".xlsx", "Classeur Excel",
                         lambda ch: export_excel.exporter(ch, self.resultat, self.params))

    def rapport(self):
        self.enregistrer("Rapport_conso_espaces_NCPA", ".html", "Page web",
                         lambda ch: rapport_html.generer(ch, self.resultat, self.params), ouvrir_apres=True)

    def geojson(self):
        def ecrire(ch, contours):
            n = export_geo.exporter_geojson(ch, self.resultat, contours)
            return f"GeoJSON enregistré : {n} commune(s), coordonnées WGS84. {ch}"
        self.app.avec_contours(self, "Conso_espaces_NCPA", ".geojson", "GeoJSON", ecrire)

    def carte(self):
        def ecrire(ch, contours):
            n = export_geo.exporter_carte(ch, self.resultat, contours, self.params)
            ouvrir(ch)
            return f"Carte enregistrée : {n} commune(s). {ch}"
        self.app.avec_contours(self, "Carte_conso_espaces_NCPA", ".html", "Page web", ecrire)


# =====================================================================
class OngletPermis(OngletTheme):
    """Thème 2 : liste des autorisations d'urbanisme (Sitadel)."""

    TITRE_SOURCE = "Source : SDES, liste des permis et autres autorisations d'urbanisme (Sitadel)"
    COLONNES = [("nom", "Territoire", 250, "w"), ("lgt_nb_permis", "Autorisations logement", 165, "e"),
                ("lgt_aut", "Logements autorisés", 150, "e"), ("lgt_ind", "Individuels", 95, "e"),
                ("lgt_col", "Collectifs", 90, "e"), ("lgt_commences", "Commencés", 100, "e"),
                ("lgt_a_venir", "À venir", 80, "e"), ("pa_nb", "Permis d'aménager", 140, "e"),
                ("pd_nb", "Permis de démolir", 135, "e")]
    EXPORTS = [("Rapport HTML", "rapport", "orange"), ("Carte HTML", "carte", "orange"),
               ("GeoJSON (QGIS)", "geojson", "navy"), ("Excel", "excel", "vert")]

    def boutons_source(self):
        return [("Diagnostic de la source", self.diagnostic)]

    def construire_options(self, cadre):
        self.v_types = {}
        for cle, lib in permis.TYPES:
            self.v_types[cle] = ctk.BooleanVar(value=True)
            ctk.CTkCheckBox(cadre, text=lib, variable=self.v_types[cle], font=ctk.CTkFont(POLICE, 13),
                            fg_color=C["vert"], hover_color=C["vert"]).pack(side="left", padx=(0, 14))
        annee = datetime.now().year
        valeurs = [str(a) for a in range(2013, annee + 1)]
        ctk.CTkLabel(cadre, text="Autorisés de").pack(side="left", padx=(10, 4))
        self.annee_min = ctk.CTkOptionMenu(cadre, values=valeurs, width=80, fg_color=C["navy"])
        self.annee_min.set(str(annee - 10))
        self.annee_min.pack(side="left")
        ctk.CTkLabel(cadre, text="à").pack(side="left", padx=4)
        self.annee_max = ctk.CTkOptionMenu(cadre, values=valeurs, width=80, fg_color=C["navy"])
        self.annee_max.set(str(annee))
        self.annee_max.pack(side="left")
        self.v_localiser = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(cadre, text="Localiser sur le cadastre", variable=self.v_localiser,
                        font=ctk.CTkFont(POLICE, 13), fg_color=C["vert"], hover_color=C["vert"]).pack(side="left", padx=14)

    def maj_source(self):
        self.lib_source.configure(text="Données interrogées directement sur le serveur du SDES (mise à jour mensuelle). "
                                       "Localisation : centre de la parcelle, d'après le plan cadastral Etalab "
                                       "(téléchargé une fois par commune, puis conservé 180 jours).")

    def diagnostic(self):
        if not self.app.demarrer(self):
            return
        self.ecrire("\nDiagnostic du jeu « Liste des permis » sur le serveur du SDES...")
        self.app.executer(self, lambda log: permis.diagnostic(self.app.stop_event, log))

    def lancer(self):
        codes = self.communes.codes_coches()
        types = [t for t, v in self.v_types.items() if v.get()]
        if not codes:
            messagebox.showwarning("Communes", "Cochez au moins une commune.")
            return
        if not types:
            messagebox.showwarning("Types", "Cochez au moins un type d'autorisation.")
            return
        a1, a2 = sorted([int(self.annee_min.get()), int(self.annee_max.get())])
        if not self.app.demarrer(self):
            return
        self.params = self.params_communs(codes)
        communes, nom, localiser = list(self.app.communes), self.app.nom_epci, self.v_localiser.get()
        self.ecrire(f"\nPermis · {len(codes)} commune(s) · autorisations de {a1} à {a2}")
        self.app.executer(self, lambda log: permis.extraire(
            communes, codes, nom, types, a1, a2, localiser, self.app.stop_event, log), fin=self.afficher)

    def afficher(self, resultat):
        self.resultat = resultat
        cles = [c[0] for c in self.COLONNES[1:]]
        lignes = [([l["nom"]] + [_nombre(l[k], 0) for k in cles], l["niveau"] != "Commune")
                  for l in resultat["synthese"]["lignes"]]
        self.remplir_tableau(lignes)
        n = len(resultat["permis"])
        loc = sum(1 for p in resultat["permis"] if p.get("lon") is not None)
        self.info.configure(text=f"{n} autorisation(s) · " + (f"{loc} localisée(s) sur le cadastre · " if resultat["localise"] else "")
                            + "« À venir » : chantier ouvert non achevé, ou autorisation de moins de 3 ans · "
                              "annulations exclues · dernières années incomplètes")
        self.ecrire(f"Terminé · {n} autorisation(s). Choisissez une sortie au-dessus du tableau.")

    def excel(self):
        self.enregistrer("Permis_NCPA", ".xlsx", "Classeur Excel",
                         lambda ch: export_permis.exporter_excel(ch, self.resultat, self.app.communes, self.params))

    def rapport(self):
        self.enregistrer("Rapport_permis_NCPA", ".html", "Page web",
                         lambda ch: rapport_permis.generer(ch, self.resultat, self.params), ouvrir_apres=True)

    def geojson(self):
        def action(ch):
            n, sans = export_permis.exporter_geojson(ch, self.resultat, self.app.communes)
            return (f"GeoJSON enregistré : {n} point(s), coordonnées WGS84"
                    + (f" ({sans} autorisation(s) non localisée(s), présentes dans l'Excel)" if sans else "") + f". {ch}")
        self.enregistrer("Permis_NCPA", ".geojson", "GeoJSON", action)

    def carte(self):
        def ecrire(ch, contours):
            n = carte_permis.exporter_carte(ch, self.resultat, self.app.communes, contours, self.params)
            ouvrir(ch)
            return f"Carte enregistrée : {n} autorisation(s) localisée(s). {ch}"
        self.app.avec_contours(self, "Carte_permis_NCPA", ".html", "Page web", ecrire, contours_facultatifs=True)


# =====================================================================
class OngletFriches(OngletTheme):
    """Thème 3 : inventaire national des friches (Cartofriches, Cerema)."""

    TITRE_SOURCE = "Source : Cerema, inventaire national des friches Cartofriches (data.gouv.fr)"
    COLONNES = [("nom", "Territoire", 250, "w"), ("niveau", "Niveau", 105, "w"), ("n", "Sites", 70, "e"),
                ("surface", "Surface (ha)", 110, "e"), ("n_friche sans projet", "Sans projet", 100, "e"),
                ("s_friche sans projet", "Sans projet (ha)", 135, "e"), ("n_friche avec projet", "Avec projet", 100, "e"),
                ("n_friche potentielle", "Potentielles", 105, "e"), ("n_friche reconvertie", "Reconverties", 110, "e")]
    EXPORTS = [("Rapport HTML", "rapport", "orange"), ("Carte HTML", "carte", "orange"),
               ("GeoJSON (QGIS)", "geojson", "navy"), ("Excel", "excel", "vert")]

    def boutons_source(self):
        return [("Diagnostic de la source", self.diagnostic), ("Chercher une mise à jour", self.maj),
                ("Utiliser un fichier CSV local", self.fichier_local)]

    def construire_options(self, cadre):
        self.v_comparer = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(cadre, text="Comparer avec la NCPA, le Calvados et la Normandie", variable=self.v_comparer,
                        font=ctk.CTkFont(POLICE, 13), fg_color=C["vert"], hover_color=C["vert"]).pack(side="left")

    def maj_source(self):
        meta = friches.source_en_cache()
        if meta:
            texte = (f"Inventaire prêt : version du {meta.get('maj', '?')} · "
                     + ("fichier local" if meta.get("origine") == "local" else "data.gouv.fr")
                     + f" · récupéré le {meta.get('date', '?')}. Inventaire non exhaustif : il dépend des "
                       "observatoires locaux transmis au Cerema.")
        else:
            texte = ("Aucun fichier en cache : l'inventaire national (environ 25 Mo) sera téléchargé à la première "
                     "extraction, puis conservé 30 jours.")
        self.lib_source.configure(text=texte)

    def diagnostic(self):
        if not self.app.demarrer(self):
            return
        self.ecrire("\nDiagnostic de la source Cartofriches...")
        self.app.executer(self, lambda log: friches.diagnostic(self.app.stop_event, log))

    def maj(self):
        if not self.app.demarrer(self):
            return
        self.ecrire("\nRecherche d'une version plus récente sur data.gouv.fr...")
        self.app.executer(self, lambda log: friches.preparer_fichier(True, self.app.stop_event, log))

    def fichier_local(self):
        chemin = filedialog.askopenfilename(title="Fichier CSV « Sites référencés dans Cartofriches »",
                                            filetypes=[("Fichier CSV", "*.csv"), ("Tous les fichiers", "*.*")])
        if not chemin:
            return
        friches.utiliser_fichier_local(chemin)
        self.maj_source()
        self.ecrire(f"Fichier local retenu : {chemin}. « Chercher une mise à jour » revient au fichier de data.gouv.fr.")

    def lancer(self):
        codes = self.communes.codes_coches()
        if not codes:
            messagebox.showwarning("Communes", "Cochez au moins une commune.")
            return
        if not self.app.demarrer(self):
            return
        self.params = self.params_communs(codes)
        self.params["codes"] = codes
        communes, nom, comparer = list(self.app.communes), self.app.nom_epci, self.v_comparer.get()
        self.ecrire(f"\nFriches · {len(codes)} commune(s)")
        self.app.executer(self, lambda log: friches.extraire(
            communes, codes, nom, comparer, False, self.app.stop_event, log), fin=self.afficher)

    def afficher(self, resultat):
        self.resultat = resultat
        lignes = []
        for l in resultat["lignes"]:
            vals = [l["nom"], l["niveau"]]
            for cle, _t, _w, _a in self.COLONNES[2:]:
                v = l.get(cle)
                vals.append(_nombre(v, 1) if cle.startswith("s") and v is not None else _nombre(v, 0))
            lignes.append((vals, l["niveau"] != "Commune"))
        self.remplir_tableau(lignes)
        n = len(resultat["sites"])
        self.info.configure(text=f"{n} site(s) sur les communes choisies · inventaire du {resultat['meta'].get('maj', '?')} "
                                 "· non exhaustif · les comparaisons reflètent aussi la couverture des observatoires locaux")
        self.ecrire(f"Terminé · {n} site(s). Choisissez une sortie au-dessus du tableau.")

    def excel(self):
        self.enregistrer("Friches_NCPA", ".xlsx", "Classeur Excel",
                         lambda ch: export_friches.exporter_excel(ch, self.resultat, self.app.communes, self.params))

    def rapport(self):
        self.enregistrer("Rapport_friches_NCPA", ".html", "Page web",
                         lambda ch: rapport_friches.generer(ch, self.resultat, self.app.communes, self.params),
                         ouvrir_apres=True)

    def geojson(self):
        def action(ch):
            n, sans = export_friches.exporter_geojson(ch, self.resultat, self.app.communes)
            return (f"GeoJSON enregistré : {n} site(s), coordonnées WGS84"
                    + (f" ({sans} sans localisation, présents dans l'Excel)" if sans else "") + f". {ch}")
        self.enregistrer("Friches_NCPA", ".geojson", "GeoJSON", action)

    def carte(self):
        def ecrire(ch, contours):
            n = carte_friches.exporter_carte(ch, self.resultat, self.app.communes, contours, self.params)
            ouvrir(ch)
            return f"Carte enregistrée : {n} site(s). {ch}"
        self.app.avec_contours(self, "Carte_friches_NCPA", ".html", "Page web", ecrire, contours_facultatifs=True)


# =====================================================================
class OngletZonage(OngletTheme):
    """Thème 4 : documents d'urbanisme et zonage (Géoportail de l'Urbanisme)."""

    TITRE_SOURCE = "Source : Géoportail de l'Urbanisme (API Carto de l'IGN)"
    COLONNES = [("nom", "Territoire", 250, "w"), ("statut", "Document", 150, "w"), ("U", "U (ha)", 90, "e"),
                ("AUc", "AUc (ha)", 90, "e"), ("AUs", "AUs (ha)", 90, "e"), ("A", "A (ha)", 90, "e"),
                ("N", "N (ha)", 90, "e"), ("CC", "Carte communale (ha)", 160, "e"), ("zone", "Total zoné (ha)", 130, "e")]
    EXPORTS = [("Rapport HTML", "rapport", "orange"), ("Carte HTML", "carte", "orange"),
               ("GeoJSON (QGIS)", "geojson", "navy")]

    def boutons_source(self):
        return [("Diagnostic de la source", self.diagnostic),
                ("Charger un GeoJSON (permis ou friches)", self.charger_points)]

    def construire_options(self, cadre):
        self.points_charges = {}            # {"permis": [...], "friches": [...]} lus depuis des GeoJSON
        ctk.CTkLabel(cadre, text="Zones et documents, plus :").pack(side="left", padx=(0, 8))
        self.v_sup = ctk.BooleanVar(value=True)
        self.v_psc = ctk.BooleanVar(value=True)
        self.v_croiser = ctk.BooleanVar(value=True)
        for texte, var in (("Servitudes d'utilité publique", self.v_sup), ("Prescriptions", self.v_psc),
                           ("Croiser avec les permis et les friches", self.v_croiser)):
            ctk.CTkCheckBox(cadre, text=texte, variable=var, font=ctk.CTkFont(POLICE, 13),
                            fg_color=C["vert"], hover_color=C["vert"]).pack(side="left", padx=(0, 14))

    def charger_points(self):
        chemin = filedialog.askopenfilename(title="GeoJSON exporté par l'onglet Permis ou Friches",
                                            filetypes=[("GeoJSON", "*.geojson *.json"), ("Tous les fichiers", "*.*")])
        if not chemin:
            return
        try:
            points, genre = croisement.points_geojson(chemin)
        except Exception as exc:
            messagebox.showerror("GeoJSON", f"Fichier non reconnu : {exc}")
            return
        self.points_charges[genre] = points
        onglet = genre.capitalize()
        self.ecrire(f"{len(points)} point(s) de {genre} chargé(s) depuis {chemin} : ils seront croisés avec le zonage "
                    f"à la prochaine extraction (à la place de ceux de l'onglet {onglet}).")

    def _points_a_croiser(self):
        """Points des onglets Permis et Friches (séance en cours), sinon ceux chargés depuis un GeoJSON."""
        points, origines = [], []
        if "permis" in self.points_charges:
            points += self.points_charges["permis"]
            origines.append("permis (GeoJSON chargé)")
        elif self.app.o_permis.resultat:
            pts = croisement.points_permis(self.app.o_permis.resultat)
            points += pts
            origines.append(f"permis (onglet Permis, {len(pts)} localisés)")
        if "friches" in self.points_charges:
            points += self.points_charges["friches"]
            origines.append("friches (GeoJSON chargé)")
        elif self.app.o_friches.resultat:
            pts = croisement.points_friches(self.app.o_friches.resultat)
            points += pts
            origines.append(f"friches (onglet Friches, {len(pts)} localisées)")
        return points, origines

    def maj_source(self):
        self.lib_source.configure(text="Interrogation directe de l'API Carto (gratuite, sans clé). Zones et prescriptions "
                                       "gardées 30 jours par document, servitudes 30 jours par commune, liste des "
                                       "documents 7 jours. Tout est découpé selon les limites communales. Le croisement "
                                       "utilise les résultats des onglets Permis et Friches, ou un GeoJSON qu'ils ont exporté.")

    def diagnostic(self):
        codes = self.communes.codes_coches()
        if not codes:
            messagebox.showwarning("Communes", "Cochez au moins une commune : le diagnostic porte sur la première.")
            return
        if not self.app.demarrer(self):
            return
        code = codes[0]
        nom = next((c["nom"] for c in self.app.communes if c["code"] == code), code)

        def travail(log):
            contours = T.contours_communes(stop_event=self.app.stop_event)
            zonage.diagnostic(code, nom, contours, self.app.stop_event, log)
        self.ecrire("")
        self.app.executer(self, travail)

    def lancer(self):
        codes = self.communes.codes_coches()
        if not codes:
            messagebox.showwarning("Communes", "Cochez au moins une commune.")
            return
        if not self.app.demarrer(self):
            return
        self.params = self.params_communs(codes)
        communes, nom = list(self.app.communes), self.app.nom_epci
        avec_sup, avec_psc = self.v_sup.get(), self.v_psc.get()
        points, origines = self._points_a_croiser() if self.v_croiser.get() else ([], [])
        self.ecrire(f"\nZonage · {len(codes)} commune(s)")
        if self.v_croiser.get() and not points:
            self.ecrire("   Croisement : aucun permis ni friche disponible. Lancez d'abord l'onglet Permis ou "
                        "Friches, ou chargez un GeoJSON exporté par ces onglets.")
        def travail(log):
            return zonage_complet.extraire(communes, codes, nom, avec_sup, avec_psc, points, origines,
                                           self.app.stop_event, log)
        self.app.executer(self, travail, fin=self.afficher)

    def afficher(self, resultat):
        self.resultat = resultat
        lignes = []
        for l in resultat["lignes"]:
            l["CC"] = (l.get("ZC") or 0) + (l.get("ZnC") or 0)
            vals = [l["nom"], l["statut"]] + [_nombre(l.get(k), 0) for k, *_r in self.COLONNES[2:]]
            lignes.append((vals, l["niveau"] != "Commune"))
        self.remplir_tableau(lignes)
        n = len(resultat["zones"]["features"])
        extra = []
        if resultat["servitudes"]["features"]:
            extra.append(f"{len(resultat['servitudes']['features'])} servitudes")
        if resultat["prescriptions"]["features"]:
            extra.append(f"{len(resultat['prescriptions']['features'])} prescriptions")
        if resultat["points"]:
            extra.append(f"{len(resultat['points'])} permis et friches croisés")
        self.info.configure(text=f"{n} morceaux de zones" + (" · " + " · ".join(extra) if extra else "")
                                 + " · AUc : à urbaniser ouverte · AUs : fermée · seul le document en vigueur "
                                   "publié sur le Géoportail fait foi")
        self.ecrire("Terminé. Choisissez une sortie au-dessus du tableau.")

    def rapport(self):
        self.enregistrer("Rapport_zonage_NCPA", ".html", "Page web",
                         lambda ch: rapport_zonage.generer(ch, self.resultat, self.params), ouvrir_apres=True)

    def geojson(self):
        def action(ch):
            fichiers = carte_zonage.exporter_geojson(ch, self.resultat)
            return "GeoJSON enregistrés (WGS84) : " + " · ".join(f"{os.path.basename(f)} ({n})" for f, n in fichiers)
        self.enregistrer("Zonage_NCPA", ".geojson", "GeoJSON", action)

    def carte(self):
        def action(ch):
            n = carte_zonage.exporter_carte(ch, self.resultat, self.resultat["contours"], self.params)
            return f"Carte enregistrée : {n} zone(s). {ch}"
        self.enregistrer("Carte_zonage_NCPA", ".html", "Page web", action, ouvrir_apres=True)


# =====================================================================
class OngletAVenir(ctk.CTkFrame):
    """Thème préparé mais pas encore développé."""

    def __init__(self, maitre, titre, texte):
        super().__init__(maitre, fg_color=C["fond"], corner_radius=0)
        cadre = ctk.CTkFrame(self, fg_color=C["panneau"], border_color=C["bordure"], border_width=1)
        cadre.pack(fill="x", padx=16, pady=16)
        ctk.CTkLabel(cadre, text=titre, font=ctk.CTkFont(POLICE, 16, "bold"),
                     text_color=C["titre"]).pack(anchor="w", padx=14, pady=(12, 6))
        ctk.CTkLabel(cadre, text=texte, justify="left", anchor="w", wraplength=900,
                     font=ctk.CTkFont(POLICE, 13)).pack(anchor="w", padx=14, pady=(0, 14))


# =====================================================================
class OngletParametres(ctk.CTkFrame):
    def __init__(self, maitre, app):
        super().__init__(maitre, fg_color=C["fond"], corner_radius=0)
        cadre = ctk.CTkFrame(self, fg_color=C["panneau"], border_color=C["bordure"], border_width=1)
        cadre.pack(fill="x", padx=16, pady=16)
        ctk.CTkLabel(cadre, text="Paramètres", font=ctk.CTkFont(POLICE, 15, "bold"),
                     text_color=C["titre"]).pack(anchor="w", padx=14, pady=(10, 6))

        ligne = ctk.CTkFrame(cadre, fg_color="transparent")
        ligne.pack(fill="x", padx=14, pady=4)
        ctk.CTkLabel(ligne, text="API de data.gouv.fr :", width=200, anchor="w").pack(side="left")
        self.url_api = ctk.CTkEntry(ligne, width=420)
        self.url_api.insert(0, conso_enaf.URL_API)
        self.url_api.pack(side="left")

        ligne = ctk.CTkFrame(cadre, fg_color="transparent")
        ligne.pack(fill="x", padx=14, pady=4)
        ctk.CTkLabel(ligne, text="Apparence :", width=200, anchor="w").pack(side="left")
        self.mode = ctk.CTkSegmentedButton(ligne, values=["Clair", "Sombre"], command=app.changer_mode,
                                           selected_color=C["orange"], selected_hover_color=C["orange"])
        self.mode.set("Clair")
        self.mode.pack(side="left")

        ligne = ctk.CTkFrame(cadre, fg_color="transparent")
        ligne.pack(fill="x", padx=14, pady=(4, 12))
        ctk.CTkLabel(ligne, text="Caches locaux :", width=200, anchor="w").pack(side="left")
        ctk.CTkButton(ligne, text="Recharger la liste des communes", fg_color=C["navy"],
                      command=lambda: app.recharger_communes(forcer=True)).pack(side="left")
        ctk.CTkButton(ligne, text="Vider les caches", fg_color=C["onglet_inactif"],
                      command=app.vider_caches).pack(side="left", padx=8)

        apropos = ctk.CTkFrame(self, fg_color=C["panneau"], border_color=C["bordure"], border_width=1)
        apropos.pack(fill="x", padx=16)
        ctk.CTkLabel(apropos, text="À propos", font=ctk.CTkFont(POLICE, 15, "bold"),
                     text_color=C["titre"]).pack(anchor="w", padx=14, pady=(10, 6))
        texte = (f"{APPLICATION['nom']} · version {APPLICATION['version']}\n"
                 f"{APPLICATION['description']}\n\n"
                 f"Auteur : {APPLICATION['auteur']} · {APPLICATION['contact']}\n\n"
                 "Sources (accès libre, sans clé API) :\n"
                 "· Cerema, consommation d'espaces NAF d'après les Fichiers fonciers (data.gouv.fr)\n"
                 "· SDES, liste des autorisations d'urbanisme, base Sitadel (API DiDo)\n"
                 "· Plan cadastral Etalab (cadastre.data.gouv.fr), pour localiser les permis\n"
                 "· Cerema, inventaire national des friches Cartofriches (data.gouv.fr)\n"
                 "· Géoportail de l'Urbanisme, API Carto de l'IGN (documents et zonage)\n"
                 "· geo.api.gouv.fr (communes, surfaces, contours)\n"
                 "· Cartes : IGN Géoplateforme (Plan IGN et photographies aériennes)")
        ctk.CTkLabel(apropos, text=texte, justify="left", anchor="w").pack(anchor="w", padx=14, pady=(0, 12))


# =====================================================================
class Application(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"{APPLICATION['nom']} · v{APPLICATION['version']}")
        self.geometry("1360x880")
        self.minsize(1120, 720)
        self.configure(fg_color=C["fond"])
        self.file = queue.Queue()
        self.stop_event = None
        self.onglet_travail = None            # onglet qui a lancé le travail en cours
        self.communes, self.nom_epci = [], T.NOM_EPCI_DEFAUT

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        conteneur = ctk.CTkFrame(self, fg_color=C["fond"], corner_radius=0)
        conteneur.grid(row=1, column=0, sticky="nsew")
        conteneur.rowconfigure(0, weight=1)
        conteneur.columnconfigure(0, weight=1)
        self.onglets = BarreOnglets(self, conteneur)
        self.onglets.grid(row=0, column=0, sticky="ew")

        self.o_parametres = OngletParametres(conteneur, self)
        self.o_conso = OngletConso(conteneur, self)
        self.o_permis = OngletPermis(conteneur, self)
        self.o_friches = OngletFriches(conteneur, self)
        self.o_zonage = OngletZonage(conteneur, self)
        self.themes = [self.o_conso, self.o_permis, self.o_friches, self.o_zonage]
        self.onglets.ajouter("Consommation d'espaces", self.o_conso, 220)
        self.onglets.ajouter("Permis", self.o_permis)
        self.onglets.ajouter("Friches", self.o_friches)
        self.onglets.ajouter("Zonage", self.o_zonage)
        self.onglets.ajouter("Paramètres", self.o_parametres, 150)
        self.onglets.afficher("Consommation d'espaces")

        self.appliquer_theme_ttk()
        for t in self.themes:
            t.maj_source()
        self.after(100, self._traiter_messages)
        self.after(200, self.recharger_communes)

    # ------------------------------------------------------------ outillage
    def appliquer_theme_ttk(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Urba.Treeview", background=couleur("panneau"), fieldbackground=couleur("panneau"),
                        foreground=couleur("texte"), rowheight=26, font=(POLICE, 10), borderwidth=0)
        style.configure("Urba.Treeview.Heading", background=couleur("navy"), foreground="#ffffff",
                        font=(POLICE, 10, "bold"), relief="flat")
        style.map("Urba.Treeview", background=[("selected", couleur("selection"))],
                  foreground=[("selected", couleur("texte"))])
        style.map("Urba.Treeview.Heading", background=[("active", couleur("orange"))])
        for t in self.themes:
            t.appliquer_couleurs()

    def changer_mode(self, valeur):
        ctk.set_appearance_mode("dark" if valeur == "Sombre" else "light")
        self.appliquer_theme_ttk()

    def _envoyer(self, type_msg, contenu=None):
        self.file.put((type_msg, contenu))

    def _traiter_messages(self):
        try:
            while True:
                type_msg, contenu = self.file.get_nowait()
                onglet = self.onglet_travail or self.o_conso
                if type_msg == "journal":
                    onglet.ecrire(contenu)
                elif type_msg == "journal_tous":
                    for t in self.themes:
                        t.ecrire(contenu)
                elif type_msg == "appel":
                    contenu()
                elif type_msg == "progression":
                    onglet.progression(*contenu)
                elif type_msg == "erreur":
                    self._terminer()
                    onglet.ecrire(f"ERREUR : {contenu}")
                    messagebox.showerror("Erreur", contenu)
                elif type_msg == "annule":
                    self._terminer()
                    onglet.ecrire("Opération annulée.")
                elif type_msg == "fini":
                    self._terminer()
        except queue.Empty:
            pass
        self.after(100, self._traiter_messages)

    def _terminer(self):
        if self.onglet_travail:
            self.onglet_travail.en_cours(False)
            self.onglet_travail.maj_source()
        self.onglet_travail = None

    def _thread(self, cible):
        def enveloppe():
            try:
                cible()
            except reseau.Annulation:
                self._envoyer("annule")
            except reseau.ErreurSource as exc:
                self._envoyer("erreur", str(exc))
            except Exception as exc:            # dernier filet : message lisible, pas de plantage
                self._envoyer("erreur", f"{exc.__class__.__name__} : {exc}")
        threading.Thread(target=enveloppe, daemon=True).start()

    def demarrer(self, onglet):
        """Un seul travail à la fois (tous thèmes confondus)."""
        if self.onglet_travail is not None:
            messagebox.showinfo("Patience", "Une opération est déjà en cours, attendez sa fin ou annulez-la.")
            return False
        self.onglet_travail = onglet
        self.stop_event = reseau.nouvel_evenement_stop()
        onglet.en_cours(True)
        return True

    def executer(self, onglet, travail, fin=None):
        """travail(log) tourne dans un thread ; fin(résultat) est appelée dans l'interface."""
        def log(texte):
            self._envoyer("journal", f"{datetime.now():%H:%M:%S}  {texte}")

        derniere = [-1.0]

        def suivi(valeur, texte):
            if valeur - derniere[0] >= 0.005 or valeur >= 1:      # pas plus de 200 mises à jour
                derniere[0] = valeur
                self._envoyer("progression", (valeur, texte))

        def cible():
            reseau.definir_suivi(suivi)
            try:
                resultat = travail(log)
            finally:
                reseau.definir_suivi(None)
            if fin:
                self._envoyer("appel", lambda: fin(resultat))
            self._envoyer("fini")
        self._thread(cible)

    def basculer_detail(self, onglet):
        if onglet.v_detail.get():
            reseau.definir_ecouteur(lambda t: self._envoyer("journal", "      · " + t))
        else:
            reseau.definir_ecouteur(None)

    def ouvrir_journal_technique(self):
        chemin = os.path.join(dossier_application(), "journal_technique.log")
        if not os.path.exists(chemin):
            messagebox.showinfo("Journal technique", "Aucun appel enregistré pour l'instant.")
            return
        ouvrir(chemin)

    def annuler(self):
        if self.stop_event and self.onglet_travail:
            self.stop_event.set()
            self.onglet_travail.ecrire("Annulation demandée...")

    def chemin_sortie(self, prefixe, extension, libelle):
        nom = f"{prefixe}_{datetime.now():%Y-%m-%d_%H%M}{extension}"
        return filedialog.asksaveasfilename(defaultextension=extension, initialfile=nom,
                                            filetypes=[(libelle, f"*{extension}")])

    def avec_contours(self, onglet, prefixe, extension, libelle, ecrire, contours_facultatifs=False):
        """Choix du fichier, puis contours des communes (geo.api, réseau) dans un thread, puis écriture."""
        chemin = self.chemin_sortie(prefixe, extension, libelle)
        if not chemin or not self.demarrer(onglet):
            return
        onglet.ecrire("Récupération des contours des communes...")

        def ecrire_ici(contours):
            try:
                message = ecrire(chemin, contours)
                if message:
                    onglet.ecrire(message)
            except PermissionError:
                messagebox.showerror("Export", "Le fichier est peut-être ouvert dans un autre logiciel : fermez-le.")
            except Exception as exc:
                messagebox.showerror("Export", f"Échec de l'export : {exc}")

        def cible():
            try:
                contours = T.contours_communes(stop_event=self.stop_event)
            except reseau.ErreurSource as exc:
                if not contours_facultatifs:
                    raise
                self._envoyer("journal", f"Contours des communes indisponibles ({exc}) : carte sans limites communales.")
                contours = None
            self._envoyer("appel", lambda: ecrire_ici(contours))
            self._envoyer("fini")
        self._thread(cible)

    # ------------------------------------------------------------ communes et caches
    def recharger_communes(self, forcer=False):
        def cible():
            try:
                communes = T.communes_epci(forcer=forcer)
                nom = T.nom_epci()
                self._envoyer("appel", lambda: self._communes_chargees(communes, nom))
            except reseau.ErreurSource as exc:
                self._envoyer("journal_tous", f"Impossible de charger les communes : {exc}")
        self._thread(cible)

    def _communes_chargees(self, communes, nom):
        self.communes, self.nom_epci = communes, nom
        pop = sum(c["population"] for c in communes)
        for t in self.themes:
            t.communes.remplir(communes)
            t.ecrire(f"{nom} : {len(communes)} communes, {_milliers(pop)} habitants.")

    def vider_caches(self):
        n = 0
        dossier = dossier_application()
        for f in os.listdir(dossier):
            if f.startswith("cache_") and f.endswith(".json"):
                try:
                    os.remove(os.path.join(dossier, f))
                    n += 1
                except OSError:
                    pass
        for sous in ("cache_conso", "cache_cadastre", "cache_friches", "cache_zonage"):
            chemin = os.path.join(dossier, sous)
            if os.path.isdir(chemin):
                n += len(os.listdir(chemin))
                shutil.rmtree(chemin, ignore_errors=True)
        for t in self.themes:
            t.maj_source()
        messagebox.showinfo("Caches", f"{n} fichier(s) de cache supprimé(s).")


def ouvrir(chemin):
    try:
        os.startfile(chemin)
    except (AttributeError, OSError):
        webbrowser.open("file:///" + os.path.abspath(chemin).replace("\\", "/"))


if __name__ == "__main__":
    ctk.set_appearance_mode("light")      # doit précéder la création de la fenêtre
    reseau.activer_journal_fichier()
    Application().mainloop()

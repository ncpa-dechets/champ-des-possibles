# -*- coding: utf-8 -*-
"""Déplacements domicile-travail : base « flux de mobilité » du recensement (Insee).

Vérifié par la sonde 5 du 20/10/2026 : page https://www.insee.fr/fr/statistiques/8582949, fichier
base-flux-mobilite-domicile-lieu-travail-2022_csv.zip (12 Mo, un CSV de 55 Mo, 987 000 lignes), colonnes
CODGEO (commune de résidence), LIBGEO, DCLT (commune de travail), L_DCLT, NBFLUX_C22_ACTOCC15P (actifs occupés de
15 ans ou plus). Tous les flux sont présents, y compris les très petits (valeurs pondérées non entières).
Pour NCPA : 6 750 sortants, 3 670 entrants, 5 560 actifs habitant et travaillant dans l'EPCI."""
import csv
import io
import re
import zipfile

PAGE = "https://www.insee.fr/fr/statistiques/8582949"
URL = "https://www.insee.fr/fr/statistiques/fichier/8582949/base-flux-mobilite-domicile-lieu-travail-2022_csv.zip"
GEO = "https://geo.api.gouv.fr"
NAVIGATEUR = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ObservatoireEmploiNCPA"}


def _zip(client, log):
    try:
        return client.get(URL, brut=True, timeout=300, entetes=NAVIGATEUR).content
    except Exception as e:
        log(f"      adresse habituelle indisponible ({str(e)[:80]}) : recherche du lien sur la page Insee")
    page = client.get(PAGE, brut=True, timeout=60, entetes=NAVIGATEUR).text
    liens = re.findall(r"(/fr/statistiques/fichier/\d+/[^\"'\s>]*csv[^\"'\s>]*\.zip)", page)
    if not liens:
        raise RuntimeError("lien du fichier introuvable sur la page Insee")
    return client.get("https://www.insee.fr" + liens[0], brut=True, timeout=300, entetes=NAVIGATEUR).content


def telecharger(client, codes, log=print):
    """Flux qui partent de l'EPCI ou y arrivent. -> {'annee', 'flux': [[res, lib_res, trav, lib_trav, n], ...]}."""
    codes = set(codes)
    contenu = _zip(client, log)
    log(f"      {len(contenu) / 1e6:.1f} Mo reçus")
    z = zipfile.ZipFile(io.BytesIO(contenu))
    nom = max((n for n in z.namelist() if n.lower().endswith(".csv")), key=lambda n: z.getinfo(n).file_size)
    with io.TextIOWrapper(z.open(nom), encoding="utf-8-sig", errors="replace") as f:
        entete = f.readline()
        sep = ";" if entete.count(";") >= entete.count(",") else ","
        cols = [c.strip().strip('"') for c in entete.rstrip("\r\n").split(sep)]
        c_flux = next((c for c in cols if c.upper().startswith("NBFLUX")), None)
        if not c_flux or "CODGEO" not in cols or "DCLT" not in cols:
            raise RuntimeError(f"colonnes inattendues : {cols}")
        m = re.search(r"C(\d{2})_", c_flux)
        annee = 2000 + int(m.group(1)) if m else None
        flux = []
        for l in csv.DictReader(f, fieldnames=cols, delimiter=sep):
            r, t = l["CODGEO"], l["DCLT"]
            if r in codes or t in codes:
                try:
                    n = float(str(l[c_flux]).replace(",", "."))
                except ValueError:
                    continue
                flux.append([r, l.get("LIBGEO") or r, t, l.get("L_DCLT") or t, round(n, 2)])
    log(f"      {len(flux)} flux concernent l'EPCI (recensement {annee})")
    return {"annee": annee, "flux": flux}


def centres(client, flux, codes, log=print, part_min=.97):
    """Coordonnées (lon, lat) des communes reliées à l'EPCI, par département, en couvrant au moins 97 % des actifs
    concernés (les départements lointains ne servent qu'à quelques actifs). -> {code commune: [lon, lat]}."""
    poids = {}
    for r, _, t, _, n in flux:
        for c in (r, t):
            d = c[:3] if c.startswith("97") else c[:2]
            poids[d] = poids.get(d, 0) + n
    total, cumul, deps = sum(poids.values()) or 1, 0, []
    for d, n in sorted(poids.items(), key=lambda x: -x[1]):
        deps.append(d)
        cumul += n
        if cumul / total >= part_min or len(deps) >= 8:
            break
    out = {}
    for d in deps:
        try:
            js = client.get(f"{GEO}/communes", {"codeDepartement": d, "fields": "code,centre", "format": "json"},
                            timeout=60, essais=2)
            for c in js:
                if (c.get("centre") or {}).get("coordinates"):
                    out[c["code"]] = c["centre"]["coordinates"]
        except Exception as e:
            log(f"      centres des communes du département {d} indisponibles ({str(e)[:80]})")
    log(f"      coordonnées de {len(out)} communes ({len(deps)} départements)")
    return out

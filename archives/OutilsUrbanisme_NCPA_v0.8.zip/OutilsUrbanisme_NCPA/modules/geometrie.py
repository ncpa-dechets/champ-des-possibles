"""Outils géométriques sans dépendance (pas de shapely, pour garder un .exe léger).

- lecture du WKT (POINT, POLYGON, MULTIPOLYGON, MULTIPOINT) vers GeoJSON ;
- détection et correction de l'ordre des coordonnées (latitude/longitude
  inversées) et conversion Lambert-93 (EPSG:2154) vers WGS84 ;
- surface approchée d'un polygone WGS84 (sphère), suffisante pour des
  sites de quelques hectares ;
- centre d'une géométrie.
"""
import math
import re

# Lambert-93 (EPSG:2154), paramètres IGN
_N = 0.7256077650532670
_C = 11754255.426096
_XS, _YS = 700000.0, 12655612.049876
_E = 0.0818191910428158
_LON0 = math.radians(3.0)
RAYON = 6371008.8


def lambert93_vers_wgs84(x, y):
    dx, dy = x - _XS, y - _YS
    r = math.hypot(dx, dy)
    gamma = math.atan(dx / -dy)
    lon = _LON0 + gamma / _N
    latiso = -1 / _N * math.log(abs(r / _C))
    phi = 2 * math.atan(math.exp(latiso)) - math.pi / 2
    for _ in range(12):
        s = _E * math.sin(phi)
        phi = 2 * math.atan(((1 + s) / (1 - s)) ** (_E / 2) * math.exp(latiso)) - math.pi / 2
    return math.degrees(lon), math.degrees(phi)


def _paires(texte):
    nombres = [float(v) for v in re.findall(r"-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", texte)]
    return [[nombres[i], nombres[i + 1]] for i in range(0, len(nombres) - 1, 2)]


def _anneaux(texte):
    """'(x y, x y), (x y, ...)' -> liste d'anneaux."""
    return [_paires(a) for a in re.findall(r"\(([^()]+)\)", texte)]


def wkt_vers_geojson(wkt):
    """Géométrie GeoJSON brute (coordonnées non corrigées) ou None."""
    if not wkt:
        return None
    t = str(wkt).strip()
    t = re.sub(r"^SRID=\d+;", "", t, flags=re.I)
    m = re.match(r"^\s*([A-Za-z]+)\s*(?:Z|M|ZM)?\s*\((.*)\)\s*$", t, re.S)
    if not m:
        return None
    genre, corps = m.group(1).upper(), m.group(2)
    try:
        if genre == "POINT":
            p = _paires(corps)
            return {"type": "Point", "coordinates": p[0]} if p else None
        if genre == "MULTIPOINT":
            return {"type": "MultiPoint", "coordinates": _paires(corps)}
        if genre == "POLYGON":
            return {"type": "Polygon", "coordinates": _anneaux(corps)}
        if genre == "MULTIPOLYGON":
            polys = [_anneaux(p) for p in re.findall(r"\(\s*(\(.*?\))\s*\)", corps, re.S)]
            return {"type": "MultiPolygon", "coordinates": [p for p in polys if p]}
    except (ValueError, IndexError):
        return None
    return None


def _toutes(geom):
    t, c = geom["type"], geom["coordinates"]
    if t == "Point":
        return [c]
    if t == "MultiPoint":
        return c
    if t == "Polygon":
        return [p for anneau in c for p in anneau]
    return [p for poly in c for anneau in poly for p in anneau]


def _transformer(geom, f):
    def tr(p):
        return list(f(p[0], p[1]))
    t, c = geom["type"], geom["coordinates"]
    if t == "Point":
        return {"type": t, "coordinates": tr(c)}
    if t == "MultiPoint":
        return {"type": t, "coordinates": [tr(p) for p in c]}
    if t == "Polygon":
        return {"type": t, "coordinates": [[tr(p) for p in a] for a in c]}
    return {"type": t, "coordinates": [[[tr(p) for p in a] for a in poly] for poly in c]}


def normaliser(geom):
    """Remet la géométrie en WGS84 [longitude, latitude] (France métropolitaine).
    -> (géométrie, mention) où mention vaut '', 'inversée' ou 'lambert93'."""
    if not geom or not geom.get("coordinates"):
        return None, ""
    pts = _toutes(geom)
    if not pts:
        return None, ""
    x, y = pts[0]
    if abs(x) > 1000 and abs(y) > 1000:
        return _transformer(geom, lambda a, b: (round(v, 7) for v in lambert93_vers_wgs84(a, b))), "lambert93"
    if 41 <= x <= 52 and -6 <= y <= 10:
        return _transformer(geom, lambda a, b: (b, a)), "inversée"
    return geom, ""


def centre(geom):
    """Centre (moyenne des sommets du plus grand anneau, ou point)."""
    if not geom:
        return None
    t, c = geom["type"], geom["coordinates"]
    if t == "Point":
        return c
    if t == "MultiPoint":
        return [sum(p[0] for p in c) / len(c), sum(p[1] for p in c) / len(c)] if c else None
    anneaux = [c[0]] if t == "Polygon" else [poly[0] for poly in c if poly]
    if not anneaux:
        return None
    anneau = max(anneaux, key=len)
    return [round(sum(p[0] for p in anneau) / len(anneau), 7), round(sum(p[1] for p in anneau) / len(anneau), 7)]


def surface_m2(geom):
    """Surface approchée (m²) d'un polygone WGS84, trous déduits."""
    if not geom or geom["type"] not in ("Polygon", "MultiPolygon"):
        return None
    polys = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]

    def anneau(a):
        s = 0.0
        for (x1, y1), (x2, y2) in zip(a, a[1:]):
            s += math.radians(x2 - x1) * (2 + math.sin(math.radians(y1)) + math.sin(math.radians(y2)))
        return abs(s) * RAYON ** 2 / 2
    return sum(anneau(p[0]) - sum(anneau(t) for t in p[1:]) for p in polys if p)


def wgs84_vers_lambert93(lon, lat):
    """Projection directe WGS84 -> Lambert-93 (m), pour mesurer des surfaces exactes."""
    phi = math.radians(lat)
    s = _E * math.sin(phi)
    latiso = math.log(math.tan(math.pi / 4 + phi / 2) * ((1 - s) / (1 + s)) ** (_E / 2))
    r = _C * math.exp(-_N * latiso)
    gamma = _N * (math.radians(lon) - _LON0)
    return _XS + r * math.sin(gamma), _YS - r * math.cos(gamma)

"""Sources sans API stable : fichiers à déposer dans donnees_manuelles/ (facultatifs).
Si un fichier est absent, le volet correspondant est simplement signalé « non disponible »."""
import re

import pandas as pd

from ..utils import MANUELS, log, norm


def _lire(f):
    if f.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(f, dtype=str)
    return pd.read_csv(f, sep=None, engine="python", dtype=str, encoding="utf-8-sig")


def _navettes_detail(f, deps):
    """Fichier détail INSEE (FD_MOBPRO : une ligne par individu, pondération IPONDI).
    Plusieurs millions de lignes : agrégé avec DuckDB sans tout charger en mémoire."""
    import duckdb
    chemin = f.as_posix().replace("'", "''")
    src = (f"read_parquet('{chemin}')" if f.suffix.lower() == ".parquet"
           else f"read_csv('{chemin}', delim=';', header=true, all_varchar=true)")
    con = duckdb.connect()
    cols = {r[0].upper(): r[0] for r in con.execute(f"DESCRIBE SELECT * FROM {src}").fetchall()}
    c_o = cols.get("COMMUNE") or cols.get("CODGEO")
    c_d, c_p = cols.get("DCLT"), cols.get("IPONDI")
    if not (c_o and c_d and c_p):
        con.close()
        raise ValueError(f"colonnes COMMUNE, DCLT et IPONDI attendues ; trouvées : {list(cols)[:12]}")
    liste = ",".join(f"'{d}'" for d in deps)
    q = f"""SELECT lpad(CAST("{c_o}" AS VARCHAR), 5, '0') AS origine, lpad(CAST("{c_d}" AS VARCHAR), 5, '0') AS destination,
                   SUM(TRY_CAST(replace(CAST("{c_p}" AS VARCHAR), ',', '.') AS DOUBLE)) AS flux
            FROM {src} WHERE substr(lpad(CAST("{c_o}" AS VARCHAR), 5, '0'), 1, 2) IN ({liste}) GROUP BY 1, 2"""
    out = con.execute(q).df()
    con.close()
    return out


def charger_navettes(cfg=None):
    """Flux domicile-lieu de travail (INSEE, mobilités professionnelles). Deux formats acceptés :
    - base des flux agrégés : CODGEO (résidence), DCLT (travail), NBFLUX_xxx ;
    - fichier détail FD_MOBPRO (csv ou parquet) : COMMUNE, DCLT, IPONDI (pondération)."""
    etape = "Navettes domicile-travail"
    fichiers = [f for f in MANUELS.iterdir()
                if f.suffix.lower() in (".csv", ".xlsx", ".txt", ".parquet")
                and re.search(r"flux|mobpro|navette|domicile", f.name, flags=re.I)]
    if not fichiers:
        log(etape, "fichier non fourni (facultatif) — part des actifs travaillant hors EPCI = hypothèse", "info")
        return None
    f = fichiers[0]
    deps = (cfg or {}).get("deps_region") or []
    try:
        entete = []
        if f.suffix.lower() in (".csv", ".txt"):
            entete = pd.read_csv(f, sep=None, engine="python", dtype=str, nrows=2, encoding="utf-8-sig").columns
        detail = f.suffix.lower() == ".parquet" or any(c.upper() == "IPONDI" for c in entete)
        if detail:
            if not deps:
                raise ValueError("liste des départements inconnue")
            log(etape, f"{f.name} : fichier détail (pondéré), agrégation en cours — peut prendre une minute…")
            out = _navettes_detail(f, deps)
            c_f = "IPONDI"
        else:
            df = _lire(f)
            cols = {c.upper(): c for c in df.columns}
            c_o = cols.get("CODGEO") or next(c for c in df.columns if "codgeo" in c.lower())
            c_d = cols.get("DCLT") or next(c for c in df.columns if "dclt" in c.lower())
            c_f = next(c for c in df.columns if c.upper().startswith("NBFLUX") or "flux" in c.lower())
            out = pd.DataFrame({"origine": df[c_o].str.zfill(5), "destination": df[c_d].str.zfill(5),
                                "flux": pd.to_numeric(df[c_f].str.replace(",", "."), errors="coerce")})
        out = out.dropna(subset=["flux"])
        log(etape, f"{f.name} : {len(out)} flux lus ({c_f})", "ok")
        return out
    except Exception as e:
        log(etape, f"lecture impossible de {f.name} : {e}", "erreur")
        return None


def charger_spheres_officielles(codes_connus):
    """Série officielle « Part des emplois de la sphère présentielle » (INSEE RP 1975-2021),
    téléchargée sur l'Observatoire des territoires. Lecture tolérante : on cherche la colonne
    des codes géographiques, l'année et la valeur."""
    etape = "Sphères (Observatoire)"
    fichiers = [f for f in MANUELS.iterdir() if re.search(r"spher|presentiel", norm(f.name))
                and not re.search(r"grille|naf", norm(f.name))       # grille INSEE des codes : autre usage
                and f.suffix.lower() in (".csv", ".xlsx", ".xls")]
    if not fichiers:
        log(etape, "fichier officiel non fourni (facultatif) — approximation URSSAF seule", "info")
        return None
    f = fichiers[0]
    try:
        c_geo, df = None, None
        # l'Observatoire place parfois des lignes de titre au-dessus de l'en-tête
        for saut in range(0, 6):
            if f.suffix.lower() in (".xlsx", ".xls"):
                d = pd.read_excel(f, dtype=str, skiprows=saut)
            else:
                d = pd.read_csv(f, sep=None, engine="python", dtype=str, skiprows=saut, encoding="utf-8-sig")
            c_geo = next((c for c in d.columns if d[c].astype(str).isin(codes_connus).mean() > 0.3), None)
            if c_geo:
                df = d
                break
        if not c_geo:
            raise ValueError("colonne des codes géographiques introuvable")
        c_an = next((c for c in df.columns if norm(c) in ("an", "annee", "millesime", "date")), None)
        valeurs = [c for c in df.columns if c not in (c_geo, c_an)
                   and pd.to_numeric(df[c].astype(str).str.replace(",", "."), errors="coerce").notna().mean() > 0.5]
        if c_an:
            c_v = next((c for c in valeurs if "pres" in norm(c)), valeurs[0])
            out = pd.DataFrame({"geo": df[c_geo], "annee": df[c_an].str[:4],
                                "part_presentielle": pd.to_numeric(df[c_v].str.replace(",", "."), errors="coerce")})
        else:  # format large : une colonne par année
            ans = [c for c in valeurs if re.search(r"(19|20)\d\d", c)]
            m = df[[c_geo] + ans].melt(id_vars=c_geo, var_name="v", value_name="val")
            out = pd.DataFrame({"geo": m[c_geo], "annee": m["v"].str.extract(r"((?:19|20)\d\d)")[0],
                                "part_presentielle": pd.to_numeric(m["val"].str.replace(",", "."), errors="coerce")})
        out = out.dropna()
        if out.part_presentielle.max() <= 1:
            out["part_presentielle"] *= 100
        log(etape, f"{f.name} : {out.geo.nunique()} territoires, années {out.annee.min()}–{out.annee.max()}", "ok")
        return out
    except Exception as e:
        log(etape, f"lecture impossible de {f.name} : {e}", "erreur")
        return None

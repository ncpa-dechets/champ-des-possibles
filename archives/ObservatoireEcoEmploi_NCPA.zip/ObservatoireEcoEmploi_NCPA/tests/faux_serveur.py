# -*- coding: utf-8 -*-
"""Faux serveur : reproduit les structures de réponse relevées par les sondes (Urssaf, OFGL, geo.api, Insee,
France Travail, SIRENE, BODACC...) avec des valeurs inventées mais plausibles. Sert aux tests hors ligne."""
import csv
import io
import json
import math
import random
import re
import zipfile
from types import SimpleNamespace
from urllib.parse import parse_qs, urlparse

R = random.Random(7)
SIREN = "200065563"
CAEN_LA_MER = "200065597"
ANNEES = list(range(2006, 2026))
COMMUNES = [("14117", "Cabourg", ["14390"])] + [(f"14{500 + i:03d}", f"Commune {i}", [f"14{400 + i % 9:03d}"])
                                                for i in range(1, 38)]
CODES_NCPA = [c for c, _, _ in COMMUNES]
SECTEURS = [("IZ", "IZ Hébergement et restauration", "Services"), ("GZ", "GZ Commerce ; réparation d'automobiles "
            "et de motocycles", "Commerce"), ("FZ", "FZ Construction", "Construction"),
            ("QB", "QB Hébergement médico-social et social et action sociale sans hébergement", "Services"),
            ("CA", "CA Fabrication de denrées alimentaires, de boissons et de produits à base de tabac", "Industrie"),
            ("NZ", "NZ Activités de services administratifs et de soutien", "Services"),
            ("HZ", "HZ Transports et entreposage", "Services"), ("LZ", "LZ Activités immobilières", "Services"),
            ("QA", "QA Activités pour la santé humaine", "Services")]
APE = {"IZ": ["5510Z Hôtels et hébergement similaire", "5610A Restauration traditionnelle"],
       "GZ": ["4711D Supermarchés", "4778C Autres commerces de détail spécialisés divers"],
       "FZ": ["4399C Travaux de maçonnerie générale"], "QB": ["8810A Aide à domicile"],
       "CA": ["1071C Boulangerie et boulangerie-pâtisserie"], "NZ": ["8121Z Nettoyage courant des bâtiments"],
       "HZ": ["4941A Transports routiers de fret interurbains"], "LZ": ["6831Z Agences immobilières"],
       "QA": ["8690D Activités des infirmiers et des sages-femmes"]}
AUTRES_EPCI = [(f"2000{10000 + i:05d}", f"CC Fictive {i}", R.choice(["14", "27", "50", "61", "76", "29", "35", "56"]))
               for i in range(650)]
AUTRES_EPCI.append((CAEN_LA_MER, "CU Caen la Mer", "14"))
AUTRES_EPCI.append(("ZZZZZZZZZ", "Sans objet", "14"))  # communes hors EPCI chez l'Urssaf
TOUS_EPCI = [(SIREN, "CC Normandie-Cabourg-Pays d'Auge", "14")] + AUTRES_EPCI
REG = {"14": "28", "27": "28", "50": "28", "61": "28", "76": "28", "29": "53", "35": "53", "56": "53"}
COMMUNE_EPCI = {c: SIREN for c in CODES_NCPA}
for i, (e, _, d) in enumerate(AUTRES_EPCI):
    COMMUNE_EPCI[f"{d}{600 + i % 400:03d}" if False else f"5{i:04d}"] = e
COMMUNE_EPCI["14118"] = CAEN_LA_MER
COMMUNE_EPCI["14327"] = CAEN_LA_MER
LITTORAL_EPCI = {e for e, _, _ in AUTRES_EPCI[:180]} | {SIREN}


class Rep:
    def __init__(self, data=None, contenu=None, statut=200, texte=None, entetes=None):
        self.status_code, self._data = statut, data
        self.content = contenu if contenu is not None else (json.dumps(data).encode() if data is not None else b"")
        self.text = texte if texte is not None else self.content.decode("utf-8", errors="replace")
        self.headers = entetes or {}

    def json(self):
        return self._data if self._data is not None else json.loads(self.content)

    def iter_content(self, n):
        for i in range(0, len(self.content), n):
            yield self.content[i:i + n]

    def close(self):
        pass


def _eff(base, a, saut=0.0):
    return round(base * (1 + .012 * (a - 2015) + saut) * (1 + R.uniform(-.02, .02)))


# ---------------------------------------------------------------- Urssaf
def champs_urssaf():
    f = [{"name": n, "label": l, "type": "text"} for n, l in [
        ("code_commune", "Code commune"), ("intitule_commune", "Commune"), ("code_epci", "Code EPCI"),
        ("epci", "EPCI"), ("code_departement", "Code département"), ("departement", "Département"),
        ("code_region", "Code région"), ("region", "Région"), ("grand_secteur_d_activite", "Grand secteur"),
        ("secteur_na17j", "Secteur NA17"), ("secteur_na38i", "Secteur NA38"), ("secteur_na88i", "Secteur NA88"),
        ("ape", "APE")]]
    for a in ANNEES:
        f += [{"name": f"effectifs_salaries_{a}", "label": f"Effectifs salariés {a}", "type": "double"},
              {"name": f"nombre_d_etablissements_{a}", "label": f"Nombre d'établissements {a}", "type": "double"}]
    return f


def detail_ncpa():
    rows = []
    for k, (c, nom, _) in enumerate(COMMUNES):
        poids = 6 if c == "14117" else (1 + (k % 5))
        for code, lib, gs in SECTEURS:
            for ape in APE[code]:
                base = poids * R.randint(1, 6) * (3 if code == "IZ" else 1)
                r = {"code_commune": c, "intitule_commune": nom, "grand_secteur_d_activite": gs,
                     "secteur_na17j": lib, "secteur_na38i": lib, "secteur_na88i": lib, "ape": ape}
                for a in ANNEES:
                    r[f"effectifs_salaries_{a}"] = _eff(base, a)
                    r[f"nombre_d_etablissements_{a}"] = max(1, round(base / 6))
                rows.append(r)
    return rows


def references():
    rows = []
    for d, reg in REG.items():
        for code, lib, gs in SECTEURS + [("OZ", "OZ Administration publique", "Services")]:
            r = {"code_region": reg, "region": "Normandie" if reg == "28" else "Bretagne", "code_departement": d,
                 "departement": "Calvados" if d == "14" else f"Département {d}", "grand_secteur_d_activite": gs,
                 "secteur_na17j": lib, "secteur_na38i": lib, "secteur_na88i": lib}
            base = R.randint(3000, 30000)
            for a in ANNEES:
                r[f"eff_{a}"], r[f"etab_{a}"] = _eff(base, a), round(base / 9)
            rows.append(r)
    return rows


def totaux_epci():
    rows = []
    for e, nom, d in TOUS_EPCI:
        base = 6500 if e == SIREN else R.randint(2000, 60000)
        r = {"code_epci": e, "epci": nom, "code_departement": d, "code_region": REG[d]}
        for a in ANNEES:
            r[f"eff_{a}"], r[f"etab_{a}"] = _eff(base, a), round(base / 8)
        rows.append(r)
    return rows


def urssaf_export(ds, p):
    if "masse" in ds:
        return [{"code_epci": e, "epci": n, "annee": str(a), "nombre_d_etablissements": 500,
                 "effectifs_salaries_moyens": 5000 + 10 * (a - 2010), "masse_salariale": (5000 + 10 * (a - 2010))
                 * (24000 + 400 * (a - 2010)) * R.uniform(.85, 1.15)} for e, n, _ in TOUS_EPCI for a in range(2010, 2025)]
    sel = p.get("select", "")
    if "where" in p:
        return detail_ncpa()
    if p.get("group_by", "").startswith("code_region"):
        return references()
    if p.get("group_by") == "code_epci,code_commune":
        return [{"code_epci": e, "code_commune": c} for c, e in COMMUNE_EPCI.items()]
    if "code_epci" in sel:
        return totaux_epci()
    raise RuntimeError(f"requête Urssaf inattendue {p}")


# ---------------------------------------------------------------- fichiers
def fichier_tourisme():
    s = io.StringIO()
    w = csv.writer(s, delimiter=";")
    w.writerow(["GEO", "GEO_OBJECT", "TOUR_MEASURE", "ACTIVITY", "UNIT_LOC_RANKING", "L_STAY", "OBS_VALUE_NIVEAU"])
    for e, _, _ in TOUS_EPCI:
        lit = e in LITTORAL_EPCI
        for act, mes, v in (("I551", "PLACE", 300 if lit else 60), ("I553", "PLACE", 900 if lit else 100),
                            ("I552", "BEDPLACE", 400 if lit else 50)):
            w.writerow([e, "EPCI", mes, act, "_T", "_T", v * (4 if e == SIREN else R.uniform(.5, 2))])
    return s.getvalue().encode("utf-8")


def fichier_bmo():
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["met", "xmet", "smet", "Code métier BMO", "Nom métier BMO", "Lbl_fam_met", "REG", "NOM_REG", "Dept",
               "NomDept", "BE24", "NOMBE24"])
    metiers = [("S1X40", "Serveurs de cafés et de restaurants", .8), ("S1X20", "Cuisiniers", .6),
               ("T4X60", "Agents d'entretien de locaux", .4), ("J3X40", "Employés de libre-service", .3),
               ("A0X40", "Viticulteurs, arboriculteurs salariés", .9), ("T2A60", "Aides à domicile", .1)]
    for be, nom in (("1407", "CAEN"), ("1409", "LISIEUX"), ("2818", "BAYEUX")):
        for code, m, sais in metiers:
            p = R.randint(50, 900)
            ws.append([p, round(p * .5), round(p * sais), code, m, "Fam", "28", "Normandie", "14", "Calvados", be, nom])
    for code, m, sais in metiers:
        p = 200000
        ws.append([p, p * .5, p * sais * .4, code, m, "Fam", "11", "IDF", "75", "Paris", "1101", "PARIS"])
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


def fichier_mobilites():
    s = io.StringIO()
    w = csv.writer(s, delimiter=";")
    w.writerow(["CODGEO", "LIBGEO", "DCLT", "L_DCLT", "NBFLUX_C22_ACTOCC15P"])
    noms = {c: n for c, n, _ in COMMUNES}
    noms.update({"14118": "Caen", "14327": "Hérouville-Saint-Clair", "14220": "Deauville", "14366": "Lisieux",
                 "75056": "Paris", "27001": "Évreux"})
    for c, n, _ in COMMUNES:
        w.writerow([c, n, c, n, R.uniform(50, 400)])
        for t, f in (("14118", 50), ("14327", 12), ("14220", 8), ("14366", 6), ("75056", 2), ("27001", .7)):
            w.writerow([c, n, t, noms[t], round(f * R.uniform(.5, 1.5), 4)])
        w.writerow([c, n, CODES_NCPA[(CODES_NCPA.index(c) + 1) % 38], "voisine", R.uniform(5, 40)])
    for o, f in (("14118", 400), ("14327", 120), ("14366", 60), ("27001", 5)):
        for c, n, _ in COMMUNES[:20]:
            w.writerow([o, noms[o], c, n, f / 20 * R.uniform(.5, 1.5)])
    for i in range(2000):
        w.writerow([f"9{i:04d}", "Ailleurs", f"8{i:04d}", "Loin", 3])
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr("base-flux-mobilite-domicile-lieu-travail-2022.csv", s.getvalue().encode("utf-8"))
    return b.getvalue()


def geojson():
    feats = []
    for k, (c, n, cps) in enumerate(COMMUNES):
        x0, y0 = -0.35 + (k % 7) * .05, 49.10 + (k // 7) * .035
        feats.append({"type": "Feature", "properties": {"code": c, "nom": n, "population": 1000 + 100 * k,
                                                        "codesPostaux": cps},
                      "geometry": {"type": "Polygon", "coordinates": [[[x0, y0], [x0 + .05, y0], [x0 + .05, y0 + .035],
                                                                       [x0, y0 + .035], [x0, y0]]]}})
    return {"type": "FeatureCollection", "features": feats}


# ---------------------------------------------------------------- Melodi « data »
def melodi(ds, p):
    geos = p.get("GEO")
    geos = geos if isinstance(geos, list) else [geos]
    obs = []

    def o(dims, v):
        obs.append({"dimensions": dims, "measures": {"OBS_VALUE_NIVEAU": {"value": v}}, "attributes": {"OBS_STATUS": "A"}})
    for g in geos:
        code = g.rsplit("-", 1)[-1]
        geo = f"2026-{g}"
        if ds == "DS_RP_LOGEMENT_PRINC":
            if not g.startswith("EPCI"):
                continue
            base = 30000 if code == SIREN else R.randint(5000, 80000)
            prs = .55 if code == SIREN else (.35 if code in LITTORAL_EPCI else .08)
            for an, f in (("2012", .93), ("2017", .97), ("2023", 1)):
                for ocs, part in (("_T", 1), ("DW_SEC_DW_OCC", prs), ("DW_MAIN", 1 - prs - .06), ("DW_VAC", .06)):
                    if p.get("OCS") and ocs != p["OCS"]:
                        continue
                    for tdw in ("_T", "1", "2"):
                        o({"CARS": "_T", "BUILD_END": "_T", "NRG_SRC": "_T", "TDW": tdw, "TSH": "_T", "CARPARK": "_T",
                           "RP_MEASURE": "DWELLINGS", "GEO": geo, "NOR": "_T", "FREQ": "A", "TIME_PERIOD": an,
                           "OCS": ocs, "L_STAY": "_T"}, round(base * part * f * (1 if tdw == "_T" else .5)))
                    o({"CARS": "_T", "BUILD_END": "_T", "NRG_SRC": "_T", "TDW": "_T", "TSH": "_T", "CARPARK": "_T",
                       "RP_MEASURE": "DWELLINGS_ROOMS", "GEO": geo, "NOR": "_T", "FREQ": "A", "TIME_PERIOD": an,
                       "OCS": ocs, "L_STAY": "_T"}, 99)
        elif ds == "DS_FLORES_A38":
            mult = 1 if code == SIREN else 40
            secteurs = {"IZ": 2400, "GZ": 1500, "FZ": 700, "QB": 650, "CA": 300, "NZ": 500, "HZ": 250, "LZ": 160,
                        "QA": 900, "OZ": 1100, "PZ": 600, "AZ": 380, "TZ": 210}
            tot = 0
            for act, v in secteurs.items():
                tot += v * mult
                for mes, f in (("EMPL3112", 1), ("UNIT_LOC", .12)):
                    for ne in ("_T", "E1T4"):
                        o({"GEO": geo, "NUMBER_EMPL": ne, "FLORES_MEASURE": mes, "FREQ": "A",
                           "LEGAL_FORM_WITH_PUBLIC": "1T9X7", "TIME_PERIOD": "2024", "ACTIVITY": act},
                          round(v * mult * f * (1 if ne == "_T" else .2)))
            for mes, f in (("EMPL3112", 1), ("UNIT_LOC", .12)):
                o({"GEO": geo, "NUMBER_EMPL": "_T", "FLORES_MEASURE": mes, "FREQ": "A", "LEGAL_FORM_WITH_PUBLIC": "1T9X7",
                   "TIME_PERIOD": "2024", "ACTIVITY": "_T"}, round(tot * f))
        elif ds in ("DS_SIDE_CREA_COM", "DS_SIDE_CREA_DEP_REG_NAT"):
            mult = 1 if code == SIREN else 14
            for a in range(2012, 2026):
                tot = round((520 + 30 * (a - 2012)) * mult * R.uniform(.9, 1.1))
                for mes, f in (("BURE", 1), ("UNIT_LOC_BURE", 1.15)):
                    o({"GEO": geo, "FREQ": "A", "SIDE_MEASURE": mes, "TIME_PERIOD": str(a), "ACTIVITY": "_T",
                       "LEGAL_FORM": "_T"}, round(tot * f))
                    for lf, pf in (("10", .6), ("54", .1), ("57", .25), ("OTH_SIDE", .05)):
                        o({"GEO": geo, "FREQ": "A", "SIDE_MEASURE": mes, "TIME_PERIOD": str(a), "ACTIVITY": "_T",
                           "LEGAL_FORM": lf}, round(tot * f * pf))
                    for act, pa in (("GI", .3), ("FZ", .15), ("MN", .2), ("RU", .1), ("LZ", .1), ("BE", .05),
                                    ("OQ", .05), ("KZ", .03), ("JZ", .02)):
                        o({"GEO": geo, "FREQ": "A", "SIDE_MEASURE": mes, "TIME_PERIOD": str(a), "ACTIVITY": act,
                           "LEGAL_FORM": "_T"}, round(tot * f * pa))
        elif ds in ("DS_SIDE_STOCKS_COM", "DS_SIDE_STOCKS_A21"):
            mult = 1 if code == SIREN else 14
            for a in range(2014, 2025):
                for mes, v in (("LEGAL_UNIT", 4300 + 120 * (a - 2014)), ("UNIT_LOC", 5200 + 130 * (a - 2014))):
                    o({"GEO": geo, "FREQ": "A", "SIDE_MEASURE": mes, "TIME_PERIOD": str(a), "ACTIVITY": "_T"}, v * mult)
        else:
            raise RuntimeError(f"jeu Melodi inattendu {ds}")
    return {"observations": obs}


# ---------------------------------------------------------------- SIRENE
def sirene(p):
    q = p.get("q", "")
    if p.get("nombre") == 1 or p.get("nombre") == "1":
        a = re.search(r"\[(\d{4})-01-01", q)
        n = (900 + 20 * (int(a.group(1)) - 2015)) if "dateCreation" in q else (650 + 15 * (int(a.group(1)) - 2015))
        return {"header": {"total": n}, "etablissements": []}
    etabs = []
    for i in range(120):
        etat = "F" if i % 3 == 0 else "A"
        emp = "N" if i % 10 == 9 else "O"
        c = CODES_NCPA[i % 38]
        x, y = 470000 + 300 * (i % 37), 6910000 + 200 * (i % 29)
        etabs.append({"siren": f"{800000000 + i}", "siret": f"{800000000 + i}00011", "dateCreationEtablissement": "2010-05-01",
                      "trancheEffectifsEtablissement": ["01", "02", "11", "12", "21", None][i % 6],
                      "anneeEffectifsEtablissement": "2023", "etablissementSiege": True, "statutDiffusionEtablissement": "O",
                      "uniteLegale": {"denominationUniteLegale": f"ENTREPRISE {i}", "categorieEntreprise": "PME"},
                      "adresseEtablissement": {"codeCommuneEtablissement": c, "libelleCommuneEtablissement": c,
                                               "coordonneeLambertAbscisseEtablissement": str(x),
                                               "coordonneeLambertOrdonneeEtablissement": str(y),
                                               "libelleVoieEtablissement": "DE LA MER"},
                      "periodesEtablissement": [{"dateFin": None, "etatAdministratifEtablissement": etat,
                                                 "caractereEmployeurEtablissement": emp,
                                                 "activitePrincipaleEtablissement": ["55.10Z", "56.10A", "47.11D"][i % 3]},
                                                {"dateFin": "2015-01-01", "etatAdministratifEtablissement": "A",
                                                 "caractereEmployeurEtablissement": "O"}]})
    return {"header": {"total": len(etabs), "curseurSuivant": p.get("curseur")}, "etablissements": etabs}


# ---------------------------------------------------------------- France Travail
def _saison_ft(base, profil, debut=2020, fin=(2026, 2)):
    out = {}
    for a in range(debut, fin[0] + 1):
        for t in range(1, 5):
            if (a, t) > fin:
                break
            out[f"{a}T{t}"] = round(base * (1 + .01 * (a - debut)) * profil[t - 1] * R.uniform(.97, 1.03))
    return out


def ft_indicateur(chemin, corps):
    t, nomen = corps.get("codeTypeTerritoire"), corps.get("codeTypeNomenclature")
    amp = {"EPCI": 2.5, "DEP": 1.4, "REG": 1.2, "NAT": 1}[t]
    taille = {"EPCI": 1, "DEP": 25, "REG": 120, "NAT": 2500}[t]
    vals = []

    def ajoute(serie, code, lib):
        for per, v in serie.items():
            vals.append({"codePeriode": per, "codeNomenclature": code, "libNomenclature": lib,
                         "valeurPrincipaleNombre": v, "codeTypePeriode": "TRIMESTRE", "listeValeurParCaract": []})
    if chemin.endswith("stat-demandeurs"):
        ajoute(_saison_ft(1500 * taille, [1 + .03 * amp, 1 - .045 * amp, 1 - .002 * amp, 1 + .02 * amp], 2021), "A", "A")
        ajoute(_saison_ft(2900 * taille, [1 + .01 * amp, 1 - .025 * amp, 1 + .01 * amp, 1 + .005 * amp], 2021), "ABC", "ABC")
    elif chemin.endswith("stat-demandeurs-entrant"):
        vals.append({"codePeriode": "2026T2", "codeNomenclature": "CUMUL 12 MOIS", "valeurPrincipaleNombre": 2500 * taille})
    elif chemin.endswith("stat-offres"):
        ajoute(_saison_ft(900 * taille, [1 + .02 * amp, 1 + .03 * amp, 1 - .05 * amp, 1]), "TOFF", "Toutes offres")
        ajoute(_saison_ft(300 * taille, [1 + .04 * amp, 1 + .05 * amp, 1 - .01, 1 - .08 * amp]), "PE", "Offres FT")
        ajoute({"2026T2": 3600 * taille}, "TOFF-CUMUL12MOIS", "cumul")
        ajoute({"2026T2": 1200 * taille}, "PE-CUMUL12MOIS", "cumul")
    elif chemin.endswith("stat-embauches"):
        tt = _saison_ft(3500 * taille, [1 - .15 * amp ** .5, 1 + .05 * amp, 1 + .18 * amp ** .5, 1 - .06], 2020, (2025, 3))
        ajoute(tt, "TOUT-TOUTE", "Toutes durées")
        ajoute({k: round(v * .45) for k, v in tt.items()}, "TOUT-SUP1M", "Plus d'un mois")
        ajoute({k: round(v * .8) for k, v in tt.items()}, "ABCDEFG-TOUTE", "DE toutes")
    elif chemin.endswith("stat-dynamique-emploi"):
        vals.append({"codePeriode": "2026T2", "valeurPrincipaleNombre": 3})
    elif chemin.endswith(("stat-population-active", "stat-salaries")):
        vals.append({"codePeriode": "2022", "valeurPrincipaleNombre": 21000 * taille})
    elif chemin.endswith("stat-perspective-employeur"):
        return None
    return {"listeValeursParPeriode": vals}


# ---------------------------------------------------------------- BODACC
def bodacc(p):
    a = re.search(r"date'(\d{4})", p.get("where", "")).group(1)
    out = []
    natures = ["Jugement d'ouverture de liquidation judiciaire", "Jugement d'ouverture d'une procédure de redressement "
               "judiciaire", "Jugement de clôture pour insuffisance d'actif", "Liste des créances nées après le "
               "jugement d'ouverture d'une procédure de liquidation judiciaire"]
    for i in range(160):
        nat = natures[i % 4]
        siren = f"{800000000 + (i % 40)}" if i % 9 == 0 else f"{700000000 + i}"
        ville, cp = ("Cabourg", "14390") if i % 11 == 0 else ("Caen", "14000")
        out.append({"dateparution": f"{a}-03-{1 + i % 27:02d}", "cp": cp, "ville": ville,
                    "registre": None if i % 13 == 0 else [siren, f"{siren[:3]} {siren[3:6]} {siren[6:]}"],
                    "commercant": f"SOCIETE {i}", "jugement": json.dumps({"type": "initial", "nature": nat,
                                                                          "date": f"{a}-03-01"})})
    return out


# ---------------------------------------------------------------- client
class Session:
    def __init__(self, serveur):
        self.v = serveur

    def post(self, url, **kw):
        return Rep({"access_token": "jeton", "expires_in": 1499})

    def request(self, methode, url, **kw):
        if "referentiel" in url:
            return Rep({"codeTerritoire": SIREN, "libelleTerritoire": "CC NCPA"})
        d = ft_indicateur(url, kw.get("json") or {})
        return Rep(d) if d is not None else Rep(statut=204)

    def get(self, url, params=None, **kw):
        return self.v.repondre(url, params or {}, brut=True)


class FauxClient:
    """Remplace modules.reseau.Client. pannes : ensemble de mots-clés d'adresse à faire échouer."""

    def __init__(self, log=print, pannes=()):
        self.log, self.pannes, self.appels = log, set(pannes), []
        self.s = Session(self)

    def get(self, url, params=None, timeout=300, essais=3, brut=False, entetes=None):
        r = self.repondre(url, params or {}, brut)
        if r.status_code != 200:
            raise RuntimeError(f"échec de l'appel ({r.status_code})")
        return r if brut else r.json()

    def repondre(self, url, p, brut=False):
        self.appels.append(url)
        if any(k in url for k in self.pannes):
            return Rep(statut=503, texte="panne simulée")
        u = urlparse(url)
        if "open.urssaf.fr" in url:
            ds = u.path.split("/datasets/")[1].split("/")[0]
            if url.endswith(ds):
                return Rep({"fields": champs_urssaf()})
            return Rep(urssaf_export(ds, p))
        if "data.ofgl.fr" in url:
            return Rep([{"siren": e, "exer": "2024", "ptot": 22000 if e == SIREN else R.randint(8000, 200000)}
                        for e, _, _ in TOUS_EPCI])
        if "geo.api.gouv.fr" in url:
            if "/epcis/" in url:
                return Rep(geojson())
            d = p.get("codeDepartement")
            centres = [{"code": c, "centre": {"coordinates": [-0.35 + i % 7 * .05, 49.1 + i // 7 * .035]}}
                       for i, (c, _, _) in enumerate(COMMUNES)] if d == "14" else []
            centres += [{"code": c, "centre": {"coordinates": xy}} for c, xy in
                        (("14118", [-0.37, 49.18]), ("14327", [-0.33, 49.20]), ("14220", [0.07, 49.36]),
                         ("14366", [0.23, 49.15])) if c[:2] == d]
            if d == "75":
                centres.append({"code": "75056", "centre": {"coordinates": [2.35, 48.85]}})
            return Rep(centres)
        if "DS_TOUR_CAP" in url:
            return Rep(contenu=fichier_tourisme())
        if "melodi/data/" in url:
            geos = p.get("GEO") if isinstance(p.get("GEO"), list) else [p.get("GEO")]
            if any(str(g).endswith("ZZZZZZZZZ") or str(g).endswith("200010007") for g in geos):
                return Rep(statut=400, texte="Aucun territoire trouvé pour EPCI-ZZZZZZZZZ-2026")
            return Rep(melodi(u.path.rsplit("/", 1)[-1], p))
        if "melodi/catalog" in url:
            return Rep({"identifier": "x"})
        if "data.gouv.fr/api/1/datasets" in url:
            return Rep({"resources": [{"format": "csv", "url": "https://static.data.gouv.fr/littoral.csv",
                                       "title": "Communes littorales", "last_modified": "2026-06-01"}]})
        if "static.data.gouv.fr/littoral.csv" in url:
            codes = [c for c, e in COMMUNE_EPCI.items() if e in LITTORAL_EPCI] + [f"7{i:04d}" for i in range(400)]
            return Rep(contenu=("code_insee\n" + "\n".join(codes)).encode())
        if "observatoire-des-territoires" in url:
            ind = p.get("indic", "x")
            lignes = ["codgeo;libgeo;an;sexe;" + ind] + [f"{e};{n};2022;T;{R.uniform(5, 15):.1f}" for e, n, _ in TOUS_EPCI]
            return Rep(contenu="\n".join(lignes).encode())
        if "BMO" in url:
            return Rep(contenu=fichier_bmo())
        if "api-sirene" in url:
            return Rep(sirene(p))
        if "insee.fr/fr/statistiques/fichier/8582949" in url:
            return Rep(contenu=fichier_mobilites())
        if "insee.fr/fr/statistiques/8582949" in url:
            return Rep(texte='<a href="/fr/statistiques/fichier/8582949/base-flux-mobilite-domicile-lieu-travail-2022_csv.zip">')
        if "bodacc" in url:
            return Rep(bodacc(p)) if "exports" in url else Rep({"fields": []})
        raise RuntimeError(f"adresse non simulée : {url} {p}")

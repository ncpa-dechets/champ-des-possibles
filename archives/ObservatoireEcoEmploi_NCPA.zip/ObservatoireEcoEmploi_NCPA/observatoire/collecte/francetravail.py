# -*- coding: utf-8 -*-
"""API France Travail : « Marché du travail » et « Informations sur un territoire ».
Identifiants dans identifiants_francetravail.txt, à côté de l'application (ligne 1 : identifiant, ligne 2 : clé).

Vérifié par les sondes 4 et 4b du 01/10/2026 :
  - jeton par formulaire (client_credentials), scopes des deux API acceptés ensemble, durée 1 499 s ;
  - types de territoire : NAT, REG, DEP, BASBMO, EPCI, COM, CLPE (l'EPCI est accepté par DE_1, DE_5, EMB_1, OFF_1,
    DYN_1, ETAB_1, POP_1, POP_2, SAL_1 ; PAS par la tension PERSP_2, limitée à NAT, REG, DEP, BASBMO) ;
  - activité « CUMUL » (toutes activités) acceptée ; une requête sans code d'activité renvoie 404 :
    les tensions se demandent donc métier par métier.
Vérifié par les sondes 5 et 5b du 20/10/2026 :
  - le SIREN de l'EPCI est accepté comme code de territoire ;
  - sans « dernierePeriode », les demandeurs, embauches et offres renvoient l'historique trimestriel (2020 ou 2021 à
    aujourd'hui) en données BRUTES : la série nationale des demandeurs A ondule de 7,8 % sur l'année, alors que les
    séries publiées corrigées sont plates. La saisonnalité est donc lisible ; il n'existe pas de série mensuelle ;
  - embauches : modalités TOUT-TOUTE (toutes durées) et TOUT-SUP1M (contrats de plus d'un mois) ;
  - offres : TOFF (toutes offres), PE (déposées à France Travail) et leurs cumuls sur 12 mois."""
import os
import re
import time

from ..utils import dossier_application

JETON_URL = "https://entreprise.francetravail.fr/connexion/oauth2/access_token"
MDT = "https://api.francetravail.io/partenaire/stats-offres-demandes-emploi"
INFO = "https://api.francetravail.io/partenaire/stats-informations-territoire"
SCOPES = "api_stats-offres-demandes-emploiv1 offresetdemandesemploi api_stats-informations-territoirev1 infosterritoire"
NB_METIERS_TENSION = 15


def _nettoyer(v):
    v = v.replace("\ufeff", "").replace("\u200b", "").replace("\xa0", " ").strip().strip('"').strip("'")
    return re.sub(r"\s+", "", v)


def lire_identifiants():
    for chemin in (os.path.join(dossier_application(), "identifiants_francetravail.txt"),
                   "identifiants_francetravail.txt"):
        if os.path.exists(chemin):
            with open(chemin, encoding="utf-8-sig") as f:
                l = [_nettoyer(x) for x in f.read().splitlines() if x.strip()]
            if len(l) >= 2:
                return l[0], l[1]
    return None, None


class ClientFT:
    def __init__(self, client, log):
        self.s, self.log = client.s, log
        self.cid, self.secret = lire_identifiants()
        if not self.cid:
            raise RuntimeError("fichier identifiants_francetravail.txt absent ou incomplet")
        self.jeton, self.expiration, self.dernier = None, 0, 0

    def _jeton(self):
        if self.jeton and time.time() < self.expiration - 60:
            return self.jeton
        r = self.s.post(JETON_URL, params={"realm": "/partenaire"}, timeout=60,
                        data={"grant_type": "client_credentials", "client_id": self.cid,
                              "client_secret": self.secret, "scope": SCOPES})
        if r.status_code != 200:
            raise RuntimeError(f"authentification refusée (HTTP {r.status_code} : {r.text[:150]})")
        js = r.json()
        self.jeton, self.expiration = js["access_token"], time.time() + int(js.get("expires_in", 1400))
        return self.jeton

    def _appel(self, methode, url, **kw):
        for essai in range(3):
            attente = self.dernier + .12 - time.time()  # 10 appels par seconde au plus
            if attente > 0:
                time.sleep(attente)
            h = {"Authorization": f"Bearer {self._jeton()}", "Accept": "application/json"}
            r = self.s.request(methode, url, headers=h, timeout=90, **kw)
            self.dernier = time.time()
            if r.status_code == 200:
                return r.json()
            if r.status_code in (204, 404):
                return None
            if r.status_code == 401:
                self.jeton = None
            elif r.status_code not in (429, 500, 502, 503):
                raise RuntimeError(f"HTTP {r.status_code} : {r.text[:200]}")
            time.sleep(1.5 * (essai + 1))
        return None

    def get(self, base, chemin, params=None):
        return self._appel("GET", base + chemin, params=params)

    def post(self, base, chemin, corps):
        return self._appel("POST", base + chemin, json=corps)


def _valeurs(js):
    return (js or {}).get("listeValeursParPeriode") or []


def _derniere(vals, nomenclature=None):
    v = [x for x in vals if nomenclature is None or x.get("codeNomenclature") == nomenclature]
    v.sort(key=lambda x: str(x.get("codePeriode")))
    return v[-1] if v else None


def _nombre(x):
    return (x or {}).get("valeurPrincipaleNombre")


def _serie(vals, nomenclature):
    """{période: valeur} pour une modalité (ex. « 2024T2 »: 1250)."""
    return {x["codePeriode"]: _nombre(x) for x in vals
            if x.get("codeNomenclature") == nomenclature and x.get("codePeriode") and _nombre(x) is not None}


def code_epci(ft, siren, nom, log):
    """Code de l'EPCI dans le référentiel France Travail : le SIREN si accepté, sinon recherche par le nom."""
    t = ft.get(MDT, "/v1/referentiel/territoire", {"codeTypeTerritoire": "EPCI", "codeTerritoire": siren})
    if t:
        return siren
    liste = ft.get(MDT, "/v1/referentiel/territoires/EPCI") or {}
    liste = liste.get("territoires", liste) if isinstance(liste, dict) else liste
    mots = [m for m in re.split(r"[^a-z]+", (nom or "").lower()) if len(m) > 4]
    for x in liste or []:
        code, lib = str(x.get("codeTerritoire", "")), str(x.get("libelleTerritoire", "")).lower()
        if siren in code or (mots and all(m in lib for m in mots[:3])):
            log(f"      EPCI trouvé dans le référentiel : {x.get('libelleTerritoire')} (code {code})")
            return code
    log("      EPCI introuvable dans le référentiel France Travail : seuls département, région et France seront chargés")
    return None


def indicateurs_territoire(ft, type_t, code_t):
    """Chiffres clés d'un territoire. Chaque indicateur est facultatif."""
    base = {"codeTypeTerritoire": type_t, "codeTerritoire": code_t}
    cumul = {"codeTypeActivite": "CUMUL", "codeActivite": "CUMUL"}
    out = {}
    js = ft.post(MDT, "/v1/indicateur/stat-demandeurs",
                 {**base, **cumul, "codeTypePeriode": "TRIMESTRE", "codeTypeNomenclature": "CATCAND"})
    v = _valeurs(js)
    if v:
        abc, a = _derniere(v, "ABC"), _derniere(v, "A")
        out.update({"de_abc": _nombre(abc), "de_a": _nombre(a), "periode_de": (abc or {}).get("codePeriode")})
        out["serie_abc"] = _serie(v, "ABC")
        out["serie_a"] = _serie(v, "A")
        out["profil"] = [{"type": c.get("codeTypeCaract"), "caracteristique": c.get("libCaract"),
                          "nombre": c.get("nombre"), "pourcentage": c.get("pourcentage")}
                         for c in (abc or {}).get("listeValeurParCaract") or []]
    js = ft.post(MDT, "/v1/indicateur/stat-demandeurs-entrant",
                 {**base, **cumul, "codeTypePeriode": "TRIMESTRE", "codeTypeNomenclature": "CATCAND",
                  "dernierePeriode": True})
    out["entrants_12m"] = _nombre(_derniere(_valeurs(js), "CUMUL 12 MOIS"))
    # Historique complet (pas de « dernierePeriode ») : sert aussi au calcul de la saisonnalité
    js = ft.post(MDT, "/v1/indicateur/stat-offres",
                 {**base, **cumul, "codeTypePeriode": "TRIMESTRE", "codeTypeNomenclature": "ORIGINEOFF"})
    v = _valeurs(js)
    out["offres_12m"] = _nombre(_derniere(v, "TOFF-CUMUL12MOIS"))
    out["offres_ft_12m"] = _nombre(_derniere(v, "PE-CUMUL12MOIS"))
    out["periode_offres"] = (_derniere(v, "TOFF-CUMUL12MOIS") or _derniere(v) or {}).get("codePeriode")
    out["serie_offres"] = _serie(v, "TOFF")
    out["serie_offres_ft"] = _serie(v, "PE")
    js = ft.post(MDT, "/v1/indicateur/stat-embauches",
                 {**base, **cumul, "codeTypePeriode": "TRIMESTRE", "codeTypeNomenclature": "CATCANDxDUREEEMP"})
    v = _valeurs(js)
    e = _derniere(v, "TOUT-TOUTE")
    out.update({"embauches": _nombre(e), "periode_embauches": (e or {}).get("codePeriode")})
    out["serie_embauches"] = _serie(v, "TOUT-TOUTE")
    out["serie_embauches_long"] = _serie(v, "TOUT-SUP1M")
    js = ft.post(MDT, "/v1/indicateur/stat-dynamique-emploi",
                 {**base, "codeTypeActivite": "MOYENNE", "codeActivite": "MOYENNE", "codeTypePeriode": "TRIMESTRE",
                  "dernierePeriode": True})
    d = _derniere(_valeurs(js))
    out.update({"dynamique": _nombre(d), "periode_dynamique": (d or {}).get("codePeriode")})
    for cle, chemin in (("pop_active", "/v1/indicateur/stat-population-active"),
                        ("salaries", "/v1/indicateur/stat-salaries")):
        js = ft.post(INFO, chemin, {**base, **cumul, "codeTypePeriode": "ANNEE", "dernierePeriode": True})
        x = _derniere(_valeurs(js))
        out[cle], out[f"annee_{cle}"] = _nombre(x), (x or {}).get("codePeriode")
    de, act, off = out.get("de_abc"), out.get("pop_active"), out.get("offres_12m")
    out["de_pour_100_actifs"] = de / act * 100 if de and act else None
    out["offres_pour_100_de"] = off / de * 100 if off and de else None
    return out


def tensions(ft, metiers_bmo, bassin, dep, log):
    """Difficultés de recrutement (PERSP_2) pour les métiers qui recrutent le plus dans le bassin (enquête BMO).
    Les métiers BMO sont en FAP ; l'API attend des codes ROME : correspondance par le référentiel ROME/FAP."""
    table = ft.get(MDT, "/v1/referentiel/rechercherActivitesRomeFap") or {}
    rf = table.get("romeFapList") or []
    if not rf:
        log("      correspondance ROME / FAP indisponible : tensions non calculées")
        return [], None
    par_fap = {}
    for x in rf:
        par_fap.setdefault(str(x.get("codeFap", ""))[:5], []).append(x.get("codeRome"))
    territoire = ("BASBMO", bassin) if bassin else ("DEP", dep)
    essai = None
    out = []
    for m in metiers_bmo[:NB_METIERS_TENSION]:
        romes = par_fap.get(str(m.get("code_metier") or "")[:5], [])[:3]
        for rome in romes:
            corps = {"codeTypeTerritoire": territoire[0], "codeTerritoire": territoire[1], "codeTypeActivite": "ROME",
                     "codeActivite": rome, "codeTypePeriode": "ANNEE", "codeTypeNomenclature": "TYPE_TENSION",
                     "dernierePeriode": True}
            js = ft.post(MDT, "/v1/indicateur/stat-perspective-employeur", corps)
            if js is None and essai is None and territoire[0] == "BASBMO":
                log(f"      le bassin {bassin} n'est pas reconnu par l'API : tensions au niveau du département")
                territoire = ("DEP", dep)
                corps.update({"codeTypeTerritoire": "DEP", "codeTerritoire": dep})
                js = ft.post(MDT, "/v1/indicateur/stat-perspective-employeur", corps)
            essai = True
            v = _valeurs(js)
            if not v:
                continue
            ligne = {"metier_bmo": m.get("metier"), "projets_bmo": m.get("projets"), "rome": rome,
                     "metier_rome": v[0].get("libActivite"), "annee": v[0].get("codePeriode")}
            for x in v:
                ligne[x.get("libNomenclature") or x.get("codeNomenclature")] = _nombre(x)
            out.append(ligne)
    if not out and not any(par_fap.get(str(m.get("code_metier") or "")[:5]) for m in metiers_bmo[:5]):
        log("      les codes métier du fichier BMO ne correspondent pas aux codes FAP du référentiel")
    return out, territoire


def collecter(client, siren, nom, dep, reg, bassin_bmo, metiers_bmo, log):
    ft = ClientFT(client, log)
    ft._jeton()
    log("      jeton d'accès obtenu")
    territoires = []
    c = code_epci(ft, siren, nom, log)
    if c:
        territoires.append(("EPCI", c, "EPCI"))
    territoires += [("DEP", dep, "Département"), ("REG", reg, "Région"), ("NAT", "FR", "France")]
    res = {"territoires": {}}
    for type_t, code_t, lib in territoires:
        log(f"      indicateurs : {lib}")
        res["territoires"][lib] = indicateurs_territoire(ft, type_t, code_t)
    if metiers_bmo:
        log("      difficultés de recrutement des métiers qui recrutent le plus (enquête BMO)")
        res["tensions"], t = tensions(ft, metiers_bmo, bassin_bmo, dep, log)
        res["tensions_territoire"] = list(t) if t else None
    return res


def tensions_seules(client, metiers_bmo, bassin, dep, log):
    ft = ClientFT(client, log)
    t, terr = tensions(ft, metiers_bmo, bassin, dep, log)
    return {"tensions": t, "tensions_territoire": list(terr) if terr else None}

"""Bouton « Tester la source » : chaque service est testé séparément, pour
distinguer un problème de réseau (proxy, pare-feu) d'une panne du serveur."""
import time

from . import conso_enaf, reseau, territoire


def _essai(nom, fonction, journal):
    debut = time.time()
    try:
        detail = fonction()
        journal(f"  OK      {nom} ({time.time() - debut:.1f} s){' · ' + detail if detail else ''}")
        return True
    except reseau.ErreurSource as exc:
        journal(f"  ÉCHEC   {nom} : {exc}")
        return False


def tester(url_api=conso_enaf.URL_API, journal=print):
    journal("Test des sources du thème « Consommation d'espaces »...")
    ok_geo = _essai("geo.api.gouv.fr (communes et contours)",
                    lambda: f"{len(reseau.get(territoire.GEO_API + '/communes', params={'codeEpci': territoire.CODE_EPCI, 'fields': 'code'}))} communes",
                    journal)
    trouve = {}

    def recherche():
        trouve.update(conso_enaf.trouver_millesime(url_api, journal=lambda _m: None))
        return f"millésime le plus récent : {trouve['millesime']}"
    ok_api = _essai("API data.gouv.fr (recherche du fichier du Cerema)", recherche, journal)

    def fichier():
        url = trouve.get("url") or conso_enaf.URL_SECOURS
        rep = reseau._session.head(url, allow_redirects=True, timeout=reseau.TIMEOUT)
        reseau._tracer(f"HEAD {url}  →  HTTP {rep.status_code}")
        if rep.status_code >= 400:
            raise reseau.ErreurSource(f"HTTP {rep.status_code} · adresse : {url}", rep.status_code)
        taille = int(rep.headers.get("Content-Length") or 0)
        return f"fichier accessible{f' ({taille / 1048576:.0f} Mo)' if taille else ''}"
    try:
        ok_fic = _essai("Téléchargement du fichier (data.gouv.fr)", fichier, journal)
    except Exception as exc:          # erreur réseau brute sur HEAD
        journal(f"  ÉCHEC   Téléchargement du fichier : {exc.__class__.__name__}")
        ok_fic = False

    if ok_api and ok_fic:
        journal("  → Tout est accessible.")
    elif ok_fic or not ok_api:
        journal("  → Si le téléchargement échoue, solution de repli : télécharger le CSV depuis votre navigateur "
                "(page data.gouv « Consommation d'espaces naturels, agricoles et forestiers ») puis bouton "
                "« Utiliser un fichier CSV local ».")
    if not ok_geo:
        journal("  → Sans geo.api.gouv.fr : pas de liste de communes au premier lancement, ni de carte.")

# -*- coding: utf-8 -*-
"""Classeur Excel : un onglet par analyse des thèmes choisis (lecture, source, tableau, graphique Excel modifiable
quand il existe), listes d'entreprises, base économique recalculable par formules, méthode et journal."""
import re

import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import AreaChart, BarChart, LineChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from .. import catalogue
from ..analyses.eco import E_ACT, E_AGRI, E_AUT, E_CAMP, E_HOT, E_NV, E_PAT, E_PEN, E_POP, E_PRE, E_PROD, E_PUB, E_RS
from ..analyses.textes import METHODE, METHODE_ECO

ROUGE, VERT = "B91E27", "B1B993"
F_TITRE = Font(name="Calibri", size=14, bold=True, color=ROUGE)
F_ENTETE = Font(name="Calibri", bold=True, color="FFFFFF")
F_NORMAL = Font(name="Calibri", size=11)
F_SOURCE = Font(name="Calibri", size=9, italic=True, color="666666")
F_SAISIE = Font(name="Calibri", color="0000FF")
F_GRAS = Font(name="Calibri", bold=True)
FOND_E = PatternFill("solid", fgColor=ROUGE)
FOND_L = PatternFill("solid", fgColor="F4F5EE")
FOND_H = PatternFill("solid", fgColor="FFF2CC")
FIN = Border(bottom=Side(style="thin", color="DDDDDD"))
COULEURS = [ROUGE, VERT, "5B6770", "D98C8F", "7D8A5B", "9DA7B0", "E5B8BA", "3B3B3B"]
MOTS_FRACTION = ("Évolution", "Part", "Taux", "Amplitude", "trim.", "dont entrepreneurs", "Écart")


def _nom_onglet(t, pris):
    n = re.sub(r"[\[\]\*\?/\\:]", "", t)[:28].strip()
    base, i = n, 2
    while n in pris:
        n = f"{base[:25]}_{i}"
        i += 1
    pris.add(n)
    return n


def _format_colonne(nom, serie):
    """Les tableaux de l'ancien outil Emploi stockent les parts en fraction (0,25) : format %."""
    nom = str(nom)
    if "(%)" in nom or nom.endswith("%"):
        return "#,##0.0"
    if any(m in nom for m in MOTS_FRACTION):
        v = pd.to_numeric(serie, errors="coerce").dropna()
        if len(v) and v.abs().max() <= 5:
            return "0.0%"
    return None


def _ecrire_table(ws, df, r0, c0=1):
    df = df.reset_index(drop=True)
    for j, col in enumerate(df.columns):
        c = ws.cell(r0, c0 + j, str(col))
        c.font, c.fill = F_ENTETE, FOND_E
        c.alignment = Alignment(wrap_text=True, vertical="center")
    formats = {j: _format_colonne(col, df.iloc[:, j]) for j, col in enumerate(df.columns)}
    for i, row in enumerate(df.itertuples(index=False), 1):
        for j, v in enumerate(row):
            if isinstance(v, float) and v != v:
                v = None
            elif hasattr(v, "item"):
                v = v.item()
            if isinstance(v, (list, dict, set, tuple)):
                v = str(v)
            c = ws.cell(r0 + i, c0 + j, v)
            c.font, c.border = F_NORMAL, FIN
            if isinstance(v, bool):
                continue
            if formats[j] and isinstance(v, (int, float)):
                c.number_format = formats[j]
            elif isinstance(v, float):
                c.number_format = "#,##0.0" if abs(v) < 1000 else "#,##0"
            elif isinstance(v, int):
                c.number_format = "#,##0"
    for j, col in enumerate(df.columns):
        larg = max([len(str(col))] + [len(str(x)) for x in df.iloc[:, j].head(50)])
        ws.column_dimensions[get_column_letter(c0 + j)].width = min(max(10, larg + 2), 45)
    ws.auto_filter.ref = f"{get_column_letter(c0)}{r0}:{get_column_letter(c0 + max(len(df.columns) - 1, 0))}{r0 + len(df)}"
    return r0 + len(df)


def _graphique_natif(ws, spec, df, r0, ancre):
    """Graphique Excel modifiable (blocs du portrait économique, qui en décrivent un)."""
    if not spec or df is None or len(df) == 0 or spec.get("cats") not in list(df.columns):
        return
    n = min(len(df), spec.get("max_rows", len(df)))
    cols = list(df.columns)
    ic = cols.index(spec["cats"]) + 1
    t = spec["type"]
    if t in ("bar", "barh", "stack100"):
        ch = BarChart()
        ch.type = "bar" if t in ("barh", "stack100") else "col"
        if t == "stack100":
            ch.grouping, ch.overlap = "percentStacked", 100
    elif t == "line":
        ch = LineChart()
    elif t == "area":
        ch = AreaChart()
        ch.grouping = "stacked"
    else:
        return
    for s in spec["series"]:
        if s in cols:
            j = cols.index(s) + 1
            ch.add_data(Reference(ws, min_col=j, min_row=r0, max_row=r0 + n), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=ic, min_row=r0 + 1, max_row=r0 + n))
    for k, s in enumerate(ch.series):
        coul = COULEURS[k % len(COULEURS)]
        if t == "line":
            s.graphicalProperties.line.solidFill = coul
            s.graphicalProperties.line.width = 28000 if k == 0 else 18000
            s.smooth = False
        else:
            s.graphicalProperties.solidFill = coul
            s.graphicalProperties.line.solidFill = coul
    ch.height, ch.width = 9, 17
    ch.legend.position = "b"
    if len(spec["series"]) == 1:
        ch.legend = None
    ws.add_chart(ch, ancre)


def _onglet_bloc(wb, b, pris):
    ws = wb.create_sheet(_nom_onglet(b["titre"], pris))
    ws["A1"], ws["A1"].font = b["titre"], F_TITRE
    ws["A2"] = b.get("lecture") or ""
    ws["A2"].alignment = Alignment(wrap_text=True, vertical="top")
    ws.merge_cells("A2:J2")
    ws.row_dimensions[2].height = max(30, 15 * (len(ws["A2"].value) // 140 + 1))
    ws["A3"], ws["A3"].font = f"Source : {b.get('source', '')}", F_SOURCE
    r = 5
    t = b.get("table")
    if t is not None and len(t):
        fin = _ecrire_table(ws, t, r)
        if b.get("excel"):
            _graphique_natif(ws, b["excel"], t, r, f"{get_column_letter(len(t.columns) + 2)}5")
        r = fin + 3
    t2 = b.get("table2")
    if t2 is not None and len(t2):
        ws.cell(r - 1, 1, "Détail complémentaire").font = F_GRAS
        _ecrire_table(ws, t2, r)
    ws.freeze_panes = "A6"


def _onglet_liste(wb, titre, lignes, colonnes, pris, note=""):
    ws = wb.create_sheet(_nom_onglet(titre, pris))
    ws["A1"], ws["A1"].font = titre, F_TITRE
    ws["A2"], ws["A2"].font = note, F_SOURCE
    df = pd.DataFrame(lignes)
    cols = [c for c in colonnes if c in df.columns]
    df = df[cols].rename(columns=colonnes)
    _ecrire_table(ws, df, 4)
    ws.freeze_panes = "B5"


def _onglet_base_eco(wb, be, pris):
    """Base économique recalculable : hypothèses modifiables (cellules bleues), formules (repris du portrait)."""
    ws = wb.create_sheet(_nom_onglet("Base_eco", pris))
    ws["A1"], ws["A1"].font = "Base économique estimée (approche Davezies)", F_TITRE
    ws["A2"] = ("Ordre de grandeur. Cellules en BLEU sur fond jaune = hypothèses modifiables ; tous les calculs "
                "se mettent à jour. Données d'entrée issues de l'Insee et de l'Urssaf.")
    ws["A2"].font = F_SOURCE
    avert = []
    if be.get("replis"):
        avert.append("décomposition du revenu non publiée par l'Insee pour l'EPCI : parts de revenus "
                     f"{be.get('lib_repli', 'du département')}"
                     + (" (part des pensions corrigée par l'IRCOM)" if be.get("ircom") else ""))
    avert += be.get("defauts", [])
    if avert:
        ws["A3"] = "ATTENTION : " + " ; ".join(avert) + ". Origine de chaque donnée : colonne G."
        ws["A3"].font = Font(name="Calibri", bold=True, color=ROUGE)
    for col, w in zip("ABCDEFG", (62, 4, 14, 14, 14, 16, 95)):
        ws.column_dimensions[col].width = w
    r = 4
    ws.cell(r, 1, "Données d'entrée").font = F_GRAS
    ws.cell(r, 3, "Valeur").font = F_GRAS
    ws.cell(r, 7, "Source et millésime").font = F_GRAS
    ent = {}
    for k, v in be["entrees"].items():
        r += 1
        ws.cell(r, 1, k)
        c = ws.cell(r, 3, None if v != v else float(v))
        c.number_format = "#,##0.0" if (v == v and abs(v) < 1000) else "#,##0"
        src = be.get("sources", {}).get(k, "")
        cs = ws.cell(r, 7, src)
        cs.font = Font(name="Calibri", bold=True, color=ROUGE) if "DÉFAUT" in src else F_SOURCE
        ent[k] = f"$C${r}"
    r += 2
    ws.cell(r, 1, "Hypothèses").font = F_GRAS
    for j, t in enumerate(("Bas", "Central", "Haut", "Unité", "Commentaire")):
        ws.cell(r, 3 + j, t).font = F_GRAS
    hyp = {}
    for k, v in be["hypotheses"].items():
        r += 1
        ws.cell(r, 1, k)
        for j, sc in enumerate(("bas", "central", "haut")):
            c = ws.cell(r, 3 + j, float(v[sc]))
            c.font, c.fill = F_SAISIE, FOND_H
            c.number_format = "0.00" if v[sc] < 10 else "#,##0"
        ws.cell(r, 6, v["unite"])
        ws.cell(r, 7, v["commentaire"]).alignment = Alignment(wrap_text=True)
        hyp[k] = r
    r += 2
    ws.cell(r, 1, "Calcul (millions d'euros par an)").font = F_GRAS
    for j, t in enumerate(("Bas", "Central", "Haut")):
        ws.cell(r, 3 + j, t).font = F_GRAS
    E = ent
    lignes = [
        ("Revenu disponible total des ménages", lambda h: f"={E[E_POP]}*"
         f"{E[E_NV]}*{h('coef_moyenne_mediane')}/{h('personnes_par_uc')}/1000000"),
        ("  dont revenus d'activité", lambda h: f"=RD*{E[E_ACT]}/100"),
        ("  … gagnés hors du territoire (navetteurs)", lambda h: f"=ACT*{h('part_actifs_hors_epci')}"),
        ("  … gagnés sur le territoire", lambda h: "=ACT-HORS"),
        ("Productive : revenus d'activité liés aux activités exportatrices",
         lambda h: f"=(LOC-PUB)*({E[E_AGRI]}+(100-{E[E_AGRI]}-{E[E_PUB]})*{E[E_PROD]}/100)/(100-{E[E_PUB]})"),
        ("Publique : revenus des emplois publics locaux", lambda h: f"=LOC*{E[E_PUB]}/100"),
        ("Résidentielle : salaires gagnés hors du territoire", lambda h: "=HORS"),
        ("Résidentielle : pensions et retraites", lambda h: f"=RD*{E[E_PEN]}/100"),
        ("Résidentielle : revenus du patrimoine", lambda h: f"=RD*{E[E_PAT]}/100"),
        ("Résidentielle : dépenses des résidents secondaires",
         lambda h: f"={E[E_RS]}*{h('nuits_occupees_par_rs')}*{h('personnes_par_sejour_rs')}*{h('depense_jour_rs')}/1000000"),
        ("Résidentielle : dépenses touristiques (hébergement marchand)",
         lambda h: f"=({E[E_HOT]}*{h('lits_par_place_hotel')}+{E[E_CAMP]}*{h('lits_par_place_camping')}"
                   f"+{E[E_AUT]})*{h('nuitees_par_lit_marchand')}*{h('depense_par_nuitee_marchande')}/1000000"),
        ("Sociale : prestations sociales", lambda h: f"=RD*{E[E_PRE]}/100"),
    ]
    debut = r + 1
    alias = {"Revenu disponible total des ménages": "RD", "  dont revenus d'activité": "ACT",
             "  … gagnés hors du territoire (navetteurs)": "HORS", "  … gagnés sur le territoire": "LOC",
             "Publique : revenus des emplois publics locaux": "PUB"}
    noms = {alias.get(l, l): debut + i for i, (l, _) in enumerate(lignes)}
    for i, (lib, fn) in enumerate(lignes):
        rr = debut + i
        ws.cell(rr, 1, lib).font = F_GRAS if not lib.startswith(" ") else F_NORMAL
        for j, col in enumerate("CDE"):
            f = fn(lambda k, col=col: f"{col}${hyp[k]}")
            for al in ("HORS", "LOC", "ACT", "PUB", "RD"):
                f = re.sub(rf"\b{al}\b", f"{col}{noms[al]}", f)
            ws.cell(rr, 3 + j, f).number_format = "#,##0.0"
    fin = debut + len(lignes) - 1
    comp = list(range(debut + 4, fin + 1))
    r = fin + 2
    ws.cell(r, 1, "TOTAL des revenus basiques").font = F_GRAS
    for j, col in enumerate("CDE"):
        c = ws.cell(r, 3 + j, f"=SUM({col}{comp[0]}:{col}{comp[-1]})")
        c.font, c.number_format = F_GRAS, "#,##0.0"
    tot = r
    r += 2
    ws.cell(r, 1, "Répartition (scénario central)").font = F_GRAS
    ws.cell(r, 3, "M€").font = F_GRAS
    ws.cell(r, 4, "Part").font = F_GRAS
    r_rep = r + 1
    for i, (lib, pref) in enumerate([("Base productive", "Productive"), ("Base publique", "Publique"),
                                     ("Base résidentielle", "Résidentielle"), ("Base sociale", "Sociale")]):
        rr = r + 1 + i
        ws.cell(rr, 1, lib)
        lg = [debut + k for k, (l, _) in enumerate(lignes) if l.startswith(pref)]
        ws.cell(rr, 3, "=" + "+".join(f"D{x}" for x in lg)).number_format = "#,##0.0"
        ws.cell(rr, 4, f"=C{rr}/D${tot}").number_format = "0.0%"
    ch = BarChart()
    ch.type = "bar"
    ch.add_data(Reference(ws, min_col=3, min_row=r_rep, max_row=r_rep + 3), titles_from_data=False)
    ch.set_categories(Reference(ws, min_col=1, min_row=r_rep, max_row=r_rep + 3))
    ch.series[0].graphicalProperties.solidFill = ROUGE
    ch.legend = None
    ch.title = "Base économique (scénario central, M€/an)"
    ch.height, ch.width = 7, 16
    ws.add_chart(ch, f"A{r_rep + 6}")


COLS_EMPLOYEURS = {"nom": "Établissement", "siret": "SIRET", "activite": "Activité", "secteur": "Secteur (NA38)",
                   "grand_secteur": "Grand secteur", "tranche_lib": "Tranche d'effectif", "eff_min": "Effectif min",
                   "eff_max": "Effectif max", "annee_effectif": "Année de l'effectif", "siege": "Siège",
                   "categorie": "Catégorie d'entreprise", "creation": "Création", "adresse": "Adresse",
                   "code_commune": "Code commune", "commune": "Commune", "lat": "Latitude", "lon": "Longitude"}
COLS_LBB = {"nom": "Entreprise", "siret": "SIRET", "metier": "Métier recherché", "rome": "Code ROME",
            "activite": "Activité", "naf": "NAF", "effectif": "Effectif", "commune": "Commune",
            "code_commune": "Code commune", "potentiel": "Potentiel d'embauche (0-100)",
            "fort_potentiel": "Fort potentiel", "lat": "Latitude", "lon": "Longitude",
            "position_approx": "Position approximative"}


def produire(res, chemin, themes=None, listes=True, etat_sources=None):
    """Écrit le classeur. themes : thèmes à inclure (tous les thèmes analysés par défaut)."""
    themes = themes or res["themes"]
    wb = Workbook()
    pris = set()
    ws = wb.active
    ws.title = _nom_onglet("Lisez-moi", pris)
    ws["A1"], ws["A1"].font = f"Économie et emploi · {res['nom_long']}", F_TITRE
    p = res["params"]
    infos = [("Extraction", res["date"]), ("EPCI", f"{res['nom_long']} (SIREN {res['siren']})"),
             ("Période (emploi salarié privé)", f"{p.get('a1')}-{p.get('a2')}" if p.get("a1") else "n.d."),
             ("Niveau de secteurs", p.get("niveau")), ("Groupes d'EPCI", ", ".join(res.get("groupes") or []) or "aucun"),
             ("Thèmes", " ; ".join(catalogue.THEMES[t][1] for t in themes))]
    for i, (k, v) in enumerate(infos, 3):
        ws.cell(i, 1, k).font = F_GRAS
        ws.cell(i, 2, v)
    ws.column_dimensions["A"].width, ws.column_dimensions["B"].width = 34, 120
    r = len(infos) + 5
    if etat_sources:
        ws.cell(r, 1, "Sources interrogées").font = F_GRAS
        df = pd.DataFrame([{"Source": e["libelle"], "Fournisseur": e["api"], "État": e["statut"], "Appels": e["appels"],
                            "Message": e["message"]} for e in etat_sources])
        _ecrire_table(ws, df, r + 1)
        ws.auto_filter.ref = None

    ws = wb.create_sheet(_nom_onglet("Chiffres clés", pris))
    ws["A1"], ws["A1"].font = "Chiffres clés et synthèse", F_TITRE
    if res["cles"]:
        _ecrire_table(ws, pd.DataFrame([{"Indicateur": c["libelle"], "Valeur": c["valeur"], "Affichage": c["texte"],
                                         "Précision": c["sous"]} for c in res["cles"]]), 3)
    r = len(res["cles"]) + 6
    ws.cell(r, 1, "Synthèse").font = F_GRAS
    for i, s in enumerate(res["synthese"], r + 1):
        c = ws.cell(i, 1, "• " + s)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=i, start_column=1, end_row=i, end_column=6)
        ws.row_dimensions[i].height = 15 * (len(s) // 150 + 1)
    ws.column_dimensions["A"].width = 45
    ws.column_dimensions["D"].width = 60

    for b in res["blocs"]:
        if b["theme"] in themes:
            _onglet_bloc(wb, b, pris)
    if listes and "employeurs" in themes and res.get("employeurs"):
        _onglet_liste(wb, "Liste des employeurs", res["employeurs"], COLS_EMPLOYEURS, pris,
                      "Insee, SIRENE : établissements employeurs actifs. Usage interne.")
    if listes and "lbb" in themes and res.get("lbb"):
        _onglet_liste(wb, "Susceptibles d'embaucher", res["lbb"], COLS_LBB, pris,
                      "France Travail, La Bonne Boite (licence ouverte) : prévision d'embauche, pas des offres d'emploi.")
    if res.get("base_eco") and "base_eco" in themes:
        _onglet_base_eco(wb, res["base_eco"], pris)

    ws = wb.create_sheet(_nom_onglet("Méthode", pris))
    ws["A1"], ws["A1"].font = "Méthode et sources", F_TITRE
    ws.column_dimensions["A"].width, ws.column_dimensions["B"].width = 40, 120
    for i, (k, v) in enumerate(METHODE_ECO + METHODE, 3):
        ws.cell(i, 1, k).font = F_GRAS
        c = ws.cell(i, 2, v)
        c.alignment = Alignment(wrap_text=True, vertical="top")
    if res.get("journal_collecte"):
        ws = wb.create_sheet(_nom_onglet("Journal", pris))
        _ecrire_table(ws, pd.DataFrame(res["journal_collecte"]), 1)
    wb.save(chemin)
    return chemin

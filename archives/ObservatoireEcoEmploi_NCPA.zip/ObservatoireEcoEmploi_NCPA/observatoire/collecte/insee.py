"""INSEE — base du dossier complet (≈ 700 indicateurs, toutes géographies, RP 2012/2017/2023,
Filosofi, Flores, tourisme…). Un seul fichier Parquet de ~300 Mo, téléchargé une fois puis
filtré localement avec DuckDB (aucune saisie de clé d'API nécessaire).

Documentation : https://www.insee.fr/fr/statistiques/5359146
"""
import re
import warnings

import duckdb
import pandas as pd

from ..config import CALCULES
from ..utils import CACHE, MANUELS, SORTIES, age_jours, enregistrer_sur, log, nom_extrait_insee, norm, telecharger

ETAPE = "INSEE dossier complet"
warnings.filterwarnings("ignore", message="This pattern is interpreted as a regular expression")
URL_PARQUET = "https://www.insee.fr/fr/statistiques/fichier/5359146/dossier_complet.parquet"
# Indicateurs facultatifs : leur absence est signalée sans alerte (l'outil a une solution de repli)
OPTIONNELS = {"pers_menfisc"}
COLS = ["GEO_OBJECT", "GEO", "GEO_LABEL", "TIME_PERIOD", "ID_TAB", "ID_TAB_LABEL",
        "TAB_MEASURE", "TAB_MEASURE_LABEL", "OBS_VALUE", "UNIT_MULT", "UNIT_MEASURE"]


def _source_parquet(cfg, session, forcer, hors_ligne):
    """Chemin de la base complète (cache ou donnees_manuelles), téléchargée si besoin.
    Renvoie None si elle est introuvable : l'extrait régional peut alors suffire."""
    f = CACHE / "dossier_complet.parquet"
    age = age_jours(f)
    if not hors_ligne and (forcer or age is None or age > cfg["duree_cache"]):
        try:
            log(ETAPE, "téléchargement de la base (≈ 300 Mo, quelques minutes)…")
            telecharger(URL_PARQUET, f, session, ETAPE, timeout=600)
        except Exception as e:
            log(ETAPE, f"échec du téléchargement : {e}", "erreur")
    if f.exists():
        return f
    m = MANUELS / "dossier_complet.parquet"
    if m.exists():
        log(ETAPE, "base lue dans donnees_manuelles/dossier_complet.parquet", "alerte")
        return m
    return None


def charger_insee(cfg, session, forcer=False, hors_ligne=False):
    """Extrait les lignes utiles (communes de la région, tous les EPCI, départements,
    régions, France) et les met en cache. Renvoie un DataFrame long.
    L'extrait suffit pour travailler : la base complète de 300 Mo peut être supprimée
    du cache, le mode hors ligne fonctionnera quand même."""
    extrait = CACHE / nom_extrait_insee(cfg)
    ancien = CACHE / f"insee_extrait_{cfg['region']}.parquet"   # nom utilisé jusqu'à la v1.3
    if not extrait.exists() and ancien.exists() and cfg["deps_region"] == ["14", "27", "50", "61", "76"]:
        ancien.rename(extrait)
    src = _source_parquet(cfg, session, forcer, hors_ligne)
    if extrait.exists() and not (forcer and src is not None) and (
            src is None or extrait.stat().st_mtime >= src.stat().st_mtime):
        df = pd.read_parquet(extrait)
        if src is None:
            log(ETAPE, f"base complète absente du cache : extrait régional utilisé ({len(df)} lignes)", "ok")
        else:
            log(ETAPE, f"extrait en cache : {len(df)} lignes", "ok")
        return df
    if src is None:
        raise RuntimeError("Base du dossier complet indisponible. Télécharger dossier_complet.parquet "
                           "depuis https://www.insee.fr/fr/statistiques/5359146 et le déposer dans donnees_manuelles/")

    con = duckdb.connect()
    cols_dispo = [r[0] for r in con.execute(f"DESCRIBE SELECT * FROM read_parquet('{src.as_posix()}')").fetchall()]
    manquantes = [c for c in COLS if c not in cols_dispo]
    if manquantes:
        log(ETAPE, f"colonnes absentes de la base : {manquantes} (structure INSEE modifiée ?)", "alerte")
    sel = ", ".join(c if c in cols_dispo else f"NULL AS {c}" for c in COLS)
    deps = ",".join(f"'{d}'" for d in cfg["deps_region"])
    q = f"""
        SELECT {sel} FROM read_parquet('{src.as_posix()}')
        WHERE (GEO_OBJECT = 'COM' AND substr(GEO, 1, 2) IN ({deps}))
           OR GEO_OBJECT IN ('EPCI', 'DEP', 'REG')
           OR upper(GEO_OBJECT) LIKE 'FR%' OR upper(GEO_OBJECT) LIKE 'PAYS%'
    """
    df = con.execute(q).df()
    con.close()
    df["TIME_PERIOD"] = df["TIME_PERIOD"].astype(str).str[:4]
    df["OBS_VALUE"] = pd.to_numeric(df["OBS_VALUE"], errors="coerce")
    mult = pd.to_numeric(df["UNIT_MULT"], errors="coerce").fillna(0)
    df.loc[mult != 0, "OBS_VALUE"] = df.loc[mult != 0, "OBS_VALUE"] * (10.0 ** mult[mult != 0])
    df.to_parquet(extrait, index=False)
    log(ETAPE, f"extrait créé : {len(df)} lignes, niveaux {', '.join(sorted(df.GEO_OBJECT.dropna().unique()))}", "ok")
    return df


def niveau(geo_object):
    g = str(geo_object).upper()
    if g in ("COM", "EPCI", "DEP", "REG"):
        return g
    return "FR"


def _est_pct(row):
    u = norm(row.get("UNIT_MEASURE", ""))
    lab = norm(row.get("TAB_MEASURE_LABEL", ""))
    return ("pct" in u or "pour" in u or "%" in lab or "part" in lab.split(" ")[:1]
            or lab.startswith("taux"))


def _diagnostic(combos, m_tab, motif_tab):
    """Explique un échec : tableau absent (et tableaux voisins) ou mesures disponibles."""
    tabs = combos[m_tab]
    if tabs.empty:
        pref = re.sub(r"[^A-Za-z].*", "", motif_tab.lstrip("^"))[:3].upper()
        voisins = sorted(combos[combos.ID_TAB.astype(str).str.upper().str.startswith(pref)].ID_TAB.astype(str).unique()) if pref else []
        return (f"tableau « {motif_tab} » absent de la base"
                + (f" ; tableaux {pref}… existants : {', '.join(voisins[:12])}" if voisins else ""))
    mes = tabs.drop_duplicates("TAB_MEASURE_LABEL")
    liste = " | ".join(f"{r.ID_TAB}: {r.TAB_MEASURE_LABEL}" for r in mes.head(8).itertuples())
    return f"mesures disponibles dans ce tableau : {liste}" + (" | …" if len(mes) > 8 else "")


def extraire_indicateurs(df, specs, code_epci):
    """Applique les motifs de config.xlsx (onglet Indicateurs).
    Renvoie (tidy, rapport) : tidy = code, niveau, geo, libgeo, annee, valeur."""
    combos = (df[["ID_TAB", "ID_TAB_LABEL", "TAB_MEASURE", "TAB_MEASURE_LABEL", "UNIT_MEASURE"]]
              .drop_duplicates().reset_index(drop=True))
    combos["_tab"] = combos["ID_TAB"].astype(str) + " | " + combos["ID_TAB_LABEL"].map(norm)
    combos["_mes"] = combos["TAB_MEASURE_LABEL"].map(norm)
    # Les libellés INSEE sont du type « Mesure – Modalité » (ex. « Logements – Résidences
    # secondaires… ») : un motif est testé sur le libellé complet ET sur chacun de ses segments,
    # pour que « ^ensemble » trouve « Population – Ensemble ».
    combos["_segs"] = combos["_mes"].map(lambda t: [t] + [x.strip() for x in re.split(r"\s[–-]\s", t)])
    cible = df[(df.GEO_OBJECT == "EPCI") & (df.GEO == code_epci)]
    couverture = cible.groupby(["ID_TAB", "TAB_MEASURE"]).size()

    morceaux, rapport = [], []
    for s in specs:
        code = s["code"]
        code_insee = str(s.get("code_insee", "") or "").strip()
        try:
            m_tab = combos["_tab"].str.contains(s["tableau"], flags=re.I, regex=True) | \
                combos["ID_TAB"].astype(str).str.contains(s["tableau"], flags=re.I, regex=True)
        except re.error as e:
            log(ETAPE, f"[{code}] motif de tableau invalide : {e}", "erreur")
            rapport.append({"code": code, "statut": "motif invalide", "tableau": "", "mesure": ""})
            continue
        cand = pd.DataFrame()
        methode = "code"
        if code_insee:  # 1. repérage par code exact (robuste aux changements de libellé)
            cand = combos[(combos.TAB_MEASURE.astype(str) == code_insee) & m_tab].copy()
            if cand.empty:
                cand = combos[combos.TAB_MEASURE.astype(str) == code_insee].copy()
                if len(cand):
                    log(ETAPE, f"[{code}] code {code_insee} trouvé hors du tableau « {s['tableau']} » "
                               f"(dans {', '.join(cand.ID_TAB.astype(str).unique())})", "alerte")
            if cand.empty:
                log(ETAPE, f"[{code}] code INSEE {code_insee} absent de la base — repli sur le libellé", "alerte")
        if cand.empty and str(s.get("mesure", "")).strip():  # 2. repli : motif sur le libellé
            methode = "libellé"
            try:
                motif = re.compile(norm(s["mesure"]))
                m_mes = combos["_segs"].map(lambda segs: any(motif.search(x) for x in segs))
                if s.get("exclure"):
                    m_mes &= ~combos["_mes"].str.contains(norm(s["exclure"]), regex=True)
            except re.error as e:
                log(ETAPE, f"[{code}] motif invalide : {e}", "erreur")
                rapport.append({"code": code, "statut": "motif invalide", "tableau": "", "mesure": ""})
                continue
            cand = combos[m_tab & m_mes].copy()
        if cand.empty:
            diag = _diagnostic(combos, m_tab, s["tableau"])
            log(ETAPE, f"[{code}] aucun libellé ne correspond — {diag}",
                "info" if code in OPTIONNELS else "alerte")
            rapport.append({"code": code, "statut": "non trouvé", "tableau": "", "mesure": "", "diagnostic": diag})
            continue
        veut_pct = str(s.get("unite", "")).lower().startswith("p")
        cand["_pct"] = cand.apply(_est_pct, axis=1)
        cand["_unit_ok"] = cand["_pct"] == veut_pct
        cand["_couv"] = [couverture.get((a, b), 0) for a, b in zip(cand.ID_TAB, cand.TAB_MEASURE)]
        cand["_len"] = cand["_mes"].str.len()
        cand = cand.sort_values(["_unit_ok", "_couv", "_len"], ascending=[False, False, True])
        choix = cand.iloc[0]
        if len(cand) > 1:
            autres = "; ".join(f"{r.ID_TAB}/{r.TAB_MEASURE_LABEL}" for r in cand.iloc[1:4].itertuples())
            log(ETAPE, f"[{code}] {len(cand)} correspondances, retenu « {choix.TAB_MEASURE_LABEL} » "
                       f"({choix.ID_TAB}) ; autres : {autres}", "info")
        sous = df[(df.ID_TAB == choix.ID_TAB) & (df.TAB_MEASURE == choix.TAB_MEASURE)]
        t = pd.DataFrame({"code": code, "niveau": sous.GEO_OBJECT.map(niveau), "geo": sous.GEO.astype(str),
                          "libgeo": sous.GEO_LABEL, "annee": sous.TIME_PERIOD.astype(str),
                          "valeur": sous.OBS_VALUE})
        t = t.dropna(subset=["valeur"]).drop_duplicates(["code", "niveau", "geo", "annee"])
        morceaux.append(t)
        annees = sorted(t[(t.niveau == "EPCI") & (t.geo == code_epci)].annee.unique())
        statut = "ok" if annees else "absent pour l'EPCI"
        if not annees:
            libs = {"COM": "des communes", "EPCI": "d'autres EPCI", "DEP": "les départements",
                    "REG": "les régions", "FR": "la France"}
            niv = [libs.get(n, n) for n in ("COM", "EPCI", "DEP", "REG", "FR") if n in set(t.niveau)]
            log(ETAPE, f"[{code}] trouvé ({choix.ID_TAB}) mais non publié pour l'EPCI étudié (secret statistique "
                       f"probable) ; publié pour {', '.join(niv) or 'aucun territoire'}",
                "info" if code in OPTIONNELS else "alerte")
        rapport.append({"code": code, "statut": statut, "methode": methode, "tableau": choix.ID_TAB,
                        "code_insee": choix.TAB_MEASURE, "mesure": choix.TAB_MEASURE_LABEL,
                        "annees": ", ".join(annees)})
    tidy = pd.concat(morceaux, ignore_index=True) if morceaux else pd.DataFrame(
        columns=["code", "niveau", "geo", "libgeo", "annee", "valeur"])
    ok = sum(r["statut"] == "ok" for r in rapport)
    oblig = [r for r in rapport if r["code"] not in OPTIONNELS]
    log(ETAPE, f"{ok}/{len(specs)} indicateurs trouvés",
        "ok" if all(r["statut"] == "ok" for r in oblig) else "alerte")
    tidy, calc = ajouter_calcules(tidy, code_epci)
    return tidy, pd.DataFrame(rapport + calc)


def ajouter_calcules(tidy, code_epci):
    """Indicateurs dérivés (ratio de deux indicateurs extraits), pour chaque territoire et
    chaque année où les deux termes existent : concentration d'emploi, chômage, sphères."""
    cles = ["niveau", "geo", "annee"]
    ajouts, rapport = [], []
    for code, (lib, num, den, mult) in CALCULES.items():
        a = tidy[tidy.code == num].set_index(cles)["valeur"]
        b = tidy[tidy.code == den].set_index(cles)["valeur"]
        if a.empty or b.empty:
            manque = num if a.empty else den
            log(ETAPE, f"[{code}] non calculé : indicateur « {manque} » manquant", "alerte")
            rapport.append({"code": code, "statut": "non calculé", "methode": "calcul",
                            "mesure": lib, "diagnostic": f"{manque} manquant"})
            continue
        r = (a / b.where(b > 0) * mult).dropna()
        libgeo = tidy.drop_duplicates(cles).set_index(cles)["libgeo"]
        t = r.rename("valeur").reset_index()
        t["code"] = code
        t["libgeo"] = [libgeo.get(k) for k in zip(t.niveau, t.geo, t.annee)]
        ajouts.append(t[["code", "niveau", "geo", "libgeo", "annee", "valeur"]])
        annees = sorted(t[(t.niveau == "EPCI") & (t.geo == code_epci)].annee.unique())
        rapport.append({"code": code, "statut": "ok" if annees else "absent pour l'EPCI", "methode": "calcul",
                        "tableau": "", "code_insee": f"{num} ÷ {den} × {mult}", "mesure": lib,
                        "annees": ", ".join(annees)})
    if ajouts:
        tidy = pd.concat([tidy] + ajouts, ignore_index=True)
    log(ETAPE, f"{sum(r['statut'] == 'ok' for r in rapport)}/{len(CALCULES)} indicateurs calculés", "ok")
    return tidy, rapport


def exporter_catalogue(df, code_epci, nom):
    """Tous les indicateurs disponibles pour l'EPCI, années en colonnes : pour repérer
    de nouveaux indicateurs et ajuster les motifs de config.xlsx."""
    sous = df[(df.GEO_OBJECT == "EPCI") & (df.GEO == code_epci)]
    if sous.empty:
        log(ETAPE, "catalogue non produit : EPCI cible absent de la base", "alerte")
        return None
    cles = ["ID_TAB", "ID_TAB_LABEL", "TAB_MEASURE", "TAB_MEASURE_LABEL", "UNIT_MEASURE", "TIME_PERIOD"]
    sous = sous.assign(**{c: sous[c].fillna("") for c in cles})
    pv = (sous.groupby(cles, sort=True)["OBS_VALUE"].first().unstack("TIME_PERIOD").reset_index())
    pv.columns = [str(c) for c in pv.columns]
    def ecrire(f):
        with pd.ExcelWriter(f, engine="openpyxl") as w:
            pv.to_excel(w, sheet_name="Catalogue", index=False)
            ws = w.sheets["Catalogue"]
            for col, larg in zip("ABCDE", (12, 60, 30, 60, 12)):
                ws.column_dimensions[col].width = larg
            ws.auto_filter.ref = ws.dimensions
            ws.freeze_panes = "E2"
    f = enregistrer_sur(SORTIES / f"catalogue_INSEE_{nom}.xlsx", ecrire, ETAPE)
    log(ETAPE, f"catalogue des {len(pv)} mesures disponibles : {f.name}", "ok")
    return f

"""Carte HTML autonome des permis (Leaflet), même charte que la carte de
consommation d'espaces : fonds Plan IGN ou photographies aériennes IGN,
bibliothèques embarquées, tableau lié à la carte, filtres par type, année
et état d'avancement, statistiques qui suivent les filtres."""
import json

from . import permis as P
from .export_geo import _lire
from .fonds_carte import FONDS_CSS, FONDS_JS
from .export_permis import entites

COULEURS = {"logements": "#B91E27", "amenager": "#5E7A2E", "demolir": "#3F4448"}


def exporter_carte(chemin, resultat, communes, contours, params):
    feats = entites(resultat, communes)
    if not feats:
        raise ValueError("aucun permis localisé : relancez l'extraction avec la localisation cadastrale cochée")
    codes = {p["commune"] for p in resultat["permis"]}
    limites = {"type": "FeatureCollection",
               "features": [f for f in (contours or {}).get("features", [])
                            if str(f.get("properties", {}).get("code")) in codes]}
    donnees = {"points": {"type": "FeatureCollection", "features": feats}, "limites": limites,
               "types": [(t, P.LIB_TYPE[t], COULEURS[t]) for t in resultat["types"]],
               "annees": resultat["annees"], "non_localises": len(resultat["permis"]) - len(feats)}
    html = (GABARIT
            .replace("/*LEAFLET_CSS*/", _lire("donnees/leaflet.css"))
            .replace("/*FONDS_CSS*/", FONDS_CSS)
            .replace("/*LEAFLET_JS*/", _lire("donnees/leaflet.js"))
            .replace("/*FONDS_JS*/", FONDS_JS)
            .replace("__TITRE__", params.get("titre", "NCPA"))
            .replace("__DATE__", params.get("date", ""))
            .replace("__DONNEES__", json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")))
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(html)
    return len(feats)


GABARIT = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Permis · __TITRE__</title>
<style>/*LEAFLET_CSS*/</style>
<style>/*FONDS_CSS*/</style>
<style>
:root{--rouge:#B91E27;--vert:#B1B993;--encre:#1F2A2E;--doux:#5E6A6E;--brume:#F3F4EF;--trait:#DCDDD3;
      font-family:Calibri,"Segoe UI",system-ui,sans-serif;color:var(--encre)}
*{box-sizing:border-box}
html,body{margin:0;height:100%}
body{display:flex;flex-direction:column;height:100vh;background:#fff}
header{border-left:6px solid var(--rouge);border-bottom:1px solid var(--trait);padding:10px 18px 10px 16px}
.eyebrow{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:var(--rouge);font-weight:700}
h1{font-size:21px;margin:2px 0 0;font-weight:700}
.sous{font-size:13px;color:var(--doux)}
#corps{flex:1 1 auto;display:flex;min-height:0}
#panneau{width:300px;flex:0 0 300px;border-right:1px solid var(--trait);padding:14px;overflow-y:auto;background:var(--brume)}
#droite{flex:1 1 auto;display:flex;flex-direction:column;min-width:0}
#map{position:relative;flex:1 1 auto;height:0}
label.titre{display:block;font-weight:700;font-size:13px;margin:12px 0 4px}
select,input[type=search]{padding:6px;border:1px solid var(--trait);border-radius:4px;font:inherit;background:#fff}
.types label{display:flex;align-items:center;gap:8px;margin:4px 0;font-size:14px}
.pastille{width:14px;height:14px;border-radius:50%;display:inline-block;border:1px solid #fff;box-shadow:0 0 0 1px #888}
.annees{display:flex;gap:6px;align-items:center}
.annees select{flex:1}
.fonds label{margin-right:12px;font-size:14px}
.stats{margin-top:14px;padding:10px;background:#fff;border:1px solid var(--trait);border-radius:4px;font-size:13px;line-height:1.55}
.stats b{font-size:15px}
.note{font-size:12px;color:var(--doux);margin-top:12px;line-height:1.4}
button{font:inherit;padding:6px 10px;border:1px solid var(--rouge);background:#fff;color:var(--rouge);border-radius:4px;cursor:pointer;margin-top:12px}
button:hover,button:focus-visible{background:var(--rouge);color:#fff;outline:none}
#zoneTable{display:none;flex:0 0 38%;overflow:auto;border-top:2px solid var(--vert)}
table{border-collapse:collapse;width:100%;font-size:13px}
th{position:sticky;top:0;background:var(--encre);color:#fff;text-align:left;padding:6px 8px;cursor:pointer;white-space:nowrap}
td{padding:4px 8px;border-bottom:1px solid var(--trait)}
td.n{text-align:right}
tr.actif td{background:#F6E3E4}
tbody tr:hover td{background:#EEF0E6;cursor:pointer}
.leaflet-popup-content{font-family:Calibri,"Segoe UI",sans-serif;font-size:13px;min-width:240px}
.leaflet-popup-content h3{margin:0 0 6px;font-size:15px}
.leaflet-popup-content table td{border:none;padding:1px 4px}
@media (max-width:840px){#corps{flex-direction:column}#panneau{width:auto;flex:0 0 auto;border-right:none;border-bottom:1px solid var(--trait)}#map{min-height:60vh}}
</style>
</head>
<body>
<header>
  <div class="eyebrow">NCPA · Observatoire foncier</div>
  <h1>Permis et autorisations d'urbanisme</h1>
  <div class="sous" id="sousTitre"></div>
</header>
<div id="corps">
  <aside id="panneau">
    <label class="titre">Types d'autorisation</label>
    <div class="types" id="types"></div>
    <label class="titre">Année d'autorisation</label>
    <div class="annees"><select id="deb" aria-label="Année de début"></select><span>à</span><select id="fin" aria-label="Année de fin"></select></div>
    <label class="titre" for="etat">État d'avancement</label>
    <select id="etat" style="width:100%">
      <option value="tous">Tous</option>
      <option value="venir">Logements à venir (chantier ou autorisation récente)</option>
      <option value="Autorisé">Autorisés, chantier non ouvert</option>
      <option value="Commencé">Commencés</option>
      <option value="Terminé">Terminés</option>
    </select>
    <label style="display:flex;gap:8px;align-items:center;margin-top:10px;font-size:14px"><input type="checkbox" id="taille" checked> Taille selon le nombre de logements</label>
    <div class="stats" id="stats"></div>
    <button id="btnTable" type="button" aria-expanded="false">Afficher le tableau</button>
    <p class="note" id="noteLoc"></p>
    <p class="note">Point placé au centre de la parcelle cadastrale du terrain. « Logements à venir » : chantier ouvert non achevé, ou autorisation de moins de 3 ans sans ouverture de chantier connue. Les dernières années sont incomplètes (transmissions tardives).</p>
    <p class="note">Sources : SDES (Sitadel), cadastre Etalab · Carte générée le __DATE__.</p>
  </aside>
  <div id="droite">
    <div id="map"></div>
    <div id="zoneTable">
      <input type="search" id="filtre" placeholder="Filtrer par commune, adresse ou numéro..." style="margin:6px;width:calc(100% - 12px)">
      <table id="table"><thead></thead><tbody></tbody></table>
    </div>
  </div>
</div>
<script>/*LEAFLET_JS*/</script>
<script>/*FONDS_JS*/</script>
<script>
const D = __DONNEES__;
const COUL = Object.fromEntries(D.types.map(([k,l,c]) => [k,c]));
const LIB = Object.fromEntries(D.types.map(([k,l]) => [k,l]));
const fmt = v => v==null || v==="" ? "" : Number(v).toLocaleString("fr-FR",{maximumFractionDigits:0});
const dateFr = d => d ? d.split("-").reverse().join("/") : "";
document.getElementById("sousTitre").textContent =
  `${D.points.features.length} autorisation(s) localisée(s) · ${D.annees[0]} à ${D.annees[D.annees.length-1]}`;
document.getElementById("noteLoc").textContent = D.non_localises ?
  `${D.non_localises} autorisation(s) sans parcelle reconnue ne figurent pas sur la carte (elles sont dans l'export Excel).` : "";

// ---------- fonds
const map = L.map("map", {zoomSnap:0.25, preferCanvas:true});
const fonds = installerFonds(map, estPhoto => surFond(estPhoto));
function surFond(estPhoto) { limites.setStyle(() => styleLimite(estPhoto)); }
const limites = L.geoJSON(D.limites, {style:() => styleLimite(fonds.photo()),
  interactive:false}).addTo(map);

// ---------- filtres
const typesEl = document.getElementById("types");
D.types.forEach(([k,l,c]) => typesEl.insertAdjacentHTML("beforeend",
  `<label><input type="checkbox" value="${k}" checked><span class="pastille" style="background:${c}"></span>${l}</label>`));
const deb = document.getElementById("deb"), fin = document.getElementById("fin");
D.annees.forEach(a => { deb.add(new Option(a,a)); fin.add(new Option(a,a)); });
deb.value = D.annees[0]; fin.value = D.annees[D.annees.length-1];
function filtres() {
  const types = [...typesEl.querySelectorAll("input:checked")].map(i => i.value);
  const etat = document.getElementById("etat").value, t = document.getElementById("filtre").value.toLowerCase();
  const a1 = +deb.value, a2 = +fin.value;
  return f => {
    const p = f.properties;
    if (!types.includes(p.theme_code) || p.annee < a1 || p.annee > a2) return false;
    if (etat === "venir" && p.a_venir !== "oui") return false;
    if (etat !== "tous" && etat !== "venir" && p.etat !== etat) return false;
    if (t && !(`${p._nom} ${p.adresse} ${p.num}`.toLowerCase().includes(t))) return false;
    return true;
  };
}

// ---------- points
let marqueurs = {}, actif = null;
const couche = L.layerGroup().addTo(map);
function rayon(p) {
  if (!document.getElementById("taille").checked || p.theme_code !== "logements") return 6;
  return Math.min(22, 5 + Math.sqrt(p.logements || 1) * 2.2);
}
function popup(p) {
  const l = (t,v) => v==null || v==="" ? "" : `<tr><td>${t}</td><td><b>${v}</b></td></tr>`;
  return `<h3 style="color:${COUL[p.theme_code]}">${p.theme} · ${p.type_dau} ${p.num || ""}</h3><table>
    ${l("Commune", p._nom)}${l("Adresse", p.adresse)}${l("Parcelles", p.parcelles_txt)}
    ${l("Autorisé le", dateFr(p.date_aut))}${l("État", p.etat)}
    ${l("Chantier ouvert le", dateFr(p.date_doc))}${l("Achevé le", dateFr(p.date_daact))}
    ${l("Logements créés", fmt(p.logements))}${l("dont individuels", fmt(p.lgt_ind))}${l("dont collectifs", fmt(p.lgt_col))}
    ${l("Logements démolis", fmt(p.lgt_demolis))}${l("Lots", fmt(p.lots))}${l("Terrain (m²)", fmt(p.superficie))}
    ${l("Demandeur", p.demandeur)}${l("Dénomination", p.denomination)}
    ${l("Logements à venir", p.a_venir)}</table>`;
}
function dessiner() {
  couche.clearLayers(); marqueurs = {};
  const garde = filtres();
  D.points.features.forEach((f, i) => {
    if (!garde(f)) return;
    const p = f.properties, [x, y] = f.geometry.coordinates;
    const m = L.circleMarker([y, x], {radius:rayon(p), color:"#fff", weight:1, fillColor:COUL[p.theme_code], fillOpacity:.85})
      .bindPopup(() => popup(p)).bindTooltip(`${p._nom} · ${p.type_dau} ${p.num||""}`)
      .on("click", () => { actif = i; tableau(); const r = document.querySelector(`tr[data-i="${i}"]`); if (r) r.scrollIntoView({block:"nearest"}); });
    m.addTo(couche); marqueurs[i] = m;
  });
  stats(); tableau();
}
function stats() {
  const v = D.points.features.filter(filtres()).map(f => f.properties);
  const s = k => v.filter(p => p.etat !== "Annulé").reduce((a,p) => a + (+p[k] || 0), 0);
  const lg = v.filter(p => p.theme_code === "logements");
  document.getElementById("stats").innerHTML =
    `<div><b>${v.length}</b> autorisation(s) affichée(s)</div>
     <div><b>${fmt(s("logements"))}</b> logements autorisés (hors annulations)</div>
     <div><b>${fmt(lg.filter(p => p.a_venir==="oui" && p.etat !== "Annulé").reduce((a,p) => a + (+p.logements||0), 0))}</b> logements à venir</div>
     <div>${v.filter(p => p.theme_code==="amenager").length} permis d'aménager · ${v.filter(p => p.theme_code==="demolir").length} permis de démolir</div>`;
}
const COLS = [["_nom","Commune"],["type_dau","Type"],["num","Numéro"],["date_aut","Autorisé le"],["etat","État"],["logements","Logements"],["adresse","Adresse"]];
let tri = ["date_aut", -1];
function tableau() {
  const th = document.querySelector("#table thead"), tb = document.querySelector("#table tbody");
  th.innerHTML = "<tr>" + COLS.map(([k,l]) => `<th data-k="${k}" scope="col">${l}${tri[0]===k?(tri[1]>0?" ▲":" ▼"):""}</th>`).join("") + "</tr>";
  const lignes = D.points.features.map((f,i) => [f,i]).filter(([f,i]) => marqueurs[i] !== undefined)
    .sort(([a],[b]) => { const x=a.properties[tri[0]], y=b.properties[tri[0]];
      if (typeof x === "number" || typeof y === "number") return ((x||0)-(y||0))*tri[1];
      return String(x||"").localeCompare(String(y||""))*tri[1]; }).slice(0, 2000);
  tb.innerHTML = lignes.map(([f,i]) => { const p = f.properties;
    return `<tr data-i="${i}" class="${i===actif?"actif":""}"><td>${p._nom}</td><td>${p.type_dau}</td><td>${p.num||""}</td><td>${dateFr(p.date_aut)}</td><td>${p.etat}</td><td class="n">${fmt(p.logements)}</td><td>${p.adresse||""}</td></tr>`; }).join("");
  th.querySelectorAll("th").forEach(h => h.onclick = () => { tri = [h.dataset.k, tri[0]===h.dataset.k ? -tri[1] : 1]; tableau(); });
  tb.querySelectorAll("tr").forEach(r => r.onclick = () => {
    const i = +r.dataset.i, m = marqueurs[i]; actif = i;
    if (m) { map.setView(m.getLatLng(), Math.max(map.getZoom(), 16)); m.openPopup(); }
    tableau();
  });
}
[typesEl, deb, fin, document.getElementById("etat"), document.getElementById("taille")].forEach(el => el.addEventListener("change", dessiner));
document.getElementById("filtre").addEventListener("input", dessiner);
document.getElementById("btnTable").onclick = e => {
  const z = document.getElementById("zoneTable"), ouvert = z.style.display === "block";
  z.style.display = ouvert ? "none" : "block";
  e.target.textContent = ouvert ? "Afficher le tableau" : "Masquer le tableau";
  e.target.setAttribute("aria-expanded", String(!ouvert));
  setTimeout(() => map.invalidateSize(), 50);
};
dessiner();
const bornes = D.limites.features.length ? limites.getBounds() : L.latLngBounds(D.points.features.map(f => [f.geometry.coordinates[1], f.geometry.coordinates[0]]));
map.fitBounds(bornes, {padding:[12,12]});
setTimeout(() => map.invalidateSize(), 50);
</script>
</body>
</html>
"""

"""Rapport HTML autonome du thème « Consommation d'espaces ».

Chart.js est embarqué dans le fichier : le rapport s'ouvre sans internet et
peut être envoyé par courriel. Charte NCPA (rouge #B91E27, vert #B1B993,
Calibri). Élément central : la jauge de l'enveloppe indicative 2021-2031,
mise en regard du temps déjà écoulé sur la décennie.
"""
import json

from . import conso_enaf as C
from .chemins import chemin_ressource

COULEURS_DEST = {"hab": "#B5563A", "act": "#4F6D7A", "mix": "#B1B993",
                 "rou": "#8A8A80", "fer": "#3F4448", "inc": "#D9D6CC"}


def territoire_principal(territoires):
    """Sélection s'il y en a une, sinon la commune seule, sinon l'EPCI."""
    selection = [t for t in territoires if t["niveau"] == "Sélection"]
    communes = [t for t in territoires if t["niveau"] == "Commune"]
    epci = [t for t in territoires if t["niveau"] == "EPCI"]
    if selection:
        return selection[0]
    if len(communes) == 1:
        return communes[0]
    return epci[0] if epci else territoires[0]


def generer(chemin, resultat, params):
    territoires, annees = resultat["territoires"], resultat["annees"]
    principal = territoire_principal(territoires)
    dests = resultat["destinations"]

    def r(v, n=3):
        return round(v, n) if isinstance(v, (int, float)) else v

    donnees = {
        "annees": annees,
        "destinations": [(d, C.LIB_DEST[d], COULEURS_DEST[d]) for d in dests],
        "principal": {"nom": principal["nom"], "niveau": principal["niveau"],
                      "flux": {a: {k: r(v) for k, v in principal["flux"][a].items()} for a in annees},
                      "synthese": {k: r(v) for k, v in principal["synthese"].items()}},
        "territoires": [{"nom": t["nom"], "niveau": t["niveau"], "surface": r(t["surface"], 1),
                         "synthese": {k: r(v) for k, v in t["synthese"].items()}} for t in territoires],
        "tranche_debut": C.TRANCHE_DEBUT,
        "millesime": resultat["meta"].get("millesime"),
    }
    with open(chemin_ressource("donnees/chart.umd.min.js"), encoding="utf-8") as f:
        chartjs = f.read()
    html = (GABARIT.replace("/*CHARTJS*/", chartjs)
            .replace("__TITRE__", params.get("titre", "NCPA"))
            .replace("__DATE__", params.get("date", ""))
            .replace("__COMMUNES__", params.get("communes", ""))
            .replace("__DONNEES__", json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")))
    with open(chemin, "w", encoding="utf-8") as f:
        f.write(html)


GABARIT = r"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Consommation d'espaces · __TITRE__</title>
<style>
:root{--rouge:#B91E27;--vert:#B1B993;--vert-fonce:#6F7A4A;--encre:#1F2A2E;--doux:#5E6A6E;--brume:#F3F4EF;--trait:#DCDDD3}
*{box-sizing:border-box}
body{margin:0;font-family:Calibri,"Segoe UI",system-ui,sans-serif;color:var(--encre);background:#fff;line-height:1.45}
header{border-left:8px solid var(--rouge);padding:22px 32px 18px;border-bottom:1px solid var(--trait)}
.eyebrow{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--rouge);font-weight:700}
h1{font-size:30px;margin:4px 0 2px;font-weight:700}
.sous{color:var(--doux);font-size:15px}
main{max-width:1080px;margin:0 auto;padding:8px 32px 48px}
h2{font-size:21px;margin:40px 0 4px}
.chapo{color:var(--doux);margin:0 0 14px;max-width:72ch}
/* jauge de l'enveloppe */
.enveloppe{margin-top:28px;padding:24px 28px;background:var(--brume);border-radius:6px}
.phrase{font-size:24px;max-width:36ch;margin:0 0 38px;line-height:1.3}
.phrase b{color:var(--rouge)}
.jauge{position:relative;height:34px;background:#fff;border:1px solid var(--trait);border-radius:4px}
.jauge .rempli{position:absolute;left:0;top:0;bottom:0;background:var(--rouge);border-radius:3px 0 0 3px;max-width:100%}
.jauge .temps{position:absolute;top:-8px;bottom:-8px;width:3px;background:var(--encre)}
.jauge .temps span{position:absolute;top:-22px;left:50%;transform:translateX(-50%);white-space:nowrap;font-size:13px;color:var(--encre)}
.graduation{display:flex;justify-content:space-between;font-size:13px;color:var(--doux);margin-top:6px}
.chiffres{display:flex;flex-wrap:wrap;gap:28px;margin-top:20px;font-size:14px;color:var(--doux)}
.chiffres strong{display:block;font-size:22px;color:var(--encre)}
.cadre{position:relative;height:340px}
.cadre.grand{height:auto}
table{border-collapse:collapse;width:100%;font-size:14px;margin-top:8px}
th{background:var(--encre);color:#fff;padding:7px 8px;text-align:right;font-weight:700}
th:first-child,td:first-child{text-align:left}
td{padding:5px 8px;border-bottom:1px solid var(--trait);text-align:right}
tr.comp td{background:var(--brume);font-weight:700}
.tableau{overflow-x:auto}
.methode{font-size:14px;color:var(--doux);max-width:80ch}
.methode li{margin-bottom:6px}
footer{margin-top:40px;font-size:13px;color:var(--doux);border-top:1px solid var(--trait);padding-top:10px}
@media print{header{border-left-width:4px}.enveloppe{break-inside:avoid}h2{break-after:avoid}.cadre{break-inside:avoid}}
@media (max-width:700px){main,header{padding-left:16px;padding-right:16px}.phrase{font-size:19px}h1{font-size:24px}}
</style>
</head>
<body>
<header>
  <div class="eyebrow">NCPA · Observatoire foncier</div>
  <h1>Consommation d'espaces naturels, agricoles et forestiers</h1>
  <div class="sous" id="sous"></div>
</header>
<main>
  <section class="enveloppe" aria-labelledby="titreEnv">
    <h2 id="titreEnv" style="margin-top:0;font-size:17px;color:var(--doux);font-weight:400"></h2>
    <p class="phrase" id="phrase"></p>
    <div class="jauge" role="img" id="jauge"><div class="rempli" id="rempli"></div><div class="temps" id="temps"><span id="tempsTxt"></span></div></div>
    <div class="graduation"><span>0 ha</span><span id="gradFin"></span></div>
    <div class="chiffres" id="chiffres"></div>
  </section>

  <h2>Année après année</h2>
  <p class="chapo" id="chapoAnnuel"></p>
  <div class="cadre"><canvas id="gAnnuel"></canvas></div>

  <h2>Comparaison avec les territoires voisins</h2>
  <p class="chapo">Surface consommée chaque année pour 1 000 ha de territoire. Ce ratio permet de comparer des territoires de tailles très différentes.</p>
  <div class="cadre"><canvas id="gComparaison"></canvas></div>

  <section id="blocCommunes">
    <h2>Commune par commune</h2>
    <p class="chapo">Rythme annuel moyen de chaque commune, sur la période de référence et depuis 2021. Les communes sont classées selon leur consommation 2011-2021.</p>
    <div class="cadre grand" id="cadreCommunes"><canvas id="gCommunes"></canvas></div>
  </section>

  <h2>Tableau de synthèse</h2>
  <div class="tableau"><table id="table"></table></div>

  <h2>Méthode et précautions</h2>
  <ul class="methode">
    <li>Source : Cerema, consommation d'espaces naturels, agricoles et forestiers mesurée par les Fichiers fonciers (données publiées sur data.gouv.fr, millésime <span class="mill"></span>).</li>
    <li>Une consommation est enregistrée quand la parcelle change de nature fiscale, c'est-à-dire au commencement des travaux. Une année « 2021-2022 » couvre la période du 1er janvier 2021 au 1er janvier 2022.</li>
    <li>La dernière année est provisoire : des consommations arrivent avec retard et la font réviser à la hausse. Il faut environ trois ans pour qu'un chiffre se stabilise.</li>
    <li>L'enveloppe indicative correspond à 50 % de la consommation 2011-2021, soit l'objectif national de la loi Climat et résilience pour 2021-2031. L'enveloppe réellement applicable est fixée par le SRADDET de Normandie puis déclinée par le SCoT : c'est un repère, pas une limite opposable à une commune.</li>
  </ul>
  <footer>Rapport produit le __DATE__ par Outils Urbanisme · NCPA · Communes : __COMMUNES__</footer>
</main>
<script>/*CHARTJS*/</script>
<script>
const D = __DONNEES__;
const P = D.principal, S = P.synthese, A = D.annees, DERNIERE = A[A.length-1];
const f = (v, d=1) => v==null || isNaN(v) ? "n.d." : v.toLocaleString("fr-FR",{maximumFractionDigits:d, minimumFractionDigits:d});
document.querySelectorAll(".mill").forEach(e => e.textContent = D.millesime);
document.getElementById("sous").textContent = `${P.nom} · flux annuels ${A[0]} à ${DERNIERE+1} · millésime ${D.millesime}`;
Chart.defaults.font.family = 'Calibri, "Segoe UI", system-ui, sans-serif';
Chart.defaults.font.size = 13;
Chart.defaults.color = "#1F2A2E";

// ---------- jauge
const nbRec = DERNIERE - D.tranche_debut + 1;             // années observées depuis 2021
const tempsPct = Math.min(100, nbRec / 10 * 100);
document.getElementById("titreEnv").textContent = `${P.nom} · première décennie de la loi Climat et résilience (2021-2031)`;
if (S.enveloppe) {
  const pct = S.part_enveloppe;
  document.getElementById("phrase").innerHTML =
    `<b>${f(S.rec_ha)} ha</b> consommés de ${D.tranche_debut} à ${DERNIERE+1}, soit <b>${f(pct,0)} %</b> de l'enveloppe indicative de ${f(S.enveloppe)} ha, alors que ${f(tempsPct,0)} % de la décennie est écoulée.`;
  document.getElementById("rempli").style.width = Math.min(100, pct) + "%";
  document.getElementById("temps").style.left = `calc(${tempsPct}% - 1px)`;
  document.getElementById("tempsTxt").textContent = `${nbRec} an${nbRec>1?"s":""} sur 10`;
  document.getElementById("gradFin").textContent = `${f(S.enveloppe)} ha (enveloppe indicative)`;
  document.getElementById("jauge").setAttribute("aria-label", `${f(pct,0)} % de l'enveloppe consommée, ${f(tempsPct,0)} % du temps écoulé`);
} else {
  document.getElementById("phrase").textContent = "La période de référence 2011-2021 n'est pas complète dans ce millésime : l'enveloppe ne peut pas être calculée.";
  document.getElementById("jauge").style.display = "none";
}
const chiffres = [
  [`${f(S.ref_ha)} ha`, "consommés de 2011 à 2021"],
  [`${f(S.ref_rythme,2)} ha/an`, "rythme de référence"],
  [`${f(S.rec_rythme,2)} ha/an`, `rythme depuis ${D.tranche_debut}`],
  [S.evolution==null ? "n.d." : `${S.evolution>0?"+":""}${f(S.evolution,0)} %`, "évolution du rythme"],
  [`${f(S.ref_hab_part,0)} %`, "part de l'habitat (2011-2021)"],
];
document.getElementById("chiffres").innerHTML = chiffres.map(([v,l]) => `<div><strong>${v}</strong>${l}</div>`).join("");

// ---------- annuel empilé par destination
document.getElementById("chapoAnnuel").textContent =
  `${P.nom} : surface consommée chaque année, par destination. La dernière année (${DERNIERE}-${DERNIERE+1}) est provisoire et apparaît en couleurs atténuées.`;
new Chart(document.getElementById("gAnnuel"), {
  type: "bar",
  data: {
    labels: A.map(a => a===DERNIERE ? `${a} (prov.)` : String(a)),
    datasets: D.destinations.map(([k, lib, c]) => ({
      label: lib, data: A.map(a => P.flux[a][k]),
      backgroundColor: A.map(a => a===DERNIERE ? c + "66" : c), stack: "s"}))
  },
  options: {maintainAspectRatio:false, plugins:{legend:{position:"bottom"},
    tooltip:{callbacks:{label: x => `${x.dataset.label} : ${f(x.raw,2)} ha`}}},
    scales:{x:{stacked:true, grid:{display:false}}, y:{stacked:true, title:{display:true, text:"hectares"}}}}
});

// ---------- comparaison (pour 1 000 ha de territoire)
const comp = D.territoires.filter(t => t.niveau !== "Commune" && t.surface);
if (P.niveau === "Commune" && !comp.some(t => t.nom === P.nom)) {
  const tp = D.territoires.find(t => t.nom === P.nom); if (tp && tp.surface) comp.unshift(tp);
}
const ratio = (t, k) => t.synthese[k]==null ? null : t.synthese[k] / t.surface * 1000;
new Chart(document.getElementById("gComparaison"), {
  type: "bar",
  data: {labels: comp.map(t => t.nom), datasets: [
    {label: "2011-2021", data: comp.map(t => ratio(t, "ref_rythme")), backgroundColor: "#B1B993"},
    {label: `Depuis ${D.tranche_debut}`, data: comp.map(t => ratio(t, "rec_rythme")), backgroundColor: "#B91E27"}]},
  options: {maintainAspectRatio:false, plugins:{legend:{position:"bottom"},
    tooltip:{callbacks:{label: x => `${x.dataset.label} : ${f(x.raw,2)} ha par an pour 1 000 ha`}}},
    scales:{x:{grid:{display:false}}, y:{title:{display:true, text:"ha / an pour 1 000 ha"}}}}
});

// ---------- communes
const communes = D.territoires.filter(t => t.niveau === "Commune")
  .sort((a,b) => (b.synthese.ref_ha||0) - (a.synthese.ref_ha||0));
if (communes.length > 1) {
  document.getElementById("cadreCommunes").style.height = (communes.length * 24 + 80) + "px";
  new Chart(document.getElementById("gCommunes"), {
    type: "bar",
    data: {labels: communes.map(t => t.nom), datasets: [
      {label: "Rythme 2011-2021", data: communes.map(t => t.synthese.ref_rythme), backgroundColor: "#B1B993"},
      {label: `Rythme depuis ${D.tranche_debut}`, data: communes.map(t => t.synthese.rec_rythme), backgroundColor: "#B91E27"}]},
    options: {indexAxis:"y", maintainAspectRatio:false, plugins:{legend:{position:"top"},
      tooltip:{callbacks:{label: x => `${x.dataset.label} : ${f(x.raw,2)} ha/an`}}},
      scales:{x:{title:{display:true, text:"ha / an"}}, y:{grid:{display:false}, ticks:{autoSkip:false}}}}
  });
} else { document.getElementById("blocCommunes").style.display = "none"; }

// ---------- tableau
const COLS = [["ref_ha","2011-2021 (ha)",1],["ref_rythme","Rythme réf. (ha/an)",2],["rec_ha",`Depuis ${D.tranche_debut} (ha)`,1],
  ["rec_rythme","Rythme récent (ha/an)",2],["evolution","Évolution (%)",0],["part_enveloppe","Enveloppe consommée (%)",0],["part_surface","Part de la surface (%)",2]];
document.getElementById("table").innerHTML =
  `<thead><tr><th scope="col">Territoire</th>${COLS.map(c => `<th scope="col">${c[1]}</th>`).join("")}</tr></thead><tbody>` +
  D.territoires.map(t => `<tr class="${t.niveau!=="Commune"?"comp":""}"><td>${t.nom}</td>${COLS.map(([k,_l,d]) => `<td>${f(t.synthese[k], d)}</td>`).join("")}</tr>`).join("") +
  "</tbody>";
</script>
</body>
</html>
"""

# -*- coding: utf-8 -*-
"""Cartes interactives (Leaflet) : une même fonction JavaScript par carte sert à l'aperçu dans l'interface
(composant HTML) et aux exports HTML. Fond OpenFreeMap Positron par défaut, photographie aérienne IGN en bascule.
Bibliothèques embarquées (aucun CDN) : la carte exportée s'ouvre sur un poste sans accès à unpkg ou cdnjs, seules
les tuiles du fond viennent d'internet.

Trois cartes :
  - communes : indicateurs par commune de l'EPCI et par EPCI de la région (choroplèthe en quintiles) ;
  - entreprises : employeurs SIRENE et entreprises susceptibles d'embaucher (La Bonne Boite), avec filtres ;
  - flux : déplacements domicile-travail entre l'EPCI et les communes extérieures.
"""
import base64
import html
import json
import re

import numpy as np
import pandas as pd

from pathlib import Path

ASSETS = Path(__file__).resolve().parent / "assets"
ROUGE = "#B91E27"


# ============================================================================================ données
def _ratio(a, b):
    return np.where((b > 0) & pd.notna(a), a / b * 100, np.nan)


def _geojson_leger(gdf, champs, tolerance):
    g = gdf[["code", "nom", "geometry"] + list(champs)].copy()
    g["geometry"] = g.to_crs(2154).geometry.simplify(tolerance).to_crs(4326)
    for k in champs:
        g[k] = pd.to_numeric(g[k], errors="coerce").round(2)
    fc = json.loads(g.to_json(na="null"))

    def arrondi(x):
        if isinstance(x, list):
            return [arrondi(v) for v in x]
        return round(x, 5) if isinstance(x, float) else x
    for f in fc["features"]:
        f["geometry"]["coordinates"] = arrondi(f["geometry"]["coordinates"])
    return fc


def donnees_choroplethe(res_eco, r, brut):
    """Indicateurs par commune (EPCI étudié) et par EPCI (région). Repris du portrait économique, complété par
    l'évolution de l'emploi par commune sur la période choisie (outil Emploi)."""
    com, epcis = brut.get("com"), brut.get("epcis")
    if com is None:
        return None
    siren = brut["siren"]
    c = com[com.code_epci == siren].copy()
    champs_c, champs_e = {}, {}
    e = epcis.copy()
    if res_eco is not None:
        D, U = res_eco["D"], res_eco["U"]
        t = D.t

        def par_geo(code, niveau):
            s = t[(t.code == code) & (t.niveau == niveau)]
            if s.empty:
                return pd.Series(dtype=float), None
            an = s.annee.max()
            return s[s.annee == an].set_index("geo")["valeur"], an
        pop, an = par_geo("pop", "COM")
        if an:
            c["pop"] = c.code.map(pop)
            champs_c["pop"] = (f"Population ({an})", 0, "")
        rs, an = par_geo("log_rs", "COM")
        lt, _ = par_geo("log_total", "COM")
        if an:
            c["part_rs"] = _ratio(c.code.map(rs), c.code.map(lt))
            champs_c["part_rs"] = (f"Part des résidences secondaires ({an})", 1, " %")
        for code, lib in (("part_pres_off", "Part présentielle des salariés, Insee"), ("chomage", "Taux de chômage 15-64 ans")):
            v, an = par_geo(code, "COM")
            if an and c.code.map(v).notna().any():
                c[code] = c.code.map(v)
                champs_c[code] = (f"{lib} ({an})", 1, " %")
        nv, an = par_geo("niv_vie_med", "COM")
        if an:
            c["niv_vie"] = c.code.map(nv)
            champs_c["niv_vie"] = (f"Niveau de vie médian ({an})", 0, " €")
        e["nom"] = e.code.map(D.nom)
        for code, lib, dec, u in (("ice", "Concentration d'emploi", 1, ""), ("part_pres_off", "Part présentielle des "
                                  "salariés, Insee", 1, " %"), ("chomage", "Taux de chômage 15-64 ans", 1, " %"),
                                  ("niv_vie_med", "Niveau de vie médian", 0, " €"),
                                  ("part_pensions", "Part des pensions dans le revenu", 1, " %")):
            v, an = par_geo(code, "EPCI")
            if an:
                e[code] = e.code.map(v)
                champs_e[code] = (f"{lib} ({an})", dec, u)
        rs, an = par_geo("log_rs", "EPCI")
        lt, _ = par_geo("log_total", "EPCI")
        if an:
            e["part_rs"] = _ratio(e.code.map(rs), e.code.map(lt))
            champs_e["part_rs"] = (f"Part des résidences secondaires ({an})", 1, " %")
        if U is not None:
            a1 = U.annee.max()
            g = U[U.annee == a1].groupby(["epci", "sphere"]).effectifs.sum().unstack(fill_value=0)
            e["part_presentielle"] = e.code.map(g.get("P", 0) / g.sum(axis=1) * 100)
            champs_e["part_presentielle"] = (f"Part présentielle de l'emploi salarié privé ({a1}, Urssaf)", 1, " %")
    if r is not None:
        a1, a2 = r["a_deb"], r["a_fin"]
        eff = {x["code_commune"]: x["eff"] for x in r["communes"]}
        evo = {x["code_commune"]: (x["evol"] * 100 if x["evol"] is not None and (x["eff_deb"] or 0) >= 20 else None)
               for x in r["communes"]}
        c["sal_prives"] = c.code.map(eff)
        champs_c["sal_prives"] = (f"Salariés privés ({a2})", 0, "")
        c["evol_sal"] = c.code.map(evo)
        champs_c["evol_sal"] = (f"Évolution des salariés privés {a1}-{a2} (communes de 20 salariés ou plus)", 1, " %")
        ev_e = {d["code_epci"]: (d["evol"] * 100 if d["evol"] is not None else None)
                for t in r.get("comparaisons", {}).values() for d in t}
        if ev_e:
            e["evol_sal"] = e.code.map(ev_e)
            champs_e["evol_sal"] = (f"Évolution des salariés privés {a1}-{a2}", 1, " %")
    if "nom" not in e or e["nom"].isna().all():
        e["nom"] = e["code"]
    e["nom"] = e["nom"].fillna(e["code"])
    for gdf, champs in ((c, champs_c), (e, champs_e)):
        for k in list(champs):
            if pd.to_numeric(gdf[k], errors="coerce").dropna().nunique() < 3:
                del champs[k]
    out = {"cible": siren}
    if champs_c:
        out["communes"] = {"titre": "Communes de l'EPCI", "fc": _geojson_leger(c, champs_c, 30), "champs": champs_c}
    if champs_e:
        out["epci"] = {"titre": "EPCI de la région", "fc": _geojson_leger(e, champs_e, 150), "champs": champs_e}
    return out if len(out) > 1 else None


def _contours(brut, tol=25):
    com = brut.get("com")
    if com is None:
        return None
    sel = com[com.code_epci == brut["siren"]]
    if sel.empty:
        return None
    return _geojson_leger(sel, [], tol)


def donnees_entreprises(employeurs, lbb, brut):
    pts = []
    for d in employeurs or []:
        if d.get("lat") is None:
            continue
        pts.append({"t": "e", "n": d["nom"], "s": d.get("siret"), "a": d.get("activite"), "g": d.get("grand_secteur"),
                    "s38": d.get("secteur"), "tr": d.get("tranche_lib"), "m": d.get("eff_min"), "c": d.get("commune"),
                    "ad": d.get("adresse"), "si": d.get("siege"), "y": round(d["lat"], 5), "x": round(d["lon"], 5)})
    for d in lbb or []:
        if d.get("lat") is None:
            continue
        pts.append({"t": "b", "n": d["nom"], "s": d.get("siret"), "a": d.get("activite"), "me": d.get("metier"),
                    "r": d.get("rome"), "ef": d.get("effectif"), "c": d.get("commune"), "p": d.get("potentiel"),
                    "f": bool(d.get("fort_potentiel")), "ap": bool(d.get("position_approx")),
                    "y": round(d["lat"], 5), "x": round(d["lon"], 5)})
    return {"points": pts, "contours": _contours(brut), "nom": brut["cfg"]["nom_court"]}


def donnees_flux(m, brut):
    return {"centre": m.get("centre"), "liens": m.get("liens") or [], "annee": m.get("annee"),
            "contours": _contours(brut), "nom": brut["cfg"]["nom_court"]}


# ============================================================================================ HTML
def bibliotheques():
    """CSS et JS de Leaflet et MapLibre, embarqués."""
    css = (ASSETS / "leaflet.css").read_text(encoding="utf-8")
    for nom in ("layers.png", "layers-2x.png"):
        b = base64.b64encode((ASSETS / nom).read_bytes()).decode()
        css = css.replace(f"url(images/{nom})", f"url(data:image/png;base64,{b})")
    css += (ASSETS / "maplibre-gl.css").read_text(encoding="utf-8")
    js = (ASSETS / "leaflet.js").read_text(encoding="utf-8")
    for nom in ("maplibre-gl.js", "leaflet-maplibre-gl.js"):
        js += "\n" + re.sub(r"//# sourceMappingURL=\S+", "", (ASSETS / nom).read_text(encoding="utf-8"))
    return css, js


CSS_CARTES = """
.carto,.carto *{box-sizing:border-box}
.carto{display:grid;grid-template-columns:270px 1fr;border:1px solid #E3E3DE;background:#fff;height:620px;
  font-family:Calibri,Carlito,"Segoe UI",system-ui,sans-serif;font-size:14px;color:#222}
.carto .panneau{padding:12px;border-right:1px solid #E3E3DE;overflow:auto}
.carto .panneau label{display:block;font-weight:700;margin:10px 0 3px;font-size:13px}
.carto .panneau select,.carto .panneau input[type=text]{width:100%;padding:4px;font-family:inherit;font-size:13px}
.carto .panneau .coche{font-weight:400;display:flex;gap:6px;align-items:center;margin:3px 0}
.carto .zone{position:relative;height:100%}
.carto .leg div{display:flex;align-items:center;gap:6px;font-size:12.5px;margin:2px 0}
.carto .leg span{display:inline-block;width:16px;height:12px;border:1px solid #bbb;flex:none}
.carto .compte{margin-top:10px;font-size:13px;color:#5B6770}
.carto button{margin-top:10px;font-family:inherit;font-size:13px;padding:4px 8px;cursor:pointer;border:1px solid #ccc;
  background:#fafaf8;border-radius:3px}
.carto .mention{font-size:11.5px;color:#777;margin-top:10px}
@media (max-width:860px){.carto{grid-template-columns:1fr;height:auto}.carto .zone{height:480px}}
/* pleine page : la carte occupe tout l'écran, les filtres flottent par-dessus et se replient */
.carto.plein{display:block;position:relative;border:0}
.carto.plein .zone{position:absolute;inset:0;height:auto}
.carto.plein .panneau{position:absolute;z-index:1000;top:10px;left:54px;width:285px;max-height:calc(100% - 20px);
  background:rgba(255,255,255,.96);border:1px solid #ccc;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,.18)}
.carto .tete{display:none}
.carto.plein .tete{display:flex;justify-content:space-between;align-items:center;font-weight:700;color:#B91E27;
  margin:-2px 0 4px}
.carto.plein .tete button{margin:0;padding:1px 8px}
.carto.plein .panneau.replie{width:auto;overflow:hidden}
.carto.plein .panneau.replie>*:not(.tete){display:none}
.carto.plein .panneau.replie .tete{margin:0;gap:10px}
"""

JS_CARTES = r"""
window.CARTES = window.CARTES || [];
// une carte créée dans un onglet masqué (largeur nulle) se cadre mal : on attend qu'elle soit visible
function quandVisible(id,f){const el=document.getElementById(id);
  if(el.offsetWidth>0&&el.offsetHeight>0){f();return;}
  const ro=new ResizeObserver(()=>{if(el.offsetWidth>0&&el.offsetHeight>0){ro.disconnect();f();}});ro.observe(el);}
// Fond « Plan » : OpenFreeMap Positron (vectoriel, il faut WebGL). Sur les postes où WebGL est désactivé ou
// bloqué (accélération matérielle coupée, proxy), le plan reste vide : on bascule alors automatiquement sur le
// Plan IGN (images, sans WebGL). Bascule photographie aérienne IGN toujours visible.
const ATTR_OFM='<a href="https://openfreemap.org" target="_blank">OpenFreeMap</a> © <a href="https://www.openstreetmap.org/copyright" target="_blank">contributeurs OpenStreetMap</a>';
const URL_IGN=c=>"https://data.geopf.fr/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER="+c+"&STYLE=normal&TILEMATRIXSET=PM&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}";
// cadrage : en pleine page, on laisse la place du panneau de filtres à gauche
function cadrer(map,b,maxZoom){if(!b||!b.isValid())return;
  const plein=map.getContainer().closest(".carto.plein"), p=plein&&plein.querySelector(".panneau:not(.replie)");
  const o=p?{paddingTopLeft:[p.offsetWidth+70,20],paddingBottomRight:[20,20]}:{padding:[12,12]};
  if(maxZoom)o.maxZoom=maxZoom;map.fitBounds(b,o);}
function webglDispo(){try{const c=document.createElement("canvas");return !!(c.getContext("webgl2")||c.getContext("webgl"));}catch(e){return false;}}
function planIGN(){return L.tileLayer(URL_IGN("GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2")+"&FORMAT=image%2Fpng",
  {attribution:"© IGN / Géoplateforme",maxNativeZoom:19,maxZoom:20});}
function fondCarte(map){
  const ortho=L.tileLayer(URL_IGN("ORTHOIMAGERY.ORTHOPHOTOS")+"&FORMAT=image%2Fjpeg",
    {attribution:"© IGN / Géoplateforme",maxNativeZoom:19,maxZoom:20});
  const plan=L.layerGroup().addTo(map);
  const ctrl=L.control.layers({"Plan":plan,"Photographie aérienne":ortho},null,{collapsed:false,position:"topright"}).addTo(map);
  let fait=false;
  const repli=raison=>{if(fait)return;fait=true;plan.clearLayers();plan.addLayer(planIGN());
    console.warn("Fond Positron indisponible ("+raison+") : Plan IGN utilisé");};
  if(!webglDispo()||!L.maplibreGL){repli("WebGL absent");return;}
  try{
    const gl=L.maplibreGL({style:"https://tiles.openfreemap.org/styles/positron",attribution:ATTR_OFM});
    plan.addLayer(gl);
    const m=gl.getMaplibreMap&&gl.getMaplibreMap();
    if(m){m.on("error",e=>{if(!m.isStyleLoaded())repli("style non chargé");});
      m.on("load",()=>{fait=true;});}
    setTimeout(()=>{if(!fait&&!(m&&m.isStyleLoaded()))repli("délai dépassé");},8000);
  }catch(e){repli(e.message||e);}
}
// Contours : sombres sur le plan, blancs et fins sur la photographie aérienne
function contourSelonFond(map,couche,stylePlan){
  map.on("baselayerchange",e=>couche.setStyle(e.name==="Photographie aérienne"?
    {color:"#ffffff",weight:1.2,dashArray:null,fillOpacity:0}:stylePlan));}
const fmtN=(v,d)=>v==null||isNaN(v)?"n.d.":Number(v).toLocaleString("fr-FR",{minimumFractionDigits:d,maximumFractionDigits:d});
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
function nouvelleCarte(id){const m=L.map(id,{zoomSnap:0.25,preferCanvas:true});fondCarte(m);
  window.CARTES.push(m);return m;}

// ------------------------------------------------------------------ communes / EPCI
function carteChoro(id,D){
  const PAL=["#F7EDED","#E3A9AC","#C9535A","#B91E27","#6E1015"];
  const map=nouvelleCarte(id+"_m");
  const selC=document.getElementById(id+"_c"), selI=document.getElementById(id+"_i");
  for(const k of ["communes","epci"]) if(D[k]){const o=document.createElement("option");o.value=k;o.textContent=D[k].titre;selC.appendChild(o);}
  let couche=null;
  function remplir(){const ch=D[selC.value].champs;selI.innerHTML="";
    for(const k in ch){const o=document.createElement("option");o.value=k;o.textContent=ch[k][0];selI.appendChild(o);} }
  function bornes(v){v=v.filter(x=>x!=null&&!isNaN(x)).sort((a,b)=>a-b);if(!v.length)return[];
    const b=[];for(let i=1;i<5;i++)b.push(v[Math.min(v.length-1,Math.floor(i*v.length/5))]);return [...new Set(b)];}
  function classe(x,b){if(x==null||isNaN(x))return -1;let i=0;while(i<b.length&&x>=b[i])i++;return i;}
  function dessiner(){const d=D[selC.value],k=selI.value,[titre,dec,u]=d.champs[k];
    const b=bornes(d.fc.features.map(f=>f.properties[k]));
    if(couche)map.removeLayer(couche);
    couche=L.geoJSON(d.fc,{style:f=>{const c=classe(f.properties[k],b);const cible=f.properties.code===D.cible;
        return{fillColor:c<0?"#EEEEEE":PAL[Math.min(c,4)],fillOpacity:.78,color:cible?"#111":"#fff",weight:cible?2.5:0.8};},
      onEachFeature:(f,l)=>{let h="<b>"+esc(f.properties.nom)+"</b><table style='font-size:12px'>";
        for(const j in d.champs){const[t,dd,uu]=d.champs[j];h+="<tr><td>"+esc(t)+"</td><td style='text-align:right;padding-left:8px'><b>"+fmtN(f.properties[j],dd)+(f.properties[j]==null?"":uu)+"</b></td></tr>";}
        l.bindPopup(h+"</table>");l.bindTooltip(esc(f.properties.nom)+" : "+fmtN(f.properties[k],dec)+(f.properties[k]==null?"":u),{sticky:true});}}).addTo(map);
    cadrer(map,couche.getBounds());
    let lg="<div style='font-weight:700;margin-bottom:4px'>"+esc(titre)+"</div>";const lims=[null].concat(b).concat([null]);
    for(let i=0;i<=b.length;i++){const a=lims[i],z=lims[i+1];
      const t=a==null?"moins de "+fmtN(z,dec):z==null?fmtN(a,dec)+" et plus":fmtN(a,dec)+" à "+fmtN(z,dec);
      lg+="<div><span style='background:"+PAL[i]+"'></span>"+t+u+"</div>";}
    lg+="<div><span style='background:#EEEEEE'></span>non disponible</div>";
    document.getElementById(id+"_l").innerHTML=lg;}
  selC.onchange=()=>{remplir();dessiner();};selI.onchange=dessiner;remplir();dessiner();
  map._refit=()=>{if(couche)cadrer(map,couche.getBounds());};
  setTimeout(()=>{map.invalidateSize();if(couche)cadrer(map,couche.getBounds());},250);
}

// ------------------------------------------------------------------ entreprises
function carteEntreprises(id,D){
  const map=nouvelleCarte(id+"_m");
  const COUL={"Industrie":"#7D8A5B","Construction":"#D98C8F","Commerce":"#5B6770","Services":"#9DA7B0"};
  const coul=g=>COUL[g]||"#B1B993";
  const ray=m=>m==null?3.5:m>=250?11:m>=50?8.5:m>=10?6.5:m>=3?5:4;
  const lbbCoul=p=>p==null?"#E0A030":p>=80?"#8C1C22":p>=60?"#B91E27":p>=40?"#E0703A":"#E0A030";
  if(D.contours){const st={color:"#333",weight:1,fill:false,dashArray:"3 3"};
    contourSelonFond(map,L.geoJSON(D.contours,{style:st,interactive:false}).addTo(map),st);}
  const P=D.points, g=k=>document.getElementById(id+"_"+k);
  const vals=(t,k)=>[...new Set(P.filter(p=>p.t===t||t==="*").map(p=>p[k]).filter(x=>x))].sort();
  const remplir=(sel,liste,tous)=>{sel.innerHTML="<option value=''>"+tous+"</option>"+liste.map(v=>"<option>"+esc(v)+"</option>").join("");};
  remplir(g("com"),vals("*","c"),"toutes les communes");remplir(g("sec"),vals("e","g"),"tous les secteurs");
  remplir(g("met"),vals("b","me"),"tous les métiers");
  if(!P.some(p=>p.t==="e")){g("blocE").style.display="none";g("fe").style.display="none";g("ce").checked=false;}
  if(!P.some(p=>p.t==="b")){g("blocB").style.display="none";g("fb").style.display="none";g("cb").checked=false;}
  const couche=L.layerGroup().addTo(map);let vus=[];
  function filtre(){const com=g("com").value,sec=g("sec").value,met=g("met").value,tmin=+g("taille").value,
      fort=g("fort").checked,txt=g("txt").value.toLowerCase().trim(),ce=g("ce").checked,cb=g("cb").checked;
    return P.filter(p=>{if(p.t==="e"&&!ce)return false;if(p.t==="b"&&!cb)return false;
      if(com&&p.c!==com)return false;
      if(p.t==="e"){if(sec&&p.g!==sec)return false;if(tmin&&(p.m==null||p.m<tmin))return false;}
      if(p.t==="b"){if(met&&p.me!==met)return false;if(fort&&!p.f)return false;}
      if(txt&&!((p.n+" "+(p.a||"")+" "+(p.me||"")+" "+(p.s||"")).toLowerCase().includes(txt)))return false;return true;});}
  function dessiner(ajuster){couche.clearLayers();vus=filtre();
    for(const p of vus){let mk;
      if(p.t==="e"){mk=L.circleMarker([p.y,p.x],{radius:ray(p.m),color:"#fff",weight:.8,fillColor:coul(p.g),fillOpacity:.85});
        mk.bindPopup("<b>"+esc(p.n)+"</b><br>"+esc(p.a)+"<br>"+esc(p.tr)+(p.si?" · siège":"")+"<br>"+esc(p.ad)+" "+esc(p.c)+"<br><small>SIRET "+esc(p.s)+"</small>");}
      else{mk=L.circleMarker([p.y,p.x],{radius:7,color:lbbCoul(p.p),weight:3,fillColor:"#fff",fillOpacity:.9,dashArray:p.ap?"2 2":null});
        mk.bindPopup("<b>"+esc(p.n)+"</b><br>Recrute potentiellement : <b>"+esc(p.me)+"</b> ("+esc(p.r)+")<br>"+esc(p.a||"")+
          (p.ef?"<br>Effectif : "+esc(p.ef):"")+"<br>Potentiel d'embauche : "+(p.p==null?"n.d.":fmtN(p.p,0)+" / 100")+(p.f?" (fort)":"")+
          "<br>"+esc(p.c)+(p.ap?"<br><i>position approximative (centre de la commune)</i>":"")+"<br><small>SIRET "+esc(p.s)+" · source France Travail, La Bonne Boite</small>");}
      mk.bindTooltip(esc(p.n));couche.addLayer(mk);}
    const ne=vus.filter(p=>p.t==="e").length, nb=vus.filter(p=>p.t==="b").length;
    g("n").innerHTML=(ne?ne+" employeurs":"")+(ne&&nb?" · ":"")+(nb?nb+" entreprise×métier susceptibles d'embaucher":"")+(ne||nb?"":"aucun point");
    if(ajuster&&vus.length){cadrer(map,L.latLngBounds(vus.map(p=>[p.y,p.x])),15);}}
  for(const k of ["com","sec","met","taille"]) g(k).onchange=()=>dessiner(true);
  for(const k of ["fort","ce","cb"]) g(k).onchange=()=>dessiner(false);
  g("txt").oninput=()=>dessiner(false);
  g("csv").onclick=()=>{const cols=["type","nom","siret","activite","secteur","metier","rome","effectif","potentiel","commune","lat","lon"];
    const l=[cols.join(";")].concat(vus.map(p=>[p.t==="e"?"employeur":"susceptible d'embaucher",p.n,p.s,p.a,p.g||"",p.me||"",p.r||"",p.tr||p.ef||"",p.p==null?"":p.p,p.c,p.y,p.x]
      .map(v=>'"'+String(v==null?"":v).replace(/"/g,'""')+'"').join(";")));
    const b=new Blob(["\ufeff"+l.join("\n")],{type:"text/csv"});const a=document.createElement("a");a.href=URL.createObjectURL(b);
    a.download="entreprises_filtrees.csv";a.click();};
  let lg="";
  if(P.some(p=>p.t==="e")){lg+="<div style='font-weight:700'>Employeurs (SIRENE)</div>";
    for(const k in COUL)lg+="<div><span style='background:"+COUL[k]+";border-radius:50%'></span>"+k+"</div>";
    lg+="<div style='font-size:11.5px;color:#777'>taille du point : tranche d'effectif</div>";}
  if(P.some(p=>p.t==="b")){lg+="<div style='font-weight:700;margin-top:6px'>Susceptibles d'embaucher</div>";
    for(const [t,c] of [["potentiel 80 et plus","#8C1C22"],["60 à 79","#B91E27"],["40 à 59","#E0703A"],["moins de 40","#E0A030"]])
      lg+="<div><span style='background:#fff;border:3px solid "+c+";border-radius:50%'></span>"+t+"</div>";
    lg+="<div style='font-size:11.5px;color:#777'>pointillé : position approximative</div>";}
  g("l").innerHTML=lg;
  map._refit=()=>{if(D.contours)cadrer(map,L.geoJSON(D.contours).getBounds());
    else if(P.length)cadrer(map,L.latLngBounds(P.map(p=>[p.y,p.x])));else map.setView([49.2,-0.1],10);};
  map._refit();dessiner(false);setTimeout(()=>map.invalidateSize(),250);
}

// ------------------------------------------------------------------ flux domicile-travail
function carteFlux(id,D){
  const map=nouvelleCarte(id+"_m");
  if(D.contours){const st={color:"#B91E27",weight:1.5,fillColor:"#B91E27",fillOpacity:.08,dashArray:null};
    contourSelonFond(map,L.geoJSON(D.contours,{style:st,interactive:false}).addTo(map),st);}
  const c=D.centre, liens=D.liens; if(!c||!liens.length){map.setView([49.2,-0.1],9);return;}
  const vmax=Math.max(...liens.map(l=>l.sortants+l.entrants),1);const pts=[[c[1],c[0]]];
  const g=k=>document.getElementById(id+"_"+k);const couche=L.layerGroup().addTo(map);
  function dessiner(){couche.clearLayers();const n=+g("nb").value,sens=g("sens").value;
    let L2=liens.slice().sort((a,b)=>(b.sortants+b.entrants)-(a.sortants+a.entrants)).slice(0,n);
    for(const l of L2.slice().reverse()){const v=sens==="s"?l.sortants:sens==="e"?l.entrants:l.sortants+l.entrants;if(!v)continue;
      const col=l.sortants>=l.entrants?"#B91E27":"#3A7D2C";
      couche.addLayer(L.polyline([[c[1],c[0]],[l.lat,l.lon]],{color:sens==="e"?"#3A7D2C":sens==="s"?"#B91E27":col,weight:1+10*Math.pow(v/vmax,.7),opacity:.7,lineCap:"round"})
        .bindTooltip(esc(l.commune)+" : "+fmtN(l.sortants,0)+" habitants y travaillent, "+fmtN(l.entrants,0)+" actifs en viennent",{sticky:true}));
      couche.addLayer(L.circleMarker([l.lat,l.lon],{radius:3,color:col,fillOpacity:1}).bindTooltip(esc(l.commune)));pts.push([l.lat,l.lon]);}
    couche.addLayer(L.circleMarker([c[1],c[0]],{radius:7,color:"#111",fillColor:"#111",fillOpacity:1}).bindTooltip(esc(D.nom)));}
  g("nb").onchange=dessiner;g("sens").onchange=dessiner;dessiner();
  g("l").innerHTML="<div><span style='background:#B91E27'></span>surtout des habitants qui vont y travailler</div>"+
    "<div><span style='background:#3A7D2C'></span>surtout des actifs qui en viennent</div>"+
    "<div style='font-size:11.5px;color:#777'>épaisseur : nombre d'actifs (recensement "+D.annee+")</div>";
  map._refit=()=>cadrer(map,L.latLngBounds([[c[1],c[0]]].concat(liens.slice(0,25).map(l=>[l.lat,l.lon]))));
  map._refit();
  setTimeout(()=>map.invalidateSize(),250);
}
"""


def fragment(type_, donnees, id_, plein=False):
    """Panneau + carte + appel JS. Les bibliothèques sont ajoutées une seule fois par la page qui l'accueille.
    plein : la carte remplit son conteneur, le panneau de filtres flotte par-dessus et se replie."""
    d = json.dumps(donnees, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    if type_ == "communes":
        panneau = (f'<label for="{id_}_c">Échelle</label><select id="{id_}_c"></select>'
                   f'<label for="{id_}_i">Indicateur</label><select id="{id_}_i"></select>'
                   f'<div class="leg" id="{id_}_l" style="margin-top:12px"></div>'
                   '<div class="mention">Classes : quintiles. Trait noir : le territoire étudié. Cliquer pour le détail.</div>')
        appel = f"quandVisible('{id_}_m',()=>carteChoro('{id_}',{d}));"
    elif type_ == "entreprises":
        panneau = (f'<label>Afficher</label><div id="{id_}_blocE"><label class="coche"><input type="checkbox" id="{id_}_ce" checked>'
                   f'Employeurs (SIRENE)</label></div><div id="{id_}_blocB"><label class="coche">'
                   f'<input type="checkbox" id="{id_}_cb" checked>Susceptibles d\'embaucher</label></div>'
                   f'<label for="{id_}_com">Commune</label><select id="{id_}_com"></select>'
                   f'<div id="{id_}_fe"><label for="{id_}_sec">Grand secteur (employeurs)</label><select id="{id_}_sec"></select>'
                   f'<label for="{id_}_taille">Taille minimale (employeurs)</label><select id="{id_}_taille">'
                   '<option value="0">toutes</option><option value="1">1 salarié ou plus</option>'
                   '<option value="10">10 ou plus</option><option value="50">50 ou plus</option>'
                   '<option value="250">250 ou plus</option></select></div>'
                   f'<div id="{id_}_fb"><label for="{id_}_met">Métier (La Bonne Boite)</label><select id="{id_}_met"></select>'
                   f'<label class="coche"><input type="checkbox" id="{id_}_fort">Fort potentiel seulement</label></div>'
                   f'<label for="{id_}_txt">Recherche</label><input type="text" id="{id_}_txt" placeholder="nom, activité, SIRET">'
                   f'<div class="compte" id="{id_}_n"></div><button id="{id_}_csv">Télécharger la sélection (CSV)</button>'
                   f'<div class="leg" id="{id_}_l" style="margin-top:12px"></div>'
                   '<div class="mention">Employeurs : répertoire SIRENE (Insee), usage interne. Entreprises susceptibles '
                   'd\'embaucher : France Travail, La Bonne Boite (prévision, pas des offres d\'emploi).</div>')
        appel = f"quandVisible('{id_}_m',()=>carteEntreprises('{id_}',{d}));"
    else:
        panneau = (f'<label for="{id_}_sens">Flux</label><select id="{id_}_sens"><option value="t">dans les deux sens</option>'
                   '<option value="s">habitants qui vont travailler ailleurs</option>'
                   '<option value="e">actifs qui viennent y travailler</option></select>'
                   f'<label for="{id_}_nb">Communes affichées</label><select id="{id_}_nb"><option>15</option>'
                   '<option selected>30</option><option>60</option></select>'
                   f'<div class="leg" id="{id_}_l" style="margin-top:12px"></div>'
                   '<div class="mention">Insee, recensement : flux domicile-lieu de travail. Les flux de moins de 200 '
                   'actifs sont des ordres de grandeur.</div>')
        appel = f"quandVisible('{id_}_m',()=>carteFlux('{id_}',{d}));"
    tete = ('<div class="tete"><span>Filtres et légende</span><button type="button" '
            'onclick="const p=this.closest(\'.panneau\');p.classList.toggle(\'replie\');'
            'this.textContent=p.classList.contains(\'replie\')?\'Afficher\':\'Masquer\'">Masquer</button></div>')
    return (f'<div class="carto{" plein" if plein else ""}"><div class="panneau">{tete}{panneau}</div>'
            f'<div class="zone" id="{id_}_m"></div></div><script>{appel}</script>')


def page(type_, donnees, titre, hauteur=None):
    """Page HTML autonome en pleine page (export d'une carte seule) ; hauteur fixe pour l'aperçu dans l'interface."""
    css, js = bibliotheques()
    h = f".carto{{height:{hauteur}px}}" if hauteur else "html,body{height:100%}.carto{height:100vh}"
    return (f'<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" '
            f'content="width=device-width,initial-scale=1"><title>{html.escape(titre)}</title>'
            f"<style>{css}{CSS_CARTES}{h}body{{margin:0}}</style><script>{js}</script><script>{JS_CARTES}</script>"
            f"</head><body>{fragment(type_, donnees, 'c0', plein=True)}</body></html>")

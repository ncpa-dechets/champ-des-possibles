"""Territoires : communes de l'EPCI, surfaces et contours.

Source : geo.api.gouv.fr (sans clé). Cache local à côté du .exe (30 jours),
repli sur le cache même périmé si le réseau est coupé.
Les contours ne servent qu'à la carte et à l'export GeoJSON : s'ils sont
indisponibles, les autres sorties fonctionnent quand même.
"""
import json
import os
import time

from . import reseau
from .chemins import dossier_application

GEO_API = "https://geo.api.gouv.fr"

CODE_EPCI = "200065563"
NOM_EPCI_DEFAUT = "NCPA"
CODE_DEP = "14"
NOM_DEP = "Calvados"
CODE_REG = "28"
NOM_REG = "Normandie"

DUREE_CACHE = 30 * 24 * 3600


def _cache(nom):
    return os.path.join(dossier_application(), f"cache_{nom}.json")


def _lire_cache(nom, accepter_perime=False):
    chemin = _cache(nom)
    if not os.path.exists(chemin):
        return None
    if not accepter_perime and time.time() - os.path.getmtime(chemin) > DUREE_CACHE:
        return None
    try:
        with open(chemin, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _ecrire_cache(nom, donnees):
    try:
        with open(_cache(nom), "w", encoding="utf-8") as f:
            json.dump(donnees, f, ensure_ascii=False)
    except OSError:
        pass  # dossier en lecture seule : on continue sans cache


def _avec_cache(nom, fonction, forcer=False):
    if not forcer:
        donnees = _lire_cache(nom)
        if donnees is not None:
            return donnees
    try:
        donnees = fonction()
        _ecrire_cache(nom, donnees)
        return donnees
    except reseau.ErreurSource:
        donnees = _lire_cache(nom, accepter_perime=True)
        if donnees is not None:
            return donnees
        raise


def communes_epci(forcer=False):
    """Liste [{code, nom, population, surface_ha}] triée par nom."""
    def charger():
        rep = reseau.get(f"{GEO_API}/communes",
                         params={"codeEpci": CODE_EPCI, "fields": "nom,code,population,surface"})
        return sorted(
            ({"code": c["code"], "nom": c["nom"], "population": c.get("population") or 0,
              "surface_ha": c.get("surface")} for c in rep),
            key=lambda c: c["nom"],
        )
    return _avec_cache(f"communes_{CODE_EPCI}", charger, forcer)


def nom_epci():
    def charger():
        rep = reseau.get(f"{GEO_API}/epcis/{CODE_EPCI}", params={"fields": "nom"})
        return {"nom": rep.get("nom", NOM_EPCI_DEFAUT)}
    try:
        return _avec_cache(f"epci_{CODE_EPCI}", charger)["nom"]
    except reseau.ErreurSource:
        return NOM_EPCI_DEFAUT


def contours_communes(forcer=False, stop_event=None):
    """FeatureCollection GeoJSON (WGS84) des communes de l'EPCI, propriétés code et nom."""
    def charger():
        rep = reseau.get(f"{GEO_API}/communes",
                         params={"codeEpci": CODE_EPCI, "fields": "nom,code",
                                 "format": "geojson", "geometry": "contour"},
                         stop_event=stop_event)
        if not isinstance(rep, dict) or not rep.get("features"):
            raise reseau.ErreurSource("contours des communes : réponse vide de geo.api.gouv.fr")
        return rep
    return _avec_cache(f"contours_{CODE_EPCI}", charger, forcer)

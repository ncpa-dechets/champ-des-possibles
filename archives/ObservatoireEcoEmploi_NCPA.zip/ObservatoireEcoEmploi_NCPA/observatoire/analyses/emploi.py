# -*- coding: utf-8 -*-
"""Tous les calculs, en Python pur (pas de pandas, pour garder un .exe léger).
Entrée : le dictionnaire « brut » assemblé par l'application. Sortie : un dictionnaire de résultats."""
from statistics import median

CRITERES = {"emplois": "nombre d'emplois", "population": "population",
            "touristique": "EPCI littoraux de capacité touristique proche"}


# ---------------------------------------------------------------------------
# Petits outils
# ---------------------------------------------------------------------------
def somme(valeurs):
    v = [x for x in valeurs if x is not None]
    return sum(v) if v else None


def div(a, b):
    return a / b if a is not None and b not in (None, 0) else None


def evol(v1, v0):
    r = div(v1, v0)
    return r - 1 if r is not None else None


def tcam(v0, v1, n):
    if v0 is None or v1 is None or v0 <= 0 or n <= 0:
        return None
    return (v1 / v0) ** (1 / n) - 1


def mediane(valeurs):
    v = [x for x in valeurs if x is not None]
    return median(v) if v else None


def rang(valeur, valeurs):
    """1 = valeur la plus élevée."""
    if valeur is None:
        return None
    return 1 + sum(1 for x in valeurs if x is not None and x > valeur)


def total_par_annee(lignes, annees):
    return {a: somme(l["eff"].get(a) for l in lignes) for a in annees}, \
           {a: somme(l["etab"].get(a) for l in lignes) for a in annees}


def par_cle(lignes, cle, annee):
    out = {}
    for l in lignes:
        k = l.get(cle)
        v = l["eff"].get(annee)
        if k is None or v is None:
            continue
        out[k] = out.get(k, 0) + v
    return out


def premier(lignes, cle, defaut=None):
    return next((l[cle] for l in lignes if l.get(cle)), defaut)


# ---------------------------------------------------------------------------
def calculer(brut, p):
    """p : a1, a2, niveau, grp_dep, grp_reg, grp_taille, critere, tolerance, grp_france"""
    ref, a1, a2, niv = brut["siren"], p["a1"], p["a2"], p["niveau"]
    det, refs, ep = brut["detail"], brut["refs"], brut["epci"]
    annees = [a for a in brut["annees"] if a1 <= a <= a2]
    n_ans = a2 - a1
    journal = []

    # --- identité ---------------------------------------------------------
    e_ref = [l for l in ep if l.get("code_epci") == ref]
    nom = premier(e_ref, "epci", f"EPCI {ref}")
    deps, regs = {}, {}
    for l in e_ref:
        v = l["eff"].get(a2) or 0
        deps[l.get("code_dep")] = deps.get(l.get("code_dep"), 0) + v
        regs[l.get("code_reg")] = regs.get(l.get("code_reg"), 0) + v
    dep = max(deps, key=deps.get) if deps else None
    reg = max(regs, key=regs.get) if regs else None
    dep_nom = premier([l for l in refs if l.get("code_dep") == dep], "dep", dep)
    reg_nom = premier([l for l in refs if l.get("code_reg") == reg], "reg", reg)
    r_dep = [l for l in refs if l.get("code_dep") == dep]
    r_reg = [l for l in refs if l.get("code_reg") == reg]

    # --- évolution par territoire -----------------------------------------
    territoires = {nom: det, f"Département ({dep_nom})": r_dep, f"Région ({reg_nom})": r_reg, "France": refs}
    serie, evol_terr = [], {}
    for t, lignes in territoires.items():
        eff, etab = total_par_annee(lignes, annees)
        for a in annees:
            serie.append({"territoire": t, "annee": a, "eff": eff[a], "etab": etab[a],
                          "taille_moy": div(eff[a], etab[a]), "base100": (div(eff[a], eff[a1]) or 0) * 100
                          if eff.get(a1) else None})
        evol_terr[t] = {"eff": eff.get(a2), "var": (eff[a2] - eff[a1]) if None not in (eff.get(a1), eff.get(a2)) else None,
                        "evol": evol(eff.get(a2), eff.get(a1)), "tcam": tcam(eff.get(a1), eff.get(a2), n_ans)}

    # --- structure sectorielle ---------------------------------------------
    s = {"ref": par_cle(det, niv, a2), "ref_deb": par_cle(det, niv, a1), "dep": par_cle(r_dep, niv, a2),
         "reg": par_cle(r_reg, niv, a2), "fr": par_cle(refs, niv, a2), "fr_deb": par_cle(refs, niv, a1)}
    tot = {k: sum(v.values()) for k, v in s.items()}
    G = evol(tot["fr"], tot["fr_deb"]) or 0
    secteurs = sorted(set(s["ref"]) | set(s["ref_deb"]) | set(s["fr"]))
    structure = []
    for sec in secteurs:
        e = {k: s[k].get(sec, 0) for k in s}
        d = {"secteur": sec, "eff_ref": e["ref"], "eff_ref_deb": e["ref_deb"], "eff_dep": e["dep"],
             "eff_reg": e["reg"], "eff_fr": e["fr"], "eff_fr_deb": e["fr_deb"],
             "part_ref": div(e["ref"], tot["ref"]), "part_dep": div(e["dep"], tot["dep"]),
             "part_reg": div(e["reg"], tot["reg"]), "part_fr": div(e["fr"], tot["fr"]),
             "var_ref": e["ref"] - e["ref_deb"], "var_ref_pct": evol(e["ref"], e["ref_deb"]),
             "var_fr_pct": evol(e["fr"], e["fr_deb"])}
        d["spec_fr"] = div(d["part_ref"], d["part_fr"])
        d["spec_reg"] = div(d["part_ref"], d["part_reg"])
        g = d["var_fr_pct"] if d["var_fr_pct"] is not None else G
        d["attendu"] = e["ref_deb"] * g
        d["effet_local"] = d["var_ref"] - d["attendu"]
        structure.append(d)
    structure.sort(key=lambda d: -d["eff_ref"])
    E0, E1 = tot["ref_deb"], tot["ref"]
    attendu = sum(d["attendu"] for d in structure)
    shift = {"E0": E0, "E1": E1, "variation": E1 - E0, "G": G, "effet_national": E0 * G,
             "effet_structurel": attendu - E0 * G, "effet_local": (E1 - E0) - attendu}

    # --- communes -----------------------------------------------------------
    noms_com = {l["code_commune"]: l.get("commune") or l["code_commune"] for l in det}
    communes = []
    tot_ref_a2 = tot["ref"] or None
    for code, nm in noms_com.items():
        lignes = [l for l in det if l["code_commune"] == code]
        eff, etab = total_par_annee(lignes, [a1, a2])
        ps = par_cle(lignes, niv, a2)
        sp = max(ps, key=ps.get) if ps else None
        communes.append({"code_commune": code, "commune": nm, "eff": eff[a2], "etab": etab[a2],
                         "eff_deb": eff[a1],
                         "var": (eff[a2] - eff[a1]) if None not in (eff[a1], eff[a2]) else None,
                         "evol": evol(eff[a2], eff[a1]), "taille_moy": div(eff[a2], etab[a2]),
                         "part_epci": div(eff[a2], tot_ref_a2), "secteur_principal": sp,
                         "part_secteur_principal": div(ps.get(sp), eff[a2]) if sp else None})
    communes.sort(key=lambda d: -(d["eff"] or 0))
    communes_secteurs = {c["commune"]: par_cle([l for l in det if l["code_commune"] == c["code_commune"]], niv, a2)
                         for c in communes}

    # --- activités détaillées ------------------------------------------------
    activites = []
    if any("APE" in l for l in det):
        e2, e1 = par_cle(det, "APE", a2), par_cle(det, "APE", a1)
        n2 = {}
        for l in det:
            if l.get("APE") and l["etab"].get(a2) is not None:
                n2[l["APE"]] = n2.get(l["APE"], 0) + l["etab"][a2]
        for ape in set(e2) | set(e1):
            activites.append({"APE": ape, "eff": e2.get(ape, 0), "etab": n2.get(ape), "eff_deb": e1.get(ape, 0),
                              "var": e2.get(ape, 0) - e1.get(ape, 0), "evol": evol(e2.get(ape), e1.get(ape)),
                              "part": div(e2.get(ape, 0), tot_ref_a2)})
        activites.sort(key=lambda d: -d["eff"])

    # --- indicateurs par EPCI (France entière) ------------------------------
    meta = {}
    for l in ep:
        c = l.get("code_epci")
        if not c:
            continue
        m = meta.setdefault(c, {"nom": l.get("epci") or c, "deps": set(), "regs": set(), "eff": {}, "etab": {}})
        if l.get("code_dep"):
            m["deps"].add(l["code_dep"])
        if l.get("code_reg"):
            m["regs"].add(l["code_reg"])
        for a in brut["annees"]:
            for k in ("eff", "etab"):
                v = l[k].get(a)
                if v is not None:
                    m[k][a] = m[k].get(a, 0) + v
    if ref not in meta:
        raise RuntimeError(f"l'EPCI {ref} est absent des totaux Urssaf par EPCI")

    # masse salariale : dernière année disponible <= a2, et première >= a1
    ms = {}
    for l in brut.get("masse", []):
        ms.setdefault(l["code_epci"], {})[l["annee"]] = l
    annees_ms = sorted({a for d in ms.values() for a in d})
    a2_ms = max([a for a in annees_ms if a <= a2], default=None)
    a1_ms = min([a for a in annees_ms if a >= a1], default=None)

    def salaire(code, a):
        x = ms.get(code, {}).get(a)
        return div(x["masse"], x["eff_moy"]) if x else None

    pop, tour, litt, com_epci = brut.get("pop") or {}, brut.get("tourisme") or {}, brut.get("littoral") or set(), \
        brut.get("communes_epci") or {}
    epci_littoraux = {com_epci[c] for c in litt if c in com_epci}
    # v0.5 : capacité d'accueil = lits marchands + 5 lits par résidence secondaire (convention Insee-DGE), si les
    # résidences secondaires sont connues pour tous les EPCI ; sinon lits marchands seuls (critère homogène).
    rs_tous = brut.get("rs") or {}
    avec_rs = len(rs_tous) >= 500
    if not avec_rs:
        journal.append("Résidences secondaires indisponibles pour l'ensemble des EPCI : critère touristique calculé "
                       "sur les seuls lits marchands (hôtels, campings, autres hébergements collectifs).")

    ind = {}
    for c, m in meta.items():
        eff2, eff1 = m["eff"].get(a2), m["eff"].get(a1)
        p_ = (pop.get(c) or (None, None))[0]
        lits_m = (tour.get(c) or {}).get("lits")
        rs_c = (rs_tous.get(c) or [None])[0]
        lits = (lits_m + 5 * rs_c if lits_m is not None and rs_c is not None else None) if avec_rs else lits_m
        ind[c] = {"code_epci": c, "nom": m["nom"], "eff": eff2, "eff_deb": eff1, "etab": m["etab"].get(a2),
                  "var": (eff2 - eff1) if None not in (eff1, eff2) else None, "evol": evol(eff2, eff1),
                  "tcam": tcam(eff1, eff2, n_ans), "taille_moy": div(eff2, m["etab"].get(a2)),
                  "pop": p_, "emplois_100hab": (div(eff2, p_) or 0) * 100 if div(eff2, p_) is not None else None,
                  "salaire": salaire(c, a2_ms) if a2_ms else None,
                  "evol_salaire": evol(salaire(c, a2_ms), salaire(c, a1_ms)) if a1_ms and a2_ms else None,
                  "lits": lits, "lits_100hab": (div(lits, p_) or 0) * 100 if div(lits, p_) is not None else None,
                  "lits_marchands": lits_m, "rs": rs_c,
                  "lits_m_100hab": (div(lits_m, p_) or 0) * 100 if div(lits_m, p_) is not None else None,
                  "littoral": c in epci_littoraux}

    # --- groupes de comparaison ----------------------------------------------
    r0 = ind[ref]
    tol = p.get("tolerance", 30) / 100
    groupes = {}
    if p.get("grp_dep") and dep:
        groupes[f"Département ({dep_nom})"] = {c for c, m in meta.items() if dep in m["deps"]}
    if p.get("grp_reg") and reg:
        groupes[f"Région ({reg_nom})"] = {c for c, m in meta.items() if reg in m["regs"]}
    if p.get("grp_taille"):
        crit = p.get("critere", "emplois")
        pct = int(round(tol * 100))

        def proche(cle):
            v0 = r0.get(cle)
            if v0 is None:
                return None
            return {c for c, d in ind.items() if d.get(cle) is not None and v0 * (1 - tol) <= d[cle] <= v0 * (1 + tol)}

        if crit == "emplois":
            sel, lib = proche("eff"), f"Taille similaire (emplois à ±{pct} %)"
        elif crit == "population":
            sel, lib = proche("pop"), f"Taille similaire (population à ±{pct} %)"
        else:
            lib = f"Littoraux et touristiques (lits{' et résidences secondaires' if avec_rs else ' marchands'} " \
                  f"pour 100 hab. à ±{pct} %)"
            sel = proche("lits_100hab")
            if sel is None:
                journal.append("Capacité touristique indisponible : groupe limité aux EPCI littoraux.")
                lib, sel = "EPCI littoraux", set(ind)
            if epci_littoraux:
                sel = sel & epci_littoraux
            else:
                journal.append("Liste des communes littorales indisponible : critère littoral non appliqué.")
        if sel is None:
            journal.append(f"Critère « {CRITERES.get(crit, crit)} » indisponible pour l'EPCI de référence.")
        else:
            groupes[lib] = sel
    if p.get("grp_france"):
        groupes["France entière"] = set(ind)
    for g in groupes.values():
        g.add(ref)

    IND = ["evol", "tcam", "taille_moy", "emplois_100hab", "salaire", "evol_salaire", "lits_100hab"]
    comparaisons, stats, medianes, medianes_salaire = {}, [], [], []
    for gn, codes in groupes.items():
        t = [dict(ind[c]) for c in codes if c in ind]
        t.sort(key=lambda d: (d["evol"] is None, -(d["evol"] or 0)))
        for i, d in enumerate(t, 1):
            d["rang"], d["est_ref"] = i, d["code_epci"] == ref
        comparaisons[gn] = t
        autres = [d for d in t if not d["est_ref"]]
        for k in IND:
            vals = [d[k] for d in t]
            stats.append({"groupe": gn, "indicateur": k, "valeur_ref": r0.get(k),
                          "mediane": mediane(d[k] for d in autres), "rang_ref": rang(r0.get(k), vals),
                          "nb": sum(1 for v in vals if v is not None)})
        for a in annees:
            b = [div(meta[c]["eff"].get(a), meta[c]["eff"].get(a1)) for c in codes if c != ref and c in meta]
            m_ = mediane(b)
            medianes.append({"groupe": gn, "annee": a, "base100": m_ * 100 if m_ is not None else None})
        for a in annees_ms:
            medianes_salaire.append({"groupe": gn, "annee": a,
                                     "salaire": mediane(salaire(c, a) for c in codes if c != ref)})

    serie_salaire = [{"annee": a, "salaire": salaire(ref, a), "eff_moy": (ms.get(ref, {}).get(a) or {}).get("eff_moy"),
                      "masse": (ms.get(ref, {}).get(a) or {}).get("masse")} for a in annees_ms]
    # salaire moyen France (somme des masses / somme des effectifs moyens)
    for a in annees_ms:
        tm = somme(ms[c][a]["masse"] for c in ms if a in ms[c])
        te = somme(ms[c][a]["eff_moy"] for c in ms if a in ms[c])
        medianes_salaire.append({"groupe": "France (moyenne)", "annee": a, "salaire": div(tm, te)})

    res = {
        "ref": ref, "ref_nom": nom, "dep": dep, "dep_nom": dep_nom, "reg": reg, "reg_nom": reg_nom,
        "a_deb": a1, "a_fin": a2, "niveau": niv, "params": p, "annees": annees,
        "serie": serie, "evol_terr": evol_terr, "structure": structure, "shift": shift,
        "communes": communes, "communes_secteurs": communes_secteurs, "activites": activites,
        "ind_ref": r0, "groupes": {k: sorted(v) for k, v in groupes.items()},
        "comparaisons": comparaisons, "stats": stats, "medianes_groupes": medianes,
        "serie_salaire": serie_salaire, "medianes_salaire": medianes_salaire,
        "annee_salaire": a2_ms, "annee_salaire_deb": a1_ms,
        "tourisme_ref": tour.get(ref), "littoral_ref": ref in epci_littoraux, "lits_avec_rs": avec_rs,
        "nb_epci_littoraux": len(epci_littoraux),
        "pop_dispo": bool(pop), "geo": brut.get("geo"), "date": brut["date"], "journal": journal,
    }
    res["synthese"] = phrases_synthese(res)
    return res


# ---------------------------------------------------------------------------
# Synthèse rédigée (pour les élus et la DGS)
# ---------------------------------------------------------------------------
def _n(v):
    return "nd" if v is None else f"{v:,.0f}".replace(",", " ")


def _p(v, signe=True):
    if v is None:
        return "nd"
    return (f"{v * 100:+.1f} %" if signe else f"{v * 100:.1f} %").replace(".", ",")


def phrases_synthese(r):
    a1, a2, nom = r["a_deb"], r["a_fin"], r["ref_nom"]
    e, fr = r["evol_terr"][nom], r["evol_terr"].get("France", {})
    dep = r["evol_terr"].get(f"Département ({r['dep_nom']})", {})
    out = []
    if e.get("evol") is not None:
        comp = "plus vite que" if fr.get("evol") is not None and e["evol"] > fr["evol"] else "moins vite que"
        texte = (f"Entre {a1} et {a2}, l'emploi salarié privé est passé de {_n(e['eff'] - (e['var'] or 0))} à "
                 f"{_n(e['eff'])} postes ({_p(e['evol'])}), soit {comp} la France ({_p(fr.get('evol'))})")
        if dep.get("evol") is not None:
            texte += f" ; le département ({r['dep_nom']}) a évolué de {_p(dep['evol'])}"
        out.append(texte + ".")
    sh = r["shift"]
    if sh["effet_local"] is not None:
        sens = "fait mieux" if sh["effet_local"] >= 0 else "fait moins bien"
        out.append(f"Compte tenu de ses secteurs d'activité, le territoire {sens} que prévu : "
                   f"l'effet local représente {_n(sh['effet_local'])} emplois sur la période.")
    sp = sorted([s for s in r["structure"] if s["spec_fr"] and s["spec_fr"] >= 1.2 and s["eff_ref"] >= 50],
                key=lambda s: -s["spec_fr"])[:3]
    if sp:
        out.append("Secteurs nettement plus présents qu'en moyenne nationale : "
                   + ", ".join(f"{s['secteur']} ({s['spec_fr']:.1f} fois)".replace(".", ",") for s in sp) + ".")
    g = sorted(r["structure"], key=lambda s: -s["var_ref"])
    if g and g[0]["var_ref"] > 0:
        texte = f"Le secteur qui a le plus créé d'emplois est « {g[0]['secteur']} » (+{_n(g[0]['var_ref'])})"
        if g[-1]["var_ref"] < 0:
            texte += f" ; celui qui en a le plus perdu est « {g[-1]['secteur']} » ({_n(g[-1]['var_ref'])})"
        out.append(texte + ".")
    i = r["ind_ref"]
    if i.get("salaire") is not None:
        st = next((s for s in r["stats"] if s["indicateur"] == "salaire"), None)
        compar = f", contre {_n(st['mediane'])} € en médiane pour le groupe « {st['groupe']} »" \
            if st and st["mediane"] is not None else ""
        out.append(f"Le salaire brut annuel moyen par salarié atteint {_n(i['salaire'])} € en "
                   f"{r['annee_salaire']}{compar}.")
    if i.get("emplois_100hab") is not None:
        out.append(f"Le territoire compte {i['emplois_100hab']:.0f} emplois salariés privés pour 100 habitants.")
    out.append("Emploi salarié privé mesuré au 31 décembre : les emplois saisonniers de l'été n'y figurent pas "
               "(voir la saisonnalité, mesurée par France Travail).")
    return out


# ---------------------------------------------------------------------------
# Compléments v0.3 : Observatoire des territoires, enquête BMO, employeurs
# ---------------------------------------------------------------------------
def completer(res, brut, p):
    from ..collecte import anct, bmo, sirene
    groupes = {g: set(v) for g, v in res["groupes"].items()}
    res["anct"] = anct.comparer(brut.get("anct") or {}, groupes, res["ref"]) if brut.get("anct") else []
    res["bmo_bassins"] = bmo.bassins(brut.get("bmo") or {}, res["dep"]) if brut.get("bmo") else {}
    b = p.get("bassin")
    if b not in res["bmo_bassins"]:
        b = next(iter(res["bmo_bassins"]), None)
    res["bmo"] = bmo.analyser(brut["bmo"], b, res["dep"], res["reg"]) if b else None
    res["ft"] = brut.get("ft") or None
    res["ft_cles"] = tableau_ft(res["ft"]) if res["ft"] else []
    res["synthese"] = [x for x in res["synthese"] if not x.startswith(("France Travail compte", "Sur les 12 derniers"))]
    if res["ft"]:
        e = (res["ft"]["territoires"].get("EPCI") or {})
        d = (res["ft"]["territoires"].get("Département") or {})
        if e.get("de_abc"):
            res["synthese"].insert(-1, f"France Travail compte {_n(e['de_abc'])} demandeurs d'emploi en catégories A, B "
                                       f"et C ({e.get('periode_de')}), soit {_p((e.get('de_pour_100_actifs') or 0) / 100, False)}"
                                       f" de la population active (département : "
                                       f"{_p((d.get('de_pour_100_actifs') or 0) / 100, False)}).")
        if e.get("offres_pour_100_de"):
            res["synthese"].insert(-1, f"Sur les 12 derniers mois, {_n(e['offres_12m'])} offres d'emploi ont été "
                                       f"diffusées, soit {e['offres_pour_100_de']:.0f} offres pour 100 demandeurs "
                                       f"(département : {d.get('offres_pour_100_de') or 0:.0f}).")
    res["employeurs"] = brut.get("employeurs") or []
    res["employeurs_synthese"] = sirene.synthese(res["employeurs"]) if res["employeurs"] else None
    completer_v05(res, brut)
    return res


def completer_v05(res, brut):
    """Indicateurs v0.5. Chaque bloc est facultatif : une source absente laisse le bloc à None."""
    from datetime import datetime

    from . import complements as cp
    codes_ref = [f["properties"]["code"] for f in (brut.get("geo") or {}).get("features", [])] or \
        sorted({l["code_commune"] for l in brut["detail"] if l.get("code_commune")})
    nouvelles = []
    res["saison"] = cp.saisonnalite(res.get("ft"), res.get("bmo"), res["ref_nom"]) if (res.get("ft") or
                                                                                       res.get("bmo")) else None
    if res["saison"]:
        nouvelles += cp.phrases_saison(res["saison"], res["ref_nom"])
    res["logement"] = cp.logement(brut.get("logements"))
    lg, t = res["logement"], res.get("tourisme_ref") or {}
    if lg and lg.get("rs") is not None:
        lits_m = t.get("lits")
        pop = (res.get("ind_ref") or {}).get("pop")
        txt = (f"Le territoire compte {_n(lg['rs'])} résidences secondaires en {lg['annee']}, soit "
               f"{_p(lg['part_rs'], False)} des logements")
        if lits_m is not None:
            tot = lits_m + lg["lits_rs"]
            txt += (f" ; avec les {_n(lits_m)} lits marchands, la capacité d'accueil touristique atteint {_n(tot)} lits"
                    + (f", soit {tot / pop * 100:.0f} pour 100 habitants" if pop else ""))
        nouvelles.append(txt + ".")
    try:
        res["hors_champ"] = cp.hors_champ(brut.get("flores"), brut, res.get("dep"))
    except Exception as e:  # le libellé des secteurs Urssaf peut changer : ne pas bloquer le reste
        res["hors_champ"] = None
        res["journal"].append(f"Comparaison Flores / Urssaf impossible ({e}).")
    nouvelles += cp.phrases_hors_champ(res["hors_champ"], res.get("dep_nom"))
    res["mobilites"] = cp.mobilites(brut.get("mobilites"), brut, codes_ref)
    nouvelles += cp.phrases_mobilites(res["mobilites"])
    res["demographie"] = cp.demographie(brut.get("creations"), brut.get("sirene_demo"), brut.get("bodacc"),
                                        brut.get("employeurs_tous"), brut.get("geo"), datetime.now().year)
    nouvelles += cp.phrases_demographie(res["demographie"], res.get("dep_nom"))
    res["synthese"] = res["synthese"][:-1] + nouvelles + res["synthese"][-1:]


LIGNES_FT = [("de_abc", "Demandeurs d'emploi catégories A, B, C (fin de trimestre)", "int", "periode_de"),
             ("de_a", "dont catégorie A (sans aucune activité)", "int", "periode_de"),
             ("de_pour_100_actifs", "Demandeurs A, B, C pour 100 actifs", "num1", "annee_pop_active"),
             ("entrants_12m", "Nouveaux inscrits sur 12 mois", "int", "periode_de"),
             ("offres_12m", "Offres d'emploi diffusées sur 12 mois (toutes origines)", "int", "periode_offres"),
             ("offres_ft_12m", "dont offres déposées à France Travail", "int", "periode_offres"),
             ("offres_pour_100_de", "Offres sur 12 mois pour 100 demandeurs A, B, C", "num1", "periode_offres"),
             ("embauches", "Embauches du trimestre (hors intérim)", "int", "periode_embauches"),
             ("dynamique", "Indicateur de dynamique de l'emploi (France Travail)", "num1", "periode_dynamique"),
             ("pop_active", "Population active", "int", "annee_pop_active"),
             ("salaries", "Salariés", "int", "annee_salaries")]


def tableau_ft(ft):
    terr = ft.get("territoires", {})
    out = []
    for cle, lib, fmt, per in LIGNES_FT:
        ligne = {"indicateur": lib, "format": fmt}
        for t, d in terr.items():
            ligne[t] = d.get(cle)
            ligne["periode"] = ligne.get("periode") or d.get(per)
        out.append(ligne)
    return out


def dep_reg(brut):
    """Département et région de rattachement de l'EPCI (là où il compte le plus d'emplois)."""
    a = brut["annees"][-1]
    deps, regs = {}, {}
    for l in brut["epci"]:
        if l.get("code_epci") == brut["siren"]:
            v = l["eff"].get(a) or 0
            deps[l.get("code_dep")] = deps.get(l.get("code_dep"), 0) + v
            regs[l.get("code_reg")] = regs.get(l.get("code_reg"), 0) + v
    return (max(deps, key=deps.get) if deps else None), (max(regs, key=regs.get) if regs else None)

@echo off
REM Fabrication du .exe (a lancer depuis ce dossier, Python installe)
pip install -r requirements.txt
for /f "delims=" %%i in ('python -c "import customtkinter, os; print(os.path.dirname(customtkinter.__file__))"') do set CTK=%%i
pyinstaller --onefile --windowed --name "OutilsUrbanisme_NCPA" --add-data "donnees;donnees" --add-data "%CTK%;customtkinter" --collect-all shapely app_urbanisme.py
echo.
echo Executable : dist\OutilsUrbanisme_NCPA.exe
pause

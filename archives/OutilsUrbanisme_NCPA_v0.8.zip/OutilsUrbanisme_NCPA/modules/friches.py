"""Friches : inventaire national Cartofriches (Cerema).

Source : jeu data.gouv « Sites référencés dans Cartofriches », fichier CSV
national (environ 25 Mo) au format du standard CNIG Friches
(github.com/cnigfr/schema-friches). Mis à jour plusieurs fois par an.
L'API Données foncières du Cerema, qui sert aussi ces données, est en
version beta et renvoie des erreurs 503 depuis octobre 2026 : elle n'est
pas utilisée.

Mêmes replis que pour la consommation d'espaces : adresse trouvée via l'API
de data.gouv, sinon fichier en cache, sinon fichier CSV local choisi par
l'utilisateur. Cache de 30 jours.

Rappel affiché partout : l'inventaire n'est pas exhaustif. Il dépend des
observatoires locaux transmis au Cerema ; une commune sans friche dans le
fichier n'est pas forcément une commune sans friche.
"""
import csv
import json
import os
import re
import sys
import time

from . import geometrie as G
from . import reseau
from .chemins import dossier_application

URL_JEU = "https://www.data.gouv.fr/api/1/datasets/sites-references-dans-cartofriches/"
DUREE_CACHE = 30 * 24 * 3600
DEPS_NORMANDIE = ("14", "27", "50", "61", "76")

STATUTS = [("friche sans projet", "Sans projet", "#B91E27"),
           ("friche avec projet", "Avec projet", "#D6977A"),
           ("friche potentielle", "Potentielle", "#4F6D7A"),
           ("friche reconvertie", "Reconvertie", "#5E7A2E"),
           ("autre", "Autre ou inconnu", "#9A9A90")]
LIB_STATUT = {s: l for s, l, _c in STATUTS}

# Colonnes du standard CNIG (les plus utiles) -> libellé lisible
COLONNES = [
    ("site_id", "Identifiant"), ("site_nom", "Nom du site"), ("site_type", "Type de friche"),
    ("site_statut", "Statut"), ("site_occupation", "Occupation"), ("site_adresse", "Adresse"),
    ("comm_insee", "Code commune"), ("comm_nom", "Commune"),
    ("unite_fonciere_surface", "Surface de l'unité foncière (m²)"), ("bati_surface", "Surface bâtie (m²)"),
    ("bati_nombre", "Nombre de bâtiments"), ("bati_etat", "État du bâti"), ("bati_vacance", "Vacance du bâti"),
    ("bati_patrimoine", "Patrimoine bâti"), ("bati_pollution", "Pollution du bâti"),
    ("sol_pollution_existe", "Pollution des sols"), ("activite_libelle", "Ancienne activité"),
    ("activite_fin_annee", "Fin d'activité"), ("proprio_type", "Type de propriétaire"),
    ("proprio_personne", "Personne morale ou physique"), ("urba_doc_type", "Document d'urbanisme"),
    ("urba_zone_type", "Type de zone"), ("urba_zone_lib", "Zone"), ("site_reconv_type", "Type de reconversion"),
    ("site_reconv_annee", "Année de reconversion"), ("unite_fonciere_refcad", "Parcelles"),
    ("site_identif_date", "Identifiée le"), ("site_actu_date", "Actualisée le"),
    ("source_nom", "Source"), ("source_producteur", "Producteur"), ("site_url", "Fiche du site"),
]


# ------------------------------------------------------------------ fichier
def dossier_cache():
    chemin = os.path.join(dossier_application(), "cache_friches")
    os.makedirs(chemin, exist_ok=True)
    return chemin


def source_en_cache():
    try:
        with open(os.path.join(dossier_cache(), "source.json"), encoding="utf-8") as f:
            meta = json.load(f)
        if os.path.exists(meta.get("fichier", "")):
            return meta
    except (OSError, ValueError):
        pass
    return None


def _ecrire_meta(meta):
    try:
        with open(os.path.join(dossier_cache(), "source.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=1)
    except OSError:
        pass


def trouver_ressource(stop_event=None):
    """Adresse du CSV principal du jeu Cartofriches sur data.gouv."""
    jeu = reseau.get(URL_JEU, stop_event=stop_event)
    csvs = [r for r in jeu.get("resources", [])
            if str(r.get("format", "")).lower() == "csv" and "dictionnaire" not in str(r.get("title", "")).lower()]
    if not csvs:
        raise reseau.ErreurSource("jeu Cartofriches trouvé sur data.gouv, mais sans fichier CSV")
    r = max(csvs, key=lambda x: x.get("filesize") or 0)
    return {"url": r.get("url"), "maj": str(r.get("last_modified", ""))[:10], "taille": r.get("filesize") or 0,
            "titre": jeu.get("title", "Sites référencés dans Cartofriches")}


def preparer_fichier(forcer=False, stop_event=None, journal=print):
    meta = source_en_cache()
    if meta and meta.get("origine") == "local" and not forcer:
        journal(f"   fichier local choisi par l'utilisateur : {meta['fichier']}")
        return meta
    if meta and not forcer and time.time() - os.path.getmtime(meta["fichier"]) < DUREE_CACHE:
        journal(f"   fichier en cache : version du {meta.get('maj', '?')} (téléchargé le {meta.get('date', '?')})")
        return meta
    try:
        cible = trouver_ressource(stop_event)
    except reseau.ErreurSource as exc:
        if meta:
            journal(f"   data.gouv indisponible ({exc}) : utilisation du fichier en cache")
            return meta
        raise reseau.ErreurSource(f"{exc}. Solution de repli : télécharger le CSV « Sites référencés dans "
                                  "Cartofriches » depuis data.gouv.fr avec votre navigateur, puis bouton "
                                  "« Utiliser un fichier CSV local ».")
    if meta and meta.get("maj") == cible["maj"] and meta.get("origine") != "local":
        journal(f"   le fichier en cache est déjà le plus récent (version du {cible['maj']})")
        os.utime(meta["fichier"])
        return meta
    chemin = os.path.join(dossier_cache(), "cartofriches.csv")
    journal(f"   téléchargement de l'inventaire national (version du {cible['maj']}"
            + (f", {cible['taille'] / 1048576:.0f} Mo" if cible["taille"] else "") + ")...")
    if not reseau.telecharger(cible["url"], chemin, stop_event):
        raise reseau.ErreurSource(f"fichier introuvable (HTTP 404) · adresse : {cible['url']}")
    meta = {"fichier": chemin, "maj": cible["maj"], "titre": cible["titre"], "url": cible["url"],
            "date": time.strftime("%d/%m/%Y"), "origine": "data.gouv"}
    _ecrire_meta(meta)
    return meta


def utiliser_fichier_local(chemin):
    meta = {"fichier": chemin, "maj": time.strftime("%Y-%m-%d", time.localtime(os.path.getmtime(chemin))),
            "titre": f"Fichier local : {os.path.basename(chemin)}", "url": chemin,
            "date": time.strftime("%d/%m/%Y"), "origine": "local"}
    _ecrire_meta(meta)
    return meta


# ------------------------------------------------------------------ lecture
def _ouvrir(chemin):
    with open(chemin, "rb") as f:
        debut = f.read(300000)
    for enc in ("utf-8-sig", "cp1252"):
        try:
            debut.decode(enc)
            return open(chemin, encoding=enc, newline="", errors="replace")
        except UnicodeDecodeError:
            continue
    return open(chemin, encoding="latin-1", newline="")


def _nombre(texte):
    t = str(texte or "").strip().replace(" ", "").replace(",", ".")
    try:
        return float(t) if t else None
    except ValueError:
        return None


def _statut(texte):
    t = str(texte or "").strip().lower()
    for s, _l, _c in STATUTS:
        if s in t:
            return s
    return "autre"


def analyser_entetes(entetes):
    bas = [h.strip().lstrip("\ufeff").strip('"').lower() for h in entetes]
    idx = {h: i for i, h in enumerate(bas)}

    def trouver(*noms, motif=None):
        for n in noms:
            if n in idx:
                return idx[n]
        if motif:
            for h, i in idx.items():
                if re.search(motif, h):
                    return i
        return None
    col = {
        "commune": trouver("comm_insee", "code_insee", "insee_com", "insee", motif=r"insee"),
        "point": trouver("geompoint", "geom_point", "geometrie_point"),
        "surface_geo": trouver("geomsurf", "geom_surf", "geom", "geometry", "the_geom", "wkt"),
        "lat": trouver("latitude", "lat", "y_wgs84"),
        "lon": trouver("longitude", "lon", "lng", "x_wgs84"),
    }
    if col["commune"] is None:
        raise reseau.ErreurSource("colonne du code commune (comm_insee) introuvable dans le fichier Cartofriches")
    return col, bas


def lire(chemin, codes, comparer=True, stop_event=None, journal=print):
    """Friches des communes demandées (+ cumuls Calvados et Normandie)."""
    csv.field_size_limit(min(sys.maxsize, 2 ** 31 - 1))      # géométries très longues
    voulus = set(codes)
    sites, comp = [], {"14": {"n": 0, "surface": 0.0, "sans_projet": 0},
                       "28": {"n": 0, "surface": 0.0, "sans_projet": 0}}
    corrections = {"inversée": 0, "lambert93": 0}
    with _ouvrir(chemin) as f:
        premiere = f.readline()
        sep = ";" if premiere.count(";") > premiere.count(",") else ","
        f.seek(0)
        lecteur = csv.reader(f, delimiter=sep)
        entetes = next(lecteur)
        col, bas = analyser_entetes(entetes)
        n = 0
        total = max(1, sum(1 for _ in open(chemin, "rb")))
        for ligne in lecteur:
            n += 1
            if n % 1000 == 0:
                reseau.verifier_annulation(stop_event)
                reseau.avancement(n / total)
            if len(ligne) < len(entetes) * 0.5:
                continue
            code = ligne[col["commune"]].strip()
            code = code.zfill(5) if code.isdigit() else code
            dep = code[:2]
            if comparer and dep in DEPS_NORMANDIE:
                attr = dict(zip(bas, ligne))
                surf = (_nombre(attr.get("unite_fonciere_surface")) or 0) / 10000
                sp = _statut(attr.get("site_statut")) == "friche sans projet"
                for cle in (["14", "28"] if dep == "14" else ["28"]):
                    comp[cle]["n"] += 1
                    comp[cle]["surface"] += surf
                    comp[cle]["sans_projet"] += sp
            if code not in voulus:
                continue
            attr = dict(zip(bas, ligne))
            geom, mention = None, ""
            for cle in ("surface_geo", "point"):
                if col[cle] is not None and ligne[col[cle]].strip():
                    geom, mention = G.normaliser(G.wkt_vers_geojson(ligne[col[cle]]))
                    if geom:
                        break
            if geom is None and col["lat"] is not None and col["lon"] is not None:
                la, lo = _nombre(ligne[col["lat"]]), _nombre(ligne[col["lon"]])
                if la and lo:
                    geom, mention = G.normaliser({"type": "Point", "coordinates": [lo, la]})
            if mention:
                corrections[mention] += 1
            surface = _nombre(attr.get("unite_fonciere_surface"))
            origine_surface = "déclarée"
            if not surface and geom and geom["type"] in ("Polygon", "MultiPolygon"):
                surface, origine_surface = G.surface_m2(geom), "calculée"
            sites.append({
                "commune": code, "statut": _statut(attr.get("site_statut")),
                "statut_brut": attr.get("site_statut", ""),
                "nom": attr.get("site_nom", "") or attr.get("site_id", ""),
                "type": attr.get("site_type", ""), "surface_m2": surface,
                "origine_surface": origine_surface if surface else "",
                "geom": geom, "centre": G.centre(geom), "attr": attr,
            })
    journal(f"   {n} sites lus dans l'inventaire national, {len(sites)} sur les communes demandées")
    if corrections["inversée"] or corrections["lambert93"]:
        journal(f"   coordonnées corrigées : {corrections['inversée']} inversée(s), "
                f"{corrections['lambert93']} en Lambert-93 converties")
    sans_geo = sum(1 for s in sites if not s["geom"])
    if sans_geo:
        journal(f"   {sans_geo} site(s) sans géométrie lisible : absents de la carte, présents dans l'Excel")
    return sites, comp, bas


def synthese(sites, comp, communes, codes, nom_epci, comparer=True):
    noms = {c["code"]: c["nom"] for c in communes}
    surf_com = {c["code"]: c.get("surface_ha") for c in communes}

    def bilan(liste):
        b = {"n": len(liste), "surface": sum((s["surface_m2"] or 0) for s in liste) / 10000}
        for st, _l, _c in STATUTS:
            sel = [s for s in liste if s["statut"] == st]
            b[f"n_{st}"] = len(sel)
            b[f"s_{st}"] = sum((s["surface_m2"] or 0) for s in sel) / 10000
        return b
    lignes = []
    for code in sorted(codes, key=lambda c: noms.get(c, c)):
        b = bilan([s for s in sites if s["commune"] == code])
        lignes.append({"niveau": "Commune", "code": code, "nom": noms.get(code, code), **b,
                       "surface_territoire": surf_com.get(code)})
    if len(codes) > 1:
        tous = len(codes) == len(communes)
        lignes.append({"niveau": "EPCI" if tous else "Sélection", "code": "TOTAL",
                       "nom": nom_epci if tous else f"Sélection ({len(codes)} communes)", **bilan(sites),
                       "surface_territoire": sum(surf_com.get(c) or 0 for c in codes)})
    if comparer:
        for cle, nom, niveau in (("14", "Calvados", "Département"), ("28", "Normandie", "Région")):
            v = comp[cle]
            lignes.append({"niveau": niveau, "code": cle, "nom": nom, "n": v["n"], "surface": v["surface"],
                           "n_friche sans projet": v["sans_projet"], "surface_territoire": None})
    return lignes


def extraire(communes, codes, nom_epci, comparer, forcer=False, stop_event=None, journal=print):
    with reseau.etape(0, 0.6, "Téléchargement de l'inventaire national"):
        meta = preparer_fichier(forcer, stop_event, journal)
    journal(f"Lecture de l'inventaire (version du {meta.get('maj', '?')})...")
    with reseau.etape(0.6, 0.98, "Lecture de l'inventaire"):
        sites, comp, colonnes = lire(meta["fichier"], codes, comparer, stop_event, journal)
    return {"sites": sites, "lignes": synthese(sites, comp, communes, codes, nom_epci, comparer),
            "meta": meta, "colonnes": colonnes, "comparer": comparer}


def diagnostic(stop_event=None, journal=print):
    journal("Recherche du jeu « Sites référencés dans Cartofriches » sur data.gouv.fr...")
    try:
        c = trouver_ressource(stop_event)
        journal(f"  OK      fichier CSV trouvé · version du {c['maj']}"
                + (f" · {c['taille'] / 1048576:.0f} Mo" if c["taille"] else "") + f"\n          {c['url']}")
    except reseau.ErreurSource as exc:
        journal(f"  ÉCHEC   {exc}")
    meta = source_en_cache()
    if not meta:
        journal("  Aucun fichier en cache : lancez une extraction pour le télécharger.")
        return
    with _ouvrir(meta["fichier"]) as f:
        premiere = f.readline()
    sep = ";" if premiere.count(";") > premiere.count(",") else ","
    entetes = next(csv.reader([premiere], delimiter=sep))
    try:
        col, bas = analyser_entetes(entetes)
    except reseau.ErreurSource as exc:
        journal(f"  ÉCHEC   {exc}")
        return
    journal(f"  Fichier en cache : {len(entetes)} colonnes, séparateur « {sep} »")
    journal("  Colonnes clés : " + ", ".join(f"{k}={bas[i] if i is not None else 'ABSENTE'}" for k, i in col.items()))
    absentes = [c for c, _l in COLONNES if c not in bas]
    if absentes:
        journal("  Colonnes du standard CNIG absentes du fichier : " + ", ".join(absentes))

# -*- coding: utf-8 -*-
"""Urssaf, établissements et effectifs salariés par commune x activité (APE), au 31/12 depuis 2006.

Avant la fusion, le jeu était téléchargé deux fois : en CSV pour la région (portrait économique) et en JSON pour
l'EPCI (outil Emploi). Il ne l'est plus qu'une fois, pour les départements de la région ; le détail de l'EPCI en
est extrait. S'y ajoutent trois agrégations calculées par le serveur (toute la France) : totaux par département et
secteur, totaux par EPCI, rattachement des communes aux EPCI.
"""
import pandas as pd

from .sources import convertir, decrire_schema, detecter_schema


def charger(src, cfg, siren, log):
    sc = detecter_schema(src.champs_communes())
    log(f"      structure reconnue, années {sc['annees'][0]} à {sc['annees'][-1]}")
    region = convertir(src.detail_departements(sc, cfg["deps_region"]), sc, groupe=False)
    detail = [l for l in region if l.get("code_epci") == siren]
    if not detail:
        raise RuntimeError(f"aucune donnée Urssaf pour l'EPCI {siren} dans les départements "
                           f"{', '.join(cfg['deps_region'])} (nomenclature des EPCI au 1/1/2023)")
    log(f"      région : {len(region)} lignes commune x activité ; EPCI : {len(detail)} lignes")
    refs = convertir(src.references(sc), sc, groupe=True)
    log("      totaux par département et secteur (France entière)")
    epci = convertir(src.totaux_epci(sc), sc, groupe=True)
    log(f"      totaux de {len({l.get('code_epci') for l in epci})} EPCI")
    try:
        communes_epci = src.communes_par_epci(sc)
    except Exception as e:  # sert au critère littoral et aux déplacements : facultatif
        communes_epci = {}
        log(f"      rattachement des communes aux EPCI indisponible ({str(e)[:120]})")
    return {"schema": decrire_schema(sc), "annees": sc["annees"], "detail": detail, "region": region,
            "refs": refs, "epci": epci, "communes_epci": communes_epci}


def vers_dataframe(region):
    """Lignes converties -> format long attendu par le portrait économique :
    commune, ape, ape_lib, secteur, na38, annee (texte), effectifs, etablissements."""
    lignes = []
    for l in region:
        ape_lib = l.get("APE") or ""
        ape = ape_lib.replace(".", "").split(" ", 1)[0][:5] if ape_lib else None
        base = {"commune": l.get("code_commune"), "ape": ape, "ape_lib": ape_lib,
                "secteur": l.get("Grand secteur") or "n.d.", "na38": l.get("NA38")}
        for a, v in l["eff"].items():
            if v is not None:
                lignes.append({**base, "annee": str(a), "effectifs": v, "etablissements": l["etab"].get(a)})
    df = pd.DataFrame(lignes)
    if df.empty:
        return None
    return df

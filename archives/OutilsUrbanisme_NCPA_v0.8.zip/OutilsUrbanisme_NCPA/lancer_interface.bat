@echo off
REM Lance l interface Streamlit (Python doit etre installe)
cd /d "%~dp0"
where python >nul 2>nul && (python lancer_interface.py) || (py lancer_interface.py)
pause

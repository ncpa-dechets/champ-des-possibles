"""Enchaînement complet du thème Zonage (zones, prescriptions, servitudes,
croisement), commun à l'application .exe et à l'interface Streamlit."""
from . import croisement, reseau, servitudes, zonage
from . import territoire as T


def extraire(communes, codes, nom_epci, avec_sup=True, avec_psc=True, points=None, origines=None,
             stop_event=None, journal=print):
    points, origines = points or [], origines or []
    noms = {c["code"]: c["nom"] for c in communes}
    journal("   contours des communes (geo.api.gouv.fr)...")
    with reseau.etape(0, 0.03, "Contours des communes"):
        contours = T.contours_communes(stop_event=stop_event)
    fin_zones = 0.5 if (avec_sup or avec_psc) else 0.95
    with reseau.etape(0.03, fin_zones, "Documents et zones"):
        resultat = zonage.extraire(communes, codes, nom_epci, contours, stop_event, journal)
    vide = {"type": "FeatureCollection", "features": []}
    resultat.update(contours=contours, servitudes=vide, bilan_sup={}, prescriptions=vide, bilan_psc={},
                    types_psc={}, points=[], croisement=None, origines=origines)
    if avec_psc:
        journal("   prescriptions des documents d'urbanisme...")
        par_partition = {}
        with reseau.etape(fin_zones, 0.65 if avec_sup else 0.95, "Prescriptions"):
            for d in resultat["documents"].values():
                part = (d.get("document") or {}).get("partition")
                if part and part not in par_partition and str(d["statut"]).upper() != "CC":
                    par_partition[part] = servitudes.prescriptions_partition(part, stop_event, journal)
        morceaux, bilan, types = servitudes.decouper_prescriptions(par_partition, contours, codes,
                                                                   resultat["documents"], noms)
        resultat.update(prescriptions={"type": "FeatureCollection", "features": morceaux},
                        bilan_psc=bilan, types_psc=types)
        journal(f"   {len(morceaux)} morceaux de prescriptions · types : " + ", ".join(sorted(types.values())))
    if avec_sup:
        with reseau.etape(0.65 if avec_psc else fin_zones, 0.95, "Servitudes d'utilité publique"):
            morceaux, bilan = servitudes.recuperer_servitudes(contours, codes, noms, stop_event, journal)
        resultat.update(servitudes={"type": "FeatureCollection", "features": morceaux}, bilan_sup=bilan)
    if points:
        reseau.avancement(0.97, "Croisement avec les permis et les friches")
        gardes = [p for p in points if not p.get("commune_code") or p["commune_code"] in codes]
        journal(f"   croisement de {len(gardes)} point(s) : " + ", ".join(origines))
        pts, syn = croisement.croiser(gardes, resultat["zones"]["features"],
                                      resultat["servitudes"]["features"], resultat["prescriptions"]["features"])
        resultat.update(points=pts, croisement=syn)
    return resultat
